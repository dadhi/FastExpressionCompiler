from pathlib import Path
import os,json,subprocess,hashlib
w=Path(__file__).parent;m=json.loads((w/'manifest.json').read_text());out=w/'replay-results';out.mkdir(exist_ok=False)
for p,digest in dict(m['sources'],**m['binaries']).items():assert hashlib.sha256((w/p).read_bytes()).hexdigest()==digest,p
names=json.loads((w/'results/shapes.json').read_text())
for rd in range(2):
 configs=[(t,f) for t in ['net8.0','net10.0'] for f in ['standard','light']]
 if rd:configs.reverse()
 for tfm,flavor in configs:
  labels=['master','after558','after559']
  if rd:labels.reverse()
  paths=[str(w/'stack-snapshots'/s/flavor/'bin/Release'/tfm/'Facade.dll') for s in labels]
  env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0',BENCH_ROUND=str(rd),BENCH_SAMPLES='7',BENCH_PIN='1')
  with (out/f'{tfm}-{flavor}-{rd}.jsonl').open('w') as log,(out/f'{tfm}-{flavor}-{rd}.log').open('w') as err:
   subprocess.run(['dotnet',str(w/'stack-host/bin/Release'/tfm/'Host.dll'),flavor,';'.join(labels),';'.join(paths),*names],stdout=log,stderr=err,env=env,check=True)
for rd in range(2):
 for tfm in (['net8.0','net10.0'] if rd==0 else ['net10.0','net8.0']):
  env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0',BENCH_ROUND=str(rd),BENCH_SAMPLES='7',BENCH_PIN='1')
  with (out/f'{tfm}-System-{rd}.jsonl').open('w') as log,(out/f'{tfm}-System-{rd}.log').open('w') as err:
   subprocess.run(['dotnet',str(w/'stack-host/bin/Release'/tfm/'Host.dll'),'standard','System',str(w/'stack-snapshots/after559/standard/bin/Release'/tfm/'Facade.dll'),*names],stdout=log,stderr=err,env=env,check=True)
