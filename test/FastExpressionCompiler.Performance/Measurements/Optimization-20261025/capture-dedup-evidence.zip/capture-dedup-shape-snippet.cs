   // Insert in Build's switch. This remains a Func<int, Func<int>> factory,
   // so the existing compile/first-invocation/warm-invocation drivers apply.
   case "capture_mutable_reference32":{
    var v=E.Variable(typeof(string),"text");
    var updates=Enumerable.Range(0,32).Select(i=>(X)E.Assign(v,
      E.Condition(E.Equal(v,E.Constant("first")),E.Constant("second"),E.Constant("first"))));
    X child=E.Lambda<Func<int>>(E.Block(updates.Concat(new X[]{E.Property(v,"Length")})));
    return E.Lambda<Func<int,Func<int>>>(E.Block(new[]{v},E.Assign(v,E.Constant("first")),child),x);
   }