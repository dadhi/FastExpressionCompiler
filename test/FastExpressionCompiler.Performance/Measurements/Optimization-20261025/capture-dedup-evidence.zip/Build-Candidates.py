from pathlib import Path
import shutil,subprocess,sys
w=Path(__file__).resolve().parent
facade=(w/'StackFacade.cs').read_text();snippet=(w/'capture-dedup-shape-snippet.cs').read_text()
needle='   case "constant": body=E.Constant(42);break;';assert facade.count(needle)==1
(w/'CandidateFacade.cs').write_text(facade.replace(needle,snippet+needle))
for stage in sys.argv[1:]:
 source=None if stage=='screen-base' else (w/(stage+'-candidate.cs')).read_bytes()
 for flavor in ['standard','light']:
  d=w/'stack-snapshots'/stage/flavor;d.mkdir(parents=True,exist_ok=True)
  for p in (w/'stack-snapshots/after559'/flavor).iterdir():
   if p.is_file() and p.suffix in ['.cs','.csproj']:shutil.copy2(p,d/p.name)
  p=d/'Facade.csproj';p.write_text(p.read_text().replace('../../../StackFacade.cs','../../../CandidateFacade.cs'))
  if source:(d/'FastExpressionCompiler.cs').write_bytes(source)
  with (w/f'build-{stage}-{flavor}.log').open('w') as log:
   subprocess.run(['dotnet','build','Facade.csproj','-c','Release','--disable-build-servers','-m:1','-v:q'],cwd=d,stdout=log,stderr=subprocess.STDOUT,check=True)
  print('BUILT',stage,flavor,flush=True)
