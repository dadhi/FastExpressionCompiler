from pathlib import Path
import subprocess,os,json,statistics,sys,hashlib
w=Path(__file__).resolve().parent
candidate=sys.argv[1];names=sys.argv[2:] or ['arithmetic64','balanced256','add','blocks32']
out=w/('screen-'+candidate);out.mkdir(exist_ok=True)
rows=[]; hashes={}
for rd in range(3):
 configs=[(t,f) for t in ['net8.0','net10.0'] for f in ['standard','light']]
 if rd%2:configs.reverse()
 for tfm,flavor in configs:
  labels=['after559',candidate]
  if rd%2:labels.reverse()
  paths=[str(w/'stack-snapshots'/(os.environ.get('BENCH_BASE','after559') if v=='after559' else v)/flavor/'bin/Release'/tfm/'Facade.dll') for v in labels]
  for v in labels:
   for p in (w/'stack-snapshots'/(os.environ.get('BENCH_BASE','after559') if v=='after559' else v)/flavor/'bin/Release'/tfm).glob('*.dll'):hashes[str(p.relative_to(w))]=hashlib.sha256(p.read_bytes()).hexdigest()
  env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0',BENCH_ROUND=str(rd),BENCH_SAMPLES='11',BENCH_PIN='1')
  stem=f'{tfm}-{flavor}-{rd}'
  with (out/(stem+'.jsonl')).open('w') as stdout,(out/(stem+'.log')).open('w') as stderr:
   subprocess.run(['dotnet',str(w/'candidate-host/bin/Release'/tfm/'Host.dll'),flavor,';'.join(labels),';'.join(paths),*names],env=env,stdout=stdout,stderr=stderr,check=True,timeout=1200)
  xs=[json.loads(x) for x in (out/(stem+'.jsonl')).read_text().splitlines()];rows+=xs
  print('MEASURED',stem,len(xs),flush=True)
summary=[]
for rt in sorted({x['runtime'] for x in rows}):
 for flavor in ['standard','light']:
  for name in names:
   for phase in ['compile','compile_first','invoke','construct']:
    item=dict(runtime=rt,flavor=flavor,shape=name,phase=phase)
    for v in ['after559',candidate]:
     xs=[x for x in rows if (x['runtime'],x['flavor'],x['shape'],x['phase'],x['version'])==(rt,flavor,name,phase,v)]
     item[v]=dict(ns=statistics.median(x['ns'] for x in xs),bytes=statistics.median(x['bytes'] for x in xs),rounds=[statistics.median(x['ns'] for x in xs if x['round']==rd) for rd in range(3)])
    item['ratio']=item[candidate]['ns']/item['after559']['ns'];item['roundRatios']=[a/b for a,b in zip(item[candidate]['rounds'],item['after559']['rounds'])];summary.append(item)
(out/'summary.json').write_text(json.dumps(summary,indent=2));(out/'binary-sha256.json').write_text(json.dumps(hashes,indent=2))
for x in summary:
 if x['phase']=='compile':print(x['runtime'],x['flavor'],x['shape'],round(x['ratio'],3),[round(z,3) for z in x['roundRatios']],flush=True)
