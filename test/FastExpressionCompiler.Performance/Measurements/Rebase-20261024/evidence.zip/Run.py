from pathlib import Path
import json,subprocess,os,hashlib,time
w=Path(__file__).resolve().parent;m=json.loads((w/'source-manifest.json').read_text());hashes=json.loads((w/'binary-manifest.json').read_text())
for name,sha in hashes.items():assert hashlib.sha256((w/name).read_bytes()).hexdigest()==sha
# Keep measurement serial and separate from all validation/build jobs.
v=w/('validation-'+m['versions']['after559'][:8]);codes=json.loads((v/'codes.json').read_text());assert len(codes)==8 and all(x==0 for x in codes.values())
output=w/'runs';assert not output.exists();output.mkdir()
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0',DOTNET_CLI_UI_LANGUAGE='en')
for runtime in ['net8.0','net10.0']:
 for flavor in ['standard','light']:
  for round,versions in enumerate([['before558','after558','after559'],['after559','after558','before558']]):
   for version in versions:
    tag=f'{runtime}-{flavor}-{round}-{version}';dll=w/'snapshots'/version/flavor/'bin/Release'/runtime/'Harness.dll'
    start=time.time()
    with (output/(tag+'.jsonl')).open('w',encoding='utf-8') as out,(output/(tag+'.log')).open('w',encoding='utf-8') as err:
     p=subprocess.run(['dotnet',str(dll),version,flavor,str(round),*m['selectedBenchmarkShapes']],stdout=out,stderr=err,env=env,timeout=300)
    assert p.returncode==0,(tag,p.returncode)
    log=(output/(tag+'.log')).read_text(encoding='utf-8');assert 'FAIL ' not in log,(tag,log)
    rows=[json.loads(x) for x in (output/(tag+'.jsonl')).read_text(encoding='utf-8').splitlines()]
    assert len(rows)==41*3*7,(tag,len(rows));assert all(x['Version']==version for x in rows)
    print(tag,f'{time.time()-start:.1f}s',flush=True)
