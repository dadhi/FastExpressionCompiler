from pathlib import Path
from collections import defaultdict
import json,statistics,csv,hashlib
w=Path(__file__).resolve().parent;manifest=json.loads((w/'source-manifest.json').read_text());groups=defaultdict(list);allrows=[]
for p in sorted((w/'runs').glob('*.jsonl')):
 for line in p.read_text(encoding='utf-8').splitlines():
  x=json.loads(line);assert x['Version'] in ['before558','after558','after559','system-reference'];assert x['NsPerOp']>0 and x['BytesPerOp']>=0
  groups[tuple(x[k] for k in ['Runtime','Flavor','Scenario','Phase','Version'])].append(x);allrows.append(x)
rows=[]
for key,xs in sorted(groups.items()):
 assert len(xs)==14 and {x['Round'] for x in xs}=={0,1},(key,len(xs))
 rows.append(dict(zip(['runtime','flavor','scenario','phase','version'],key),ns=statistics.median(x['NsPerOp'] for x in xs),bytes=statistics.median(x['BytesPerOp'] for x in xs),minNs=min(x['NsPerOp'] for x in xs),maxNs=max(x['NsPerOp'] for x in xs),samples=len(xs),operationsMin=min(x['Operations'] for x in xs),operationsMax=max(x['Operations'] for x in xs)))
assert len(allrows)==41*3*7*3*4*2+41*2*7*2*2,len(allrows)
index={tuple(x[k] for k in ['runtime','flavor','scenario','phase','version']):x for x in rows};comparisons=[]
for row in rows:
 if row['version']!='after559':continue
 key=tuple(row[k] for k in ['runtime','flavor','scenario','phase'])
 before=index[key+('before558',)];fix=index[key+('after558',)]
 comparisons.append(dict(runtime=key[0],flavor=key[1],scenario=key[2],phase=key[3],before558Ns=before['ns'],after558Ns=fix['ns'],after559Ns=row['ns'],before558Bytes=before['bytes'],after558Bytes=fix['bytes'],after559Bytes=row['bytes'],ratio558vsBefore=fix['ns']/before['ns'],ratio559vs558=row['ns']/fix['ns'],ratio559vsBefore=row['ns']/before['ns']))
summary=[]
for runtime in sorted({x['runtime'] for x in comparisons}):
 for flavor in ['standard','light']:
  for phase in ['construct','compile','invoke']:
   xs=[x for x in comparisons if x['runtime']==runtime and x['flavor']==flavor and x['phase']==phase];assert len(xs)==41
   entry=dict(runtime=runtime,flavor=flavor,phase=phase,shapes=41)
   for name in ['ratio558vsBefore','ratio559vs558','ratio559vsBefore']:entry[name]=statistics.median(x[name] for x in xs)
   for prefix,a,b in [('558','before558Bytes','after558Bytes'),('559','after558Bytes','after559Bytes')]:
    entry[prefix+'AllocationLower']=sum(x[b]<x[a] for x in xs);entry[prefix+'AllocationEqual']=sum(x[b]==x[a] for x in xs);entry[prefix+'AllocationHigher']=sum(x[b]>x[a] for x in xs)
   summary.append(entry)
sourceProof={}
for flavor in ['standard','light']:
 sourceProof[flavor]={}
 for p in (w/'snapshots/after558'/flavor).glob('*.cs'):
  sourceProof[flavor][p.name]=p.read_bytes()==(w/'snapshots/after559'/flavor/p.name).read_bytes()
(w/'analysis.json').write_text(json.dumps(dict(rows=rows,comparisons=comparisons,summary=summary,sourceEquality558vs559=sourceProof,sampleCount=len(allrows),systemReference='One unchanged compiler reference per runtime; not a before/after variant.'),indent=2),encoding='utf-8')
for name,data in [('three-stage',comparisons),('phase-medians',rows),('summary',summary)]:
 with (w/(name+'.csv')).open('w',encoding='utf-8',newline='') as f:writer=csv.DictWriter(f,fieldnames=list(data[0]));writer.writeheader();writer.writerows(data)
print(json.dumps(summary,indent=2));print('Samples',len(allrows));print('Source equality',sourceProof)
