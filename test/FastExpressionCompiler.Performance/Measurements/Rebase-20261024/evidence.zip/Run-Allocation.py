from pathlib import Path
import subprocess,json,os,statistics
w=Path(__file__).resolve().parent;m=json.loads((w/'source-manifest.json').read_text());out=w/'allocation-confirmation';assert not out.exists();out.mkdir();data=[]
for version in ['before558','after558','after559']:
 for flavor in ['standard','light']:
  with (out/f'build-{version}-{flavor}.log').open('w',encoding='utf-8') as log:subprocess.run(['dotnet','build','Allocation.csproj','-c','Release','--disable-build-servers','-m:1','-v:q'],cwd=w/'snapshots'/version/flavor,stdout=log,stderr=subprocess.STDOUT,check=True)
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
for tfm in ['net8.0','net10.0']:
 for flavor in ['standard','light']:
  for round,versions in enumerate([['before558','after558','after559'],['after559','after558','before558']]):
   for version in versions:
    tag=f'{tfm}-{flavor}-{round}-{version}';dll=w/'snapshots'/version/flavor/'bin/Release'/tfm/'Allocation.dll'
    p=subprocess.run(['dotnet',str(dll),version,flavor,str(round),*m['selectedBenchmarkShapes']],capture_output=True,text=True,env=env,timeout=180);assert p.returncode==0 and 'FAIL ' not in p.stderr
    (out/(tag+'.jsonl')).write_text(p.stdout,encoding='utf-8');(out/(tag+'.log')).write_text(p.stderr,encoding='utf-8');xs=list(map(json.loads,p.stdout.splitlines()));assert len(xs)==41*7 and all(x['Operations']==200 for x in xs);data+=xs
    print(tag,flush=True)
rows=[]
for runtime in sorted({x['Runtime'] for x in data}):
 for flavor in ['standard','light']:
  for shape in m['selectedBenchmarkShapes']:
   row=dict(runtime=runtime,flavor=flavor,shape=shape)
   for version in m['versions']:
    xs=[x['BytesPerOp'] for x in data if x['Runtime']==runtime and x['Flavor']==flavor and x['Scenario']==shape and x['Version']==version];assert len(xs)==14;row[version]=statistics.median(xs)
   rows.append(row)
(w/'allocation-confirmation.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
