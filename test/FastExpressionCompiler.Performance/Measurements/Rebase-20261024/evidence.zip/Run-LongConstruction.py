from pathlib import Path
import subprocess,json,os,hashlib
w=Path(__file__).resolve().parent;out=w/'construction-confirmation';assert not out.exists();out.mkdir()
for version in ['before558','after558','after559']:
 for flavor in ['standard','light']:
  with (out/f'build-{version}-{flavor}.log').open('w',encoding='utf-8') as log:subprocess.run(['dotnet','build','LongHarness.csproj','-c','Release','--disable-build-servers','-m:1','-v:q'],cwd=w/'snapshots'/version/flavor,stdout=log,stderr=subprocess.STDOUT,check=True)
names=['constant','array','new_member','capture_reference','capture_mutable_reference','capture_mutable_reference_ctor','capture_mutable_reference_array']
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
for tfm in ['net8.0','net10.0']:
 for flavor in ['standard','light']:
  for round,versions in enumerate([['after558','before558','after559'],['after559','before558','after558']]):
   for version in versions:
    tag=f'{tfm}-{flavor}-{round}-{version}';dll=w/'snapshots'/version/flavor/'bin/Release'/tfm/'LongHarness.dll'
    with (out/(tag+'.jsonl')).open('w',encoding='utf-8') as rows,(out/(tag+'.log')).open('w',encoding='utf-8') as log:p=subprocess.run(['dotnet',str(dll),version,flavor,str(round),*names],stdout=rows,stderr=log,env=env,timeout=180)
    assert p.returncode==0 and 'FAIL ' not in (out/(tag+'.log')).read_text(encoding='utf-8')
    print(tag,flush=True)
(out/'manifest.json').write_text(json.dumps(dict(harnessSha256=hashlib.sha256((w/'LongConstruction.cs').read_bytes()).hexdigest(),shapes=names,reason='The broad construction samples reach their operation cap on fast shapes. Confirm selected changed shapes and unchanged controls with a higher cap/30ms target; retain both datasets.'),indent=2),encoding='utf-8')
