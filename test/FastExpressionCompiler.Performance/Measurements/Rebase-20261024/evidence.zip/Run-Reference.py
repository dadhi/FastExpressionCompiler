from pathlib import Path
import json,subprocess,os,hashlib
w=Path(__file__).resolve().parent;m=json.loads((w/'source-manifest.json').read_text());d=w/'system-reference'
with (w/'system-reference-build.log').open('w',encoding='utf-8') as log:subprocess.run(['dotnet','build','Reference.csproj','-c','Release','--disable-build-servers','-m:1','-v:q'],cwd=d,stdout=log,stderr=subprocess.STDOUT,check=True)
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
for runtime in ['net8.0','net10.0']:
 for round in [0,1]:
  tag=f'{runtime}-system-reference-{round}';dll=d/'bin/Release'/runtime/'Reference.dll'
  with (w/'runs'/(tag+'.jsonl')).open('w',encoding='utf-8') as out,(w/'runs'/(tag+'.log')).open('w',encoding='utf-8') as err:
   p=subprocess.run(['dotnet',str(dll),'system-reference','system',str(round),*m['selectedBenchmarkShapes']],stdout=out,stderr=err,env=env,timeout=300)
  assert p.returncode==0
  assert 'FAIL ' not in (w/'runs'/(tag+'.log')).read_text(encoding='utf-8')
  rows=[json.loads(x) for x in (w/'runs'/(tag+'.jsonl')).read_text(encoding='utf-8').splitlines()];assert len(rows)==41*2*7
  print(tag,'complete',flush=True)
(w/'system-reference-manifest.json').write_text(json.dumps(dict(harnessSha256=hashlib.sha256((d/'Program.cs').read_bytes()).hexdigest(),runtimeVersions=[subprocess.check_output(['dotnet','--list-runtimes'],text=True)],binaries={str(x.relative_to(w)):hashlib.sha256(x.read_bytes()).hexdigest() for x in (d/'bin').rglob('*') if x.is_file()},meaning='Unchanged System compiler, separately measured reference; no before/after intervention applies.'),indent=2),encoding='utf-8')
