from pathlib import Path
import subprocess,json,os
w=Path(__file__).resolve().parent;m=json.loads((w/'source-manifest.json').read_text());records={}
for version in ['after558','after559']:
 for flavor in ['standard','light']:
  d=w/'snapshots'/version/flavor
  with (w/f'inspect-build-{version}-{flavor}.log').open('w',encoding='utf-8') as log:subprocess.run(['dotnet','build','Inspect.csproj','-c','Release','--disable-build-servers','-m:1','-v:q'],cwd=d,stdout=log,stderr=subprocess.STDOUT,check=True)
  p=subprocess.run(['dotnet',str(d/'bin/Release/net10.0/Inspect.dll'),version,flavor,'0',*m['selectedBenchmarkShapes']],capture_output=True,text=True,env=dict(os.environ,FEC_INSPECT='1'));assert p.returncode==0 and 'FAIL ' not in p.stderr
  (w/f'inspect-{version}-{flavor}.jsonl').write_text(p.stdout,encoding='utf-8');records[version,flavor]={x['scenario']:x['il'] for x in map(json.loads,p.stdout.splitlines())};assert len(records[version,flavor])==41
results=[]
for flavor in ['standard','light']:
 for shape in m['selectedBenchmarkShapes']:results.append(dict(flavor=flavor,shape=shape,equal=records['after558',flavor][shape]==records['after559',flavor][shape]))
(w/'il-comparison.json').write_text(json.dumps(results,indent=2),encoding='utf-8');print('Matching root delegate IL',sum(x['equal'] for x in results),'/',len(results))
