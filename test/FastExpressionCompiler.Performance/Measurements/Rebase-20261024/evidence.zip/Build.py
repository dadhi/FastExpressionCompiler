from pathlib import Path
import json,subprocess,hashlib
w=Path(__file__).resolve().parent;m=json.loads((w/'source-manifest.json').read_text());binaries={}
for version in m['versions']:
 for flavor in ['standard','light']:
  d=w/'snapshots'/version/flavor
  with (w/f'build-{version}-{flavor}.log').open('w',encoding='utf-8') as log:
   subprocess.run(['dotnet','build','Harness.csproj','-c','Release','--disable-build-servers','-m:1','-v:q'],cwd=d,stdout=log,stderr=subprocess.STDOUT,check=True)
  for p in (d/'bin/Release').rglob('*'):
   if p.is_file():binaries[str(p.relative_to(w))]=hashlib.sha256(p.read_bytes()).hexdigest()
  print('Built',version,flavor,flush=True)
(w/'binary-manifest.json').write_text(json.dumps(binaries,indent=2),encoding='utf-8')
