from pathlib import Path
import subprocess
w=Path(__file__).resolve().parent
for name in ['Measure-350-Exact.py','Measure-250.py','Measure-250-Flat.py','Measure-250-Pooled.py']:
 subprocess.run(['python',str(w/name)],cwd=w,check=True)
