from pathlib import Path
import subprocess,os,json,hashlib,statistics
w=Path(__file__).resolve().parent;out=w/'measure-250';snaps=w/'snapshots250'
m=json.loads((out/'manifest.json').read_text());labels0=['after559','after350','after250','after250-precreated']
for path,digest in {**m['sources'],**m['binaries']}.items():assert hashlib.sha256((w/path).read_bytes()).hexdigest()==digest,path
names=['flat_constants64','nested_constants8','nested_constants64','nested_siblings8','nested_reused8'];phases=['compile','compile_first','invoke','invoke_nested','construct']
(out/'shapes.json').write_bytes(json.dumps(names).encode());rows=[]
for rd in range(2):
 configs=[(t,f) for t in ['net8.0','net10.0'] for f in ['standard','light']]
 if rd:configs.reverse()
 for tfm,flavor in configs:
  labels=labels0[::-1] if rd else labels0
  paths=[str(snaps/v.split('-')[0]/flavor/'bin/Release'/tfm/'Facade.dll') for v in labels]
  env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0',BENCH_ROUND=str(rd),BENCH_SAMPLES='7',BENCH_PIN='1')
  stem=f'{tfm}-{flavor}-{rd}'
  with (out/(stem+'.jsonl')).open('w',encoding='utf-8') as stdout,(out/(stem+'.log')).open('w',encoding='utf-8') as stderr:
   subprocess.run(['dotnet',str(w/'host250/bin/Release'/tfm/'Host.dll'),flavor,';'.join(labels),';'.join(paths),*names],env=env,stdout=stdout,stderr=stderr,check=True,timeout=1800)
  xs=[json.loads(x) for x in (out/(stem+'.jsonl')).read_text().splitlines()];assert len(xs)==len(names)*len(phases)*7*len(labels0);rows+=xs
  print('MEASURED',stem,len(xs),flush=True)
summary=[]
for rt in sorted({x['runtime'] for x in rows}):
 for flavor in ['standard','light']:
  for name in names:
   for phase in phases:
    item=dict(runtime=rt,flavor=flavor,shape=name,phase=phase)
    for v in labels0:
     xs=[x for x in rows if (x['runtime'],x['flavor'],x['shape'],x['phase'],x['version'])==(rt,flavor,name,phase,v)];assert len(xs)==14
     item[v]=dict(ns=statistics.median(x['ns'] for x in xs),bytes=statistics.median(x['bytes'] for x in xs),rounds=[dict(ns=statistics.median(x['ns'] for x in xs if x['round']==rd),bytes=statistics.median(x['bytes'] for x in xs if x['round']==rd)) for rd in range(2)])
    
    for v in labels0[1:]:
     item[v+'/after559']=item[v]['ns']/item['after559']['ns'];item[v+'/allocationDelta']=item[v]['bytes']-item['after559']['bytes']
    item['manual/normal']=item['after250-precreated']['ns']/item['after250']['ns'];summary.append(item)
(out/'summary.json').write_bytes(json.dumps(summary,indent=2).encode());print('DONE',len(rows),'samples',flush=True)
