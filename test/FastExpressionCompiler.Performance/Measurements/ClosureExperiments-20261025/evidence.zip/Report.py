from pathlib import Path
import json,math,statistics,subprocess,csv,io,zipfile,hashlib
w=Path(__file__).resolve().parent;r=Path(r'C:\Data\Git\Github\FastExpressionCompiler');out=r/'test/FastExpressionCompiler.Performance/Measurements/ClosureExperiments-20261025';out.mkdir(exist_ok=True)
profiles=['measure-350-exact','measure-250','measure-250-flat','measure-250-pooled'];sets={p:json.loads((w/p/'summary.json').read_text()) for p in profiles}
def table(head,rows):return '| '+' | '.join(head)+' |\n| '+' | '.join('---' for _ in head)+' |\n'+''.join('| '+' | '.join(map(str,row))+' |\n' for row in rows)
def geo(xs):return math.exp(statistics.mean(math.log(x) for x in xs))
for profile,rows in sets.items():
 (out/(profile+'-summary.json')).write_bytes(json.dumps(rows,indent=2).encode())
 flat=[]
 for x in rows:
  q={k:v for k,v in x.items() if not isinstance(v,dict)}
  for key,value in x.items():
   if isinstance(value,dict):
    q[key+'_ns']=value['ns'];q[key+'_bytes']=value['bytes']
  flat.append(q)
 buf=io.StringIO();writer=csv.DictWriter(buf,fieldnames=list(flat[0]),lineterminator='\n');writer.writeheader();writer.writerows(flat);(out/(profile+'.csv')).write_bytes(buf.getvalue().encode())
s=sets['measure-350-exact'];stats=[]
for rt in ['8.0.28','10.0.9']:
 for flavor in ['standard','light']:
  group=[x for x in s if (x['runtime'],x['flavor'])==(rt,flavor)]
  stats.append([rt+' / '+flavor,*[f"{geo([x['ratio'] for x in group if x['phase']==phase]):.3f}x" for phase in ['compile','compile_first','invoke','invoke_nested','construct']]])
summary350=table(['Runtime / API','Compile','Compile + first','Root/factory execution','Cached inner execution','Construction control'],stats)
s=sets['measure-250'];stats=[]
for rt in ['8.0.28','10.0.9']:
 for flavor in ['standard','light']:
  for shape in ['nested_constants64','nested_siblings8','nested_reused8']:
   q={x['phase']:x for x in s if (x['runtime'],x['flavor'],x['shape'])==(rt,flavor,shape)}
   stats.append([rt+' / '+flavor,shape,*[f"{q[phase]['after559']['ns']/1000:.2f} / {q[phase]['after250-precreated']['ns']/1000:.2f}" for phase in ['compile','compile_first']],f"{q['compile']['after559']['bytes']:.0f} / {q['compile']['after250-precreated']['bytes']:.0f}",f"{q['invoke_nested']['manual/normal']:.3f}x"])
summary250=table(['Runtime / API','Shape','#559 normal / new manual compile, us','#559 normal / new manual + first, us','Compile B/op before / manual','Manual / current normal cached runtime'],stats)
f=sets['measure-250-flat'];stats=[]
for x in f:
 if x['phase']=='compile':stats.append([x['runtime']+' / '+x['flavor'],f"{x['after559-precreated']['ns']/1000:.2f}",f"{x['after250-precreated']['ns']/1000:.2f}",f"{x['after559-precreated']['bytes']:.0f} / {x['after250-precreated']['bytes']:.0f}"])
flat=table(['Runtime / API','Old manual compile, us','New manual compile, us','Compile B/op before / after'],stats)
pooled=sets['measure-250-pooled'];poolrows=[]
for x in pooled:
 if x['phase']=='compile':
  first=next(y for y in pooled if (y['runtime'],y['flavor'],y['shape'],y['phase'])==(x['runtime'],x['flavor'],x['shape'],'compile_first'))
  inner=next(y for y in pooled if (y['runtime'],y['flavor'],y['shape'],y['phase'])==(x['runtime'],x['flavor'],x['shape'],'invoke_nested'))
  poolrows.append([x['runtime']+' / '+x['flavor'],x['shape'],*[f"{x[v]['ns']/1000:.2f}" for v in ['after559','after250-precreated','after250pooled-precreated']],f"{first['after559']['ns']/1000:.2f} / {first['after250pooled-precreated']['ns']/1000:.2f}",*[f"{x[v]['bytes']:.0f}" for v in ['after559','after250-precreated','after250pooled-precreated']],f"{inner['after250pooled-precreated']['ns']/inner['after559']['ns']:.3f}x"])
pooltable=table(['Runtime / API','Shape','#559 normal compile us','Initial manual us','Pooled manual us','#559 normal / pooled + first us','Normal B/op','Initial manual B/op','Pooled manual B/op','Pooled / #559 cached runtime'],poolrows)
roles=table(['Stage','Commit'],[['#559 baseline','4a933287c45552ec208a24752c8b82fb75470f79'],['#350 prototype','db7168ff792698092a32eff6ee6f26b84def7cd9'],['#250 initial prototype','ddfc9e123938f85a376f303298bd2bb2f7e65059'],['Current pooled revision','5a0d565c3d0d865d1a05e47272c7ae41cb530f3a']])
text=f'''# Local closure experiments above #559

Branch: `perf/closure-experiments-250-350`. Local experiments only: no push and no pull request created. The parent #559 branch is unchanged. These are fresh paired measurements against the current local #559 production code, without previous-branch numbers or parent-history baselines. System is an untimed behavior oracle, not a before/after timing series.

{roles}
## Assessment

- #350 is the stronger candidate: a deterministic 24 B saving per created captured delegate and approximately 9% lower root/factory execution geometric means in this profile. Small compile-time and cached-call differences remain noisy; slower individual results are retained.
- #250 is functional but not a general performance improvement. The pooled flat and sibling cases allocate less, while the single nested 64-constant case allocates about 1,200 B more than ordinary #559 compilation. For eight siblings, compile plus first execution is about 19–62% slower than #559 across the four measured configurations. Compile-only timings are dominated by the different JIT boundary and must not be used alone.
- The shared manual target retains unrelated constants after one child escapes; the final pooled revision reproduces the same lifetime result. Keep this path experimental and explicitly selected. No production/default-path replacement or combined PR is recommended yet.

## Issue #350: combine captured storage and delegate target

The open delegate now resides in a typed target deriving from `ArrayClosureWithNonPassedParams`; its `Invoke` passes itself to the open method. This removes the separate Curry display class. Existing open signatures, capture cells and custom-delegate adaptation remain. Modern .NET uses the exact existing open-delegate type; Framework preserves its existing signature choices, including variance where needed. Public constant-array layout is unchanged.

The retained version saves **24 B for each created captured delegate** in every captured workload/configuration measured. Cached invocation allocates the same as before. Compilation allocations also decrease; complete values are in the data. Ratios below are geometric means across 14 equally weighted shapes (above 1 means slower), not application-throughput predictions or significance tests:

{summary350}
Root execution for factory shapes creates a returned delegate and invokes it once. Cached-inner execution obtains that delegate once outside timing and calls it repeatedly. Scalar controls use the same root driver in both execution phases.

Timing variation affects unchanged construction and execution controls. No universal compilation or cached-runtime speedup is established. All pooled medians and both round medians are retained, including slower results. The initial all-variance candidate was screened, then replaced by the exact-type version; its figures are not mixed into retained-version results. Custom delegates still use the pre-existing extra canonical-delegate adaptation, so that additional allocation remains an opportunity rather than a claimed fix.

## Issue #250: collection-free precreated constants with nested lambdas

The explicit `TryCompileWithPreCreatedClosure` path can now compile capture-free nested lambdas during emission. It splits the nested-delegate table from the supplied constants, binds every nested delegate to one target, reuses a lambda instance's compiled delegate, and omits constant-usage metadata. It retains direct indexed constant loads rather than counting uses or automatically hoisting constants. Ordinary `CompileFast` keeps its existing collector and closure layout.

Support probes verified all four nested workloads on both APIs and runtimes. The old manual path rejects all four; its existing flat case works before and after. This is **partial #250 support**: a nested lambda's own parameters (including a custom byref delegate) work, but captures of outer parameters or block variables return null and require ordinary `CompileFast`. The existing manual-path label/goto and unsupported-feature limitations remain. It does not claim to resolve all of #250.

The precreated constant inventory is supplied by the caller. The benchmark prepares that inventory outside compilation timing; each timed public API call still allocates/copies its value array. Construction measures the same tree builder as a control, not the cost of discovering the constant inventory. An implementation that first discovers constants with a full visitor must include that extra work in its application-level measurement.

The initial shared prototype used the existing manual path's unpooled IL generator. It consequently allocated more than ordinary FEC despite sharing constants. A follow-up reuses FEC's existing IL-generator pool, including failure cleanup. The pooled revision is the current prototype. One remaining limit is that parent and child compilation overlap: the existing one-slot generator pool cannot supply both active generators. The large nested-child case still allocates more than ordinary compilation; extending the pool is deferred pending its retention and default-path implications. These fresh three-role measurements isolate that change:

{pooltable}

The initial unpooled experiment is retained below to show what did not work:

The new manual path conservatively uses exception-aware anonymous DynamicMethods because collection is skipped. This can move JIT/access work into delegate creation. Compare **compile + first invocation**, not compile-only alone:

{summary250}
Every row also has #350 and current normal `CompileFast` measurements in the full JSON/CSV. New manual runtime can be slower because constants are loaded by stable array index with no usage analysis, and nested delegates are loaded through the shared table. Shared storage is an opt-in tradeoff, not a default replacement.

The flat manual API provides a like-for-like old/new manual comparison with the same hosting policy:

{flat}
## Lifetime tradeoff

Keeping one escaped nested delegate alive also retains **all supplied constants and the shared nested-delegate table**, including unrelated siblings. A controlled probe keeps only the first child, then runs three full GC/finalizer rounds. An unrelated 1 MiB byte-array constant is collected with #559, #350 and current normal `CompileFast`; it stays alive with the new shared precreated path on both runtimes and both APIs. The returned child still returns the same result. See `lifetime-probes.json` and the archived no-inline probe. Lower allocation does not establish lower retained memory. This ownership/lifetime choice needs review before treating this as a general replacement.

## Correctness and method

Release solution builds passed. Standard/Light native runners passed on .NET 8/10 and Framework 4.7.2; Framework uses en-US current/default-thread culture for pre-existing message assertions. Imported runtime tests: **35,088 passed, 59 existing skips, zero failures or crashes**. Known deep-tree exclusions remain. New tests cover every existing Func/Action arity 0–10, observable mutation, independent targets, custom delegates, nested target sharing, reused delegates, custom byref parameters, exception regions, unsupported outer captures and concurrent compilation. No correctness tests were skipped to accept the new layouts; two inspection helpers now recognize direct storage targets while preserving the value/cell assertions.

Windows ARM64; SDK 10.0.301; .NET 8.0.28 and 10.0.9; Release. Frozen assemblies from exact source snapshots. CPU 5 affinity, High priority; tiering and ReadyToRun disabled. One common facade per experiment, identical drivers between stages, 1,000 warmup operations, 30 ms calibration target, two opposite-order process rounds with seven samples each. Per-phase operation counts match between compared roles. Five boundaries: tree construction, prebuilt-tree compilation, compile + first invocation, root/factory execution, cached-inner execution. Raw samples and round medians are retained; shared-host drift remains material.

`evidence.zip` includes raw measurements, manifests, source/binary hashes, actual IL, shared harnesses, capability/lifetime probes, build logs, validation logs and a replay script. #350: 7,840 observations; #250 initial mixed roles: 5,600; flat old/new manual: 840; pooled follow-up: 2,520. Pooled and unpooled figures remain distinct. The report does not combine obsolete candidate numbers with retained versions.
'''
(out/'README.md').write_bytes(text.encode())
for name in ['support-probes.json','lifetime-probes.json']:(out/name).write_bytes((w/('measure-250-pooled' if name=='lifetime-probes.json' else 'measure-250')/name).read_bytes())
# Exact ordinary-path instruction comparison between the #350 and #250 sources.
checks=[]
for p in (w/'measure-250').glob('net*-*-0.log'):
 es={}
 for line in p.read_text(encoding='utf-8').splitlines():
  if line.startswith('IL '):
   x=json.loads(line[3:]);es[x['version'],x['shape']]=x['il']
 for (v,shape),value in es.items():
  if v=='after350':checks.append({'configuration':p.stem,'shape':shape,'ordinaryInstructionsEqual':value==es['after250',shape]})
assert len(checks)==20 and all(x['ordinaryInstructionsEqual'] for x in checks)
(out/'initial-ordinary-il-comparison.json').write_bytes(json.dumps(checks,indent=2).encode())
# Manifests and frozen files are independently checked before archiving.
files=set()
for profile in profiles:
 m=json.loads((w/profile/'manifest.json').read_text())
 for group in ['sources','binaries']:
  for name,digest in m[group].items():
   assert hashlib.sha256((w/name).read_bytes()).hexdigest()==digest,name
   files.add(name.replace('\\','/'))
 for p in (w/profile).iterdir():
  if p.is_file():files.add(p.relative_to(w).as_posix())
for base in ['stack-snapshots/after559','stack-snapshots/after350-exact','snapshots250','stack-host','host250']:
 for p in (w/base).rglob('*.csproj'):files.add(p.relative_to(w).as_posix())
for name in ['StackFacade.cs','Facade250.cs','Measure-350-Exact.py','Measure-250.py','Measure-250-Flat.py','Measure-250-Pooled.py','stack-snapshots/Directory.Build.props','snapshots250/Directory.Build.props']:
 files.add(name)
for p in w.glob('*'):
 if p.suffix=='.log' and ('validated' in p.name or '250' in p.name or 'exact-net10' in p.name or 'pooled' in p.name):files.add(p.relative_to(w).as_posix())
replay='''from pathlib import Path
import subprocess
w=Path(__file__).resolve().parent
for name in ['Measure-350-Exact.py','Measure-250.py','Measure-250-Flat.py','Measure-250-Pooled.py']:
 subprocess.run(['python',str(w/name)],cwd=w,check=True)
'''
(w/'Replay.py').write_bytes(replay.encode());files.add('Replay.py')
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in sorted(files):z.write(w/name,name)
artifacts={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file() and p.name!='sha256.json'}
(out/'sha256.json').write_bytes(json.dumps(artifacts,indent=2).encode())
print('Published local report with',sum(len(x) for x in sets.values()),'groups and',len(checks),'unchanged ordinary IL bundles')
