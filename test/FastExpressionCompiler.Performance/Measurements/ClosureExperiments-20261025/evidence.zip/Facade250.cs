using System;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Text.Json;
#if LIGHT
using FastExpressionCompiler.LightExpression;
using FastExpressionCompiler.LightExpression.ILDecoder;
using E = FastExpressionCompiler.LightExpression.Expression;
using X = FastExpressionCompiler.LightExpression.Expression;
using L = FastExpressionCompiler.LightExpression.LambdaExpression;
#else
using FastExpressionCompiler;
using FastExpressionCompiler.ILDecoder;
using E = System.Linq.Expressions.Expression;
using X = System.Linq.Expressions.Expression;
using L = System.Linq.Expressions.LambdaExpression;
#endif
public delegate int CustomUnary(int value);
public class EmptyItem { }
public class Box { public int Value; public Box(int x) { Value=x; } public int Add(int x)=>Value+x; public static int Read(Box b)=>b.Value; }
public struct Counter { public int Value; public Counter(int value){Value=value;} public int Increment()=>++Value; }
public struct LargeCounter { public int Value; public long A,B,C,D; public LargeCounter(int value){this=default;Value=value;} public int Increment()=>++Value; }
public class DelegateHolder { public readonly Func<int> Reader; public DelegateHolder(Func<int> reader){Reader=reader;} }
public class Holder { public Box Box; public Holder(Box box){Box=box;} }
public static class Program {
 public static int AddRef(ref int value)=>++value;
 static object sink; static long checksum; static int observed; public static void Record(int x)=>observed=x;
#if LIGHT
 static L systemSource;
 static System.Linq.Expressions.LambdaExpression systemPrepared;
#endif
 record Scenario(string Name, Func<L> Build);
 static X Balanced(X x,int depth) => depth==0?x:E.Add(Balanced(x,depth-1),Balanced(x,depth-1));
 static L Build(string name) {
  var x=E.Parameter(typeof(int),"x"); X body=x;
  switch(name) {
   case "ctor0": return E.Lambda<Func<EmptyItem>>(E.New(typeof(EmptyItem)));
   case "ctor1": return E.Lambda<Func<int,EmptyItem>>(E.New(typeof(EmptyItem)),x);
   case "ctor2": return E.Lambda<Func<int,string,EmptyItem>>(E.New(typeof(EmptyItem)),x,E.Parameter(typeof(string),"unused"));
   case "calls32":
    body=E.Block(Enumerable.Range(0,32).Select(i=>(X)E.Call(typeof(Math).GetMethod(nameof(Math.Max),new[]{typeof(int),typeof(int)}),x,E.Constant(i))));break;
   case "constructors32":
    body=E.Block(Enumerable.Range(0,32).Select(i=>(X)E.Field(E.New(typeof(Box).GetConstructor(new[]{typeof(int)}),x),"Value")));break;
   // Insert in Build's switch. This remains a Func<int, Func<int>> factory,
   // so the existing compile/first-invocation/warm-invocation drivers apply.
   case "capture_mutable_reference32":{
    var v=E.Variable(typeof(string),"text");
    var updates=Enumerable.Range(0,32).Select(i=>(X)E.Assign(v,
      E.Condition(E.Equal(v,E.Constant("first")),E.Constant("second"),E.Constant("first"))));
    X child=E.Lambda<Func<int>>(E.Block(updates.Concat(new X[]{E.Property(v,"Length")})));
    return E.Lambda<Func<int,Func<int>>>(E.Block(new[]{v},E.Assign(v,E.Constant("first")),child),x);
   }   case "capture_func1": {var y=E.Parameter(typeof(int));return E.Lambda<Func<int,Func<int,int>>>(E.Lambda<Func<int,int>>(E.AddAssign(x,y),y),x);}
   case "capture_custom1": {var y=E.Parameter(typeof(int));return E.Lambda<Func<int,CustomUnary>>(E.Lambda<CustomUnary>(E.AddAssign(x,y),y),x);}
   case "capture_action0": return E.Lambda<Func<int,Action>>(E.Lambda<Action>(E.Call(typeof(Program).GetMethod(nameof(Record)),E.AddAssign(x,E.Constant(1)))),x);
   case "flat_constants64":case "nested_constants8":case "nested_constants64":case "nested_siblings8":case "nested_reused8": {
    var count=name=="nested_constants64"||name=="flat_constants64"?64:8;
    var values=Enumerable.Range(0,count).Select(i=>E.Constant(new Box(i+1))).ToArray();
    Func<int,X> sum=offset=>{X total=E.Constant(offset);foreach(var c in values)total=E.Add(total,E.Field(c,"Value"));return total;};
    if(name=="flat_constants64")return E.Lambda<Func<int,int>>(sum(0),x);
    if(name=="nested_siblings8"||name=="nested_reused8"){
      var reused=E.Lambda<Func<int>>(sum(0));
      var children=Enumerable.Range(0,8).Select(i=>(X)(name=="nested_reused8"?reused:E.Lambda<Func<int>>(sum(i))));
      return E.Lambda<Func<int,Func<int>[]>>(E.NewArrayInit(typeof(Func<int>),children),x);
    }
    return E.Lambda<Func<int,Func<int>>>(E.Lambda<Func<int>>(sum(0)),x);
   }
   case "constant": body=E.Constant(42);break;
   case "add": body=E.Add(x,E.Constant(1));break;
   case "arithmetic64": for(int i=0;i<64;i++)body=E.Add(body,E.Constant(i));break;
   case "balanced256":body=Balanced(x,8);break;
   case "conditional":body=E.Condition(E.LessThan(x,E.Constant(0)),E.Negate(x),x);break;
   case "nullable":body=E.Coalesce(E.Convert(x,typeof(int?)),E.Constant(7));break;
   case "new_member":body=E.Field(E.New(typeof(Box).GetConstructor(new[]{typeof(int)}),x),"Value");break;
   case "constant_object":body=E.Call(E.Constant(new Box(7)),typeof(Box).GetMethod("Add"),x);break;
   case "array":body=E.ArrayIndex(E.Constant(new[]{2,3,5,7}),E.And(x,E.Constant(3)));break;
   case "new_array":body=E.ArrayLength(E.NewArrayInit(typeof(int),x,x,x));break;
   case "interned_string":body=E.Property(E.Constant("fixed literal"),"Length");break;
   case "noninterned_string":body=E.Property(E.Constant(new string('z',37)),"Length");break;
   case "try_catch":body=E.TryCatch(E.Divide(E.Constant(42),x),E.Catch(typeof(DivideByZeroException),E.Constant(-1)));break;
   case "try_finally":body=E.TryFinally(E.Add(x,E.Constant(1)),E.Empty());break;
   case "switch":body=E.Switch(x,E.Constant(8),E.SwitchCase(E.Constant(3),E.Constant(0)),E.SwitchCase(E.Constant(4),E.Constant(1)));break;
   case "goto":{var t=E.Label(typeof(int));body=E.Block(E.Return(t,x),E.Label(t,E.Constant(0)));break;}
   case "loop":{var v=E.Variable(typeof(int));var t=E.Label(typeof(int));body=E.Block(new[]{v},E.Assign(v,E.Constant(0)),E.Loop(E.IfThenElse(E.LessThan(v,E.Constant(8)),E.Block(E.PostIncrementAssign(v),E.Empty()),E.Break(t,v)),t));break;}
   case "blocks32":case "blocks128":{int n=name=="blocks32"?32:128;var arr=new List<X>();for(int i=0;i<n;i++){var v=E.Variable(typeof(int),"v"+i);arr.Add(E.Block(new[]{v},E.Assign(v,x),E.Add(v,E.Constant(i))));}body=E.Block(arr);break;}
   case "invoke_literal":{var p=E.Parameter(typeof(int));body=E.Invoke(E.Lambda<Func<int,int>>(E.Add(p,E.Constant(2)),p),x);break;}
   case "invoke_delegate":body=E.Invoke(E.Constant((Func<int,int>)(v=>v+2)),x);break;
   case "invoke_try_argument":{var p=E.Parameter(typeof(int));body=E.Invoke(E.Lambda<Func<int,int>>(E.Add(p,E.Constant(2)),p),E.TryFinally(x,E.Empty()));break;}
   case "capture_byref_call": return E.Lambda<Func<int,Func<int>>>(E.Lambda<Func<int>>(E.Call(typeof(Program).GetMethod("AddRef"),x)),x);
   case "capture_struct":case "capture_large_struct":{
    var type=name=="capture_struct"?typeof(Counter):typeof(LargeCounter);var v=E.Variable(type);
    return E.Lambda<Func<int,Func<int>>>(E.Block(new[]{v},E.Assign(v,E.New(type.GetConstructor(new[]{typeof(int)}),x)),E.Lambda<Func<int>>(E.Call(v,type.GetMethod("Increment")))),x);
   }
   case "capture_mutable_reference":case "capture_mutable_reference_ctor":case "capture_mutable_reference_array":{
    var v=E.Variable(typeof(string),"text");
    var toggle=E.Assign(v,E.Condition(E.Equal(v,E.Constant("first")),E.Constant("second"),E.Constant("first")));
    X child=E.Lambda<Func<int>>(E.Block(toggle,E.Property(v,"Length")));
    if(name=="capture_mutable_reference_ctor")child=E.Field(E.New(typeof(DelegateHolder).GetConstructors()[0],child),"Reader");
    if(name=="capture_mutable_reference_array")child=E.ArrayIndex(E.NewArrayInit(typeof(Func<int>),child),E.Constant(0));
    return E.Lambda<Func<int,Func<int>>>(E.Block(new[]{v},E.Assign(v,E.Constant("first")),child),x);
   }
   case "capture_mutable": return E.Lambda<Func<int,Func<int>>>(E.Lambda<Func<int>>(E.PreIncrementAssign(x)),x);
   case "capture1": return E.Lambda<Func<int,Func<int>>>(E.Lambda<Func<int>>(E.Add(x,E.Constant(1))),x);
   case "capture_call":case "capture_ctor":case "capture_invoke":case "capture_try":case "capture_array":{
   var v=E.Variable(typeof(Box),"box");X read=E.Field(v,"Value");
   if(name=="capture_call")read=E.Call(typeof(Box).GetMethod("Read"),v);
   if(name=="capture_ctor")read=E.Field(E.Field(E.New(typeof(Holder).GetConstructor(new[]{typeof(Box)}),v),"Box"),"Value");
   if(name=="capture_invoke")read=E.Invoke(E.Constant((Func<Box,int>)Box.Read),v);
   if(name=="capture_try")read=E.TryFinally(read,E.Empty());
   if(name=="capture_array")read=E.Field(E.ArrayIndex(E.NewArrayInit(typeof(Box),v),E.Constant(0)),"Value");
   return E.Lambda<Func<int,Func<int>>>(E.Block(new[]{v},E.Assign(v,E.Constant(new Box(7))),E.Lambda<Func<int>>(read)),x);
   }
   case "capture_reference":{var v=E.Variable(typeof(Box),"box");return E.Lambda<Func<int,Func<int>>>(E.Block(new[]{v},E.Assign(v,E.Constant(new Box(7))),E.Lambda<Func<int>>(E.Field(v,"Value"))),x);}
   case "nested_mixed32":case "nested_mixed128":{int n=int.Parse(name.Substring("nested_mixed".Length));for(int i=0;i<n;i++)body=E.Condition(E.GreaterThan(x,E.Constant(-9)),E.Block(body),E.Constant(0));break;}
   case "nested_eh8":case "nested_eh32":{int n=int.Parse(name.Substring("nested_eh".Length));for(int i=0;i<n;i++)body=E.TryFinally(body,E.Empty());break;}
   case "nested_blocks8":case "nested_blocks32":case "nested_blocks128":{int count=int.Parse(name.Substring("nested_blocks".Length));for(int i=0;i<count;i++)body=E.Block(body);break;}
   case "capture8":{var vs=Enumerable.Range(0,8).Select(i=>E.Variable(typeof(int),"v"+i)).ToArray();X sum=x;foreach(var v in vs)sum=E.Add(sum,v);return E.Lambda<Func<int,Func<int>>>(E.Block(vs,vs.Select(v=>(X)E.Assign(v,x)).Concat(new X[]{E.Lambda<Func<int>>(sum)})),x);}
   case "quote_closed":return E.Lambda<Func<int,System.Linq.Expressions.Expression<Func<int>>>>(E.Quote(E.Lambda<Func<int>>(E.Constant(9))),x);
   case "quote_capture":return E.Lambda<Func<int,System.Linq.Expressions.Expression<Func<int>>>>(E.Quote(E.Lambda<Func<int>>(x)),x);
   case "runtime_variables":
#if LIGHT
    var sp=System.Linq.Expressions.Expression.Parameter(typeof(int));
    return System.Linq.Expressions.Expression.Lambda<Func<int,IRuntimeVariables>>(System.Linq.Expressions.Expression.RuntimeVariables(sp),sp).ToLightExpression();
#else
    return E.Lambda<Func<int,IRuntimeVariables>>(E.RuntimeVariables(x),x);
#endif
   default:throw new Exception(name);
  }
  return E.Lambda<Func<int,int>>(body,x);
 }
 static Delegate Compile(L tree,bool system) {
  if(system) {
#if LIGHT
   if(!ReferenceEquals(systemSource,tree)){systemSource=tree;systemPrepared=(System.Linq.Expressions.LambdaExpression)tree.ToExpression();}
   return systemPrepared.Compile();
#else
   return tree.Compile();
#endif
  }
  return tree.CompileFast(true)??throw new NotSupportedException("strict FEC returned null");
 }
 static string Verify(Delegate d) {
  if(d is Func<EmptyItem> c0)return c0()!=null?"item":"null";
  if(d is Func<int,EmptyItem> c1)return c1(3)!=null?"item":"null";
  if(d is Func<int,string,EmptyItem> c2)return c2(3,"x")!=null?"item":"null";
  var parts=new List<string>();
  foreach(int v in new[]{-2,0,3}) {
   var result=d.DynamicInvoke(v);
   if(result is Func<int>[] children)result=string.Join(":",children.Select(f=>f()).Concat(children.Select(f=>f())));
   if(result is Func<int> nested) result=nested()+":"+nested();
   if(result is Func<int,int> unary)result=unary(2)+":"+unary(-1);
   if(result is CustomUnary custom)result=custom(2)+":"+custom(-1);
   if(result is Action action){action();var first=observed;action();result=first+":"+observed;}
   if(result is System.Linq.Expressions.Expression<Func<int>> quote) result=quote.Compile()();
   if(result is IRuntimeVariables vars) {var initial=vars[0];vars[0]=17;result=initial+":"+vars[0];}
   parts.Add(result?.ToString()??"null");
  }
  return string.Join("|",parts);
 }
 static Action<int> Driver(Delegate d) {
  if(d is Func<int,Func<int>[]> arrayFactory)return n=>{long sum=0;for(int i=0;i<n;i++){var children=arrayFactory(3);sink=children;foreach(var child in children)sum+=child();}checksum=sum;};
  if(d is Func<int,Func<int,int>> f1)return n=>{long s=0;for(int i=0;i<n;i++)s+=f1(3)(2);checksum=s;};
  if(d is Func<int,CustomUnary> fc)return n=>{long s=0;for(int i=0;i<n;i++)s+=fc(3)(2);checksum=s;};
  if(d is Func<int,Action> fa)return n=>{for(int i=0;i<n;i++)fa(3)();checksum=observed;};
  if(d is Func<EmptyItem> c0)return n=>{for(int i=0;i<n;i++)sink=c0();};
  if(d is Func<int,EmptyItem> c1)return n=>{for(int i=0;i<n;i++)sink=c1(3);};
  if(d is Func<int,string,EmptyItem> c2)return n=>{for(int i=0;i<n;i++)sink=c2(3,"x");};
  if(d is Func<int,int> f)return n=>{long s=0;for(int i=0;i<n;i++)s+=f(3);checksum=s;};
  if(d is Func<int,Func<int>> f2)return n=>{long s=0;for(int i=0;i<n;i++){var v=f2(3);sink=v;s+=v();}checksum=s;};
  if(d is Func<int,System.Linq.Expressions.Expression<Func<int>>> fq)return n=>{for(int i=0;i<n;i++)sink=fq(3);};
  if(d is Func<int,IRuntimeVariables> fr)return n=>{for(int i=0;i<n;i++)sink=fr(3);};
  throw new Exception("driver "+d.GetType());
 }
 public static object[] CreateSystemBench(string name) {
  var tree=Build(name);var d=Compile(tree,true);
  return new object[]{(Func<object>)(()=>Compile(tree,true)),Driver(d),(Func<object>)(()=>Build(name)),"",(Action<int>)(n=>{for(int i=0;i<n;i++)First(Compile(tree,true));}),NestedDriver(d)};
 }
 sealed class ClosureConstants : System.Linq.Expressions.ExpressionVisitor {
  public readonly List<object> Values=new();
  protected override System.Linq.Expressions.Expression VisitConstant(System.Linq.Expressions.ConstantExpression node){
   var value=node.Value;
   if(value!=null&&ExpressionCompiler.IsClosureBoundConstant(value,value.GetType())&&!Values.Any(x=>ReferenceEquals(x,value)))Values.Add(value);
   return node;
  }
 }
 [MethodImpl(MethodImplOptions.NoInlining)]
 public static object[] CreateLifetimeProbe(bool manual) {
  var small=E.Constant(new Box(42));var bytes=new byte[1024*1024];bytes[0]=7;var large=E.Constant(bytes);var weak=new WeakReference(bytes);
  var first=E.Lambda<Func<int>>(E.Field(small,"Value"));
  var second=E.Lambda<Func<int>>(E.Convert(E.ArrayIndex(large,E.Constant(0)),typeof(int)));
  var tree=E.Lambda<Func<Func<int>[]>>(E.NewArrayInit(typeof(Func<int>),first,second));
  var factory=manual?tree.TryCompileWithPreCreatedClosure<Func<Func<int>[]>>(new[]{small,large}):tree.CompileFast(true);
  if(factory==null)throw new NotSupportedException("lifetime probe rejected");
  return new object[]{factory()[0],weak};
 }
 public static object[] CreatePrecreatedBench(string name) {
  var tree=Build(name);var collector=new ClosureConstants();
#if LIGHT
  collector.Visit(tree.ToExpression());
#else
  collector.Visit(tree);
#endif
  var constants=collector.Values.Select(v=>E.Constant(v)).ToArray();
  Func<Delegate> compile=()=>tree.TryCompileWithPreCreatedClosure<Delegate>(constants)??throw new NotSupportedException("precreated path rejected tree");
  var d=compile();if(Verify(Compile(tree,true))!=Verify(d))throw new InvalidOperationException("precreated behavior mismatch");
  return new object[]{(Func<object>)(()=>compile()),Driver(d),(Func<object>)(()=>Build(name)),CaptureIL(d),(Action<int>)(n=>{for(int i=0;i<n;i++)First(compile());}),NestedDriver(d)};
 }
 public static object[] CreateBench(string name) {
  var tree=Build(name);var d=Compile(tree,false);var expected=Verify(Compile(tree,true));
  if(expected!=Verify(d))throw new InvalidOperationException("Behavior mismatch "+name);
  return new object[]{(Func<object>)(()=>Compile(tree,false)),Driver(d),(Func<object>)(()=>Build(name)),CaptureIL(d),(Action<int>)(n=>{for(int i=0;i<n;i++)First(Compile(tree,false));}),NestedDriver(d)};
 }
 static Action<int> NestedDriver(Delegate d) {
  if(d is Func<int,Func<int>[]> arrayFactory){var children=arrayFactory(3);return n=>{long sum=0;for(int i=0;i<n;i++)foreach(var child in children)sum+=child();checksum=sum;};}
  if(d is Func<int,Func<int,int>> f1){var inner=f1(3);return n=>{long s=0;for(int i=0;i<n;i++)s+=inner(2);checksum=s;};}
  if(d is Func<int,CustomUnary> fc){var inner=fc(3);return n=>{long s=0;for(int i=0;i<n;i++)s+=inner(2);checksum=s;};}
  if(d is Func<int,Action> fa){var inner=fa(3);return n=>{for(int i=0;i<n;i++)inner();checksum=observed;};}
  if(d is Func<int,Func<int>> factory) {var inner=factory(3);return n=>{long s=0;for(int i=0;i<n;i++)s+=inner();checksum=s;};}
  return Driver(d);
 }
 static void First(Delegate d) {
  if(d is Func<int,Func<int>[]> arrayFactory){var children=arrayFactory(3);sink=children;long sum=0;foreach(var child in children)sum+=child();checksum=sum;return;}
  if(d is Func<int,Func<int,int>> f1){checksum=f1(3)(2);return;}
  if(d is Func<int,CustomUnary> fc){checksum=fc(3)(2);return;}
  if(d is Func<int,Action> fa){fa(3)();checksum=observed;return;}
  if(d is Func<int,int> f){checksum=f(3);return;}
  if(d is Func<int,Func<int>> ff){var inner=ff(3);sink=inner;checksum=inner();return;}
  if(d is Func<EmptyItem> c0){sink=c0();return;}
  if(d is Func<int,EmptyItem> c1){sink=c1(3);return;}
  if(d is Func<int,string,EmptyItem> c2){sink=c2(3,"x");return;}
  throw new InvalidOperationException("Unexpected first-invocation delegate "+d.GetType());
 }
 public static string CaptureIL(Delegate d) {
  var il=d.Method.ToILString().ToString();
  if(d is Func<int,Func<int>> nested)il+="\nNESTED\n"+nested(3).Method.ToILString().ToString();
  if(d is Func<int,Func<int,int>> f1)il+="\nNESTED\n"+f1(3).Method.ToILString().ToString();
  if(d is Func<int,CustomUnary> fc)il+="\nNESTED\n"+fc(3).Method.ToILString().ToString();
  if(d is Func<int,Action> fa)il+="\nNESTED\n"+fa(3).Method.ToILString().ToString();
  if(d is Func<int,Func<int>[]> arrayFactory)foreach(var child in arrayFactory(3))il+="\nCHILD\n"+child.Method.ToILString().ToString();
  return il;
 }

}
