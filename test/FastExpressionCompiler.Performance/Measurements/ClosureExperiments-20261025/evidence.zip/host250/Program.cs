using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;
class SnapshotContext : AssemblyLoadContext {
 readonly AssemblyDependencyResolver resolver;
 public SnapshotContext(string path):base(isCollectible:false){resolver=new AssemblyDependencyResolver(path);}
 protected override Assembly Load(AssemblyName name){if(name.Name.StartsWith("System.")||name.Name=="System"||name.Name=="mscorlib"||name.Name=="netstandard")return null;var path=resolver.ResolveAssemblyToPath(name);return path==null?null:LoadFromAssemblyPath(path);}
}
class Host {
 static object sink;
 static double Millis(Action<int> action,int count){var start=Stopwatch.GetTimestamp();action(count);return (Stopwatch.GetTimestamp()-start)*1000.0/Stopwatch.Frequency;}
 static void Main(string[] args){
  if(Environment.GetEnvironmentVariable("BENCH_PIN")=="1") {
   var process=Process.GetCurrentProcess();var cpu=Environment.ProcessorCount-1;
   process.ProcessorAffinity=new IntPtr(1L<<cpu);process.PriorityClass=ProcessPriorityClass.High;
   Console.Error.WriteLine("HOST "+JsonSerializer.Serialize(new{cpu,priority=process.PriorityClass.ToString(),architecture=System.Runtime.InteropServices.RuntimeInformation.ProcessArchitecture.ToString()}));
  }
  string flavor=args[0];var versions=args[1].Split(';');var paths=args[2].Split(';');var names=args.Skip(3).ToArray();var factories=new MethodInfo[versions.Length];
  for(int i=0;i<versions.Length;i++){var path=Path.GetFullPath(paths[i]);var context=new SnapshotContext(path);var assembly=context.LoadFromAssemblyPath(path);factories[i]=assembly.GetType("Program").GetMethod(versions[i]=="System"?"CreateSystemBench":versions[i].EndsWith("-precreated")?"CreatePrecreatedBench":"CreateBench");}
  if(Environment.GetEnvironmentVariable("BENCH_LIFETIME_ONLY")=="1") {
   for(int i=0;i<versions.Length;i++){
    var result=(object[])factories[i].DeclaringType.GetMethod("CreateLifetimeProbe").Invoke(null,new object[]{versions[i].EndsWith("-precreated")});
    var escaped=(Func<int>)result[0];var weak=(WeakReference)result[1];result=null;
    for(int g=0;g<3;g++){GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();}
    Console.WriteLine(JsonSerializer.Serialize(new{version=versions[i],unusedMegabyteAlive=weak.IsAlive,result=escaped()}));GC.KeepAlive(escaped);
   }
   return;
  }
  if(Environment.GetEnvironmentVariable("BENCH_PROBE_ONLY")=="1") {
   foreach(var name in names)for(int i=0;i<versions.Length;i++) {
    try {factories[i].Invoke(null,new object[]{name});Console.WriteLine(JsonSerializer.Serialize(new{shape=name,version=versions[i],supported=true}));}
    catch(TargetInvocationException e){Console.WriteLine(JsonSerializer.Serialize(new{shape=name,version=versions[i],supported=false,error=e.InnerException.GetType().FullName,message=e.InnerException.Message}));}
   }
   return;
  }
  int round=int.Parse(Environment.GetEnvironmentVariable("BENCH_ROUND")??"0");
  foreach(var name in names){var cases=new object[versions.Length][];for(int i=0;i<versions.Length;i++)cases[i]=(object[])factories[i].Invoke(null,new object[]{name});
   for(int i=0;i<versions.Length;i++)if(cases[i].Length>3)Console.Error.WriteLine("IL "+JsonSerializer.Serialize(new{version=versions[i],shape=name,il=(string)cases[i][3]}));
   foreach(var phase in new[]{"compile","compile_first","invoke","invoke_nested","construct"}) {
    var actions=new Action<int>[versions.Length];for(int i=0;i<versions.Length;i++){
     if(phase=="invoke" || phase=="compile_first" || phase=="invoke_nested")actions[i]=(Action<int>)cases[i][phase=="invoke"?1:phase=="invoke_nested"?5:4];
     else {var compile=(Func<object>)cases[i][phase=="compile"?0:2];actions[i]=n=>{for(int j=0;j<n;j++)sink=compile();};}
     actions[i](1000);
    }
    int probe=phase.StartsWith("invoke")?100000:100;var probeIndex=Array.IndexOf(versions,"after559");if(probeIndex<0)probeIndex=0;var elapsed=Millis(actions[probeIndex],probe);int max=phase.StartsWith("invoke")?20000000:phase=="construct"?1000000:10000;int count=(int)Math.Clamp(probe*30.0/Math.Max(elapsed,0.001),10,max);
    for(int sample=0;sample<int.Parse(Environment.GetEnvironmentVariable("BENCH_SAMPLES")??"21");sample++){
     for(int slot=0;slot<versions.Length;slot++){
      int i=(sample+round)%2==0?(sample+slot)%versions.Length:(sample+versions.Length-1-slot)%versions.Length;
      GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();long alloc=GC.GetAllocatedBytesForCurrentThread();long start=Stopwatch.GetTimestamp();actions[i](count);long end=Stopwatch.GetTimestamp();long bytes=GC.GetAllocatedBytesForCurrentThread()-alloc;
      Console.WriteLine(JsonSerializer.Serialize(new{runtime=Environment.Version.ToString(),flavor,round,version=versions[i],shape=name,phase,sample,operations=count,ns=(end-start)*1e9/Stopwatch.Frequency/count,bytes=bytes/(double)count}));
     }
    }
   }
   Console.Error.WriteLine("PASS "+name);
  }
  GC.KeepAlive(sink);
 }
}
