using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;
class SnapshotContext : AssemblyLoadContext {
 readonly AssemblyDependencyResolver resolver;
 public SnapshotContext(string path):base(isCollectible:false){resolver=new AssemblyDependencyResolver(path);}
 protected override Assembly Load(AssemblyName name){if(name.Name.StartsWith("System.")||name.Name=="System"||name.Name=="mscorlib"||name.Name=="netstandard")return null;var path=resolver.ResolveAssemblyToPath(name);return path==null?null:LoadFromAssemblyPath(path);}
}
class Host {
 static object sink;
 static double Millis(Action<int> action,int count){var start=Stopwatch.GetTimestamp();action(count);return (Stopwatch.GetTimestamp()-start)*1000.0/Stopwatch.Frequency;}
 static void Main(string[] args){
  string flavor=args[0];var versions=args[1].Split(';');var paths=args[2].Split(';');var names=args.Skip(3).ToArray();var factories=new MethodInfo[versions.Length];
  for(int i=0;i<versions.Length;i++){var path=Path.GetFullPath(paths[i]);var context=new SnapshotContext(path);var assembly=context.LoadFromAssemblyPath(path);factories[i]=assembly.GetType("Program").GetMethod(versions[i]=="System"?"CreateSystemBench":"CreateBench");}
  int round=int.Parse(Environment.GetEnvironmentVariable("BENCH_ROUND")??"0");
  foreach(var name in names){var cases=new object[versions.Length][];for(int i=0;i<versions.Length;i++)cases[i]=(object[])factories[i].Invoke(null,new object[]{name});
   for(int i=0;i<versions.Length;i++)if(cases[i].Length>3)Console.Error.WriteLine("IL "+JsonSerializer.Serialize(new{version=versions[i],shape=name,il=(string)cases[i][3]}));
   foreach(var phase in new[]{"compile_first_invoke"}) {
    var actions=new Action<int>[versions.Length];for(int i=0;i<versions.Length;i++){
     actions[i]=(Action<int>)cases[i][4];
     actions[i](1000);
    }
    int probe=phase=="invoke"?100000:100;var probeIndex=Array.IndexOf(versions,"after559");if(probeIndex<0)probeIndex=0;var elapsed=Millis(actions[probeIndex],probe);int max=phase=="invoke"?20000000:phase=="construct"?1000000:10000;int count=(int)Math.Clamp(probe*15.0/Math.Max(elapsed,0.001),10,max);
    for(int sample=0;sample<int.Parse(Environment.GetEnvironmentVariable("BENCH_SAMPLES")??"21");sample++){
     for(int slot=0;slot<versions.Length;slot++){
      int i=(sample+round)%2==0?(sample+slot)%versions.Length:(sample+versions.Length-1-slot)%versions.Length;
      GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();long alloc=GC.GetAllocatedBytesForCurrentThread();long start=Stopwatch.GetTimestamp();actions[i](count);long end=Stopwatch.GetTimestamp();long bytes=GC.GetAllocatedBytesForCurrentThread()-alloc;
      Console.WriteLine(JsonSerializer.Serialize(new{runtime=Environment.Version.ToString(),flavor,round,version=versions[i],shape=name,phase,sample,operations=count,ns=(end-start)*1e9/Stopwatch.Frequency/count,bytes=bytes/(double)count}));
     }
    }
   }
   Console.Error.WriteLine("PASS "+name);
  }
  GC.KeepAlive(sink);
 }
}
