using System;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
#if LIGHT
using FastExpressionCompiler.LightExpression;
using E = FastExpressionCompiler.LightExpression.Expression;
#else
using FastExpressionCompiler;
using E = System.Linq.Expressions.Expression;
#endif
public sealed class EmptyItem { public int Value = 7; }
static class ConstructorProbe
{
 static object sink; static long checksum;
 static readonly Func<long> Allocated = (Func<long>)Delegate.CreateDelegate(typeof(Func<long>),typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread",BindingFlags.Public|BindingFlags.Static));
 static void Measure(string version,string flavor,string shape,string phase,int round,Action<int> run,int count)
 {
  run(1000);
  for(int sample=0;sample<7;sample++)
  {
   GC.Collect(); GC.WaitForPendingFinalizers(); GC.Collect();
   var allocated=Allocated(); var start=Stopwatch.GetTimestamp();run(count);
   var ns=(Stopwatch.GetTimestamp()-start)*1e9/Stopwatch.Frequency/count;var bytes=(Allocated()-allocated)/(double)count;
   Console.WriteLine("{\"version\":\""+version+"\",\"flavor\":\""+flavor+"\",\"runtime\":\""+Environment.Version+"\",\"shape\":\""+shape+"\",\"phase\":\""+phase+"\",\"round\":"+round+",\"sample\":"+sample+",\"ns\":"+ns.ToString("R",CultureInfo.InvariantCulture)+",\"bytes\":"+bytes.ToString("R",CultureInfo.InvariantCulture)+"}");
  }
 }
 static int Main(string[] args)
 {
  string version=args[0],flavor=args[1];int round=int.Parse(args[2]);
  var p=E.Parameter(typeof(int));var q=E.Parameter(typeof(string));
  var zero=E.Lambda<Func<EmptyItem>>(E.New(typeof(EmptyItem)));
  var one=E.Lambda<Func<int,EmptyItem>>(E.New(typeof(EmptyItem)),p);
  var two=E.Lambda<Func<int,string,EmptyItem>>(E.New(typeof(EmptyItem)),p,q);
  var simple=E.Lambda<Func<int,int>>(E.Add(p,E.Constant(1)),p);
  foreach(var shape in new[]{"ctor0","ctor1","ctor2","add-control"})
  {
   Func<Delegate> compile=shape=="ctor0"?(Func<Delegate>)(()=>zero.CompileFast(true)):
    shape=="ctor1"?(()=>one.CompileFast(true)):shape=="ctor2"?(()=>two.CompileFast(true)):(()=>simple.CompileFast(true));
   var compiled=compile();if(compiled==null)return 1;
   Action<int> invoke;
   if(shape=="ctor0") {var d=(Func<EmptyItem>)compiled;if(d().Value!=7)return 2;invoke=n=>{long sum=0;for(int i=0;i<n;i++){var item=d();sink=item;sum+=item.Value;}checksum=sum;};}
   else if(shape=="ctor1"){var d=(Func<int,EmptyItem>)compiled;if(d(2).Value!=7)return 2;invoke=n=>{long sum=0;for(int i=0;i<n;i++){var item=d(i);sink=item;sum+=item.Value;}checksum=sum;};}
   else if(shape=="ctor2"){var d=(Func<int,string,EmptyItem>)compiled;if(d(2,"v").Value!=7)return 2;invoke=n=>{long sum=0;for(int i=0;i<n;i++){var item=d(i,"v");sink=item;sum+=item.Value;}checksum=sum;};}
   else {var d=(Func<int,int>)compiled;if(d(2)!=3)return 2;invoke=n=>{long sum=0;for(int i=0;i<n;i++)sum+=d(i);checksum=sum;};}
   Measure(version,flavor,shape,"compile",round,n=>{for(int i=0;i<n;i++)sink=compile();},2000);
   Measure(version,flavor,shape,"invoke",round,invoke,1000000);
  }
  GC.KeepAlive(sink);GC.KeepAlive(checksum);return 0;
 }
}
