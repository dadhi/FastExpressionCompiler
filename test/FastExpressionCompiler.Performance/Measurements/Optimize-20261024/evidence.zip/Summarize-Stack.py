from pathlib import Path
import json,statistics,csv,re,hashlib
w=Path(__file__).resolve().parent;out=w/'stack-measurements'
a=json.loads((out/'summary.json').read_text());m=json.loads((out/'manifest.json').read_text())
rows=[]
for x in a:
 for v in m['versions']:
  rows.append(dict(runtime=x['runtime'],flavor=x['flavor'],shape=x['shape'],phase=x['phase'],stage=v,ns=x[v]['ns'],bytes=x[v]['bytes'],round0_ns=x[v]['rounds'][0]['ns'],round1_ns=x[v]['rounds'][1]['ns']))
 if 'System' in x:rows.append(dict(runtime=x['runtime'],flavor='standard',shape=x['shape'],phase=x['phase'],stage='System-unchanged-reference',ns=x['System']['ns'],bytes=x['System']['bytes'],round0_ns=x['System']['rounds'][0]['ns'],round1_ns=x['System']['rounds'][1]['ns']))
with (out/'all-workloads.csv').open('w',newline='',encoding='utf-8') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
aggregates=[]
for rt in sorted({x['runtime'] for x in a}):
 for flavor in ['standard','light']:
  for phase in ['construct','compile','invoke']:
   xs=[x for x in a if x['runtime']==rt and x['flavor']==flavor and x['phase']==phase]
   q=dict(runtime=rt,flavor=flavor,phase=phase,workloads=len(xs))
   for before,after in [('master','after558'),('master','after559'),('after558','after559')]:
    key=after+'/'+before
    q[key]=dict(median_ratio=statistics.median(x[key] for x in xs),round_median_ratios=[statistics.median(x[after]['rounds'][rd]['ns']/x[before]['rounds'][rd]['ns'] for x in xs) for rd in range(2)],faster_over_3pct=sum(x[key]<.97 for x in xs),slower_over_3pct=sum(x[key]>1.03 for x in xs),allocation_lower=sum(x[after]['bytes']<x[before]['bytes']-.5 for x in xs),allocation_same=sum(abs(x[after]['bytes']-x[before]['bytes'])<=.5 for x in xs),allocation_higher=sum(x[after]['bytes']>x[before]['bytes']+.5 for x in xs),max_extra_bytes=max(x[after]['bytes']-x[before]['bytes'] for x in xs))
   aggregates.append(q)
(out/'aggregates.json').write_bytes(json.dumps(aggregates,indent=2).encode())
# Compare actual IL strings, including returned nested delegates. No opcode normalization.
ilrows={}
for p in out.glob('net*-*.log'):
 for line in p.read_text(encoding='utf-8').splitlines():
  if line.startswith('IL '):
   x=json.loads(line[3:]);key=(p.name.split('-')[0], 'light' if '-light-' in p.name else 'standard',x['version'],x['shape'])
   if key in ilrows:assert ilrows[key]==x['il'],('IL changed between rounds',key)
   ilrows[key]=x['il']
checks=[]
for rt in ['net8.0','net10.0']:
 for flavor in ['standard','light']:
  for name in json.loads((out/'shapes.json').read_text()):
   versions={v:ilrows[rt,flavor,v,name] for v in m['versions']}
   checks.append(dict(runtime=rt,flavor=flavor,shape=name,after558_after559_equal=versions['after558']==versions['after559'],master_after558_equal=versions['master']==versions['after558'],includes_returned_nested_delegate='NESTED' in versions['after559'],sha256={v:hashlib.sha256(s.encode()).hexdigest() for v,s in versions.items()}))
(out/'il-comparison.json').write_bytes(json.dumps(checks,indent=2).encode())
print('ACTUAL IL equal after558/after559:',sum(x['after558_after559_equal'] for x in checks),'/',len(checks))
for x in aggregates:
 print(x['runtime'],x['flavor'],x['phase'],'558/master %.4f; 559/master %.4f; 559/558 %.4f'%(x['after558/master']['median_ratio'],x['after559/master']['median_ratio'],x['after559/after558']['median_ratio']),'alloc',[(k,x[k]['allocation_lower'],x[k]['allocation_same'],x[k]['allocation_higher']) for k in ['after558/master','after559/master','after559/after558']])
