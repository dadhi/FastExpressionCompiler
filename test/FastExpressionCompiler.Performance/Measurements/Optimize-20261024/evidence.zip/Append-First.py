from pathlib import Path
import json,statistics,csv,io
w=Path(__file__).resolve().parent;d=Path(r'C:\Data\Git\Github\FastExpressionCompiler\test\FastExpressionCompiler.Performance\Measurements\Optimize-20261024')
a=json.loads((w/'first-measurements/summary.json').read_text());m=json.loads((w/'first-measurements/manifest.json').read_text());main=json.loads((w/'stack-measurements/summary.json').read_text())
(d/'first-invocation.json').write_bytes(json.dumps(a,indent=2).encode());(d/'first-invocation-manifest.json').write_bytes(json.dumps(m,indent=2).encode())
rows=[]
for x in a:
 for v in list(m['versions'])+(['System'] if 'System' in x else []):rows.append(dict(runtime=x['runtime'],flavor=x['flavor'],shape=x['shape'],stage=v,ns=x[v]['ns'],bytes=x[v]['bytes'],round0_ns=x[v]['rounds'][0]['ns'],round1_ns=x[v]['rounds'][1]['ns']))
with (d/'first-invocation.csv').open('w',newline='',encoding='utf-8') as f:
 c=csv.DictWriter(f,fieldnames=list(rows[0]));c.writeheader();c.writerows(rows)
lines=['## Compilation plus first invocation','', 'Compile-only timing has a different JIT boundary for exception regions. #558 uses the supported anonymous dynamic-method host to preserve System-compatible non-Exception catch matching. Its `restrictedSkipVisibility: true` constructor performs accessibility checking and JIT during `CreateDelegate`. Master\'s owned host can defer that work until invocation. Identical emitted instructions therefore do not imply equal work inside the compile-only timing boundary. Returning to the old host would undo correctness; it is not retained as an optimization. The existing `NonExceptionThrowPolicyRegressionTests` cover raw/wrapped payloads, filters, private access and explicit compilation paths.','', 'A separate matched three-stage pass measures compilation **plus the first invocation of each newly created delegate**, and invokes the returned inner delegate for closure factories. The expression compiler/process is warm; each generated delegate is new, so this includes its first JIT where deferred. This is not a cold-process startup measurement. Same runtimes, backends, 44 workloads, two opposite-order rounds, seven samples each: 7,392 FEC observations plus 1,232 separately calibrated unchanged System observations. Raw timings and managed allocations are in [first-invocation.csv](first-invocation.csv) and [first-invocation.json](first-invocation.json).','', '| Runtime / backend | #558 / master | #559 / master | #559 / #558 |','| --- | ---: | ---: | ---: |']
aggregates=[]
for rt in ['8.0.28','10.0.9']:
 for f in ['standard','light']:
  xs=[x for x in a if x['runtime']==rt and x['flavor']==f];q=dict(runtime=rt,flavor=f)
  for key in ['after558/master','after559/master','after559/after558']:q[key]=statistics.median(x[key] for x in xs)
  aggregates.append(q);lines.append('| %s / %s | %.4fx | %.4fx | %.4fx |'%(rt,f,q['after558/master'],q['after559/master'],q['after559/after558']))
lines+=['', 'These are descriptive medians of per-workload ratios, not an aggregate application result. The 32-deep exception-region outlier illustrates the timing boundary; absolute microseconds follow:','', '| Runtime / backend / nested_eh32 | Compile only: master / #558 / #559, us | Compile + first invoke: master / #558 / #559, us |','| --- | ---: | ---: |']
for rt in ['8.0.28','10.0.9']:
 for f in ['standard','light']:
  x=next(x for x in a if x['runtime']==rt and x['flavor']==f and x['shape']=='nested_eh32');y=next(x for x in main if x['runtime']==rt and x['flavor']==f and x['shape']=='nested_eh32' and x['phase']=='compile')
  lines.append('| %s / %s | %s | %s |'%(rt,f,' / '.join('%.2f'%(y[v]['ns']/1000) for v in m['versions']),' / '.join('%.2f'%(x[v]['ns']/1000) for v in m['versions'])))
lines+=['', 'Separate System reference for this end-to-end boundary (ratios above 1 mean System took longer):','', '| Runtime / backend | Median System / #559 | Lowest System / #559 (workload) |','| --- | ---: | ---: |']
for rt in ['8.0.28','10.0.9']:
 sys={x['shape']:x['System']['ns'] for x in a if x['runtime']==rt and x['flavor']=='standard'}
 for f in ['standard','light']:
  xs=[(x['shape'],sys[x['shape']]/x['after559']['ns']) for x in a if x['runtime']==rt and x['flavor']==f];low=min(xs,key=lambda x:x[1]);lines.append('| %s / %s | %.2fx | %.2fx (%s) |'%(rt,f,statistics.median(x[1] for x in xs),low[1],low[0]))
lines+=['', 'System is faster in some end-to-end cases; the complete data retains them. Neither the compile-only ratio nor the end-to-end ratio should be read as a universal compiler or delegate-runtime guarantee.','']
p=d/'README.md';s=p.read_text(encoding='utf-8');pos=s.index('## Unchanged System compiler reference');s=s[:pos]+'\n'.join(lines)+'\n'+s[pos:];p.write_bytes(s.encode())
(d/'first-invocation-aggregates.json').write_bytes(json.dumps(aggregates,indent=2).encode())
for x in aggregates:print(x)
