from pathlib import Path
import subprocess,json,os,statistics
w=Path(__file__).resolve().parent;out=w/'constructor-measurements-retry';assert not out.exists();out.mkdir();rows=[]
for version in ['baseline','candidate']:
 for flavor in ['standard','light']:
  with (out/f'build-{version}-{flavor}.log').open('w',encoding='utf-8') as log:subprocess.run(['dotnet','build','Harness.csproj','-c','Release','--disable-build-servers','-m:1','-v:q'],cwd=w/'ctor-snapshots'/version/flavor,stdout=log,stderr=subprocess.STDOUT,check=True)
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
for tfm in ['net8.0','net10.0','net472']:
 for flavor in ['standard','light']:
  for repeat,versions in enumerate([['baseline','candidate'],['candidate','baseline']]):
   for version in versions:
    binary=w/'ctor-snapshots'/version/flavor/'bin/Release'/tfm/('Harness.exe' if tfm=='net472' else 'Harness.dll');cmd=[str(binary)] if tfm=='net472' else ['dotnet',str(binary)]
    p=subprocess.run(cmd+[version,flavor,str(repeat)],capture_output=True,text=True,env=env,timeout=120);assert p.returncode==0,(tfm,flavor,version,p.stderr)
    tag=f'{tfm}-{flavor}-{repeat}-{version}';(out/(tag+'.jsonl')).write_text(p.stdout,encoding='utf-8');(out/(tag+'.log')).write_text(p.stderr,encoding='utf-8');xs=list(map(json.loads,p.stdout.splitlines()));assert len(xs)==4*2*7;rows+=xs;print(tag,flush=True)
summary=[]
for rt in sorted({x['runtime'] for x in rows}):
 for flavor in ['standard','light']:
  for shape in ['ctor0','ctor1','ctor2','add-control']:
   for phase in ['compile','invoke']:
    item=dict(runtime=rt,flavor=flavor,shape=shape,phase=phase)
    for v in ['baseline','candidate']:
     xs=[x for x in rows if x['runtime']==rt and x['flavor']==flavor and x['shape']==shape and x['phase']==phase and x['version']==v];assert len(xs)==14;item[v]=dict(ns=statistics.median(x['ns'] for x in xs),bytes=statistics.median(x['bytes'] for x in xs))
    summary.append(item)
(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
