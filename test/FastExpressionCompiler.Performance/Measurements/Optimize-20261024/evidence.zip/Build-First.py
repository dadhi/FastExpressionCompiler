from pathlib import Path
import subprocess,os,json,hashlib,statistics,sys,csv
w=Path(__file__).resolve().parent
repo=Path(r'C:\Data\Git\Github\FastExpressionCompiler')
versions={'master':'f49acef0d83db3dd2b1059d7fda1a5107ee4eb3a','after558':'593c72e23a560c68f973fd238d8376b1b37b38af','after559':subprocess.check_output(['git','rev-parse',sys.argv[1]],cwd=repo,text=True).strip()}
out=w/'first-measurements';assert not out.exists();out.mkdir()
snaps=w/'first-snapshots';snaps.mkdir(exist_ok=True)
(snaps/'Directory.Build.props').write_bytes(b'<Project><PropertyGroup><BaseIntermediateOutputPath>obj/$(MSBuildProjectName)/</BaseIntermediateOutputPath><MSBuildProjectExtensionsPath>$(BaseIntermediateOutputPath)</MSBuildProjectExtensionsPath></PropertyGroup></Project>')
manifest={'versions':versions,'sources':{}}
for version,commit in versions.items():
 for flavor in ['standard','light']:
  d=snaps/version/flavor;d.mkdir(parents=True,exist_ok=True)
  files=['src/FastExpressionCompiler/'+x for x in ['FastExpressionCompiler.cs','ImTools.cs','ILReader.cs','TestTools.cs']]
  if flavor=='light':files+=['src/FastExpressionCompiler.LightExpression/'+x for x in ['Expression.cs','ExpressionVisitor.cs','FlatExpression.cs']]
  for path in files:
   data=subprocess.check_output(['git','show',commit+':'+path],cwd=repo);target=d/Path(path).name;target.write_bytes(data);manifest['sources'][str(target.relative_to(w))]=hashlib.sha256(data).hexdigest()
  defines='<DefineConstants>LIGHT_EXPRESSION</DefineConstants>' if flavor=='light' else ''
  (d/'Library.csproj').write_bytes(('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><AssemblyName>StackComparison.'+flavor+'</AssemblyName><Optimize>true</Optimize><EnableDefaultCompileItems>false</EnableDefaultCompileItems>'+defines+'</PropertyGroup><ItemGroup><Compile Include="*.cs"/></ItemGroup></Project>').encode())
  defines='<DefineConstants>LIGHT</DefineConstants>' if flavor=='light' else ''
  (d/'Facade.csproj').write_bytes(('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><EnableDefaultCompileItems>false</EnableDefaultCompileItems><Optimize>true</Optimize>'+defines+'</PropertyGroup><ItemGroup><Compile Include="../../../FirstFacade.cs"/><ProjectReference Include="Library.csproj"/></ItemGroup></Project>').encode())
  with (out/f'build-{version}-{flavor}.log').open('w',encoding='utf-8') as log:subprocess.run(['dotnet','build','Facade.csproj','-c','Release','--disable-build-servers','-m:1','-v:q'],cwd=d,stdout=log,stderr=subprocess.STDOUT,check=True)
  print('BUILT',version,flavor,flush=True)
manifest['binaries']={str(p.relative_to(w)):hashlib.sha256(p.read_bytes()).hexdigest() for p in snaps.rglob('bin/Release/*/*.dll')}
(out/'manifest.json').write_bytes(json.dumps(manifest,indent=2).encode())
with (out/'build-host.log').open('w',encoding='utf-8') as log:subprocess.run(['dotnet','build','Host.csproj','-c','Release','--disable-build-servers','-m:1','-v:q'],cwd=w/'first-host',stdout=log,stderr=subprocess.STDOUT,check=True)
