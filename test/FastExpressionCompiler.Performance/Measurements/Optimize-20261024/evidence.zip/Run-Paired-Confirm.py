from pathlib import Path
import subprocess,os,json,statistics
w=Path(__file__).resolve().parent;out=w/'paired-direct-confirm';assert not out.exists();out.mkdir()
for version in ['pool-fixed','candidate-left']:
 for flavor in ['standard','light']:
  with (out/f'build-{version}-{flavor}.log').open('w',encoding='utf-8') as log:subprocess.run(['dotnet','build','Facade.csproj','-c','Release','--disable-build-servers','-m:1','-v:q'],cwd=w/'snapshots'/version/flavor,stdout=log,stderr=subprocess.STDOUT,check=True)
with (out/'build-host.log').open('w',encoding='utf-8') as log:subprocess.run(['dotnet','build','Host.csproj','-c','Release','--disable-build-servers','-m:1','-v:q'],cwd=w/'paired-host',stdout=log,stderr=subprocess.STDOUT,check=True)
names=['constant', 'add', 'arithmetic64', 'balanced256', 'conditional', 'nullable', 'new_member', 'constant_object', 'array', 'new_array', 'interned_string', 'noninterned_string', 'try_catch', 'try_finally', 'switch', 'goto', 'loop', 'blocks32', 'blocks128', 'invoke_literal', 'invoke_delegate', 'invoke_try_argument', 'capture1', 'capture8', 'capture_reference', 'nested_blocks8', 'nested_blocks32', 'nested_blocks128', 'nested_mixed32', 'nested_mixed128', 'nested_eh8', 'nested_eh32', 'capture_call', 'capture_ctor', 'capture_invoke', 'capture_try', 'capture_array', 'capture_mutable', 'capture_mutable_reference', 'capture_mutable_reference_ctor', 'capture_mutable_reference_array'];rows=[]
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
for tfm in ['net8.0','net10.0']:
 for flavor in ['standard','light']:
  cmd=['dotnet',str(w/'paired-host/bin/Release'/tfm/'Host.dll'),flavor,'pool-fixed;candidate-left',';'.join(str(w/'snapshots'/v/flavor/'bin/Release'/tfm/'Facade.dll') for v in ['pool-fixed','candidate-left']),*names]
  p=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=240);(out/(tfm+'-'+flavor+'.jsonl')).write_text(p.stdout,encoding='utf-8');(out/(tfm+'-'+flavor+'.log')).write_text(p.stderr,encoding='utf-8');assert p.returncode==0,(tfm,flavor,p.stderr);xs=list(map(json.loads,p.stdout.splitlines()));assert len(xs)==len(names)*3*21*2;rows+=xs;print(tfm,flavor,flush=True)
summary=[]
for rt in sorted({x['runtime'] for x in rows}):
 for flavor in ['standard','light']:
  for name in names:
   for phase in ['compile','invoke','construct']:
    item=dict(runtime=rt,flavor=flavor,shape=name,phase=phase)
    for v in ['pool-fixed','candidate-left']:
     xs=[x for x in rows if x['runtime']==rt and x['flavor']==flavor and x['shape']==name and x['phase']==phase and x['version']==v];assert len(xs)==21;item[v]=dict(ns=statistics.median(x['ns'] for x in xs),bytes=statistics.median(x['bytes'] for x in xs))
    item['ratio']=item['candidate-left']['ns']/item['pool-fixed']['ns'];summary.append(item)
(out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
