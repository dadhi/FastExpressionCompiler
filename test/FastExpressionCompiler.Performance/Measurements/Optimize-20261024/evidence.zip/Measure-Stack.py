from pathlib import Path
import subprocess,os,json,hashlib,statistics,sys,csv
w=Path(__file__).resolve().parent
repo=Path(r'C:\Data\Git\Github\FastExpressionCompiler')
out=w/'stack-measurements';snaps=w/'stack-snapshots'
manifest=json.loads((out/'manifest.json').read_text());versions=manifest['versions']
for path,digest in dict(manifest['sources'],**manifest['binaries']).items():assert hashlib.sha256((w/path).read_bytes()).hexdigest()==digest,path
names=json.loads((repo/'test/FastExpressionCompiler.Performance/Measurements/Rebase-20261024/source-manifest.json').read_text())['selectedBenchmarkShapes']+['ctor0','ctor1','ctor2']
(out/'shapes.json').write_bytes(json.dumps(names).encode())
rows=[]
for rd in range(2):
 configs=[(t,f) for t in ['net8.0','net10.0'] for f in ['standard','light']]
 if rd:configs.reverse()
 for tfm,flavor in configs:
  labels=list(versions)
  if rd:labels.reverse()
  paths=[str(snaps/('after559' if v=='System' else v)/flavor/'bin/Release'/tfm/'Facade.dll') for v in labels]
  env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0',BENCH_ROUND=str(rd),BENCH_SAMPLES='7')
  cmd=['dotnet',str(w/'stack-host/bin/Release'/tfm/'Host.dll'),flavor,';'.join(labels),';'.join(paths),*names]
  stem=tfm+'-'+flavor+'-'+str(rd)
  with (out/(stem+'.jsonl')).open('w',encoding='utf-8') as stdout,(out/(stem+'.log')).open('w',encoding='utf-8') as stderr:
   subprocess.run(cmd,env=env,stdout=stdout,stderr=stderr,check=True,timeout=1200)
  xs=[json.loads(x) for x in (out/(stem+'.jsonl')).read_text().splitlines()];assert len(xs)==len(names)*3*7*len(labels);rows+=xs
  print('MEASURED',stem,len(xs),flush=True)
# Independent System reference with its own calibration: never changes between PR stages.
for rd in range(2):
 for tfm in (['net8.0','net10.0'] if rd==0 else ['net10.0','net8.0']):
  env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0',BENCH_ROUND=str(rd),BENCH_SAMPLES='7')
  cmd=['dotnet',str(w/'stack-host/bin/Release'/tfm/'Host.dll'),'standard','System',str(snaps/'after559'/'standard'/'bin/Release'/tfm/'Facade.dll'),*names]
  stem=tfm+'-System-'+str(rd)
  with (out/(stem+'.jsonl')).open('w',encoding='utf-8') as stdout,(out/(stem+'.log')).open('w',encoding='utf-8') as stderr:subprocess.run(cmd,env=env,stdout=stdout,stderr=stderr,check=True,timeout=1200)
  xs=[json.loads(x) for x in (out/(stem+'.jsonl')).read_text().splitlines()];assert len(xs)==len(names)*3*7;rows+=xs
  print('REFERENCE',stem,len(xs),flush=True)
summary=[]
for rt in sorted({x['runtime'] for x in rows}):
 for flavor in ['standard','light']:
  for name in names:
   for phase in ['compile','invoke','construct']:
    item=dict(runtime=rt,flavor=flavor,shape=name,phase=phase)
    labels=list(versions)+(['System'] if flavor=='standard' else [])
    for v in labels:
     xs=[x for x in rows if x['runtime']==rt and x['flavor']==flavor and x['shape']==name and x['phase']==phase and x['version']==v];assert len(xs)==14
     item[v]=dict(ns=statistics.median(x['ns'] for x in xs),bytes=statistics.median(x['bytes'] for x in xs),rounds=[dict(ns=statistics.median(x['ns'] for x in xs if x['round']==rd),bytes=statistics.median(x['bytes'] for x in xs if x['round']==rd)) for rd in range(2)])
    item['after558/master']=item['after558']['ns']/item['master']['ns'];item['after559/master']=item['after559']['ns']/item['master']['ns'];item['after559/after558']=item['after559']['ns']/item['after558']['ns'];summary.append(item)
(out/'summary.json').write_bytes(json.dumps(summary,indent=2).encode())
print('DONE',len(rows),'samples',flush=True)
