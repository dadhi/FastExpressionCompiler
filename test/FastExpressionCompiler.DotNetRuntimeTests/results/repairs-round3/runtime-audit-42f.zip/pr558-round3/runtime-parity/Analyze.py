from pathlib import Path
from collections import defaultdict
import json,statistics
p=Path(__file__).resolve().parent
comparisons=[]
for file in sorted(p.glob('canonical-*.jsonl')):
 rows=[json.loads(s) for s in file.read_text(encoding='utf-8').splitlines()]
 groups=defaultdict(dict)
 for r in rows:groups[r['Scenario']][r['Version']]=r
 for scenario,versions in groups.items():
  before=versions['before']['Nodes'];current=versions['current']['Nodes'];paths=[]
  for path in sorted(set(before)|set(current)):
   if path not in before or path not in current:paths.append(dict(path=path,known=False,reason='Delegate graph path differs'));continue
   b=before[path];c=current[path];bm=b['Method'];cm=c['Method'];known=bm.get('Known',False) and cm.get('Known',False)
   fields=['Instructions','Signature','Locals','EH','MaxStack','InitLocals']
   differences=[field for field in fields if bm.get(field)!=cm.get(field)]
   paths.append(dict(path=path,known=known,emittedILSignatureLocalsEHEqual=known and not differences,differences=differences,
    hostEqual=bm.get('Host')==cm.get('Host'),targetTypeEqual=b.get('Target')==c.get('Target'),beforeHost=bm.get('Host'),currentHost=cm.get('Host'),
    caveat='Normalized referenced FEC helper names do not certify helper implementation equality. Native code was not compared.'))
  system=versions['system']['Nodes'].get('outer',{}).get('Method',{})
  current_outer=current.get('outer',{}).get('Method',{})
  system_outer=dict(known=system.get('Known',False) and current_outer.get('Known',False),
      equality={field:system.get(field)==current_outer.get(field) for field in ['Instructions','Signature','Locals','EH','MaxStack','InitLocals','Host']})
  comparisons.append(dict(file=file.name,scenario=scenario,paths=paths,currentSystemOuter=system_outer))
(p/'canonical-analysis.json').write_text(json.dumps(comparisons,indent=2)+'\n',encoding='utf-8')
summaries=[]
for file in sorted(p.glob('runtime-*.jsonl')):
 rows=[json.loads(s) for s in file.read_text(encoding='utf-8').splitlines()]
 groups=defaultdict(dict)
 for r in rows:groups[(r['Scenario'],r['Phase'])].setdefault(r['SampleIndex'],{})[r['Version']]=r
 for (scenario,phase),samples in groups.items():
  assert len(samples)==11
  for index,versions in samples.items():assert set(versions)=={'before','current','system'}
  versions={v:[samples[i][v] for i in sorted(samples)] for v in ['before','current','system']}
  summaries.append(dict(file=file.name,scenario=scenario,phase=phase,samples=11,
    currentBeforeRatioOfNsMedians=statistics.median(x['current']['NsPerOp'] for x in samples.values())/statistics.median(x['before']['NsPerOp'] for x in samples.values()),
    currentSystemRatioOfNsMedians=statistics.median(x['current']['NsPerOp'] for x in samples.values())/statistics.median(x['system']['NsPerOp'] for x in samples.values()),
    currentBeforePairedMedian=statistics.median(x['current']['NsPerOp']/x['before']['NsPerOp'] for x in samples.values()),
    currentSystemPairedMedian=statistics.median(x['current']['NsPerOp']/x['system']['NsPerOp'] for x in samples.values()),
    currentBeforePairedRatios=[samples[i]['current']['NsPerOp']/samples[i]['before']['NsPerOp'] for i in sorted(samples)],
    currentSystemPairedRatios=[samples[i]['current']['NsPerOp']/samples[i]['system']['NsPerOp'] for i in sorted(samples)],
    versions={v:dict(nsMedian=statistics.median(r['NsPerOp'] for r in data),bytesMedian=statistics.median(r['BytesPerOp'] for r in data),
      elapsedMs=[r['ElapsedMs'] for r in data],under20Ms=[r['Under20Ms'] for r in data],operations=[r['Operations'] for r in data],nsPerOp=[r['NsPerOp'] for r in data],bytesPerOp=[r['BytesPerOp'] for r in data],
      gc=[dict(gen0=r['Gen0'],gen1=r['Gen1'],gen2=r['Gen2']) for r in data]) for v,data in versions.items()}))
(p/'runtime-analysis.json').write_text(json.dumps(summaries,indent=2)+'\n',encoding='utf-8')
print('Canonical comparisons',len(comparisons),'runtime phase summaries',len(summaries))
