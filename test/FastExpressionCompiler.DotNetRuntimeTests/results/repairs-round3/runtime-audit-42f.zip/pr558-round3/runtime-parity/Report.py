from pathlib import Path
import json
p=Path(__file__).resolve().parent
rows=json.loads((p/'runtime-analysis.json').read_text(encoding='utf-8'))
canonical=json.loads((p/'canonical-analysis.json').read_text(encoding='utf-8'))
raw=[json.loads(s) for f in p.glob('runtime-*.jsonl') for s in f.read_text(encoding='utf-8').splitlines()]
under=[r for r in raw if r['Under20Ms']]
text='''# Sustained runtime audit: frozen e4c232da / current42f98478 / System

This focused suite has15 shapes and25 runtime phases per configuration (scalar invocation, factory activation, activation+first call, and preactivated child invocation). It covers Standard/Light on .NET8/.NET10 ARM64 and Framework4.8 X64 on ARM64 Windows. All90 shape/configuration correctness checks passed. It is not the earlier47-shape set, and no median of these ratios is a weighted application speedup.

Each process contains all three versions. Eleven samples rotate all six version orders, using one shared operation count calibrated to40ms for the fastest version. System activation can be much slower and therefore exceeds100ms. Every raw sample is retained. Raw elapsed durations, operation counts, allocations, GC counts, absolute ns and paired ratios are in runtime-analysis.json and runtime-*.jsonl.

'''
text+=f'Actual samples: {len(raw)}. Samples<20ms: {len(under)} (all flagged), minimum{min(r["ElapsedMs"] for r in raw):.3f}ms; maximum{max(r["ElapsedMs"] for r in raw):.3f}ms. These are sustained samples, but calibration is a target, not proof of identical execution context.\n\n'
text+='''Canonical findings: ordinary constant/add/arithmetic/balanced/array/blocks/goto dynamic IL, signatures, locals and EH match prePR for the tested shapes. TryFinally and invoke_try_argument also match those emitted fields while their host changes to anonymous exception-aware hosting. TryCatch adds the required catch-entry Pop and changes EH offsets/MaxStack. Readonly capture child bodies and curry wrappers match; outer factories remove the old write to the shared wrapper NonPassedParams field and retain a redundant local-load/Pop. That cleanup was already tested and HELD earlier; it is not an untried candidate. Mutable value capture changes its body/storage and removes24B per child invocation. Mutable-reference child Length changes Call→Callvirt as part of correct receiver handling. Framework outer-capture local signatures with unresolved internal type handles remain UNKNOWN; they are never declared identical.

Exact helper-source hashes for CurryClosureFuncs, ArrayClosure and ArrayClosureWithNonPassedParams match both snapshots (source-audit.json). Normalized helper names do not certify arbitrary callee implementation equality. Source/IL identity does not guarantee identical native code, generic instantiation, target placement, host policy, retained object references or speed.

Bounded separate native diagnostics (native-analysis.json/native-*.dasm) use the documented shipped-JIT method filters and pointer-normalized disassembly: add before/current is identical20B ARM64 code on .NET8/.NET10; capture1 child code is identical120B/116B respectively, and curry wrapper identical28B. Capture1 outer factory shrinks12B in both runtimes, consistent with removed shared-wrapper field assignment. This does not certify the timed processes' addresses/alignment or establish a cause for every observed time difference. The diagnostic configuration reference is https://github.com/dotnet/runtime/blob/main/docs/design/coreclr/jit/viewing-jit-dumps.md.

The separate same-current A/A diagnostic (../runtime-aa/REPORT.md) has1452 samples,66 phase rows, zero<20ms, equal allocation medians and no known canonical IL/signature/locals/EH/host differences. It still measures Light capture8 nested B/A paired ratios1.281 on .NET8 and1.275 on .NET10 (ratios of ns medians1.266/1.338). It demonstrates material independent-target/context variation, but does not reproduce or erase every version-pair cost and is never subtracted from those measurements. There is no blanket claim that all observed runtime costs are caused by changed emitter instructions or, conversely, that all are mere noise.

Ratio columns distinguish median of paired sample ratios from ratio of ns medians. They can differ considerably when samples vary: C/B pair=median(current_i/before_i), C/B med=median(current_i)/median(before_i), likewise C/System. >1 means current slower. Bytes list prePR/current/System. Phases remain separate; no statistic is silently substituted for another.

'''
for file in sorted({r['file'] for r in rows}):
 text+='## '+file.replace('runtime-','').replace('.jsonl','')+'\n\n'
 text+='| Shape | Phase | prePR ns | Current ns | System ns | C/B pair | C/B med | C/S pair | C/S med | Bytes B/C/S |\n|---|---|---:|---:|---:|---:|---:|---:|---:|---:|\n'
 for r in [x for x in rows if x['file']==file]:
  v=r['versions'];text+='|'+r['scenario']+'|'+r['phase']+'|'+ '|'.join(f'{v[k]["nsMedian"]:.3f}' for k in ['before','current','system'])+'|'+f'{r["currentBeforePairedMedian"]:.3f}|{r["currentBeforeRatioOfNsMedians"]:.3f}|{r["currentSystemPairedMedian"]:.3f}|{r["currentSystemRatioOfNsMedians"]:.3f}|'+'/'.join(f'{v[k]["bytesMedian"]:.3f}' for k in ['before','current','system'])+'|\n'
 text+='\n'
(p/'REPORT.md').write_text(text,encoding='utf-8')
manifest=json.loads((p/'manifest.json').read_text(encoding='utf-8'))
manifest.update(primaryRuntimeCompleted=True,runtimeSamples=len(raw),runtimePhaseSummaries=len(rows),samplesBelow20ms=len(under),minimumElapsedMs=min(r['ElapsedMs'] for r in raw),maximumElapsedMs=max(r['ElapsedMs'] for r in raw),noApplicationWeightedSpeedup=True)
(p/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Report written:',len(rows),'phase summaries;',len(raw),'raw samples;',len(under),'samples<20ms')
