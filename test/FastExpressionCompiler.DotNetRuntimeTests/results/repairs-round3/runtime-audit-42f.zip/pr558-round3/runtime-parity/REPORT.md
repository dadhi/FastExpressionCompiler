# Sustained runtime audit: frozen e4c232da / current42f98478 / System

This focused suite has15 shapes and25 runtime phases per configuration (scalar invocation, factory activation, activation+first call, and preactivated child invocation). It covers Standard/Light on .NET8/.NET10 ARM64 and Framework4.8 X64 on ARM64 Windows. All90 shape/configuration correctness checks passed. It is not the earlier47-shape set, and no median of these ratios is a weighted application speedup.

Each process contains all three versions. Eleven samples rotate all six version orders, using one shared operation count calibrated to40ms for the fastest version. System activation can be much slower and therefore exceeds100ms. Every raw sample is retained. Raw elapsed durations, operation counts, allocations, GC counts, absolute ns and paired ratios are in runtime-analysis.json and runtime-*.jsonl.

Actual samples: 4950. Samples<20ms: 25 (all flagged), minimum10.820ms; maximum2723.693ms. These are sustained samples, but calibration is a target, not proof of identical execution context.

Canonical findings: ordinary constant/add/arithmetic/balanced/array/blocks/goto dynamic IL, signatures, locals and EH match prePR for the tested shapes. TryFinally and invoke_try_argument also match those emitted fields while their host changes to anonymous exception-aware hosting. TryCatch adds the required catch-entry Pop and changes EH offsets/MaxStack. Readonly capture child bodies and curry wrappers match; outer factories remove the old write to the shared wrapper NonPassedParams field and retain a redundant local-load/Pop. That cleanup was already tested and HELD earlier; it is not an untried candidate. Mutable value capture changes its body/storage and removes24B per child invocation. Mutable-reference child Length changes Call→Callvirt as part of correct receiver handling. Framework outer-capture local signatures with unresolved internal type handles remain UNKNOWN; they are never declared identical.

Exact helper-source hashes for CurryClosureFuncs, ArrayClosure and ArrayClosureWithNonPassedParams match both snapshots (source-audit.json). Normalized helper names do not certify arbitrary callee implementation equality. Source/IL identity does not guarantee identical native code, generic instantiation, target placement, host policy, retained object references or speed.

Bounded separate native diagnostics (native-analysis.json/native-*.dasm) use the documented shipped-JIT method filters and pointer-normalized disassembly: add before/current is identical20B ARM64 code on .NET8/.NET10; capture1 child code is identical120B/116B respectively, and curry wrapper identical28B. Capture1 outer factory shrinks12B in both runtimes, consistent with removed shared-wrapper field assignment. This does not certify the timed processes' addresses/alignment or establish a cause for every observed time difference. The diagnostic configuration reference is https://github.com/dotnet/runtime/blob/main/docs/design/coreclr/jit/viewing-jit-dumps.md.

The separate same-current A/A diagnostic (../runtime-aa/REPORT.md) has1452 samples,66 phase rows, zero<20ms, equal allocation medians and no known canonical IL/signature/locals/EH/host differences. It still measures Light capture8 nested B/A paired ratios1.281 on .NET8 and1.275 on .NET10 (ratios of ns medians1.266/1.338). It demonstrates material independent-target/context variation, but does not reproduce or erase every version-pair cost and is never subtracted from those measurements. There is no blanket claim that all observed runtime costs are caused by changed emitter instructions or, conversely, that all are mere noise.

Ratio columns distinguish median of paired sample ratios from ratio of ns medians. They can differ considerably when samples vary: C/B pair=median(current_i/before_i), C/B med=median(current_i)/median(before_i), likewise C/System. >1 means current slower. Bytes list prePR/current/System. Phases remain separate; no statistic is silently substituted for another.

## net10.0-light

| Shape | Phase | prePR ns | Current ns | System ns | C/B pair | C/B med | C/S pair | C/S med | Bytes B/C/S |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
|constant|invoke|1.516|1.507|1.567|1.028|0.994|0.962|0.961|0.000/0.000/0.000|
|add|invoke|1.380|1.500|1.428|1.003|1.087|1.013|1.050|0.000/0.000/0.000|
|arithmetic64|invoke|1.446|1.406|1.428|0.988|0.972|0.984|0.985|0.000/0.000/0.000|
|balanced256|invoke|9.308|11.975|11.707|1.256|1.287|1.033|1.023|0.000/0.000/0.000|
|array|invoke|1.220|1.316|2.400|1.007|1.079|0.538|0.548|0.000/0.000/0.000|
|blocks32|invoke|1.507|1.453|1.473|1.006|0.964|0.939|0.986|0.000/0.000/0.000|
|goto|invoke|1.398|1.410|1.385|1.006|1.008|1.025|1.018|0.000/0.000/0.000|
|try_catch|invoke|1.406|1.314|1.078|0.963|0.934|1.196|1.219|0.000/0.000/0.000|
|try_finally|invoke|1.460|1.577|1.445|0.964|1.080|0.993|1.091|0.000/0.000/0.000|
|invoke_try_argument|invoke|1.686|2.252|2.352|1.095|1.336|0.940|0.958|0.000/0.000/0.000|
|capture1|activate|19.610|19.544|230.427|0.927|0.997|0.086|0.085|184.000/184.000/152.000|
|capture1|activation_first|29.782|40.354|389.969|1.159|1.355|0.090|0.103|184.000/184.000/152.000|
|capture1|nested_invoke|3.442|3.498|1.581|1.099|1.016|2.077|2.212|0.000/0.000/0.000|
|capture8|activate|67.477|64.563|325.868|0.878|0.957|0.184|0.198|440.000/440.000/408.000|
|capture8|activation_first|71.021|61.089|269.100|0.936|0.860|0.236|0.227|440.000/440.000/408.000|
|capture8|nested_invoke|5.607|5.321|8.762|0.935|0.949|0.596|0.607|0.000/0.000/0.000|
|capture_reference|activate|18.561|20.007|218.789|0.961|1.078|0.093|0.091|160.000/160.000/152.000|
|capture_reference|activation_first|21.314|21.963|248.153|0.844|1.030|0.089|0.089|160.000/160.000/152.000|
|capture_reference|nested_invoke|2.346|2.476|1.249|0.972|1.055|1.923|1.983|0.000/0.000/0.000|
|capture_mutable|activate|19.868|18.997|190.460|0.933|0.956|0.100|0.100|184.000/184.000/152.000|
|capture_mutable|activation_first|26.660|20.795|181.603|0.778|0.780|0.116|0.115|208.000/184.000/152.000|
|capture_mutable|nested_invoke|7.992|3.091|1.261|0.391|0.387|2.229|2.452|24.000/0.000/0.000|
|capture_mutable_reference|activate|30.296|29.202|381.792|0.863|0.964|0.074|0.076|160.000/160.000/152.000|
|capture_mutable_reference|activation_first|30.282|29.088|277.823|0.951|0.961|0.110|0.105|160.000/160.000/152.000|
|capture_mutable_reference|nested_invoke|7.112|7.068|3.434|1.003|0.994|2.060|2.058|0.000/0.000/0.000|

## net10.0-standard

| Shape | Phase | prePR ns | Current ns | System ns | C/B pair | C/B med | C/S pair | C/S med | Bytes B/C/S |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
|constant|invoke|1.293|1.300|1.299|1.004|1.006|1.003|1.001|0.000/0.000/0.000|
|add|invoke|1.309|1.310|1.311|0.995|1.000|1.001|0.999|0.000/0.000/0.000|
|arithmetic64|invoke|1.330|1.318|1.336|0.993|0.991|0.987|0.986|0.000/0.000/0.000|
|balanced256|invoke|12.701|12.609|11.895|0.975|0.993|1.044|1.060|0.000/0.000/0.000|
|array|invoke|1.692|1.466|3.145|0.858|0.867|0.531|0.466|0.000/0.000/0.000|
|blocks32|invoke|1.640|1.662|1.702|1.008|1.013|0.999|0.977|0.000/0.000/0.000|
|goto|invoke|1.400|1.398|1.398|1.004|0.999|1.001|1.000|0.000/0.000/0.000|
|try_catch|invoke|1.371|1.344|1.031|0.986|0.980|1.220|1.304|0.000/0.000/0.000|
|try_finally|invoke|1.773|1.797|1.873|1.017|1.014|0.981|0.959|0.000/0.000/0.000|
|invoke_try_argument|invoke|2.241|2.242|2.289|1.008|1.001|0.998|0.980|0.000/0.000/0.000|
|capture1|activate|18.307|16.697|167.447|0.919|0.912|0.100|0.100|184.000/184.000/152.000|
|capture1|activation_first|21.335|20.150|192.621|0.920|0.944|0.107|0.105|184.000/184.000/152.000|
|capture1|nested_invoke|2.124|2.127|1.049|1.002|1.001|2.024|2.027|0.000/0.000/0.000|
|capture8|activate|44.492|43.762|217.887|0.982|0.984|0.199|0.201|440.000/440.000/408.000|
|capture8|activation_first|51.921|54.252|216.496|1.027|1.045|0.247|0.251|440.000/440.000/408.000|
|capture8|nested_invoke|5.762|5.168|8.740|0.934|0.897|0.595|0.591|0.000/0.000/0.000|
|capture_reference|activate|18.886|16.887|192.491|0.906|0.894|0.088|0.088|160.000/160.000/152.000|
|capture_reference|activation_first|21.184|19.781|202.153|0.947|0.934|0.097|0.098|160.000/160.000/152.000|
|capture_reference|nested_invoke|2.360|2.310|1.211|0.998|0.979|1.913|1.907|0.000/0.000/0.000|
|capture_mutable|activate|21.315|19.439|199.715|0.894|0.912|0.100|0.097|184.000/184.000/152.000|
|capture_mutable|activation_first|25.443|19.904|187.823|0.776|0.782|0.110|0.106|208.000/184.000/152.000|
|capture_mutable|nested_invoke|9.128|2.861|1.301|0.354|0.313|2.231|2.199|24.000/0.000/0.000|
|capture_mutable_reference|activate|20.754|19.856|210.156|0.931|0.957|0.090|0.094|160.000/160.000/152.000|
|capture_mutable_reference|activation_first|22.909|22.177|219.939|0.968|0.968|0.110|0.101|160.000/160.000/152.000|
|capture_mutable_reference|nested_invoke|6.716|7.131|3.140|1.043|1.062|2.066|2.271|0.000/0.000/0.000|

## net472-light

| Shape | Phase | prePR ns | Current ns | System ns | C/B pair | C/B med | C/S pair | C/S med | Bytes B/C/S |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
|constant|invoke|1.328|1.304|1.055|0.986|0.981|1.246|1.235|0.000/0.000/0.000|
|add|invoke|1.293|1.284|1.038|0.995|0.993|1.235|1.237|0.000/0.000/0.000|
|arithmetic64|invoke|1.277|1.305|1.036|1.020|1.021|1.263|1.259|0.000/0.000/0.000|
|balanced256|invoke|19.301|19.349|19.293|0.999|1.002|1.009|1.003|0.000/0.000/0.000|
|array|invoke|4.578|4.599|4.600|1.006|1.005|1.008|1.000|0.000/0.000/0.000|
|blocks32|invoke|1.279|1.278|1.047|0.999|0.999|1.250|1.221|0.000/0.000/0.000|
|goto|invoke|1.272|1.283|1.038|1.005|1.009|1.248|1.237|0.000/0.000/0.000|
|try_catch|invoke|2.067|1.626|1.646|0.797|0.787|0.990|0.988|0.000/0.000/0.000|
|try_finally|invoke|1.329|1.066|1.054|0.810|0.802|1.008|1.012|0.000/0.000/0.000|
|invoke_try_argument|invoke|1.597|1.086|1.084|0.670|0.680|0.999|1.002|0.000/0.000/0.000|
|capture1|activate|23.720|24.570|437.681|1.012|1.036|0.056|0.056|184.000/184.000/152.000|
|capture1|activation_first|29.306|29.112|436.389|0.995|0.993|0.067|0.067|184.000/184.000/152.000|
|capture1|nested_invoke|4.200|4.271|2.515|1.029|1.017|1.690|1.698|0.000/0.000/0.000|
|capture8|activate|67.531|66.803|549.101|0.993|0.989|0.121|0.122|440.000/440.000/408.000|
|capture8|activation_first|83.208|82.306|564.101|0.997|0.989|0.146|0.146|440.000/440.000/408.000|
|capture8|nested_invoke|12.954|13.198|9.939|1.024|1.019|1.301|1.328|0.000/0.000/0.000|
|capture_reference|activate|27.461|30.486|578.087|1.040|1.110|0.051|0.053|160.000/160.000/152.000|
|capture_reference|activation_first|33.556|34.431|623.955|0.995|1.026|0.059|0.055|160.000/160.000/152.000|
|capture_reference|nested_invoke|4.343|4.642|3.184|1.065|1.069|1.449|1.458|0.000/0.000/0.000|
|capture_mutable|activate|29.254|28.205|514.900|0.965|0.964|0.056|0.055|184.000/184.000/152.000|
|capture_mutable|activation_first|35.967|31.466|471.237|0.919|0.875|0.067|0.067|208.000/184.000/152.000|
|capture_mutable|nested_invoke|9.309|5.167|3.411|0.558|0.555|1.514|1.515|24.000/0.000/0.000|
|capture_mutable_reference|activate|21.530|21.694|445.550|1.017|1.008|0.048|0.049|160.000/160.000/152.000|
|capture_mutable_reference|activation_first|30.579|30.526|456.794|1.011|0.998|0.067|0.067|160.000/160.000/152.000|
|capture_mutable_reference|nested_invoke|8.762|8.667|4.922|0.983|0.989|1.801|1.761|0.000/0.000/0.000|

## net472-standard

| Shape | Phase | prePR ns | Current ns | System ns | C/B pair | C/B med | C/S pair | C/S med | Bytes B/C/S |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
|constant|invoke|2.117|2.058|1.660|1.001|0.972|1.271|1.240|0.000/0.000/0.000|
|add|invoke|1.841|1.796|1.478|0.961|0.976|1.268|1.215|0.000/0.000/0.000|
|arithmetic64|invoke|1.788|1.495|1.332|0.912|0.836|1.236|1.122|0.000/0.000/0.000|
|balanced256|invoke|25.190|27.341|23.665|1.020|1.085|1.021|1.155|0.000/0.000/0.000|
|array|invoke|6.125|7.026|6.828|1.245|1.147|1.162|1.029|0.000/0.000/0.000|
|blocks32|invoke|3.233|2.901|2.114|0.878|0.897|1.372|1.372|0.000/0.000/0.000|
|goto|invoke|2.771|2.130|1.323|0.772|0.769|1.266|1.610|0.000/0.000/0.000|
|try_catch|invoke|3.425|2.887|2.953|0.947|0.843|0.979|0.978|0.000/0.000/0.000|
|try_finally|invoke|2.148|1.648|1.763|0.693|0.767|1.022|0.935|0.000/0.000/0.000|
|invoke_try_argument|invoke|2.866|1.946|1.900|0.665|0.679|1.024|1.024|0.000/0.000/0.000|
|capture1|activate|28.266|27.033|523.625|0.996|0.956|0.055|0.052|184.000/184.000/152.000|
|capture1|activation_first|31.094|31.954|485.846|1.025|1.028|0.065|0.066|184.000/184.000/152.000|
|capture1|nested_invoke|4.177|4.100|2.537|0.987|0.982|1.602|1.616|0.000/0.000/0.000|
|capture8|activate|66.370|65.905|531.420|0.991|0.993|0.124|0.124|440.000/440.000/408.000|
|capture8|activation_first|79.728|79.550|540.754|0.983|0.998|0.145|0.147|440.000/440.000/408.000|
|capture8|nested_invoke|12.406|12.891|10.162|1.051|1.039|1.252|1.269|0.000/0.000/0.000|
|capture_reference|activate|23.407|22.623|438.835|0.979|0.966|0.051|0.052|160.000/160.000/152.000|
|capture_reference|activation_first|26.825|27.122|440.122|1.011|1.011|0.060|0.062|160.000/160.000/152.000|
|capture_reference|nested_invoke|3.992|3.864|2.738|0.969|0.968|1.425|1.411|0.000/0.000/0.000|
|capture_mutable|activate|25.990|25.510|463.233|0.995|0.982|0.055|0.055|184.000/184.000/152.000|
|capture_mutable|activation_first|44.009|47.449|756.202|0.922|1.078|0.061|0.063|208.000/184.000/152.000|
|capture_mutable|nested_invoke|15.605|7.431|4.956|0.486|0.476|1.502|1.499|24.000/0.000/0.000|
|capture_mutable_reference|activate|24.475|24.174|519.648|0.982|0.988|0.046|0.047|160.000/160.000/152.000|
|capture_mutable_reference|activation_first|32.198|31.488|501.837|0.970|0.978|0.063|0.063|160.000/160.000/152.000|
|capture_mutable_reference|nested_invoke|9.392|9.327|4.850|1.000|0.993|1.917|1.923|0.000/0.000/0.000|

## net8.0-light

| Shape | Phase | prePR ns | Current ns | System ns | C/B pair | C/B med | C/S pair | C/S med | Bytes B/C/S |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
|constant|invoke|1.791|1.660|1.662|0.926|0.927|1.033|0.999|0.000/0.000/0.000|
|add|invoke|1.685|1.642|1.652|0.988|0.974|1.000|0.994|0.000/0.000/0.000|
|arithmetic64|invoke|1.777|1.742|1.699|0.997|0.980|1.010|1.025|0.000/0.000/0.000|
|balanced256|invoke|13.765|12.963|11.197|0.920|0.942|1.142|1.158|0.000/0.000/0.000|
|array|invoke|1.328|1.339|1.679|1.000|1.008|0.791|0.797|0.000/0.000/0.000|
|blocks32|invoke|1.669|1.632|1.635|0.992|0.978|1.002|0.999|0.000/0.000/0.000|
|goto|invoke|1.653|1.642|1.653|0.989|0.993|0.997|0.994|0.000/0.000/0.000|
|try_catch|invoke|1.280|1.276|0.932|1.031|0.997|1.354|1.370|0.000/0.000/0.000|
|try_finally|invoke|1.341|1.362|1.368|0.974|1.016|1.006|0.996|0.000/0.000/0.000|
|invoke_try_argument|invoke|1.334|1.328|1.316|1.008|0.995|1.006|1.009|0.000/0.000/0.000|
|capture1|activate|17.317|16.565|177.945|0.932|0.957|0.095|0.093|184.000/184.000/152.000|
|capture1|activation_first|20.287|19.141|174.713|0.939|0.944|0.111|0.110|184.000/184.000/152.000|
|capture1|nested_invoke|2.315|2.207|1.148|0.968|0.953|1.943|1.922|0.000/0.000/0.000|
|capture8|activate|41.809|44.987|192.609|1.067|1.076|0.233|0.234|440.000/440.000/408.000|
|capture8|activation_first|77.171|76.805|364.318|0.989|0.995|0.194|0.211|440.000/440.000/408.000|
|capture8|nested_invoke|7.096|6.711|7.138|0.941|0.946|0.956|0.940|0.000/0.000/0.000|
|capture_reference|activate|18.312|16.838|203.675|0.922|0.919|0.084|0.083|160.000/160.000/152.000|
|capture_reference|activation_first|21.174|20.060|231.757|0.923|0.947|0.093|0.087|160.000/160.000/152.000|
|capture_reference|nested_invoke|2.013|1.960|1.054|1.000|0.974|1.878|1.860|0.000/0.000/0.000|
|capture_mutable|activate|17.634|16.605|169.200|0.940|0.942|0.097|0.098|184.000/184.000/152.000|
|capture_mutable|activation_first|24.424|20.591|180.642|0.843|0.843|0.116|0.114|208.000/184.000/152.000|
|capture_mutable|nested_invoke|6.231|2.446|1.721|0.395|0.393|1.463|1.422|24.000/0.000/0.000|
|capture_mutable_reference|activate|16.572|15.224|169.975|0.930|0.919|0.090|0.090|160.000/160.000/152.000|
|capture_mutable_reference|activation_first|23.357|22.839|194.539|0.976|0.978|0.117|0.117|160.000/160.000/152.000|
|capture_mutable_reference|nested_invoke|5.002|4.982|2.322|1.008|0.996|2.150|2.145|0.000/0.000/0.000|

## net8.0-standard

| Shape | Phase | prePR ns | Current ns | System ns | C/B pair | C/B med | C/S pair | C/S med | Bytes B/C/S |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
|constant|invoke|2.989|2.420|2.948|0.681|0.810|0.844|0.821|0.000/0.000/0.000|
|add|invoke|2.779|3.085|2.848|1.308|1.110|0.973|1.083|0.000/0.000/0.000|
|arithmetic64|invoke|2.681|2.343|2.285|0.935|0.874|1.138|1.025|0.000/0.000/0.000|
|balanced256|invoke|23.348|24.411|20.408|1.048|1.045|1.212|1.196|0.000/0.000/0.000|
|array|invoke|2.485|2.754|3.090|1.170|1.108|0.944|0.891|0.000/0.000/0.000|
|blocks32|invoke|2.311|1.993|2.089|1.019|0.862|0.976|0.954|0.000/0.000/0.000|
|goto|invoke|2.514|2.222|2.203|0.884|0.884|0.960|1.008|0.000/0.000/0.000|
|try_catch|invoke|2.638|2.333|1.998|0.808|0.885|0.992|1.168|0.000/0.000/0.000|
|try_finally|invoke|2.715|2.453|2.585|0.769|0.903|0.953|0.949|0.000/0.000/0.000|
|invoke_try_argument|invoke|2.452|2.444|2.085|0.957|0.997|1.197|1.172|0.000/0.000/0.000|
|capture1|activate|44.079|43.605|474.098|0.858|0.989|0.085|0.092|184.000/184.000/152.000|
|capture1|activation_first|73.647|43.137|452.283|0.637|0.586|0.072|0.095|184.000/184.000/152.000|
|capture1|nested_invoke|3.352|7.107|1.632|2.010|2.120|3.426|4.356|0.000/0.000/0.000|
|capture8|activate|104.811|109.055|543.145|1.168|1.040|0.183|0.201|440.000/440.000/408.000|
|capture8|activation_first|109.440|172.312|593.529|1.317|1.574|0.282|0.290|440.000/440.000/408.000|
|capture8|nested_invoke|17.757|12.276|12.133|0.888|0.691|1.469|1.012|0.000/0.000/0.000|
|capture_reference|activate|32.013|32.135|465.958|0.826|1.004|0.069|0.069|160.000/160.000/152.000|
|capture_reference|activation_first|44.558|50.433|462.314|0.964|1.132|0.107|0.109|160.000/160.000/152.000|
|capture_reference|nested_invoke|4.387|4.112|2.126|0.829|0.937|2.039|1.934|0.000/0.000/0.000|
|capture_mutable|activate|38.826|34.054|389.917|0.654|0.877|0.087|0.087|184.000/184.000/152.000|
|capture_mutable|activation_first|59.290|50.953|446.869|0.878|0.859|0.116|0.114|208.000/184.000/152.000|
|capture_mutable|nested_invoke|12.054|5.098|4.238|0.421|0.423|1.179|1.203|24.000/0.000/0.000|
|capture_mutable_reference|activate|23.283|21.072|230.085|0.931|0.905|0.093|0.092|160.000/160.000/152.000|
|capture_mutable_reference|activation_first|57.093|40.837|438.619|0.851|0.715|0.118|0.093|160.000/160.000/152.000|
|capture_mutable_reference|nested_invoke|8.029|7.487|3.484|0.939|0.932|2.073|2.149|0.000/0.000/0.000|

