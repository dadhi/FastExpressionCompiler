"""Diagnostic only; never run during an elapsed measurement window.
Official configuration reference:
https://github.com/dotnet/runtime/blob/main/docs/design/coreclr/jit/viewing-jit-dumps.md
No optimization/alignment changes; bounded shipped-JIT method-name filtering.
"""
from pathlib import Path
import subprocess,os
p=Path(__file__).resolve().parent
for runtime in ['net8.0','net10.0']:
 for case in ['add','capture1']:
  tag='native-'+runtime+'-standard-'+case
  env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0',
    DOTNET_JitDisasm='*Curry* *ArrayClosure*:* *dynamicClass*:*',DOTNET_JitDisasmDiffable='1',
    DOTNET_JitStdOutFile=str(p/(tag+'.dasm')))
  with (p/(tag+'.jsonl')).open('w',encoding='utf-8') as out,(p/(tag+'.log')).open('w',encoding='utf-8') as log:
   subprocess.run(['dotnet',str(p/'bin/standard'/runtime/'RuntimeParity.standard.dll'),'canonical','0','11',case],env=env,stdout=out,stderr=log,check=True)
  target=p/(tag+'.dasm')
  print(tag,'bytes',target.stat().st_size if target.exists() else 'NO FILTER MATCH',flush=True)
