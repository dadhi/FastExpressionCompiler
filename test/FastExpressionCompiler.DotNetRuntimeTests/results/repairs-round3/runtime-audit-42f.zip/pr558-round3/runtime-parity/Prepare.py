from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parent;w=p.parent.parent
frozen=w/'pr558-round2/integrated'
manifest={'versions':{'before':'e4c232da108d98790f0ca73f23ec90756da0cad7','current':'42f9847843cec8edaaf11c00cb97a5dd576b82cf'},'productionCurrent':'db640cba760028d1c49ad5e4abf67f38fe683bbf','sourceHashes':{}}
for flavor in ['standard','light']:
 for version,origin in [('before','before'),('current','fixed')]:
  dest=p/flavor/version;dest.mkdir(parents=True,exist_ok=True)
  names=['FastExpressionCompiler.cs','ImTools.cs','ILReader.cs']+(['Expression.cs','ExpressionVisitor.cs','FlatExpression.cs'] if flavor=='light' else [])
  for name in names:
   data=(frozen/origin/flavor/name).read_bytes();(dest/name).write_bytes(data)
   manifest['sourceHashes'][str((dest/name).relative_to(p))]=hashlib.sha256(data).hexdigest()
  define='<DefineConstants>LIGHT_EXPRESSION</DefineConstants>' if flavor=='light' else ''
  (dest/'Library.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><AssemblyName>RuntimeParity.'+version+'.'+flavor+'</AssemblyName>'+define+'</PropertyGroup></Project>',encoding='utf-8')
 define='<DefineConstants>LIGHT</DefineConstants>' if flavor=='light' else ''
 (p/(flavor+'.csproj')).write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><OutputType>Exe</OutputType><LangVersion>latest</LangVersion><Optimize>true</Optimize><EnableDefaultCompileItems>false</EnableDefaultCompileItems><AssemblyName>RuntimeParity.'+flavor+'</AssemblyName><BaseIntermediateOutputPath>obj/'+flavor+'/</BaseIntermediateOutputPath><OutputPath>bin/'+flavor+'/</OutputPath>'+define+'</PropertyGroup><ItemGroup><Compile Include="Trees.cs"/><Compile Include="Program.cs"/><Compile Include="Canonical.cs"/><ProjectReference Include="'+flavor+'/before/Library.csproj" Aliases="Before"/><ProjectReference Include="'+flavor+'/current/Library.csproj" Aliases="Current"/></ItemGroup></Project>',encoding='utf-8')
source=(frozen/'Program.cs').read_text(encoding='utf-8')
types=source[source.index('public class Box'):source.index('public static class Program')]
build=source[source.index(' static X Balanced'):source.index(' static Delegate Compile')]
start=build.index('   case "runtime_variables":');end=build.index('   default:throw',start)
build=build[:start]+'   case "runtime_variables":return E.Lambda<Func<int,IRuntimeVariables>>(E.RuntimeVariables(x),x);\n'+build[end:]
trees='using System;\nusing System.Linq;\nusing System.Collections.Generic;\nusing System.Runtime.CompilerServices;\nusing E=System.Linq.Expressions.Expression;\nusing X=System.Linq.Expressions.Expression;\nusing L=System.Linq.Expressions.LambdaExpression;\n'+types+'public static partial class Program {\n public static int AddRef(ref int value)=>++value;\n'+build+'}\n'
(p/'Trees.cs').write_text(trees,encoding='utf-8')
(p/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Prepared distinct-identity frozen libraries and exact shared System trees; no builds/run.')
