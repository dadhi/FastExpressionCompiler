from pathlib import Path
import re,json,hashlib
p=Path(__file__).resolve().parent;result=[]
for runtime in ['net8.0','net10.0']:
 for case in ['add','capture1']:
  text=(p/('native-'+runtime+'-standard-'+case+'.dasm')).read_text(encoding='utf-8')
  blocks=re.split(r'(?=; Assembly listing for method )',text)
  targets={'add':'FastExpressionCompiler.ExpressionCompiler+ArrayClosure:(FastExpressionCompiler.ExpressionCompiler+ArrayClosure,int):int (FullOpts)'} if case=='add' else {
    'outer':'FastExpressionCompiler.ExpressionCompiler+ArrayClosure:(FastExpressionCompiler.ExpressionCompiler+ArrayClosure,int):System.Func`1[int] (FullOpts)',
    'child':'FastExpressionCompiler.ExpressionCompiler+ArrayClosure:(FastExpressionCompiler.ExpressionCompiler+ArrayClosure):int (FullOpts)',
    'curry':'FastExpressionCompiler.ExpressionCompiler+CurryClosureFuncs+<>c__DisplayClass1_0`2[System.__Canon,int]:<Curry>b__0():int:this (FullOpts)'}
  for name,header in targets.items():
   selected=[block.strip() for block in blocks if block.startswith('; Assembly listing for method '+header+'\n')]
   assert len(selected)==2,(runtime,case,name,len(selected))
   result.append(dict(runtime=runtime,case=case,method=name,nativeTextDiffableEqual=selected[0]==selected[1],
     codeBytes=[int(re.search(r'Total bytes of code (\d+)',x).group(1)) for x in selected],
     textSHA256=[hashlib.sha256(x.encode()).hexdigest() for x in selected],
     caveat='Separate diagnostic process; diffable output replaces pointer values. Does not establish same addresses/alignment/native results in timed process.'))
(p/'native-analysis.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print('Native method-pair comparisons:',len(result))
