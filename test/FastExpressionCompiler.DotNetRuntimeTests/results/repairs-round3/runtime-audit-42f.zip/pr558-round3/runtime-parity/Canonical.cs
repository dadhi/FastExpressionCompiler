using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using System.Globalization;
using System.Runtime.CompilerServices;

static class Canonical {
 const BindingFlags Flags=BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance|BindingFlags.Static;
 static readonly Dictionary<ushort,OpCode> Opcodes=typeof(OpCodes).GetFields(BindingFlags.Public|BindingFlags.Static).Where(f=>f.FieldType==typeof(OpCode)).Select(f=>(OpCode)f.GetValue(null)).ToDictionary(o=>unchecked((ushort)o.Value));
 static string Normalize(string s)=>s==null?null:s.Replace("RuntimeParity.before.standard","CompilerSnapshot.standard").Replace("RuntimeParity.current.standard","CompilerSnapshot.standard").Replace("RuntimeParity.before.light","CompilerSnapshot.light").Replace("RuntimeParity.current.light","CompilerSnapshot.light");
 static string TypeName(Type t)=>t==null?"<null>":Normalize(t.AssemblyQualifiedName);
 static string Member(MemberInfo member){
  if(member is Type type)return TypeName(type);
  if(member is FieldInfo field)return "FIELD "+TypeName(field.DeclaringType)+"::"+field.Name+":"+TypeName(field.FieldType);
  if(member is MethodBase method)return "METHOD "+TypeName(method.DeclaringType)+"::"+method.Name+(method.IsGenericMethod?"<"+string.Join(",",method.GetGenericArguments().Select(TypeName))+">":"")+"("+string.Join(",",method.GetParameters().Select(p=>TypeName(p.ParameterType)))+"):"+(method is MethodInfo info?TypeName(info.ReturnType):"void");
  return "UNKNOWN MEMBER "+member;
 }
 static object Field(object value,params string[] names){
  if(value==null)return null;
  for(Type t=value.GetType();t!=null;t=t.BaseType)foreach(string name in names){var f=t.GetField(name,Flags|BindingFlags.DeclaredOnly);if(f!=null)return f.GetValue(value);}
  return null;
 }
 static string Token(object token,ref bool known){
  try {
   if(token==null)return "null";
   if(token is string text)return "STRING "+Json.Write(text);
   if(token is MemberInfo member)return Member(member);
   if(token is RuntimeTypeHandle th)return "TYPE "+TypeName(Type.GetTypeFromHandle(th));
   if(token is RuntimeMethodHandle mh)return Member(MethodBase.GetMethodFromHandle(mh));
   if(token is RuntimeFieldHandle fh)return Member(FieldInfo.GetFieldFromHandle(fh));
   if(token is byte[] signature){known=false;return "UNRESOLVED SIGNATURE "+Hex(signature);}
   var fields=token.GetType().GetFields(Flags|BindingFlags.DeclaredOnly);
   var contexts=fields.Where(f=>f.FieldType==typeof(RuntimeTypeHandle)).ToArray();
   var methods=fields.Where(f=>f.FieldType==typeof(RuntimeMethodHandle)).ToArray();
   var members=fields.Where(f=>f.FieldType==typeof(RuntimeFieldHandle)).ToArray();
   if(contexts.Length==1&&methods.Length==1)return Member(MethodBase.GetMethodFromHandle((RuntimeMethodHandle)methods[0].GetValue(token),(RuntimeTypeHandle)contexts[0].GetValue(token)));
   if(contexts.Length==1&&members.Length==1)return Member(FieldInfo.GetFieldFromHandle((RuntimeFieldHandle)members[0].GetValue(token),(RuntimeTypeHandle)contexts[0].GetValue(token)));
  } catch(Exception e){known=false;return "TOKEN ERROR "+e.GetType().Name;}
  known=false;return "UNKNOWN TOKEN "+token.GetType().FullName;
 }
 static string Hex(byte[] code)=>code==null?"<null>":BitConverter.ToString(code).Replace("-","");
 static string Decode(byte[] code,Func<int,string> resolve){
  var result=new List<string>();
  for(int i=0;i<code.Length;){int offset=i;ushort number=code[i++];if(number==0xfe)number=(ushort)(0xfe00|code[i++]);var op=Opcodes[number];string operand="";
   switch(op.OperandType){
    case OperandType.InlineNone:break;
    case OperandType.ShortInlineI:operand=unchecked((sbyte)code[i++]).ToString();break;
    case OperandType.ShortInlineVar:operand=code[i++].ToString();break;
    case OperandType.InlineVar:operand=BitConverter.ToUInt16(code,i).ToString();i+=2;break;
    case OperandType.ShortInlineBrTarget:operand=(i+1+unchecked((sbyte)code[i])).ToString();i++;break;
    case OperandType.InlineBrTarget:operand=(i+4+BitConverter.ToInt32(code,i)).ToString();i+=4;break;
    case OperandType.InlineI:operand=BitConverter.ToInt32(code,i).ToString();i+=4;break;
    case OperandType.InlineI8:operand=BitConverter.ToInt64(code,i).ToString();i+=8;break;
    case OperandType.ShortInlineR:operand=BitConverter.ToSingle(code,i).ToString("R",CultureInfo.InvariantCulture);i+=4;break;
    case OperandType.InlineR:operand=BitConverter.ToDouble(code,i).ToString("R",CultureInfo.InvariantCulture);i+=8;break;
    case OperandType.InlineSwitch:{int count=BitConverter.ToInt32(code,i);i+=4;int end=i+4*count;var labels=new List<int>();for(int k=0;k<count;k++){labels.Add(end+BitConverter.ToInt32(code,i));i+=4;}operand=string.Join(",",labels);break;}
    default:operand=resolve(BitConverter.ToInt32(code,i));i+=4;break;
   }result.Add(offset+":"+op.Name+" "+operand);
  }return string.Join("\n",result);
 }
 static int Compressed(byte[] s,ref int i){int b=s[i++];if((b&0x80)==0)return b;if((b&0xc0)==0x80)return ((b&0x3f)<<8)|s[i++];return ((b&0x1f)<<24)|(s[i++]<<16)|(s[i++]<<8)|s[i++];}
 static string SigType(byte[] s,ref int i){
  int tag=s[i++];string[] primitive={null,"void","bool","char","int8","uint8","int16","uint16","int32","uint32","int64","uint64","float32","float64","string"};
  if(tag>0&&tag<primitive.Length)return primitive[tag];
  if(tag==0x10)return "byref("+SigType(s,ref i)+")";
  if(tag==0x0f)return "ptr("+SigType(s,ref i)+")";
  if(tag==0x1d)return "array("+SigType(s,ref i)+")";
  if(tag==0x45)return "pinned("+SigType(s,ref i)+")";
  if(tag==0x18)return "intptr";if(tag==0x19)return "uintptr";if(tag==0x1c)return "object";
  if(tag==0x21){
   long address=IntPtr.Size==8?BitConverter.ToInt64(s,i):BitConverter.ToInt32(s,i);i+=IntPtr.Size;
   var from=typeof(RuntimeTypeHandle).GetMethod("FromIntPtr",BindingFlags.Public|BindingFlags.Static);
   object handle=from!=null?from.Invoke(null,new object[]{new IntPtr(address)}):typeof(RuntimeTypeHandle).GetConstructor(Flags,null,new[]{typeof(IntPtr)},null)?.Invoke(new object[]{new IntPtr(address)});
   if(handle==null)throw new NotSupportedException("Cannot normalize internal local type handle");
   return TypeName(Type.GetTypeFromHandle((RuntimeTypeHandle)handle));
  }
  throw new NotSupportedException("Local signature tag "+tag);
 }
 static string Locals(byte[] signature,ref bool known){
  if(signature==null){known=false;return "UNAVAILABLE";}
  try {int i=0;int header=signature[i++];if(header!=7)throw new NotSupportedException("Local signature header");int count=Compressed(signature,ref i);var types=new List<string>();for(int j=0;j<count;j++)types.Add(SigType(signature,ref i));return string.Join(";",types)+"|tail="+Hex(signature.Skip(i).ToArray());}
  catch(Exception e){known=false;return "UNRESOLVED "+e.GetType().Name+":"+e.Message+" raw="+Hex(signature);}
 }
 static object ExceptionData(object value,ref bool known,int depth=0){
  if(value==null)return null;
  if(depth>6){known=false;return "DEPTH LIMIT";}
  if(value is Type type)return TypeName(type);
  if(value.GetType().IsPrimitive||value is string)return value;
  if(value is Array array){var items=new List<object>();foreach(var x in array)items.Add(ExceptionData(x,ref known,depth+1));return items;}
  var result=new SortedDictionary<string,object>();
  foreach(var f in value.GetType().GetFields(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic).OrderBy(f=>f.Name))result[f.Name]=ExceptionData(f.GetValue(value),ref known,depth+1);
  if(result.Count==0){known=false;return "UNKNOWN EH "+value.GetType().FullName;}return result;
 }
 static object Method(MethodInfo original){
  bool known=true;var method=original;
  var owner=Field(method,"m_owner","_owner") as DynamicMethod;if(owner!=null)method=owner;
  string code,locals;object eh;int? stack=null;bool? init=null;string host;
  if(method is DynamicMethod dynamic){
   var resolver=Field(dynamic,"_resolver","m_resolver");
   if(resolver==null)throw new NotSupportedException("No finalized dynamic resolver");
   var bytes=(byte[])Field(resolver,"m_code","_code");var scope=Field(resolver,"m_scope","_scope");var tokens=(IList)Field(scope,"m_tokens","_tokens");
   code=Decode(bytes,t=>Token(tokens[t&0xffffff],ref known));
   locals=Locals((byte[])Field(resolver,"m_localSignature","_localSignature"),ref known);
   eh=ExceptionData(Field(resolver,"m_exceptions","_exceptions"),ref known);
   var raw=Field(resolver,"m_exceptionHeader","_exceptionHeader");if(raw!=null)eh=new object[]{eh,ExceptionData(raw,ref known)};
   var max=Field(resolver,"m_stackSize","_stackSize");if(max is int size)stack=size;
   init=dynamic.InitLocals;
   host=Normalize(dynamic.Module.Assembly.FullName)+"|owner="+TypeName(Field(dynamic,"m_typeOwner","_typeOwner") as Type)+"|restricted="+Field(dynamic,"m_restrictedSkipVisibility","_restrictedSkipVisibility")+"|skip="+Field(dynamic,"m_skipVisibility","_skipVisibility");
  }else{
   var body=method.GetMethodBody();if(body==null)throw new NotSupportedException("No method body");
   var module=method.Module;var typeArgs=method.DeclaringType?.GetGenericArguments();var methodArgs=method.IsGenericMethod?method.GetGenericArguments():null;
   code=Decode(body.GetILAsByteArray(),t=>{
    try{if((t&unchecked((int)0xff000000))==0x70000000)return "STRING "+Json.Write(module.ResolveString(t));return Member(module.ResolveMember(t,typeArgs,methodArgs));}catch(Exception e){known=false;return "UNRESOLVED "+t+":"+e.GetType().Name;}});
   locals=string.Join(";",body.LocalVariables.Select(v=>v.LocalIndex+":"+TypeName(v.LocalType)+":"+v.IsPinned));
   eh=body.ExceptionHandlingClauses.Select(c=>new {Flags=c.Flags.ToString(),c.TryOffset,c.TryLength,c.HandlerOffset,c.HandlerLength,Filter=c.Flags==ExceptionHandlingClauseOptions.Filter?c.FilterOffset:-1,Catch=c.Flags==ExceptionHandlingClauseOptions.Clause?TypeName(c.CatchType):null}).ToArray();
   stack=body.MaxStackSize;init=body.InitLocals;host=Normalize(module.Assembly.FullName)+"|owner="+TypeName(method.DeclaringType);
  }
  return new {Known=known,Signature=TypeName(method.ReturnType)+"("+string.Join(",",method.GetParameters().Select(x=>TypeName(x.ParameterType)))+")",Instructions=code,Locals=locals,EH=eh,MaxStack=stack,InitLocals=init,Host=host,MethodKind=method.GetType().FullName};
 }
 public static object Delegates(Delegate root){
  var result=new SortedDictionary<string,object>();var queue=new Queue<Tuple<string,Delegate>>();var seen=new List<Delegate>();queue.Enqueue(Tuple.Create("outer",root));
  if(root is Func<int,Func<int>> factory)queue.Enqueue(Tuple.Create("child",(Delegate)factory(3)));
  while(queue.Count!=0){var item=queue.Dequeue();string path=item.Item1;var d=item.Item2;if(seen.Any(x=>ReferenceEquals(x,d)))continue;seen.Add(d);
   object data;try{data=Method(d.Method);}catch(Exception e){data=new {Known=false,Error=e.GetType().Name+":"+e.Message};}
   result[path]=new {Target=TypeName(d.Target?.GetType()),DelegateType=TypeName(d.GetType()),Method=data};
   if(d.Target==null)continue;
   foreach(var field in d.Target.GetType().GetFields(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic).OrderBy(f=>f.Name)){
    var value=field.GetValue(d.Target);if(value is Delegate child)queue.Enqueue(Tuple.Create(path+"."+field.Name,child));
    else if(value is object[] entries)for(int i=0;i<entries.Length;i++)if(entries[i] is Delegate entry)queue.Enqueue(Tuple.Create(path+"."+field.Name+"["+i+"]",entry));
   }
  }return result;
 }
}
