from pathlib import Path
import subprocess,os,json,hashlib
p=Path(__file__).resolve().parent
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
for runtime in ['net8.0','net10.0','net472']:
 for flavor in ['standard','light']:
  exe=p/'bin'/flavor/runtime/('RuntimeParity.'+flavor+('.exe' if runtime=='net472' else '.dll'))
  command=[str(exe)] if runtime=='net472' else ['dotnet',str(exe)]
  for mode in ['controls','canonical']:
   tag=mode+'-'+runtime+'-'+flavor
   with (p/(tag+'.jsonl')).open('w',encoding='utf-8') as out,(p/(tag+'.log')).open('w',encoding='utf-8') as log:
    subprocess.run(command+[mode,'0','11'],env=env,stdout=out,stderr=log,check=True)
   print('PASS',tag,flush=True)
manifest=json.loads((p/'manifest.json').read_text(encoding='utf-8'))
manifest.update(controlsCompleted=True,canonicalCompleted=True,
    runnerHashes={name:hashlib.sha256((p/name).read_bytes()).hexdigest() for name in ['Program.cs','Canonical.cs','Trees.cs']},
    assemblyHashes={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in (p/'bin').rglob('RuntimeParity.*') if f.suffix in ['.exe','.dll']})
(p/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
