from pathlib import Path
import subprocess,os,json,sys
p=Path(__file__).resolve().parent
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
# All runs execute only after a coordinated exclusive CPU window is released.
# Optional args select one runtime/flavor; default schedule covers all six.
schedule=[(r,f) for r in ['net8.0','net10.0','net472'] for f in ['standard','light']]
if len(sys.argv)>1:schedule=[x for x in schedule if x[0]==sys.argv[1] and (len(sys.argv)<3 or x[1]==sys.argv[2])]
for runtime,flavor in schedule:
 exe=p/'bin'/flavor/runtime/('RuntimeParity.'+flavor+('.exe' if runtime=='net472' else '.dll'))
 command=[str(exe)] if runtime=='net472' else ['dotnet',str(exe)]
 tag='runtime-'+runtime+'-'+flavor
 print('START',tag,flush=True)
 with (p/(tag+'.jsonl')).open('w',encoding='utf-8') as out,(p/(tag+'.log')).open('w',encoding='utf-8') as log:
  subprocess.run(command+['measure','0','11'],env=env,stdout=out,stderr=log,check=True)
 rows=[json.loads(s) for s in (p/(tag+'.jsonl')).read_text(encoding='utf-8').splitlines()]
 print('COMPLETE',tag,'rows',len(rows),'minimumMs',min(r['ElapsedMs'] for r in rows),'under20ms',sum(r['Under20Ms'] for r in rows),flush=True)
print('Measurement process ended; coordinate explicit CPU-window release with parent.',flush=True)
