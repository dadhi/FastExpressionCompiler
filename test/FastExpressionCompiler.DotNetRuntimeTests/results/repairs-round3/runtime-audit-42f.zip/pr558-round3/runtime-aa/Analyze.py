from pathlib import Path
from collections import defaultdict
import json,statistics,hashlib
p=Path(__file__).resolve().parent
result=[];raw=[]
for file in sorted(p.glob('measure-*.jsonl')):
 rows=[json.loads(s) for s in file.read_text(encoding='utf-8').splitlines()];raw.extend(rows)
 groups=defaultdict(dict)
 for r in rows:groups[(r['Scenario'],r['Phase'])].setdefault(r['SampleIndex'],{})[r['Version']]=r
 for (case,phase),samples in groups.items():
  assert len(samples)==11
  for x in samples.values():assert set(x)=={'current_A','current_B'}
  a=[samples[i]['current_A'] for i in sorted(samples)];b=[samples[i]['current_B'] for i in sorted(samples)]
  result.append(dict(file=file.name,case=case,phase=phase,pairedRatios=[y['NsPerOp']/x['NsPerOp'] for x,y in zip(a,b)],
      pairedMedian=statistics.median(y['NsPerOp']/x['NsPerOp'] for x,y in zip(a,b)),ratioOfNsMedians=statistics.median(y['NsPerOp'] for y in b)/statistics.median(x['NsPerOp'] for x in a),
      versions={v:dict(nsMedian=statistics.median(x['NsPerOp'] for x in data),ns=[x['NsPerOp'] for x in data],bytesMedian=statistics.median(x['BytesPerOp'] for x in data),bytes=[x['BytesPerOp'] for x in data],elapsedMs=[x['ElapsedMs'] for x in data],operations=[x['Operations'] for x in data]) for v,data in [('current_A',a),('current_B',b)]}))
canonical=[]
for f in p.glob('canonical-*.jsonl'):
 versions=defaultdict(dict)
 for s in f.read_text(encoding='utf-8').splitlines():
  r=json.loads(s);versions[r['Scenario']][r['Version']]=r['Nodes']
 for case,vs in versions.items():
  a=vs['current_A'];b=vs['current_B'];paths=[]
  for path in sorted(set(a)|set(b)):
   if path not in a or path not in b:paths.append(dict(path=path,known=False,reason='graph differs'));continue
   x=a[path]['Method'];y=b[path]['Method'];known=x.get('Known',False) and y.get('Known',False)
   diffs=[k for k in ['Instructions','Signature','Locals','EH','MaxStack','InitLocals','Host'] if x.get(k)!=y.get(k)]
   paths.append(dict(path=path,known=known,fieldsDifferent=diffs,parity=known and not diffs))
  canonical.append(dict(file=f.name,case=case,paths=paths))
(p/'analysis.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
(p/'canonical-analysis.json').write_text(json.dumps(canonical,indent=2)+'\n',encoding='utf-8')
text='''# Current/current same-AST runtime diagnostic

Both independently compiled delegates use current42f. Five shapes, eleven phases per configuration; six configurations. Ratio B/A pair is the median of paired ratios; B/A med is the ratio of ns medians. No alignment changes, source optimization, sample filtering or additional repeats. Exact same AST object is reused, including one shared converted Light AST. System is correctness oracle only, not timed in this diagnostic.

This is evidence about independent-target/process/JIT context variation. It does not mathematically subtract from versioned measurements or prove every version-pair cost unrelated to compiler changes. Native/address/host effects must remain distinguished. Framework internal local-handle normalization remains explicitly unknown where unsupported.

'''
text+=f'{len(raw)} raw samples, {len(result)} phase summaries; samples<20ms={sum(r["Under20Ms"] for r in raw)}, minimum={min(r["ElapsedMs"] for r in raw):.3f}ms. All raw rows are retained.\n\n'
for f in sorted({r['file'] for r in result}):
 text+='## '+f+'\n\n| Shape | Phase | A ns | B ns | B/A pair | B/A med | Bytes A/B |\n|---|---|---:|---:|---:|---:|---:|\n'
 for r in [x for x in result if x['file']==f]:
  v=r['versions'];text+=f'|{r["case"]}|{r["phase"]}|{v["current_A"]["nsMedian"]:.3f}|{v["current_B"]["nsMedian"]:.3f}|{r["pairedMedian"]:.3f}|{r["ratioOfNsMedians"]:.3f}|{v["current_A"]["bytesMedian"]:.3f}/{v["current_B"]["bytesMedian"]:.3f}|\n'
 text+='\n'
(p/'REPORT.md').write_text(text,encoding='utf-8')
m=json.loads((p/'manifest.json').read_text(encoding='utf-8'));m.update(timingsRun=True,samples=len(raw),phaseSummaries=len(result),samplesBelow20ms=sum(r['Under20Ms'] for r in raw),runnerSHA256=hashlib.sha256((p/'Program.cs').read_bytes()).hexdigest());(p/'manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8')
print('A/A samples',len(raw),'phase rows',len(result),'under20ms',sum(r['Under20Ms'] for r in raw))
print('Largest pair costs',[(r['file'],r['case'],r['phase'],round(r['pairedMedian'],3),round(r['ratioOfNsMedians'],3)) for r in sorted(result,key=lambda x:x['pairedMedian'],reverse=True)[:12]])
print('Smallest pair ratios',[(r['file'],r['case'],r['phase'],round(r['pairedMedian'],3),round(r['ratioOfNsMedians'],3)) for r in sorted(result,key=lambda x:x['pairedMedian'])[:8]])
