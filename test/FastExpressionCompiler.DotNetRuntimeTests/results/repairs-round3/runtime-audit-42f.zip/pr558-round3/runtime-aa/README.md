# Same-compiler current/current runtime control

Five selected cases: add, array, capture1, capture8 and mutable capture. Both independently compiled delegates use current42f production source and the exact same AST object; Light converts the shared System AST only once before compiling twice. This is a diagnostic, not a production candidate. No alignment adjustments, result filtering or optimization flags beyond the primary suite's TieredCompilation=0/ReadyToRun=0.

The shared primary runtime driver is retained: same operation count for both versions calibrated to≥40ms for the faster, eleven alternating sample orders, direct invocation, activation, activation+first child call and preactivated child invocation. Absolute ns and all raw allocation/GC/duration data are retained. Existing System correctness oracle verifies both delegates before timing.

This tests target placement and process/JIT context variability in independently compiled same-compiler delegates. It cannot prove that a versioned difference is never caused by compiler output or certify native equivalence. Separate snapshot helper assemblies in the primary run remain a different context.

Prepared only after the primary six-group window ended. Reproduce Prepare.py, Build.ps1, Run.py controls, Run.py canonical, then Run.py measure only in the parent's coordinated exclusive window. No further variants/repeats.
