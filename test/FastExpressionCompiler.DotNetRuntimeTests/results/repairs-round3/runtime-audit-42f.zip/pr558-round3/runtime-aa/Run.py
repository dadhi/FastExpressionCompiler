from pathlib import Path
import subprocess,os,sys,json
p=Path(__file__).resolve().parent
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
mode=sys.argv[1] if len(sys.argv)>1 else 'controls'
for runtime in ['net8.0','net10.0','net472']:
 for flavor in ['standard','light']:
  exe=p/'bin'/flavor/runtime/('RuntimeAA.'+flavor+('.exe' if runtime=='net472' else '.dll'))
  command=[str(exe)] if runtime=='net472' else ['dotnet',str(exe)]
  tag=mode+'-'+runtime+'-'+flavor;print('START',tag,flush=True)
  with (p/(tag+'.jsonl')).open('w',encoding='utf-8') as out,(p/(tag+'.log')).open('w',encoding='utf-8') as log:
   subprocess.run(command+[mode,'0','11'],env=env,stdout=out,stderr=log,check=True)
  rows=[json.loads(s) for s in (p/(tag+'.jsonl')).read_text(encoding='utf-8').splitlines()]
  print('COMPLETE',tag,'rows',len(rows),flush=True)
