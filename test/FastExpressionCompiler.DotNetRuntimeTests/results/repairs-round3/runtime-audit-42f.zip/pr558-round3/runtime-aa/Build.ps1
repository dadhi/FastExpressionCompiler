$ErrorActionPreference='Stop'
foreach($flavor in @('standard','light')) {
 dotnet build (Join-Path $PSScriptRoot "$flavor.csproj") -c Release --nologo -v:q -m:1 -nodeReuse:false *> (Join-Path $PSScriptRoot "build-$flavor.log")
 if($LASTEXITCODE){Get-Content (Join-Path $PSScriptRoot "build-$flavor.log");throw "Build failed $flavor"}
}
Write-Output 'A/A diagnostic built all targets; no execution.'
