from pathlib import Path
import re,json,hashlib
p=Path(__file__).resolve().parent;origin=p.parent/'runtime-parity'
s=(origin/'Program.cs').read_text(encoding='utf-8')
s=s.replace('static readonly string[] Versions={"before","current","system"};','static readonly string[] Versions={"current_A","current_B"};')
s=re.sub(r'static readonly string\[\] Cases=\{[^\n]+\};','static readonly string[] Cases={"add","array","capture1","capture8","capture_mutable"};',s)
a=s.index(' static Delegate Compile(');b=s.index(' static string Verify(',a)
compile='''#if LIGHT
 static L cachedSource;
 static Current::FastExpressionCompiler.LightExpression.LambdaExpression cachedLight;
#endif
 static Delegate Compile(L tree,int version) {
#if LIGHT
  if(!ReferenceEquals(cachedSource,tree)){cachedSource=tree;cachedLight=Current::FastExpressionCompiler.LightExpression.FromSysExpressionConverter.ToLightExpression(tree);}
  return Current::FastExpressionCompiler.LightExpression.ExpressionCompiler.CompileFast(cachedLight,true);
#else
  return Current::FastExpressionCompiler.ExpressionCompiler.CompileFast(tree,true);
#endif
 }
'''
s=s[:a]+compile+s[b:]
s=s.replace('<3','<2').replace('%3','%2').replace('new Delegate[3]','new Delegate[2]')
s=re.sub(r'int\[\]\[\] orders=\{[^\n]+\};','int[][] orders={new[]{0,1},new[]{1,0}};',s)
s=s.replace('string oracle=Verify(delegates[2]);','string oracle=Verify(tree.Compile());')
(p/'Program.cs').write_text(s,encoding='utf-8')
for flavor in ['standard','light']:
 define='<DefineConstants>LIGHT</DefineConstants>' if flavor=='light' else ''
 (p/(flavor+'.csproj')).write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><OutputType>Exe</OutputType><LangVersion>latest</LangVersion><Optimize>true</Optimize><EnableDefaultCompileItems>false</EnableDefaultCompileItems><AssemblyName>RuntimeAA.'+flavor+'</AssemblyName><BaseIntermediateOutputPath>obj/'+flavor+'/</BaseIntermediateOutputPath><OutputPath>bin/'+flavor+'/</OutputPath>'+define+'</PropertyGroup><ItemGroup><Compile Include="../runtime-parity/Trees.cs"/><Compile Include="Program.cs"/><Compile Include="../runtime-parity/Canonical.cs"/><ProjectReference Include="../runtime-parity/'+flavor+'/before/Library.csproj" Aliases="Before"/><ProjectReference Include="../runtime-parity/'+flavor+'/current/Library.csproj" Aliases="Current"/></ItemGroup></Project>',encoding='utf-8')
(p/'Build.ps1').write_text((origin/'Build.ps1').read_text(encoding='utf-8').replace('Runtime-only runner','A/A diagnostic'),encoding='utf-8')
(p/'manifest.json').write_text(json.dumps(dict(current='42f9847843cec8edaaf11c00cb97a5dd576b82cf',cases=['add','array','capture1','capture8','capture_mutable'],versions=['current_A','current_B'],sameAST=True,lightASTConvertedOnce=True,independentCompilations=True,sourceSHA256=hashlib.sha256(s.encode()).hexdigest(),timingsRun=False),indent=2)+'\n',encoding='utf-8')
print('Prepared current/current same-AST diagnostic, no source optimization/alignment/filtering.')
