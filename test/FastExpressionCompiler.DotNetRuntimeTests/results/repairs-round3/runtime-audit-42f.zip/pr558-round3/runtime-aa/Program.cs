extern alias Before;
extern alias Current;
using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Globalization;
using System.IO;
using L=System.Linq.Expressions.LambdaExpression;

public static partial class Program {
 static object sink;static long checksum;
 static readonly string[] Versions={"current_A","current_B"};
 static readonly string[] Cases={"add","array","capture1","capture8","capture_mutable"};
#if LIGHT
 static L cachedSource;
 static Current::FastExpressionCompiler.LightExpression.LambdaExpression cachedLight;
#endif
 static Delegate Compile(L tree,int version) {
#if LIGHT
  if(!ReferenceEquals(cachedSource,tree)){cachedSource=tree;cachedLight=Current::FastExpressionCompiler.LightExpression.FromSysExpressionConverter.ToLightExpression(tree);}
  return Current::FastExpressionCompiler.LightExpression.ExpressionCompiler.CompileFast(cachedLight,true);
#else
  return Current::FastExpressionCompiler.ExpressionCompiler.CompileFast(tree,true);
#endif
 }
 static string Verify(Delegate d){
  var parts=new List<string>();foreach(int x in new[]{-2,0,3}){
   if(d is Func<int,int> scalar)parts.Add(scalar(x).ToString(CultureInfo.InvariantCulture));
   else {var child=((Func<int,Func<int>>)d)(x);parts.Add(child()+":"+child());}
  }return string.Join("|",parts);
 }
 [MethodImpl(MethodImplOptions.NoInlining)]static Action<int> ScalarDriver(Func<int,int> f)=>n=>{long value=0;for(int i=0;i<n;i++)value+=f(3);checksum=value;};
 [MethodImpl(MethodImplOptions.NoInlining)]static Action<int> NestedDriver(Func<int> f)=>n=>{long value=0;for(int i=0;i<n;i++)value+=f();checksum=value;};
 [MethodImpl(MethodImplOptions.NoInlining)]static Action<int> ActivateDriver(Func<int,Func<int>> f)=>n=>{for(int i=0;i<n;i++)sink=f(3);};
 [MethodImpl(MethodImplOptions.NoInlining)]static Action<int> ActivateFirstDriver(Func<int,Func<int>> f)=>n=>{long value=0;for(int i=0;i<n;i++){var child=f(3);sink=child;value+=child();}checksum=value;};
 static string CounterName;
 static readonly Func<long> AllocationCounter=CreateAllocationCounter();
 static Func<long> CreateAllocationCounter(){
  var m=typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread",BindingFlags.Public|BindingFlags.Static);
  if(m!=null){CounterName="GC.GetAllocatedBytesForCurrentThread";return (Func<long>)Delegate.CreateDelegate(typeof(Func<long>),m);}
#if NETFRAMEWORK
  AppDomain.MonitoringIsEnabled=true;CounterName="AppDomain.MonitoringTotalAllocatedMemorySize";return ()=>AppDomain.CurrentDomain.MonitoringTotalAllocatedMemorySize;
#else
  throw new NotSupportedException("No managed allocation counter");
#endif
 }
 static void RunPhase(string scenario,string phase,int round,Action<int>[] ops,int samples){
  foreach(var op in ops)op(1024);
  int operations=16384;int calibration=0;
  while(true){
   double fastest=double.MaxValue;
   for(int j=0;j<2;j++){int v=(j+calibration)%2;long t=Stopwatch.GetTimestamp();ops[v](operations);double ms=(Stopwatch.GetTimestamp()-t)*1000.0/Stopwatch.Frequency;fastest=Math.Min(fastest,ms);}
   if(fastest>=40)break;
   if(operations>=536870912)throw new Exception("Calibration cannot reach40ms without overflow");
   operations=checked(operations*2);calibration++;
  }
  int[][] orders={new[]{0,1},new[]{1,0}};
  for(int k=0;k<samples;k++)foreach(int v in orders[(k+round)%orders.Length]){
   int g0=GC.CollectionCount(0),g1=GC.CollectionCount(1),g2=GC.CollectionCount(2);
   long allocated=AllocationCounter();long start=Stopwatch.GetTimestamp();ops[v](operations);long elapsed=Stopwatch.GetTimestamp()-start;long bytes=AllocationCounter()-allocated;
   double milliseconds=elapsed*1000.0/Stopwatch.Frequency;
   Console.WriteLine(Json.Write(new {Kind="sample",Version=Versions[v],Runtime=Environment.Version.ToString(),Flavor=Flavor,Scenario=scenario,Phase=phase,Round=round,SampleIndex=k,Operations=operations,ElapsedMs=milliseconds,NsPerOp=elapsed*1e9/Stopwatch.Frequency/operations,Bytes=bytes,BytesPerOp=bytes/(double)operations,AllocationCounter=CounterName,Gen0=GC.CollectionCount(0)-g0,Gen1=GC.CollectionCount(1)-g1,Gen2=GC.CollectionCount(2)-g2,Checksum=checksum,Under20Ms=milliseconds<20}));
  }
 }
 static string Flavor {
  get {
#if LIGHT
   return "light";
#else
   return "standard";
#endif
  }
 }
 public static void Main(string[] args){
  string mode=args.Length==0?"controls":args[0];int round=args.Length>1?int.Parse(args[1]):0;int samples=args.Length>2?int.Parse(args[2]):11;
  var names=args.Length>3?Cases.Where(n=>args.Skip(3).Contains(n)).ToArray():Cases;
  if(round%2!=0)Array.Reverse(names);
  foreach(var name in names){
   var tree=Build(name);var delegates=new Delegate[2];
   for(int j=0;j<2;j++){int v=(j+round)%2;delegates[v]=Compile(tree,v);if(delegates[v]==null)throw new Exception("Strict null "+name+" "+Versions[v]);}
   string oracle=Verify(tree.Compile());for(int v=0;v<2;v++)if(Verify(delegates[v])!=oracle)throw new Exception("Behavior mismatch "+name+" "+Versions[v]);
   Console.Error.WriteLine("PASS "+Flavor+" "+name+" "+oracle);
   if(mode=="canonical"){
    for(int v=0;v<2;v++)Console.WriteLine(Json.Write(new {Kind="canonical",Version=Versions[v],Runtime=Environment.Version.ToString(),Flavor=Flavor,Scenario=name,Nodes=Canonical.Delegates(delegates[v])}));
    continue;
   }
   if(mode=="controls")continue;
   if(mode!="measure")throw new ArgumentException(mode);
   if(delegates[0] is Func<int,int>)RunPhase(name,"invoke",round,delegates.Select(d=>ScalarDriver((Func<int,int>)d)).ToArray(),samples);
   else {
    var factories=delegates.Cast<Func<int,Func<int>>>().ToArray();
    RunPhase(name,"activate",round,factories.Select(ActivateDriver).ToArray(),samples);
    RunPhase(name,"activation_first",round,factories.Select(ActivateFirstDriver).ToArray(),samples);
    RunPhase(name,"nested_invoke",round,factories.Select(f=>NestedDriver(f(3))).ToArray(),samples);
   }
  }
  GC.KeepAlive(sink);GC.KeepAlive(checksum);
 }
}

static class Json {
 public static string Write(object value){
  if(value==null)return "null";
  if(value is string s)return "\""+s.Replace("\\","\\\\").Replace("\"","\\\"").Replace("\r","\\r").Replace("\n","\\n").Replace("\t","\\t")+"\"";
  if(value is bool b)return b?"true":"false";
  if(value is IFormattable number&&value.GetType().IsPrimitive)return number.ToString(null,CultureInfo.InvariantCulture);
  if(value is IDictionary map){var parts=new List<string>();foreach(DictionaryEntry e in map)parts.Add(Write(e.Key.ToString())+":"+Write(e.Value));return "{"+string.Join(",",parts)+"}";}
  if(value is IEnumerable values){var parts=new List<string>();foreach(var x in values)parts.Add(Write(x));return "["+string.Join(",",parts)+"]";}
  return "{"+string.Join(",",value.GetType().GetProperties(BindingFlags.Public|BindingFlags.Instance).OrderBy(p=>p.Name).Select(p=>Write(p.Name)+":"+Write(p.GetValue(value,null))))+"}";
 }
}
