# Current/current same-AST runtime diagnostic

Both independently compiled delegates use current42f. Five shapes, eleven phases per configuration; six configurations. Ratio B/A pair is the median of paired ratios; B/A med is the ratio of ns medians. No alignment changes, source optimization, sample filtering or additional repeats. Exact same AST object is reused, including one shared converted Light AST. System is correctness oracle only, not timed in this diagnostic.

This is evidence about independent-target/process/JIT context variation. It does not mathematically subtract from versioned measurements or prove every version-pair cost unrelated to compiler changes. Native/address/host effects must remain distinguished. Framework internal local-handle normalization remains explicitly unknown where unsupported.

1452 raw samples, 66 phase summaries; samples<20ms=0, minimum=21.331ms. All raw rows are retained.

## measure-net10.0-light.jsonl

| Shape | Phase | A ns | B ns | B/A pair | B/A med | Bytes A/B |
|---|---|---:|---:|---:|---:|---:|
|add|invoke|1.406|1.399|0.997|0.995|0.000/0.000|
|array|invoke|1.152|1.149|1.004|0.997|0.000/0.000|
|capture1|activate|18.400|18.375|1.015|0.999|184.000/184.000|
|capture1|activation_first|20.105|20.011|0.988|0.995|184.000/184.000|
|capture1|nested_invoke|2.354|2.351|0.999|0.999|0.000/0.000|
|capture8|activate|41.944|42.197|1.014|1.006|440.000/440.000|
|capture8|activation_first|51.555|54.210|1.026|1.052|440.000/440.000|
|capture8|nested_invoke|5.924|7.924|1.275|1.338|0.000/0.000|
|capture_mutable|activate|22.396|22.925|0.957|1.024|184.000/184.000|
|capture_mutable|activation_first|26.482|27.502|1.043|1.038|184.000/184.000|
|capture_mutable|nested_invoke|2.804|2.862|1.017|1.021|0.000/0.000|

## measure-net10.0-standard.jsonl

| Shape | Phase | A ns | B ns | B/A pair | B/A med | Bytes A/B |
|---|---|---:|---:|---:|---:|---:|
|add|invoke|1.465|1.470|0.998|1.004|0.000/0.000|
|array|invoke|1.269|1.275|0.998|1.005|0.000/0.000|
|capture1|activate|21.578|20.213|0.973|0.937|184.000/184.000|
|capture1|activation_first|21.672|21.139|0.967|0.975|184.000/184.000|
|capture1|nested_invoke|2.534|2.509|0.990|0.990|0.000/0.000|
|capture8|activate|43.383|43.347|0.992|0.999|440.000/440.000|
|capture8|activation_first|47.639|50.008|1.053|1.050|440.000/440.000|
|capture8|nested_invoke|6.702|6.287|0.938|0.938|0.000/0.000|
|capture_mutable|activate|18.569|17.703|0.962|0.953|184.000/184.000|
|capture_mutable|activation_first|20.952|20.077|0.993|0.958|184.000/184.000|
|capture_mutable|nested_invoke|2.610|2.635|0.997|1.010|0.000/0.000|

## measure-net472-light.jsonl

| Shape | Phase | A ns | B ns | B/A pair | B/A med | Bytes A/B |
|---|---|---:|---:|---:|---:|---:|
|add|invoke|1.423|1.418|0.999|0.997|0.000/0.000|
|array|invoke|5.149|5.191|0.996|1.008|0.000/0.000|
|capture1|activate|27.610|27.925|1.009|1.011|184.000/184.000|
|capture1|activation_first|48.759|49.275|1.019|1.011|184.000/184.000|
|capture1|nested_invoke|5.340|5.348|0.993|1.001|0.000/0.000|
|capture8|activate|103.267|108.696|0.936|1.053|440.000/440.000|
|capture8|activation_first|122.670|123.841|0.963|1.010|440.000/440.000|
|capture8|nested_invoke|19.150|18.454|0.964|0.964|0.000/0.000|
|capture_mutable|activate|39.167|40.913|1.002|1.045|184.000/184.000|
|capture_mutable|activation_first|36.717|36.266|0.997|0.988|184.000/184.000|
|capture_mutable|nested_invoke|5.957|5.966|0.998|1.001|0.000/0.000|

## measure-net472-standard.jsonl

| Shape | Phase | A ns | B ns | B/A pair | B/A med | Bytes A/B |
|---|---|---:|---:|---:|---:|---:|
|add|invoke|1.539|1.537|1.001|0.999|0.000/0.000|
|array|invoke|5.456|5.211|0.959|0.955|0.000/0.000|
|capture1|activate|29.754|30.091|1.012|1.011|184.000/184.000|
|capture1|activation_first|33.026|33.035|1.004|1.000|184.000/184.000|
|capture1|nested_invoke|4.558|4.773|1.041|1.047|0.000/0.000|
|capture8|activate|77.833|78.771|1.014|1.012|440.000/440.000|
|capture8|activation_first|87.018|87.379|1.003|1.004|440.000/440.000|
|capture8|nested_invoke|14.128|14.059|0.993|0.995|0.000/0.000|
|capture_mutable|activate|28.719|28.457|0.997|0.991|184.000/184.000|
|capture_mutable|activation_first|34.008|34.399|1.007|1.012|184.000/184.000|
|capture_mutable|nested_invoke|5.680|5.749|1.021|1.012|0.000/0.000|

## measure-net8.0-light.jsonl

| Shape | Phase | A ns | B ns | B/A pair | B/A med | Bytes A/B |
|---|---|---:|---:|---:|---:|---:|
|add|invoke|1.429|1.472|0.970|1.030|0.000/0.000|
|array|invoke|1.805|1.641|1.025|0.909|0.000/0.000|
|capture1|activate|24.186|24.402|0.975|1.009|184.000/184.000|
|capture1|activation_first|20.234|22.145|0.983|1.094|184.000/184.000|
|capture1|nested_invoke|2.772|2.773|0.993|1.000|0.000/0.000|
|capture8|activate|54.926|55.806|1.015|1.016|440.000/440.000|
|capture8|activation_first|50.612|50.956|0.987|1.007|440.000/440.000|
|capture8|nested_invoke|5.909|7.483|1.281|1.266|0.000/0.000|
|capture_mutable|activate|19.284|20.762|1.031|1.077|184.000/184.000|
|capture_mutable|activation_first|24.628|24.311|0.995|0.987|184.000/184.000|
|capture_mutable|nested_invoke|2.786|2.792|1.004|1.002|0.000/0.000|

## measure-net8.0-standard.jsonl

| Shape | Phase | A ns | B ns | B/A pair | B/A med | Bytes A/B |
|---|---|---:|---:|---:|---:|---:|
|add|invoke|1.327|1.318|0.999|0.993|0.000/0.000|
|array|invoke|1.065|1.045|0.993|0.982|0.000/0.000|
|capture1|activate|16.343|16.323|0.989|0.999|184.000/184.000|
|capture1|activation_first|18.762|20.305|1.053|1.082|184.000/184.000|
|capture1|nested_invoke|2.595|2.545|0.995|0.981|0.000/0.000|
|capture8|activate|51.923|53.743|1.029|1.035|440.000/440.000|
|capture8|activation_first|60.024|58.250|0.972|0.970|440.000/440.000|
|capture8|nested_invoke|7.705|8.233|0.981|1.068|0.000/0.000|
|capture_mutable|activate|29.199|30.006|1.072|1.028|184.000/184.000|
|capture_mutable|activation_first|33.898|28.264|0.958|0.834|184.000/184.000|
|capture_mutable|nested_invoke|4.523|3.319|0.903|0.734|0.000/0.000|

