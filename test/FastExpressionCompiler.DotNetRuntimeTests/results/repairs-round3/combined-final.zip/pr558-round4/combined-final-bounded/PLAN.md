Source-only scaffolding; no final source export, build, correctness probe or timing has run.

The old combined-final directory pinned to6d397bc6 remains immutable and unmeasured. Its full native validation blocked on an unchanged-prePR SmallMap capacity bug. This NEW directory awaits the final code SHA including that capacity repair.

Preparation after root supplies final SHA:
  python Prepare.py --final EXPLICIT_COMMIT
  python Prepare-Controls.py
  python Build.py
  python Check.py
  python Compare-Canonical.py
Do not run elapsed until root confirms final full validation and grants an exclusive CPU window.

Nine cases: add, decimal_eh1, decimal_eh64, try_catch, try_finally_real, default_receiver, capture1, capture8, capture_mutable. Six scalar cases have3phases and three capture cases5phases:33phase groups/configuration,198total across Standard/Light net8/net10/Framework. Same System AST per comparison, separate Light conversion outside timed compile. Correctness oracles run before timing; newly repaired incorrect-baseline shapes are excluded from timing rather than accepted with wrong results.

Predeclared21samples/version/phase. Compile-only: each compiler calibrates independently to30ms, with21rotated samples and explicitly different operation counts; report ratios of ns medians, never a matched-count paired compile claim. The supported anonymous EH ctor eagerly JITs during CreateDelegate while historical42f module hosting deferred that work, so compile-only does not represent comparable deferred-JIT work. Compile+first and runtime phases: FEC current/final share one count calibrated to30ms for their faster version; System calibrates independently to30ms. Report FEC paired ratios only for these common-count phases, and independent System ns/bytes medians for all phases. Cap64M operations. Retain every raw row, actual elapsed, under30ms, under20ms and count-cap flags. Calibration may miss its target; no short sample is filtered. Allocations use the direct once-bound per-thread GC counter.

Raw CSV fields: name,phase,version,round,sample,operations,nsPerOp,bytesPerOp,elapsedMs,under30ms,under20ms,atCountCap.

Expected lower-bound measured work is198x21x3x30ms≈374seconds before calibration/GC/unequal FEC ratios. Run.py has a predeclared1200second total bound, preserves all partial rows on failure/timeout and refuses overwrite; no favorable-case reruns. A timeout is incomplete evidence, not an excuse to omit an unfavorable target. DOTNET_TieredCompilation=0/DOTNET_ReadyToRun=0 for modern runs. No fresh cold matrix.

Analyze.py reports actual sample counts/short flags, FEC paired median and ratio-of-medians separately, independent System comparisons, per-case/per-phase median ratios (no weighted aggregate), managed-byte deltas, and explicit increased/unchanged/decreased allocation phase-group counts overall and per configuration. All primary/raw data remain unfiltered; validity errors prevent a complete verdict.

Final source must include map promotion capacity commit3be541d3 and the supported EH-host correction. Official source forbids passing the anonymous module to the module ctor; the supported restricted anonymous ctor moves JIT into CreateDelegate. Keep compile-only, compile+first and runtime costs distinct. Old6d snapshot is not failed Try-value control-flow code: full native validation blocked on an unchanged-prePR map capacity bug; it remains preserved separately.
