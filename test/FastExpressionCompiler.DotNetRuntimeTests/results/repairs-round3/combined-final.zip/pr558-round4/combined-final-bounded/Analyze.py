"""Analyze all retained bounded combined rows; no filtering or weighted speedup."""
from pathlib import Path
import json,csv,statistics,collections,math
w=Path(__file__).resolve().parent
manifest=json.loads((w/'manifest.json').read_text());rows=[];errors=[]
columns=['scenario','phase','version','round','sample','operations','ns','bytes','elapsed_ms','under30ms','under20ms','at_count_cap']
for file in sorted(w.glob('paired-*.csv')):
 tag=file.stem[len('paired-'):];light,runtime=tag.split('-',1);flavor='Light' if light=='true' else 'Standard'
 with file.open(newline='') as f:
  for line,values in enumerate(csv.reader(f),1):
   try:
    if len(values)!=len(columns):raise ValueError('Expected12CSVfields, got'+str(len(values)))
    x=dict(zip(columns,values));x.update(runtime=runtime,flavor=flavor,raw=file.name,line=line)
    for k in ['round','sample','operations']:x[k]=int(x[k])
    for k in ['ns','bytes','elapsed_ms']:x[k]=float(x[k])
    for k in ['under30ms','under20ms','at_count_cap']:
     if x[k] not in ['True','False']:raise ValueError('Invalid bool '+k)
     x[k]=x[k]=='True'
    if x['version'] not in ['current','fixed','system'] or x['operations']<=0 or not math.isfinite(x['ns']) or x['ns']<=0 or x['bytes']<0:raise ValueError('Invalid measurement domain')
    if abs(x['elapsed_ms']-x['ns']*x['operations']/1e6)>1e-6:raise ValueError('Elapsed/count mismatch')
    rows.append(x)
   except Exception as e:errors.append(dict(raw=file.name,line=line,error=str(e),values=values))
groups=collections.defaultdict(list)
for x in rows:groups[x['runtime'],x['flavor'],x['scenario'],x['phase']].append(x)
summary=[];comparisons=[];allocation=collections.defaultdict(lambda:dict(increased=0,unchanged=0,decreased=0))
for (runtime,flavor,scenario,phase),xs in sorted(groups.items()):
 versions={v:[x for x in xs if x['version']==v] for v in ['current','fixed','system']}
 med={}
 for version,vs in versions.items():
  if len(vs)!=21:errors.append(dict(group=[runtime,flavor,scenario,phase],version=version,error='Expected21samples',actual=len(vs)))
  if not vs:continue
  m=dict(runtime=runtime,flavor=flavor,scenario=scenario,phase=phase,version=version,ns=statistics.median(x['ns'] for x in vs),bytes=statistics.median(x['bytes'] for x in vs),samples=len(vs),min_ns=min(x['ns'] for x in vs),max_ns=max(x['ns'] for x in vs),min_bytes=min(x['bytes'] for x in vs),max_bytes=max(x['bytes'] for x in vs),under30ms=sum(x['under30ms'] for x in vs),under20ms=sum(x['under20ms'] for x in vs),atCountCap=sum(x['at_count_cap'] for x in vs),minElapsedMs=min(x['elapsed_ms'] for x in vs),maxElapsedMs=max(x['elapsed_ms'] for x in vs),operationCounts=sorted(set(x['operations'] for x in vs)))
  summary.append(m);med[version]=m
 if len(med)!=3:continue
 pairs=collections.defaultdict(dict)
 for x in xs:
  if x['version']!='system':pairs[x['round'],x['sample']][x['version']]=x
 valid=[p for p in pairs.values() if set(p)=={'current','fixed'}]
 common=phase!='compile'
 if common:
  for pair in valid:
   if pair['current']['operations']!=pair['fixed']['operations']:errors.append(dict(group=[runtime,flavor,scenario,phase],error='FECcommon-count violation'))
 delta=med['fixed']['bytes']-med['current']['bytes']
 entry=dict(runtime=runtime,flavor=flavor,scenario=scenario,phase=phase,time_ratio=med['fixed']['ns']/med['current']['ns'],paired_ratio=statistics.median(p['fixed']['ns']/p['current']['ns'] for p in valid) if common and valid else None,comparisonPolicy='Common-count FECpaired samples' if common else 'Independent compile counts; marginal median comparison only',system_time_ratio=med['fixed']['ns']/med['system']['ns'],systemPolicy='Independent calibration and medians; no matched-count System claim',current_ns=med['current']['ns'],fixed_ns=med['fixed']['ns'],system_ns=med['system']['ns'],current_bytes=med['current']['bytes'],fixed_bytes=med['fixed']['bytes'],system_bytes=med['system']['bytes'],managed_byte_delta=delta,paired_byte_delta=statistics.median(p['fixed']['bytes']-p['current']['bytes'] for p in valid) if common and valid else None)
 comparisons.append(entry)
 kind='increased' if delta>0 else 'decreased' if delta<0 else 'unchanged'
 allocation['all'][kind]+=1;allocation[runtime+'-'+flavor][kind]+=1
status=json.loads((w/'execution-status.json').read_text()) if (w/'execution-status.json').exists() else dict(complete=False,note='No completed execution status')
if len(comparisons)!=198:errors.append(dict(error='Expected198phasegroups',actual=len(comparisons)))
complete=bool(status.get('complete')) and not errors
result=dict(source=dict(baseline=manifest['baseline'],final=manifest['final'],harness=manifest.get('harness'),calibration=manifest.get('calibration')),complete=complete,rows=rows,summary=summary,comparisons=comparisons,errors=errors,allocationRegressionCounts=dict(allocation),shortFlags=dict(under30ms=sum(x['under30ms'] for x in rows),under20ms=sum(x['under20ms'] for x in rows),atCountCap=sum(x['at_count_cap'] for x in rows)),execution=status,notes=['All raw observations retained; invalid records remain in raw CSV and errors.','Compile-only all compilers use independent counts; eager-JIT host shift makes deferred compile work non-equivalent.','Only compilefirst/runtime FECrows use common-count paired ratios; Systemratios are independent median comparisons.','Allocation counts classify per-case/phase marginal median deltas exactly; no tolerance or sample filtering.','No weighted aggregate application speedup or universal parity claim.'])
(w/'analysis.json').write_text(json.dumps(result,indent=2))
lines=['COMPLETE='+str(complete),'Final='+manifest['final'],'Rows='+str(len(rows))+' phasegroups='+str(len(comparisons))+' errors='+str(len(errors)), 'Allocation phase-group counts='+json.dumps(dict(allocation))]
for x in comparisons:lines.append(' '.join(str(x[k]) for k in ['runtime','flavor','scenario','phase'])+' current/final/System ns='+str([x['current_ns'],x['fixed_ns'],x['system_ns']])+' bytes='+str([x['current_bytes'],x['fixed_bytes'],x['system_bytes']])+' final/current median='+str(x['time_ratio'])+' FECpaired='+str(x['paired_ratio'])+' final/System independent='+str(x['system_time_ratio']))
(w/'REPORT.txt').write_text('\n'.join(lines))
print('\n'.join(lines[:4]))
if errors:print('Errors retained; incomplete evidence.')
