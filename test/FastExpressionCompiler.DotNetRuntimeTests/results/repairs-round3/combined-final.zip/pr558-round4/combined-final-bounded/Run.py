"""Execute only after explicit final validation and exclusive CPU grant."""
from pathlib import Path
import argparse,json,subprocess,os,time
w=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--execute-exclusive-window',action='store_true');p.add_argument('--max-seconds',type=int,default=1200);args=p.parse_args()
if not args.execute_exclusive_window:raise SystemExit('No execution requested. Obtain the exclusive window and final validation first.')
m=json.loads((w/'manifest.json').read_text());start=time.monotonic()
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
for light in ['false','true']:
 for tfm in ['net8.0','net10.0','net472']:
  tag=light+'-'+tfm;exe=w/'bench-runners'/tag/('CombinedBench.'+light+('.exe' if tfm=='net472' else '.dll'));prefix=[str(exe)] if tfm=='net472' else ['dotnet',str(exe)]
  output=w/('paired-'+tag+'.csv');errors=w/('paired-'+tag+'.log')
  if output.exists() or errors.exists():raise SystemExit('Refusing to overwrite measurements: '+tag)
  remaining=args.max_seconds-(time.monotonic()-start)
  if remaining<=0:raise SystemExit('Predeclared total time bound reached; preserve partial data and report incomplete. No selective repeats.')
  print('START '+tag,flush=True)
  try:
   with output.open('w') as f,errors.open('w') as e:subprocess.run(prefix+m['cases'],cwd=w,env=env,stdout=f,stderr=e,check=True,timeout=remaining)
  except (subprocess.TimeoutExpired,subprocess.CalledProcessError) as ex:
   (w/'execution-status.json').write_text(json.dumps(dict(complete=False,failedConfiguration=tag,error=str(ex),elapsedSeconds=time.monotonic()-start,rawRetained=True),indent=2));raise
  print('END '+tag,flush=True)
(w/'execution-status.json').write_text(json.dumps(dict(complete=True,elapsedSeconds=time.monotonic()-start,totalBoundSeconds=args.max_seconds,sourceManifest='manifest.json'),indent=2))
print('ALL ELAPSED PROCESSES STOPPED',flush=True)
