from pathlib import Path
import subprocess,hashlib,json,shutil
w=Path(__file__).resolve().parent
if not (w/'manifest.json').exists():subprocess.run(['python','Prepare.py'],cwd=w,check=True)
m=json.loads((w/'manifest.json').read_text());cases=m['original_manifest']['cases'];results={}
for light in ['false','true']:
 for tfm in ['net8.0','net10.0','net472']:
  tag=light+'-'+tfm
  buildlog=w/('build-'+tag+'.log')
  if buildlog.exists():
   i=0
   while (w/('build-failed-'+tag+'-'+str(i)+'.log')).exists():i+=1
   buildlog.rename(w/('build-failed-'+tag+'-'+str(i)+'.log'))
  with buildlog.open('w') as f:subprocess.run(['dotnet','build','Bench.csproj','-c','Release','-f',tfm,'-p:Light='+light,'--nologo','-v:q'],cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True)
  out=w/'runners'/tag;out.mkdir(parents=True)
  for p in (w/'bin'/'Release'/tfm).glob('*'):
   if p.is_file():shutil.copy2(p,out/p.name)
  for name,h in m['libraries'][tag].items():assert hashlib.sha256((out/name).read_bytes()).hexdigest()==h
  exe=out/('CombinedBench.'+light+('.exe' if tfm=='net472' else '.dll'));cmd=[str(exe)] if tfm=='net472' else ['dotnet',str(exe)]
  with (w/('allocated-'+tag+'.csv')).open('w') as stdout,(w/('check-'+tag+'.log')).open('w') as stderr:subprocess.run(cmd+cases,cwd=w,stdout=stdout,stderr=stderr,check=True,timeout=180)
  results[tag]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*') if p.is_file()}
  print('ALLOCATION PASS '+tag,flush=True)
(w/'runner-hashes.json').write_text(json.dumps(results,indent=2))
