from pathlib import Path
import json,csv,collections,statistics,hashlib
w=Path(__file__).resolve().parent;m=json.loads((w/'manifest.json').read_text());rows=[];errors=[]
for file in sorted(w.glob('allocated-*.csv')):
 light,runtime=file.stem[len('allocated-'):].split('-',1);flavor='Light' if light=='true' else 'Standard'
 for line,values in enumerate(csv.reader(file.open()),1):
  if len(values)!=7:errors.append([file.name,line,values]);continue
  scenario,phase,version,sample,ops,total,bpo=values
  row=dict(runtime=runtime,flavor=flavor,scenario=scenario,phase=phase,version=version,sample=int(sample),operations=int(ops),total_bytes=int(total),bytes=float(bpo),raw=file.name,line=line)
  assert row['operations']==200 and row['bytes']==row['total_bytes']/200;rows.append(row)
groups=collections.defaultdict(list)
for x in rows:groups[x['runtime'],x['flavor'],x['scenario'],x['phase']].append(x)
primary=json.loads((Path(m['original'])/'analysis.json').read_text())
previous={(x['runtime'],x['flavor'],x['scenario'],x['phase']):x for x in primary['comparisons']}
counts=collections.Counter();comparisons=[]
for key,xs in sorted(groups.items()):
 versions={v:[x for x in xs if x['version']==v] for v in ['current','fixed','system']}
 for v,vs in versions.items():
  if len(vs)!=5:errors.append([key,v,'expected5',len(vs)])
 if any(not vs for vs in versions.values()):continue
 med={v:statistics.median(x['bytes'] for x in vs) for v,vs in versions.items()}
 delta=med['fixed']-med['current'];kind='increased' if delta>0 else 'decreased' if delta<0 else 'unchanged';counts[kind]+=1
 pairs=[versions['fixed'][i]['bytes']-versions['current'][i]['bytes'] for i in range(5)]
 comparisons.append(dict(zip(['runtime','flavor','scenario','phase'],key),**{v+'_bytes':b for v,b in med.items()},managed_byte_delta=delta,paired_deltas=pairs,primary_delta=previous[key]['managed_byte_delta'],samples={v:[x['bytes'] for x in vs] for v,vs in versions.items()}))
if len(rows)!=2970:errors.append(['expected2970rows',len(rows)])
if len(groups)!=198:errors.append(['expected198groups',len(groups)])
for tag in m['libraries']:
 log=(w/('check-'+tag+'.log')).read_text()
 if log.count('PASS ')!=9:errors.append([tag,'correctnesscount',log.count('PASS ')])
positive_before=[x for x in comparisons if x['primary_delta']>0]
reconfirmation=dict(primary_positive=len(positive_before),positive_again=sum(x['managed_byte_delta']>0 for x in positive_before),now_equal=sum(x['managed_byte_delta']==0 for x in positive_before),now_decreased=sum(x['managed_byte_delta']<0 for x in positive_before))
result=dict(complete=not errors,source=m,rows=rows,comparisons=comparisons,counts=dict(counts),primaryPositiveReconfirmation=reconfirmation,errors=errors,notes=['New allocation-only harness; original timed evidence retained unchanged.','Exact frozen library hashes verified on copy and in every executed output folder.','Copied wrappers/shared AST source byte-identical; runner changed intentionally.','Common200operations;40warmup;5rotating samples;full9casehistory;allrowsretained.','No elapsed measurements or timing claims; observed deltas are not subtracted from original evidence.'])
(w/'analysis.json').write_text(json.dumps(result,indent=2))
lines=['Complete='+str(not errors),'Rows='+str(len(rows))+' Groups='+str(len(groups)),'Counts='+json.dumps(dict(counts)),'Primary-positive reconfirmation='+json.dumps(reconfirmation)]
for x in comparisons:
 if x['managed_byte_delta']!=0 or x['primary_delta']>0:lines.append(str({k:v for k,v in x.items() if k!='samples'}))
(w/'REPORT.txt').write_text('\n'.join(lines))
(w/'source-hashes.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in w.glob('*') if p.is_file() and p.suffix in ['.cs','.py','.csproj']},indent=2))
print('\n'.join(lines[:4]))
