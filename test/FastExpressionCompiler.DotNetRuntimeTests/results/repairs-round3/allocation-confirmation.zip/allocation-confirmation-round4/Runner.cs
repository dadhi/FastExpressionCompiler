using System;
using System.Globalization;
using System.Linq;
class Runner {
 static readonly Func<long> Allocated=(Func<long>)Delegate.CreateDelegate(typeof(Func<long>),typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread"));
 // The copied wrappers contain an unused cold entry point. This runner permits allocations only.
 public static void Row(string name,string phase,string version,int round,int sample,int operations,double ns,double bytes)=>throw new NotSupportedException("Cold timing is disabled.");
 static void Main(string[] args){
  var versions=new[]{"current","fixed","system"};_=Allocated();
  foreach(var name in args){
   var tree=SharedShapes.Build(name);
   var operations=new[]{Current.Bench.Operations(name,tree),Fixed.Bench.Operations(name,tree),SystemSide.Bench.Operations(name,tree)};
   foreach(var phase in operations[0].Keys){
    var actions=operations.Select(x=>x[phase]).ToArray();foreach(var action in actions)action(40);
    GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();
    for(int sample=0;sample<5;sample++)for(int order=0;order<3;order++){
     int v=(sample+order)%3;long before=Allocated();actions[v](200);long bytes=Allocated()-before;
     Console.WriteLine(name+","+phase+","+versions[v]+","+sample+",200,"+bytes+","+(bytes/200.0).ToString("R",CultureInfo.InvariantCulture));
    }
   }Console.Error.WriteLine("PASS "+name);
  }
 }
}
