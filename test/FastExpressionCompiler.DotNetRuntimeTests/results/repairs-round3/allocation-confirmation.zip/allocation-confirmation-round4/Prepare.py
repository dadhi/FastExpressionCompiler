from pathlib import Path
import json,hashlib,shutil
w=Path(__file__).resolve().parent;old=w.parent/'pr558-round4'/'combined-final-bounded'
if (w/'manifest.json').exists():raise SystemExit('Refusing to replace frozen preparation.')
m={'original':str(old),'original_manifest':json.loads((old/'manifest.json').read_text()),'operations':200,'warmup':40,'samples':5,'source':{},'libraries':{}}
for name in ['Current.cs','Fixed.cs','System.cs','SharedShapes.cs']:
 data=(old/name).read_bytes();(w/name).write_bytes(data);m['source'][name]=hashlib.sha256(data).hexdigest()
for light in ['false','true']:
 for tfm in ['net8.0','net10.0','net472']:
  tag=light+'-'+tfm;dest=w/'frozen'/tag;dest.mkdir(parents=True)
  m['libraries'][tag]={}
  for version in ['current','fixed']:
   name='Combined.'+version+('.Light' if light=='true' else '')+'.dll';src=old/'bench-runners'/tag/name
   shutil.copy2(src,dest/name);h=hashlib.sha256(src.read_bytes()).hexdigest();assert h==hashlib.sha256((dest/name).read_bytes()).hexdigest()
   m['libraries'][tag][name]=h
(w/'manifest.json').write_text(json.dumps(m,indent=2))
