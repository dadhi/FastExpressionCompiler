from pathlib import Path
p=Path(__file__).parent/'Bench.csproj';s=p.read_text();s=s.replace('<OutputType>', '<AssemblySearchPaths>{HintPathFromItem};{CandidateAssemblyFiles};{TargetFrameworkDirectory};{RawFileName}</AssemblySearchPaths><OutputType>');p.write_text(s)
