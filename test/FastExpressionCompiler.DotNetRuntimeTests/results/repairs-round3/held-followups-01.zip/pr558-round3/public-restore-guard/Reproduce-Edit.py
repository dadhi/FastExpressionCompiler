from pathlib import Path
p=Path(__file__).resolve().parent
b=(p/"before/FastExpressionCompiler.cs").read_bytes()
old=b'                context.RestoreLabelScopeDepth(scopeDepth);\n                if (scopeDepth == 0)'
new=b'                if (context.LabelScopeDepth != scopeDepth)\n                    context.RestoreLabelScopeDepth(scopeDepth);\n                if (scopeDepth == 0)'
assert b.count(old)==1
assert b.replace(old,new,1)==(p/"fixed/FastExpressionCompiler.cs").read_bytes()
print("Exact guard edit verified")
