extern alias Before;
extern alias After;
extern alias LightBefore;
extern alias LightAfter;
using System;
using System.Reflection;
using System.Reflection.Emit;
using System.Linq.Expressions;
using S=System.Linq.Expressions.Expression;

namespace ChecksBefore {
using F=Before::FastExpressionCompiler;
using L=LightBefore::FastExpressionCompiler.LightExpression;
using Roots=Before::FastExpressionCompiler.ImTools.SmallList<Before::FastExpressionCompiler.ExpressionCompiler.NestedLambdaInfo>;
using LightRoots=LightBefore::FastExpressionCompiler.LightExpression.ImTools.SmallList<LightBefore::FastExpressionCompiler.LightExpression.ExpressionCompiler.NestedLambdaInfo>;
public static class Run {
 static Delegate Compile(LambdaExpression tree)=>F.ExpressionCompiler.CompileFast(tree,true)??throw new Exception("Unexpected unsupported tree");
 public static void Check(){
  var token=new object();var boxed=(object)42;var text=new string('q',11);
  foreach(var value in new[]{token,boxed,text}){
   var f=(Func<object>)Compile(S.Lambda<Func<object>>(S.Constant(value,typeof(object))));
   if(!ReferenceEquals(value,f()))throw new Exception("Constant identity/boxing changed");
  }
  var sf=(Func<string>)Compile(S.Lambda<Func<string>>(S.Constant(text)));
  if(!ReferenceEquals(text,sf()))throw new Exception("Noninterned string identity changed");
  var nf=(Func<object>)Compile(S.Lambda<Func<object>>(S.Constant(null,typeof(object))));
  if(nf()!=null)throw new Exception("Null changed");
  var p=S.Parameter(typeof(int),"same");var local=S.Variable(typeof(int),"same");
  var lf=(Func<int,int>)Compile(S.Lambda<Func<int,int>>(S.Block(new[]{local},S.Assign(local,p),S.Add(local,p)),p));
  if(lf(21)!=42)throw new Exception("Parameter/local reference lookup changed");
  var nested=(Func<int,Func<int>>)Compile(S.Lambda<Func<int,Func<int>>>(S.Lambda<Func<int>>(S.Add(p,S.Constant(1))),p));
  if(nested(41)()!=42)throw new Exception("Nested capture changed");
  var context=new F.ExpressionCompiler.CompilerContext(F.ExpressionCompiler.ClosureStatus.ToBeCollected,Array.Empty<ParameterExpression>(),default);Roots roots=default;
  if(F.ExpressionCompiler.TryCollectInfo(ref context,p,null,ref roots)!=F.ExpressionCompiler.Result.ParameterIsNotVariableNorInPassedParameters)throw new Exception("Undefined parameter result changed");
  object boxedContext=context;
  typeof(F.ExpressionCompiler.CompilerContext).GetField("IsCollectingExceptionFilter",BindingFlags.Instance|BindingFlags.NonPublic).SetValue(boxedContext,true);
  context=(F.ExpressionCompiler.CompilerContext)boxedContext;
  try{F.ExpressionCompiler.TryCollectInfo(ref context,p,null,ref roots);throw new Exception("Undefined filter parameter not rejected");}
  catch(InvalidOperationException e){if(e.Message!="A variable referenced from an exception filter is not defined in its scope.")throw;}
  context=new F.ExpressionCompiler.CompilerContext(F.ExpressionCompiler.ClosureStatus.ToBeCollected,Array.Empty<ParameterExpression>(),default);
  if(F.ExpressionCompiler.TryCollectInfo(ref context,S.Empty(),null,ref roots)!=F.ExpressionCompiler.Result.OK)throw new Exception("Default changed");
  foreach(var intrinsic in new L.Expression[]{new CallbackConstant(),new CallbackParameter(),new RecoveringCallback()}){
   var result=L.ExpressionCompiler.CompileFast(L.Expression.Lambda<Func<int>>(intrinsic),true);
   if(result==null||result()!=42)throw new Exception("Light intrinsic terminal callback changed");
  }
  if(CallbackConstant.Collected==0||CallbackParameter.Collected==0)throw new Exception("Intrinsic collector bypassed");
  Console.WriteLine("ChecksBefore constant identities, boxing, null, local/parameter lookup, nested capture, undefined/filter errors, Default and Light terminal callbacks PASS");
 }
 sealed class RecoveringCallback:L.TypedUnaryExpression {
  public RecoveringCallback():base(ExpressionType.Convert,L.Expression.Constant(42),typeof(int)){}
  public override bool IsIntrinsic=>true;
  public override L.ExpressionCompiler.Result TryCollectInfo(ref L.ExpressionCompiler.CompilerContext c,L.ExpressionCompiler.NestedLambdaInfo n,ref LightRoots roots){
   var field=typeof(L.ExpressionCompiler.CompilerContext).GetField("LabelScopeDepth",BindingFlags.Instance|BindingFlags.NonPublic);var prior=(int)field.GetValue(c);
   L.Expression failing=L.Expression.Rethrow(typeof(int));var test=L.Expression.Call(typeof(string).GetMethod(nameof(string.IsNullOrEmpty)),L.Expression.Constant(""));
   for(int i=0;i<32;++i)failing=L.Expression.Block(L.Expression.Condition(test,L.Expression.Block(failing),L.Expression.Constant(0)));
   try{L.ExpressionCompiler.TryCollectInfo(ref c,failing,n,ref roots);throw new Exception("Expected invalid rethrow rejection");}catch(InvalidOperationException){}
   if((int)field.GetValue(c)!=prior)throw new Exception("Failed child collection leaked lexical frames");
   return L.ExpressionCompiler.TryCollectInfo(ref c,Operand,n,ref roots);
  }
  public override bool TryEmit(ref L.ExpressionCompiler.CompilerContext c,ILGenerator il,L.ExpressionCompiler.ParentFlags p,int byRefIndex=-1){il.Emit(OpCodes.Ldc_I4,42);return true;}
 }
 sealed class CallbackConstant:L.ConstantExpression {
  public static int Collected;public override Type Type=>typeof(int);public override object Value=>throw new Exception("Intrinsic Value must not be read");public override bool IsIntrinsic=>true;
  public override L.ExpressionCompiler.Result TryCollectInfo(ref L.ExpressionCompiler.CompilerContext c,L.ExpressionCompiler.NestedLambdaInfo n,ref LightRoots roots){++Collected;return L.ExpressionCompiler.Result.OK;}
  public override bool TryEmit(ref L.ExpressionCompiler.CompilerContext c,ILGenerator il,L.ExpressionCompiler.ParentFlags p,int byRefIndex=-1){il.Emit(OpCodes.Ldc_I4,42);return true;}
 }
 sealed class CallbackParameter:L.TypedUnaryExpression {
  public static int Collected;public CallbackParameter():base(ExpressionType.Parameter,L.Expression.Constant(0),typeof(int)){}public override bool IsIntrinsic=>true;
  public override L.ExpressionCompiler.Result TryCollectInfo(ref L.ExpressionCompiler.CompilerContext c,L.ExpressionCompiler.NestedLambdaInfo n,ref LightRoots roots){++Collected;return L.ExpressionCompiler.Result.OK;}
  public override bool TryEmit(ref L.ExpressionCompiler.CompilerContext c,ILGenerator il,L.ExpressionCompiler.ParentFlags p,int byRefIndex=-1){il.Emit(OpCodes.Ldc_I4,42);return true;}
 }
}
}

namespace ChecksAfter {
using F=After::FastExpressionCompiler;
using L=LightAfter::FastExpressionCompiler.LightExpression;
using Roots=After::FastExpressionCompiler.ImTools.SmallList<After::FastExpressionCompiler.ExpressionCompiler.NestedLambdaInfo>;
using LightRoots=LightAfter::FastExpressionCompiler.LightExpression.ImTools.SmallList<LightAfter::FastExpressionCompiler.LightExpression.ExpressionCompiler.NestedLambdaInfo>;
public static class Run {
 static Delegate Compile(LambdaExpression tree)=>F.ExpressionCompiler.CompileFast(tree,true)??throw new Exception("Unexpected unsupported tree");
 public static void Check(){
  var token=new object();var boxed=(object)42;var text=new string('q',11);
  foreach(var value in new[]{token,boxed,text}){
   var f=(Func<object>)Compile(S.Lambda<Func<object>>(S.Constant(value,typeof(object))));
   if(!ReferenceEquals(value,f()))throw new Exception("Constant identity/boxing changed");
  }
  var sf=(Func<string>)Compile(S.Lambda<Func<string>>(S.Constant(text)));
  if(!ReferenceEquals(text,sf()))throw new Exception("Noninterned string identity changed");
  var nf=(Func<object>)Compile(S.Lambda<Func<object>>(S.Constant(null,typeof(object))));
  if(nf()!=null)throw new Exception("Null changed");
  var p=S.Parameter(typeof(int),"same");var local=S.Variable(typeof(int),"same");
  var lf=(Func<int,int>)Compile(S.Lambda<Func<int,int>>(S.Block(new[]{local},S.Assign(local,p),S.Add(local,p)),p));
  if(lf(21)!=42)throw new Exception("Parameter/local reference lookup changed");
  var nested=(Func<int,Func<int>>)Compile(S.Lambda<Func<int,Func<int>>>(S.Lambda<Func<int>>(S.Add(p,S.Constant(1))),p));
  if(nested(41)()!=42)throw new Exception("Nested capture changed");
  var context=new F.ExpressionCompiler.CompilerContext(F.ExpressionCompiler.ClosureStatus.ToBeCollected,Array.Empty<ParameterExpression>(),default);Roots roots=default;
  if(F.ExpressionCompiler.TryCollectInfo(ref context,p,null,ref roots)!=F.ExpressionCompiler.Result.ParameterIsNotVariableNorInPassedParameters)throw new Exception("Undefined parameter result changed");
  object boxedContext=context;
  typeof(F.ExpressionCompiler.CompilerContext).GetField("IsCollectingExceptionFilter",BindingFlags.Instance|BindingFlags.NonPublic).SetValue(boxedContext,true);
  context=(F.ExpressionCompiler.CompilerContext)boxedContext;
  try{F.ExpressionCompiler.TryCollectInfo(ref context,p,null,ref roots);throw new Exception("Undefined filter parameter not rejected");}
  catch(InvalidOperationException e){if(e.Message!="A variable referenced from an exception filter is not defined in its scope.")throw;}
  context=new F.ExpressionCompiler.CompilerContext(F.ExpressionCompiler.ClosureStatus.ToBeCollected,Array.Empty<ParameterExpression>(),default);
  if(F.ExpressionCompiler.TryCollectInfo(ref context,S.Empty(),null,ref roots)!=F.ExpressionCompiler.Result.OK)throw new Exception("Default changed");
  foreach(var intrinsic in new L.Expression[]{new CallbackConstant(),new CallbackParameter(),new RecoveringCallback()}){
   var result=L.ExpressionCompiler.CompileFast(L.Expression.Lambda<Func<int>>(intrinsic),true);
   if(result==null||result()!=42)throw new Exception("Light intrinsic terminal callback changed");
  }
  if(CallbackConstant.Collected==0||CallbackParameter.Collected==0)throw new Exception("Intrinsic collector bypassed");
  Console.WriteLine("ChecksAfter constant identities, boxing, null, local/parameter lookup, nested capture, undefined/filter errors, Default and Light terminal callbacks PASS");
 }
 sealed class RecoveringCallback:L.TypedUnaryExpression {
  public RecoveringCallback():base(ExpressionType.Convert,L.Expression.Constant(42),typeof(int)){}
  public override bool IsIntrinsic=>true;
  public override L.ExpressionCompiler.Result TryCollectInfo(ref L.ExpressionCompiler.CompilerContext c,L.ExpressionCompiler.NestedLambdaInfo n,ref LightRoots roots){
   var field=typeof(L.ExpressionCompiler.CompilerContext).GetField("LabelScopeDepth",BindingFlags.Instance|BindingFlags.NonPublic);var prior=(int)field.GetValue(c);
   L.Expression failing=L.Expression.Rethrow(typeof(int));var test=L.Expression.Call(typeof(string).GetMethod(nameof(string.IsNullOrEmpty)),L.Expression.Constant(""));
   for(int i=0;i<32;++i)failing=L.Expression.Block(L.Expression.Condition(test,L.Expression.Block(failing),L.Expression.Constant(0)));
   try{L.ExpressionCompiler.TryCollectInfo(ref c,failing,n,ref roots);throw new Exception("Expected invalid rethrow rejection");}catch(InvalidOperationException){}
   if((int)field.GetValue(c)!=prior)throw new Exception("Failed child collection leaked lexical frames");
   return L.ExpressionCompiler.TryCollectInfo(ref c,Operand,n,ref roots);
  }
  public override bool TryEmit(ref L.ExpressionCompiler.CompilerContext c,ILGenerator il,L.ExpressionCompiler.ParentFlags p,int byRefIndex=-1){il.Emit(OpCodes.Ldc_I4,42);return true;}
 }
 sealed class CallbackConstant:L.ConstantExpression {
  public static int Collected;public override Type Type=>typeof(int);public override object Value=>throw new Exception("Intrinsic Value must not be read");public override bool IsIntrinsic=>true;
  public override L.ExpressionCompiler.Result TryCollectInfo(ref L.ExpressionCompiler.CompilerContext c,L.ExpressionCompiler.NestedLambdaInfo n,ref LightRoots roots){++Collected;return L.ExpressionCompiler.Result.OK;}
  public override bool TryEmit(ref L.ExpressionCompiler.CompilerContext c,ILGenerator il,L.ExpressionCompiler.ParentFlags p,int byRefIndex=-1){il.Emit(OpCodes.Ldc_I4,42);return true;}
 }
 sealed class CallbackParameter:L.TypedUnaryExpression {
  public static int Collected;public CallbackParameter():base(ExpressionType.Parameter,L.Expression.Constant(0),typeof(int)){}public override bool IsIntrinsic=>true;
  public override L.ExpressionCompiler.Result TryCollectInfo(ref L.ExpressionCompiler.CompilerContext c,L.ExpressionCompiler.NestedLambdaInfo n,ref LightRoots roots){++Collected;return L.ExpressionCompiler.Result.OK;}
  public override bool TryEmit(ref L.ExpressionCompiler.CompilerContext c,ILGenerator il,L.ExpressionCompiler.ParentFlags p,int byRefIndex=-1){il.Emit(OpCodes.Ldc_I4,42);return true;}
 }
}
}
public static class Checks {public static void Main(){ChecksBefore.Run.Check();ChecksAfter.Run.Check();}}
