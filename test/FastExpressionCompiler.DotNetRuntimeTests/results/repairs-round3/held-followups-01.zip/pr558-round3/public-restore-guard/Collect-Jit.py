from pathlib import Path
import subprocess,os,json
w=Path.cwd()/'work';d=w/'pr558-round3/public-restore-guard'
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
proof=[]
for runtime in ['net8.0','net10.0']:
 for version in ['before','fixed']:
  name='scalar-jit-'+runtime+'-'+version
  with (d/(name+'.log')).open('w') as log:
   subprocess.run([str(w/'pr558-repair/tools/dotnet-trace.exe'),'collect','--providers','Microsoft-Windows-DotNETRuntime:0x10:5','--output',str(d/(name+'.nettrace')),'--','dotnet',str(d/'bin'/('Cold'+version)/runtime/('Cold'+version+'.dll')),version,'42f-guard','add','0'],env=env,stdout=log,stderr=log,check=True)
  with (d/(name+'.jsonl')).open('w') as out:
   subprocess.run(['dotnet',str(w/'pr558-round2/jit-reader/bin/Release/net10.0/Reader.dll'),str(d/(name+'.nettrace'))],stdout=out,check=True)
  rows=[json.loads(x) for x in (d/(name+'.jsonl')).read_text().splitlines()]
  selected=[x for x in rows if 'RestoreLabelScopeDepth' in x['Name'] or 'TryCollectInfo' in x['Name'] or 'TryCollectSimpleBinary' in x['Name']]
  proof.append(dict(runtime=runtime,version=version,entries=selected))
(d/'scalar-jit-proof.json').write_text(json.dumps(proof,indent=2))
print(json.dumps(proof,indent=2))
