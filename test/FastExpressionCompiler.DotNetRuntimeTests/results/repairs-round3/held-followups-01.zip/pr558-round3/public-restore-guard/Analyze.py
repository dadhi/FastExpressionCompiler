from pathlib import Path
import json,statistics,collections
p=Path('work/pr558-round3/public-restore-guard');results=[]
for file in sorted(p.glob('*.jsonl')):
 if not file.name.startswith(('Collection-','Runner-')):continue
 pairs=collections.defaultdict(dict)
 for line in file.read_text().splitlines():
  x=json.loads(line);pairs[(x['Scenario'],x['Phase'],x['SampleIndex'])][x['Version']]=x
 groups=collections.defaultdict(list)
 for (case,phase,_),v in pairs.items():groups[case,phase].append(v)
 for (case,phase),vs in groups.items():
  r=dict(file=file.name,scenario=case,phase=phase,ratio=statistics.median(v['fixed']['NsPerOp']/v['before']['NsPerOp'] for v in vs),beforeBytes=statistics.median(v['before']['BytesPerOp'] for v in vs),fixedBytes=statistics.median(v['fixed']['BytesPerOp'] for v in vs))
  results.append(r)
  if phase in ['collect','compile','compile_first']:print(r)
(p/'combined-analysis.json').write_text(json.dumps(results,indent=2))
rows=[json.loads(x) for x in (p/'cold-nine.jsonl').read_text().splitlines()];cold=[]
for runtime in sorted(set(x['Runtime'] for x in rows)):
 for case in ['add','balanced256','try_finally']:
  a={v:[x for x in rows if x['Runtime']==runtime and x['Scenario']==case and x['Version']==v] for v in ['before','fixed']}
  r=dict(runtime=runtime,scenario=case)
  for key in ['CompileAndFirstNs','CompileAndFirstBytes']:
   r[key]={v:dict(median=statistics.median(x[key] for x in xs),min=min(x[key] for x in xs),max=max(x[key] for x in xs)) for v,xs in a.items()}
  r['pairsByteEqual']=all(a['before'][i]['CompileAndFirstBytes']==a['fixed'][i]['CompileAndFirstBytes'] for i in range(9));cold.append(r);print(r)
(p/'cold-analysis.json').write_text(json.dumps(cold,indent=2))
print('BYTE MEDIAN DIFFS',[r for r in results if r['beforeBytes']!=r['fixedBytes']])
