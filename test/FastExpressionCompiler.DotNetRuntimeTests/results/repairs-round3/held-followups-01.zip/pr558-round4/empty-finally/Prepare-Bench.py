from pathlib import Path
w=Path(__file__).resolve().parent
old=w.parents[1]/'pr558-round2'/'nested-terminal'
source=(old/'BenchSide.template').read_text()
source=source.replace('public static System.Linq.Expressions.LambdaExpression Build(string name){','public static int Counter; public static void Tick() { ++Counter; }\n public static System.Linq.Expressions.LambdaExpression Build(string name){')
source=source.replace('case "try_finally":body=S.TryFinally(S.Add(x,S.Constant(1)),S.Empty());break;', '''case "try_finally":body=S.TryFinally(S.Add(x,S.Constant(1)),S.Empty());break;
   case "try_finally_real":body=S.TryFinally(S.Add(x,S.Constant(1)),S.Call(typeof(Bench).GetMethod(nameof(Tick))));break;
   case "try_catch":body=S.TryCatch(S.Add(x,S.Constant(1)),S.Catch(typeof(Exception),S.Constant(-1)));break;
   case "nested_eh32":body=S.Add(x,S.Constant(1));for(int i=0;i<32;i++)body=S.TryFinally(body,S.Empty());break;
   case "nested_eh32_real":body=S.Add(x,S.Constant(1));for(int i=0;i<32;i++)body=S.TryFinally(body,S.Call(typeof(Bench).GetMethod(nameof(Tick))));break;
   case "goto_empty": var done=S.Label(typeof(int));body=S.Block(S.TryFinally(S.Goto(done,S.Add(x,S.Constant(1))),S.Empty()),S.Label(done,S.Constant(-1)));break;''')
for alias,side,version in [('Before','Current','current'),('After','Candidate','candidate')]:
 (w/(side+'.cs')).write_text(source.replace('ALIAS',alias).replace('SIDE',side).replace('VERSION',version))
system=source.replace('extern alias ALIAS;','').replace('namespace SIDE','namespace SystemSide').replace('VERSION','system')
start=system.index('#if LIGHT');end=system.index('#endif',start)+len('#endif')
system=system[:start]+'using L=System.Linq.Expressions.LambdaExpression;'+system[end:]
start=system.index(' static L Convert(');end=system.index(' static int Invoke',start)
system=system[:start]+''' static L Convert(System.Linq.Expressions.LambdaExpression source)=>source;
 [MethodImpl(MethodImplOptions.NoInlining)]static Delegate Compile(L tree)=>tree.Compile();
'''+system[end:]
(w/'System.cs').write_text(system)
project=(old/'Bench.csproj').read_text().replace('<Compile Include="Candidate.cs"/>','<Compile Include="Candidate.cs"/><Compile Include="System.cs"/>')
(w/'Bench.csproj').write_text(project)
print('Prepared measurement source, no builds or execution')
