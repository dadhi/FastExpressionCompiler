from pathlib import Path
import subprocess, shutil, hashlib, json
w=Path(__file__).resolve().parent
hashes={}
subprocess.run(['python','Prepare-Bench.py'],cwd=w,check=True)
for light in ['false','true']:
 for tfm in ['net8.0','net10.0']:
  tag=light+'-'+tfm
  with (w/('bench-build-'+tag+'.log')).open('w') as f:
   subprocess.run(['dotnet','build','Bench.csproj','-c','Release','-f',tfm,'-p:Light='+light,'--nologo','-v:q'],cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True)
  out=w/'bench-runners'/tag;out.mkdir(parents=True,exist_ok=True)
  for p in (w/'bin'/'Release'/tfm).glob('*'):
   if p.is_file():shutil.copy2(p,out/p.name)
  for v in ['current','candidate']:
   name='EmptyFinally.'+v+('.Light' if light=='true' else '')+'.dll'
   shutil.copy2(w/(v+('-light' if light=='true' else ''))/'bin'/'Release'/tfm/name,out/name)
  hashes[tag]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*') if p.is_file()}
  print('Built/frozen '+tag,flush=True)
(w/'benchmark-hashes.json').write_text(json.dumps(hashes,indent=2))
