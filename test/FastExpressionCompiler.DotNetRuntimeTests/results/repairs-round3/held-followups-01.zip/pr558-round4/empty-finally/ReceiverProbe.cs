using System;
using System.Linq;
using System.Reflection;
using E=System.Linq.Expressions;
using S=System.Linq.Expressions.Expression;
public struct ReceiverCounter { public int Value; public ReceiverCounter() { Value=9; } public int Increment() => ++Value; }
public struct ReceiverOuter { public ReceiverCounter Inner; }
class ReceiverProbe {
 static E.Expression<Func<int>> Build(string shape) {
  var value=S.Parameter(typeof(ReceiverCounter),"value");var outer=S.Parameter(typeof(ReceiverOuter),"outer");
  E.Expression receiver=shape=="default"?S.Default(typeof(ReceiverCounter)):shape=="new"?S.New(typeof(ReceiverCounter)):shape=="nested_field"?S.Field(outer,nameof(ReceiverOuter.Inner)):value;
  var call=S.Call(S.TryFinally(receiver,S.Empty()),typeof(ReceiverCounter).GetMethod(nameof(ReceiverCounter.Increment)));
  if(shape=="default"||shape=="new")return S.Lambda<Func<int>>(call);
  var body=S.Add(S.Multiply(call,S.Constant(100)),S.Field(receiver,nameof(ReceiverCounter.Value)));
  return shape=="nested_field"?S.Lambda<Func<int>>(S.Block(new[]{outer},S.Assign(outer,S.Constant(new ReceiverOuter{Inner=new ReceiverCounter{Value=5}})),body)):
   S.Lambda<Func<int>>(S.Block(new[]{value},S.Assign(value,S.Constant(new ReceiverCounter{Value=5})),body));
 }
 static void Main(string[] args) {
  foreach(var shape in new[]{"variable","nested_field","default","new"}) {
   var tree=Build(shape);int expected=tree.Compile()();Console.WriteLine("System "+shape+" "+expected);
   foreach(var path in args)foreach(var flag in new[]{"Default","NoInvocationLambdaInlining","EnableDelegateDebugInfo"}) {
    var asm=Assembly.LoadFrom(path);bool light=asm.GetType("FastExpressionCompiler.LightExpression.ExpressionCompiler")!=null;
    var compiler=asm.GetType(light?"FastExpressionCompiler.LightExpression.ExpressionCompiler":"FastExpressionCompiler.ExpressionCompiler",true);string stage="compile";
    try {
     object input=tree;
     if(light)input=compiler.GetMethods().Single(m=>m.Name=="FromSysExpression"&&!m.IsGenericMethod&&m.GetParameters().Length==1).Invoke(null,new object[]{tree});
     var compile=compiler.GetMethods().Single(m=>m.Name=="CompileFast"&&!m.IsGenericMethod&&m.GetParameters().Length==3&&m.GetParameters()[0].ParameterType.FullName==(light?"FastExpressionCompiler.LightExpression.LambdaExpression":typeof(E.LambdaExpression).FullName));
     var d=(Func<int>)compile.Invoke(null,new object[]{input,true,Enum.Parse(compile.GetParameters()[2].ParameterType,flag)});stage="invoke";
     Console.WriteLine(asm.GetName().Name+" "+shape+" "+flag+" "+(d==null?"NULL":d().ToString()));
    }catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;Console.WriteLine(asm.GetName().Name+" "+shape+" "+flag+" "+stage+" "+e.GetType().FullName+": "+e.Message);}
   }
  }
 }
}
