from pathlib import Path
import difflib,json,hashlib
w=Path(__file__).resolve().parent
p=w/'Fixture.csproj';s=p.read_text()
if 'EMPTY_FINALLY_ELIDED' not in s:
 s=s.replace('</PropertyGroup>', '<DefineConstants Condition="\'$(Variant)\'==\'candidate\'">$(DefineConstants);EMPTY_FINALLY_ELIDED</DefineConstants></PropertyGroup>')
 p.write_text(s)
a=(w/'current/FastExpressionCompiler.cs').read_text(encoding='utf-8');b=(w/'candidate/FastExpressionCompiler.cs').read_text(encoding='utf-8')
(w/'production.diff').write_text(''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/src/FastExpressionCompiler/FastExpressionCompiler.cs',tofile='b/src/FastExpressionCompiler/FastExpressionCompiler.cs')))
(w/'harness-hashes.json').write_text(json.dumps({str(p.relative_to(w)):hashlib.sha256(p.read_bytes()).hexdigest() for p in w.glob('*') if p.is_file() and p.suffix in ['.cs','.py','.csproj','.template','.diff']},indent=2))
