using System;
#if LIGHT_EXPRESSION
using FastExpressionCompiler.LightExpression;
using FastExpressionCompiler.LightExpression.UnitTests;
#else
using FastExpressionCompiler;
using FastExpressionCompiler.UnitTests;
#endif
class Program { static void Main() { System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.GetCultureInfo("en-US"); var t = new TestRun();
t.Run(new EmptyFinallyRegressionTests());
t.Run(new NonExceptionThrowPolicyRegressionTests());
t.Run(new ExceptionJumpValidationRegressionTests());
t.Run(new ExceptionRegionValidationRegressionTests());
t.Run(new InlinedRethrowBoundaryRegressionTests());
t.Run(new NestedJumpArgumentRegressionTests());
t.Run(new InvocationJumpArgumentRegressionTests());
Console.WriteLine("TOTAL="+t.TotalTestCount+" FAILED="+t.FailedTestCount); Environment.ExitCode=t.FailedTestCount==0?0:1; }}