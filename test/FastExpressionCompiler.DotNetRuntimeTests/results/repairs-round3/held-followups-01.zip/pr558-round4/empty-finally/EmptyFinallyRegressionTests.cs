using System;
using System.Threading;
using S = System.Linq.Expressions.Expression;
using E = System.Linq.Expressions;
#if LIGHT_EXPRESSION
namespace FastExpressionCompiler.LightExpression.UnitTests;
#else
namespace FastExpressionCompiler.UnitTests;
#endif

public struct EmptyFinallyRegressionTests : ITestX
{
    public static string Trace;
    static readonly CompilerFlags[] Flags = { CompilerFlags.Default, CompilerFlags.NoInvocationLambdaInlining, CompilerFlags.EnableDelegateDebugInfo };
    public static int Mark(string text, int value) { Trace += text + ";"; return value; }
    static E.Expression M(string text, int value = 0) => S.Call(typeof(EmptyFinallyRegressionTests).GetMethod(nameof(Mark)), S.Constant(text), S.Constant(value));
    public struct Pair { public int Value; public Pair() { Value = 99; Trace += "pair-ctor;"; } }
    public static int Sum(int a, int b) => a + b;
    public static int ReadRef(ref int x) { ++x; return x; }
    public void Run(TestRun t)
    {
        Values_and_evaluation_order(t);
        Struct_and_reference_results(t);
        Throw_preserves_identity_and_outer_cleanup(t);
        Raw_nonexception_preserves_matching(t);
        Outward_and_inner_goto(t);
        Outward_goto_keeps_real_outer_finally(t);
        Rethrow_keeps_enclosing_catch(t);
        Byref_argument_and_inlined_lambda(t);
        Explicit_try_result_types(t);
        Nonempty_finally_catch_and_debug_finally_are_retained(t);
        Invalid_incoming_goto_is_still_rejected(t);
        Empty_try_inside_filter_still_rejected(t);
#if NET8_0_OR_GREATER && EMPTY_FINALLY_ELIDED
        Value_break_in_empty_finally(t);
#endif
#if LIGHT_EXPRESSION
        Intrinsic_default_finally_is_not_empty(t);
#endif
#if NETFRAMEWORK
        Thread_abort_catch_and_finally_order(t);
#endif
    }
    static void Check<T>(TestContext t, E.Expression<Func<T>> source, T value, string trace)
    {
        Trace = ""; t.AreEqual(value, source.Compile()()); t.AreEqual(trace, Trace);
        foreach (var flags in Flags)
        {
            var fast = source.FromSysExpression().CompileFast(true, flags);
            if (!t.IsNotNull(fast)) continue;
            Trace = ""; t.AreEqual(value, fast()); t.AreEqual(trace, Trace);
        }
    }
    public void Values_and_evaluation_order(TestContext t)
    {
        Check(t, S.Lambda<Func<int>>(S.Block(M("before"), S.Call(typeof(EmptyFinallyRegressionTests).GetMethod(nameof(Sum)),
            S.TryFinally(M("left", 20), S.Empty()), S.TryFinally(M("right", 22), S.Empty())))), 42, "before;left;right;");
        Check(t, S.Lambda<Func<int>>(S.Block(S.TryFinally(S.Block(M("void"), S.Empty()), S.Empty()), M("after", 9))), 9, "void;after;");
        Check(t, S.Lambda<Func<int>>(S.Add(S.Constant(5), S.TryFinally(S.Constant(7), S.Empty()))), 12, "");
    }
    public void Struct_and_reference_results(TestContext t)
    {
        var pair = new Pair { Value = 17 };
        Check(t, S.Lambda<Func<Pair>>(S.TryFinally(S.Constant(pair), S.Empty())), pair, "");
        Check(t, S.Lambda<Func<Pair>>(S.TryFinally(S.Default(typeof(Pair)), S.Empty())), default(Pair), "");
        Check(t, S.Lambda<Func<int>>(S.Field(S.TryFinally(S.Constant(pair), S.Empty()), nameof(Pair.Value))), 17, "");
        var obj = new object();
        Check(t, S.Lambda<Func<object>>(S.TryFinally(S.Constant(obj), S.Empty())), obj, "");
        Check(t, S.Lambda<Func<object>>(S.TryFinally(S.Constant(null, typeof(object)), S.Empty())), null, "");
    }
    public void Throw_preserves_identity_and_outer_cleanup(TestContext t)
    {
        var exception = new InvalidOperationException("identity"); var caught = S.Parameter(typeof(Exception));
        var tree = S.Lambda<Func<Exception>>(S.TryCatch(S.TryFinally(
            S.TryFinally(S.Throw(S.Constant(exception), typeof(Exception)), S.Empty()), S.Block(M("cleanup"), S.Empty())), S.Catch(caught, caught)));
        Check(t, tree, exception, "cleanup;");
    }
    public void Raw_nonexception_preserves_matching(TestContext t)
    {
        var payload = new object(); var caught = S.Parameter(typeof(object));
        Check(t, S.Lambda<Func<object>>(S.TryCatch(S.TryFinally(S.Throw(S.Constant(payload, typeof(object)), typeof(object)), S.Empty()),
            S.Catch(caught, caught))), payload, "");
    }
    public void Outward_and_inner_goto(TestContext t)
    {
        var done = S.Label(typeof(int), "done");
        Check(t, S.Lambda<Func<int>>(S.Block(S.TryFinally(S.Goto(done, M("jump", 47)), S.Empty()), S.Label(done, S.Constant(0)))), 47, "jump;");
        var local = S.Label(typeof(int), "local");
        Check(t, S.Lambda<Func<int>>(S.TryFinally(S.Block(S.Goto(local, S.Constant(29)), M("unreachable"), S.Label(local, S.Constant(0))), S.Empty())), 29, "");
        var outer = S.Label(typeof(int), "outer");
        Check(t, S.Lambda<Func<int>>(S.Block(S.TryFinally(S.TryFinally(S.Goto(outer, S.Constant(23)), S.Empty()), S.Empty()), S.Label(outer, S.Constant(0)))), 23, "");
    }
    public void Outward_goto_keeps_real_outer_finally(TestContext t)
    {
        var done = S.Label(typeof(int), "real-outer");
        Check(t, S.Lambda<Func<int>>(S.Block(S.TryFinally(S.TryFinally(S.Goto(done, M("jump", 37)), S.Empty()),
            S.Block(M("real-finally"), S.Empty())), S.Label(done, S.Constant(0)))), 37, "jump;real-finally;");
    }
    public void Value_break_in_empty_finally(TestContext t)
    {
        var loopExit = S.Label(typeof(int), "loop-exit");
        Check(t, S.Lambda<Func<int>>(S.Loop(S.TryFinally(S.Break(loopExit, S.Constant(31)), S.Empty()), loopExit)), 31, "");
    }
    public void Rethrow_keeps_enclosing_catch(TestContext t)
    {
        var exception = new ApplicationException("same"); var caught = S.Parameter(typeof(Exception));
        Check(t, S.Lambda<Func<Exception>>(S.TryCatch(S.TryCatch(S.Throw(S.Constant(exception), typeof(Exception)),
            S.Catch(typeof(Exception), S.TryFinally(S.Rethrow(typeof(Exception)), S.Empty()))), S.Catch(caught, caught))), exception, "");
    }
    public void Byref_argument_and_inlined_lambda(TestContext t)
    {
        var x = S.Parameter(typeof(int), "x");
        Check(t, S.Lambda<Func<int>>(S.Block(new[] { x }, S.Assign(x, S.Constant(4)),
            S.TryFinally(S.Call(typeof(EmptyFinallyRegressionTests).GetMethod(nameof(ReadRef)), x), S.Empty()))), 5, "");
        var p = S.Parameter(typeof(int));
        var lambda = S.Lambda<Func<int, int>>(S.TryFinally(S.Add(p, S.Constant(3)), S.Empty()), p);
        Check(t, S.Lambda<Func<int>>(S.Invoke(lambda, S.Constant(6))), 9, "");
        Check(t, S.Lambda<Func<int>>(S.Block(new[] { x }, S.Assign(x, S.Constant(4)),
            S.Call(typeof(EmptyFinallyRegressionTests).GetMethod(nameof(ReadRef)), S.TryFinally(x, S.Empty())), x)), 4, "");
    }
    public void Explicit_try_result_types(TestContext t)
    {
        // Explicit result types are independent of the body's expression type.
        Check(t, S.Lambda<Func<object>>(S.MakeTry(typeof(object), S.Constant("reference"), S.Empty(), null, null)), (object)"reference", "");
        Check(t, S.Lambda<Func<IComparable>>(S.MakeTry(typeof(IComparable), S.Constant("interface"), S.Empty(), null, null)), (IComparable)"interface", "");
        Check(t, S.Lambda<Func<int>>(S.Block(S.MakeTry(typeof(void), M("discard", 33), S.Empty(), null, null), S.Constant(1))), 1, "discard;");
    }
    public void Nonempty_finally_catch_and_debug_finally_are_retained(TestContext t)
    {
        Check(t, S.Lambda<Func<int>>(S.TryFinally(M("body", 6), S.Block(M("finally"), S.Empty()))), 6, "body;finally;");
        Check(t, S.Lambda<Func<int>>(S.TryCatchFinally(S.Throw(S.New(typeof(Exception)), typeof(int)),
            S.Empty(), S.Catch(typeof(Exception), M("catch", 13)))), 13, "catch;");
        var doc = S.SymbolDocument("empty-finally.cs");
        Check(t, S.Lambda<Func<int>>(S.TryFinally(S.Constant(19), S.Block(S.DebugInfo(doc, 1, 1, 1, 2), S.Empty()))), 19, "");
    }
    public void Invalid_incoming_goto_is_still_rejected(TestContext t)
    {
        var target = S.Label("inside");
        var tree = S.Lambda<Action>(S.Block(S.Goto(target), S.TryFinally(S.Label(target), S.Empty())));
        t.Throws<InvalidOperationException>(() => tree.Compile());
        foreach (var flags in Flags) t.Throws<InvalidOperationException>(() => tree.FromSysExpression().CompileFast(true, flags));
    }
    public void Empty_try_inside_filter_still_rejected(TestContext t)
    {
        var tree = S.Lambda<Action>(S.TryCatch(S.Throw(S.New(typeof(Exception))),
            S.Catch(typeof(Exception), S.Empty(), S.TryFinally(S.Constant(true), S.Empty()))));
        foreach (var flags in Flags) t.Throws<InvalidOperationException>(() => tree.FromSysExpression().CompileFast(true, flags));
    }
#if LIGHT_EXPRESSION
    sealed class IntrinsicDefault : UnaryExpression
    {
        readonly Expression _body = Expression.Call(typeof(EmptyFinallyRegressionTests).GetMethod(nameof(Mark)), Expression.Constant("intrinsic-finally"), Expression.Constant(0));
        public override E.ExpressionType NodeType => E.ExpressionType.Default;
        public override Type Type => typeof(void);
        public IntrinsicDefault() : base(Expression.Empty()) { }
        public override bool IsIntrinsic => true;
        public override ExpressionCompiler.Result TryCollectInfo(ref ExpressionCompiler.CompilerContext context, ExpressionCompiler.NestedLambdaInfo nestedLambda,
            ref ImTools.SmallList<ExpressionCompiler.NestedLambdaInfo> rootNestedLambdas) => ExpressionCompiler.TryCollectInfo(ref context, _body, nestedLambda, ref rootNestedLambdas);
        public override bool TryEmit(ref ExpressionCompiler.CompilerContext context, System.Reflection.Emit.ILGenerator il, ExpressionCompiler.ParentFlags parent, int byRefIndex = -1) =>
            ExpressionCompiler.EmittingVisitor.TryEmit(_body, il, ref context, parent | ExpressionCompiler.ParentFlags.IgnoreResult, byRefIndex);
    }
    public void Intrinsic_default_finally_is_not_empty(TestContext t)
    {
        foreach (var flags in Flags)
        {
            var source = Expression.Lambda<Func<int>>(Expression.TryFinally(Expression.Constant(11), new IntrinsicDefault()));
            var fast = source.CompileFast(true, flags); Trace = "";
            t.AreEqual(11, fast()); t.AreEqual("intrinsic-finally;", Trace);
        }
    }
#endif
#if NETFRAMEWORK
    public static void AbortSelf() => Thread.CurrentThread.Abort();
    public static void ResetAbort() { Trace += "reset;"; Thread.ResetAbort(); }
    public void Thread_abort_catch_and_finally_order(TestContext t)
    {
        var abort = S.Call(typeof(EmptyFinallyRegressionTests).GetMethod(nameof(AbortSelf)));
        var reset = S.Call(typeof(EmptyFinallyRegressionTests).GetMethod(nameof(ResetAbort)));
        // The abort escapes the empty finally and is reset by the surrounding catch.
        var simple = S.Lambda<Action>(S.TryCatch(S.TryFinally(S.TryFinally(abort, S.Empty()), S.Block(M("actual-finally"), S.Empty())),
            S.Catch(typeof(ThreadAbortException), S.Block(M("catch"), reset))));
        // An automatically rethrown abort crosses another empty finally before the outer catch resets it.
        var nested = S.Lambda<Action>(S.TryCatch(S.TryCatch(abort,
            S.Catch(typeof(ThreadAbortException), S.TryFinally(S.Block(M("inner-catch"), S.Empty()), S.Empty()))),
            S.Catch(typeof(ThreadAbortException), S.Block(M("outer-catch"), reset))));
        foreach (var tree in new[] { simple, nested })
        {
            var expected = RunAbort(tree.Compile());
            t.IsTrue(expected.StartsWith("actual-finally;catch;reset;") || expected.StartsWith("inner-catch;outer-catch;reset;"));
            foreach (var flags in Flags) t.AreEqual(expected, RunAbort(tree.FromSysExpression().CompileFast(true, flags)));
        }
    }
    static string RunAbort(Action run)
    {
        Trace = ""; Exception failure = null;
        var thread = new Thread(() => { try { run(); } catch (ThreadAbortException) { Thread.ResetAbort(); failure = new Exception("escaped abort"); } catch (Exception ex) { failure = ex; } });
        thread.IsBackground = true; thread.Start();
        if (!thread.Join(10000)) { thread.Abort(); throw new Exception("abort worker did not finish"); }
        if (failure != null) throw failure;
        return Trace;
    }
#endif
}
