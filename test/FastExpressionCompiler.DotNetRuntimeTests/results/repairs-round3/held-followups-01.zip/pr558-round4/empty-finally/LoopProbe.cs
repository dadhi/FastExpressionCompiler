using System;
using System.Linq;
using System.Reflection;
using S=System.Linq.Expressions.Expression;
using L=System.Linq.Expressions.LambdaExpression;
class LoopProbe {
 static void Main(string[] args) {
  var done=S.Label(typeof(int),"loop-exit");var tree=S.Lambda<Func<int>>(S.Loop(S.TryFinally(S.Break(done,S.Constant(31)),S.Empty()),done));
  Console.WriteLine("System="+tree.Compile()());
  foreach(var path in args) foreach(var flag in new[]{"Default","NoInvocationLambdaInlining"}) {
   var asm=Assembly.LoadFrom(path);bool light=asm.GetType("FastExpressionCompiler.LightExpression.ExpressionCompiler")!=null;
   var compiler=asm.GetType(light?"FastExpressionCompiler.LightExpression.ExpressionCompiler":"FastExpressionCompiler.ExpressionCompiler",true);
   string stage="compile";
   try {
    object input=tree;
    if(light) input=compiler.GetMethods().Single(m=>m.Name=="FromSysExpression"&&!m.IsGenericMethod&&m.GetParameters().Length==1).Invoke(null,new object[]{tree});
    var compile=compiler.GetMethods().Single(m=>m.Name=="CompileFast"&&!m.IsGenericMethod&&m.GetParameters().Length==3&&m.GetParameters()[0].ParameterType.FullName==(light?"FastExpressionCompiler.LightExpression.LambdaExpression":typeof(L).FullName));
    var d=(Func<int>)compile.Invoke(null,new object[]{input,true,Enum.Parse(compile.GetParameters()[2].ParameterType,flag)});stage="invoke";
    Console.WriteLine(asm.GetName().Name+" "+flag+" "+(d==null?"NULL":d().ToString()));
   } catch(Exception e) {while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;Console.WriteLine(asm.GetName().Name+" "+flag+" "+stage+" "+e.GetType().FullName+": "+e.Message);}
  }
 }
}
