This is an isolated proposal against 42f9847843cec8edaaf11c00cb97a5dd576b82cf. No production edits or accepted performance claim.

Applicable shape: NET8_0_OR_GREATER target builds only (the tested .NET8/.NET10 targets), no catch handlers, no fault, and finally is actual DefaultExpression of void type. Light intrinsic nodes are excluded. Empty Blocks, DebugInfo Blocks, nonempty finalizers, catches and faults remain on the original emitter. Framework, netstandard and source builds without the positive target symbol retain every original region; modern netstandard consumers do not implicitly gain this optimization.

Collection, semantic jump/rethrow/filter validation, original tree/debug attachment, HasExceptionBlock, anonymous DynamicMethod selection and caller operand spill policy remain unchanged. The dispatcher passes original parent flags; only the normal EH path adds TryCatch. The elided path therefore does not introduce a nonexistent Leave region, while retaining flags for a real enclosing Try/Catch. Filter rejection precedes the fast path.

CLR CER audit (primary sources, read 2026-10-19):

- https://learn.microsoft.com/en-us/dotnet/framework/performance/constrained-execution-regions documents PrepareConstrainedRegions immediately preceding a try, delay of thread abort within CER, and support only on Framework (not Core/5+).
- https://raw.githubusercontent.com/dotnet/coreclr/release/1.0.0/src/vm/constrainedexecutionregion.cpp lines423–446 associates the PCR marker with EH try offsets immediately following its call, skipping NOPs. Lines273–285 include static constructors in prepared call graphs. Removing an entirely empty region can therefore associate a following real region with a marker in runtimes which process this path.
- https://raw.githubusercontent.com/dotnet/coreclr/release/1.0.0/src/vm/jitinterface.cpp lines4707–4725 performs this preparation only when caller MethodDesc.IsIL().
- https://raw.githubusercontent.com/dotnet/coreclr/release/1.0.0/src/vm/method.hpp lines412–416 defines IsIL to include mcIL/mcInstantiated, excluding mcDynamic (classification definition lines88–109).

The historical primary implementation excludes DynamicMethods, but is not a complete proof of the installed closed-source .NET Framework4.8 implementation. The proposal therefore excludes Framework rather than infer safety from passing tests. CER and Thread.Abort are unsupported on modern .NET. Framework tests are preservation controls, not evidence of Framework optimization.

The no-EH path retains the original Try result temporary (stloc/ldloc), including explicit node.Type and IgnoreResult handling. Plain forwarding to the body would require a separate proof of byref/struct receiver storage isolation and result typing; it is not part of this proposal.

ThreadAbort reference: https://learn.microsoft.com/en-us/dotnet/standard/threading/destroying-threads . Framework auto-rethrows ThreadAbortException after a catch unless ResetAbort is called. Modern Thread.Abort is unsupported. Focused Framework controls use a worker which aborts itself, catches/resets at an outer boundary, and records observable real-finally/catch order. They do not claim proof of every asynchronous interruption schedule.

Measurements must include actual side-effecting finalizers/catches in addition to Default(void) targets. Compare parsing/compile, first invocation, warmed runtime and managed bytes independently; retain host policy. No no-op hosting/security workaround.
