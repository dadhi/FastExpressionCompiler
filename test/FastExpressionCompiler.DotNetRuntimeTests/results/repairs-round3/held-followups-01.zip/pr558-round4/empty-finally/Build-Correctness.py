from pathlib import Path
import subprocess, shutil, json, hashlib, sys
w=Path(__file__).resolve().parent
rows=[]
for variant in ['current','candidate']:
 for light in ['false','true']:
  for tfm in (sys.argv[1:] or ['net8.0','net10.0']):
   tag=variant+'-'+light+'-'+tfm
   cmd=['dotnet','build','Fixture.csproj','-c','Release','-f',tfm,'-p:Light='+light,'-p:Variant='+variant,'--nologo','-v:q']
   with (w/('build-'+tag+'.log')).open('w') as f: subprocess.run(cmd,cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True)
   out=w/'runners'/tag; out.mkdir(parents=True,exist_ok=True)
   for p in (w/'bin'/'Release'/tfm).glob('*'):
    if p.is_file(): shutil.copy2(p,out/p.name)
   library='EmptyFinally.'+variant+('.Light' if light=='true' else '')+'.dll'
   shutil.copy2(w/(variant+('-light' if light=='true' else ''))/'bin'/'Release'/tfm/library,out/library)
   executable=out/('Fixture.'+variant+'.'+light+('.exe' if tfm=='net472' else '.dll'))
   run=[str(executable)] if tfm=='net472' else ['dotnet',str(executable)]
   with (w/('correctness-'+tag+'.log')).open('w') as f: subprocess.run(run,cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True)
   result=(w/('correctness-'+tag+'.log')).read_text()
   rows.append(dict(variant=variant,light=light,runtime=tfm,output=result,assemblySHA256=hashlib.sha256((out/library).read_bytes()).hexdigest()))
   (w/'correctness.json').write_text(json.dumps(rows,indent=2))
   print(tag,result.strip(),flush=True)
