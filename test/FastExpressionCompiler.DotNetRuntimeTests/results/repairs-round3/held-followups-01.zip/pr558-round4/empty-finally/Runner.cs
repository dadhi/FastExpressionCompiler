using System;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
class Runner {
 static readonly Func<long> Allocated=(Func<long>)Delegate.CreateDelegate(typeof(Func<long>),typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread"));
 public static void Row(string name,string phase,string version,int round,int sample,int operations,double ns,double bytes) => Console.WriteLine(name+","+phase+","+version+","+round+","+sample+","+operations+","+ns.ToString("R",CultureInfo.InvariantCulture)+","+bytes.ToString("R",CultureInfo.InvariantCulture));
 static void Measure(string name,string phase,string version,int round,int sample,Action<int> op,int n) { long b=Allocated(),t=Stopwatch.GetTimestamp();op(n);long e=Stopwatch.GetTimestamp()-t;Row(name,phase,version,round,sample,n,e*1e9/Stopwatch.Frequency/n,(Allocated()-b)/(double)n); }
 static int Count(string p)=>p=="compile"?32:p=="compile_first"?8:p=="activate"?1000:50000;
 static void Main(string[] args) {
  if(args[0]=="cold") { if(args[1]=="current")Current.Bench.Cold(args[2]);else if(args[1]=="candidate")Candidate.Bench.Cold(args[2]);else SystemSide.Bench.Cold(args[2]);return; }
  int round=int.Parse(args[1]);var versions=new[]{"current","candidate","system"};
  foreach(var name in args.Skip(2)) {
   var operations=new[]{Current.Bench.Operations(name),Candidate.Bench.Operations(name),SystemSide.Bench.Operations(name)};
   foreach(var phase in operations[0].Keys) {
    int n=Count(phase);foreach(var ops in operations)ops[phase](40);
    for(int k=0;k<31;k++) {
     if(k%8==0){GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();}
     for(int order=0;order<3;order++){int v=(k+round+order)%3;Measure(name,phase,versions[v],round,k,operations[v][phase],n);}
    }
   }
   Console.Error.WriteLine("PASS "+name);
  }
 }
}
