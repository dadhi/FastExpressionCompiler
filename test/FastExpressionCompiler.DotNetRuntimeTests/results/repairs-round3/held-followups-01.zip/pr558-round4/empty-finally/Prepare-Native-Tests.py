"""Prepare proposed native fixture diff in scratch; never changes the repo."""
from pathlib import Path
import difflib
w=Path(__file__).resolve().parent
original=(w/'ExceptionRegionValidationRegressionTests.cs').read_text()
extra=(w/'EmptyFinallyRegressionTests.cs').read_text()
extra=extra.replace('EmptyFinallyRegressionTests','ExceptionRegionValidationRegressionTests')
start=extra.index('{',extra.index('public struct'))+1
run=extra.index('    public void Run(TestRun t)')
bracket=extra.index('{',run);depth=1;end=bracket+1
while depth:
 if extra[end]=='{':depth+=1
 elif extra[end]=='}':depth-=1
 end+=1
calls=extra[bracket+1:end-1]
# Asynchronous ThreadAbort and CER diagnostics stay in scratch evidence. The
# existing regular native fixture gets deterministic semantic regressions.
calls=calls[:calls.index('#if NETFRAMEWORK')]
calls=calls.replace('NET8_0_OR_GREATER && EMPTY_FINALLY_ELIDED','NET8_0_OR_GREATER')
append=extra[start:run]+extra[end:extra.rfind('}')]
append=append[:append.index('#if NETFRAMEWORK\n    public static void AbortSelf')]
proposed=original.replace('using System;','using System;\nusing E = System.Linq.Expressions;')
anchor='        Separately_compiled_lambda_does_not_inherit_outer_catch(t);'
assert proposed.count(anchor)==1
proposed=proposed.replace(anchor,anchor+'\n'+calls.strip('\n'))
proposed=proposed[:proposed.rfind('}')]+append+'}\n'
(w/'proposed-ExceptionRegionValidationRegressionTests.cs.txt').write_text(proposed)
(w/'native-tests.diff').write_text(''.join(difflib.unified_diff(original.splitlines(keepends=True),proposed.splitlines(keepends=True),fromfile='a/test/FastExpressionCompiler.UnitTests/ExceptionRegionValidationRegressionTests.cs',tofile='b/test/FastExpressionCompiler.UnitTests/ExceptionRegionValidationRegressionTests.cs')))
print('Prepared native test diff, no repository edits')
