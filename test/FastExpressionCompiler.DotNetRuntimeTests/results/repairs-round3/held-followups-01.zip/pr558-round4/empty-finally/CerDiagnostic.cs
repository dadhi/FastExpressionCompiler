using System;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.ConstrainedExecution;
public class CerDiagnostic
{
    public static string Trace;
    public static void Mark(string s) { Trace += s+";"; }
    public static void Main()
    {
        foreach (var dynamic in new[] { false, true })
        foreach (var emptyFirst in new[] { true, false })
        {
            Trace = "";
            var assembly = AppDomain.CurrentDomain.DefineDynamicAssembly(new AssemblyName("CerProof"+Guid.NewGuid().ToString("N")), AssemblyBuilderAccess.Run);
            var module = assembly.DefineDynamicModule("proof");
            var target = module.DefineType("Target", TypeAttributes.Public|TypeAttributes.Abstract|TypeAttributes.Sealed);
            var ctor = target.DefineTypeInitializer().GetILGenerator();
            ctor.Emit(OpCodes.Ldstr, "cctor"); ctor.Emit(OpCodes.Call, typeof(CerDiagnostic).GetMethod(nameof(Mark))); ctor.Emit(OpCodes.Ret);
            var finish = target.DefineMethod("Finish", MethodAttributes.Public|MethodAttributes.Static, typeof(void), Type.EmptyTypes);
            finish.SetImplementationFlags(MethodImplAttributes.IL|MethodImplAttributes.Managed|MethodImplAttributes.NoInlining);
            finish.SetCustomAttribute(new CustomAttributeBuilder(typeof(ReliabilityContractAttribute).GetConstructor(new[]{typeof(Consistency),typeof(Cer)}),new object[]{Consistency.WillNotCorruptState,Cer.Success}));
            var fi=finish.GetILGenerator();fi.Emit(OpCodes.Ldstr,"finally");fi.Emit(OpCodes.Call,typeof(CerDiagnostic).GetMethod(nameof(Mark)));fi.Emit(OpCodes.Ret);
            var targetType=target.CreateType();
            DynamicMethod dm=null;MethodBuilder method=null;TypeBuilder container=null;
            if(dynamic) dm=new DynamicMethod("run",typeof(void),Type.EmptyTypes,true);
            else { container=module.DefineType("Container",TypeAttributes.Public);method=container.DefineMethod("Run",MethodAttributes.Public|MethodAttributes.Static,typeof(void),Type.EmptyTypes); }
            var il=dynamic?dm.GetILGenerator():method.GetILGenerator();
            il.Emit(OpCodes.Call,typeof(RuntimeHelpers).GetMethod(nameof(RuntimeHelpers.PrepareConstrainedRegions)));
            if(emptyFirst){il.BeginExceptionBlock();il.BeginFinallyBlock();il.EndExceptionBlock();}
            il.BeginExceptionBlock();il.Emit(OpCodes.Ldstr,"body");il.Emit(OpCodes.Call,typeof(CerDiagnostic).GetMethod(nameof(Mark)));
            il.BeginFinallyBlock();il.Emit(OpCodes.Call,targetType.GetMethod("Finish"));il.EndExceptionBlock();il.Emit(OpCodes.Ret);
            var action=dynamic?(Action)dm.CreateDelegate(typeof(Action)):(Action)Delegate.CreateDelegate(typeof(Action),container.CreateType().GetMethod("Run"));
            var prepared=Trace;Trace="";action();
            Console.WriteLine((dynamic?"DynamicMethod":"ordinary")+",emptyFirst="+emptyFirst+",creation="+prepared+",execution="+Trace);
        }
    }
}
