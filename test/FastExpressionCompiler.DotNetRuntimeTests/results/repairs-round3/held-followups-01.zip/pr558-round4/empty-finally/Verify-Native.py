from pathlib import Path
import subprocess,json,hashlib
w=Path(__file__).resolve().parent
(w/'NativeFixture.cs').write_text('''using System;
#if LIGHT_EXPRESSION
using FastExpressionCompiler.LightExpression;
using FastExpressionCompiler.LightExpression.UnitTests;
#else
using FastExpressionCompiler;
using FastExpressionCompiler.UnitTests;
#endif
class NativeFixture { static void Main() { System.Threading.Thread.CurrentThread.CurrentCulture=System.Globalization.CultureInfo.GetCultureInfo("en-US");var t=new TestRun();t.Run(new ExceptionRegionValidationRegressionTests());Console.WriteLine("TOTAL="+t.TotalTestCount+" FAILED="+t.FailedTestCount);Environment.ExitCode=t.FailedTestCount==0?0:1; }}
''')
project=(w/'Fixture.csproj').read_text();start=project.index('<ItemGroup>');end=project.index('</ItemGroup>',start)+len('</ItemGroup>')
project=project[:start]+'''<ItemGroup><Compile Include="NativeFixture.cs"/><Compile Include="proposed-ExceptionRegionValidationRegressionTests.cs.txt"/><ProjectReference Include="candidate/Library.csproj" Condition="'$(Light)'!='true'"/><ProjectReference Include="candidate-light/Library.csproj" Condition="'$(Light)'=='true'"/></ItemGroup>'''+project[end:]
project=project.replace('Fixture.$(Variant).$(Light)','NativeFixture.$(Light)')
(w/'NativeFixture.csproj').write_text(project)
audit={v:dict(SHA256=hashlib.sha256((w/v/'FastExpressionCompiler.cs').read_bytes()).hexdigest(),CRCRLF=(w/v/'FastExpressionCompiler.cs').read_bytes().count(b'\r\r\n')) for v in ['current','candidate']}
(w/'newline-audit.json').write_text(json.dumps(audit,indent=2))
print(audit,flush=True)
for light in ['false','true']:
 for tfm in ['net8.0','net10.0','net472']:
  tag=light+'-'+tfm
  with (w/('native-build-'+tag+'.log')).open('w') as f:subprocess.run(['dotnet','build','NativeFixture.csproj','-c','Release','-f',tfm,'-p:Light='+light,'--nologo','-v:q'],cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True)
  exe=w/'bin'/'Release'/tfm/('NativeFixture.'+light+('.exe' if tfm=='net472' else '.dll'))
  command=[str(exe)] if tfm=='net472' else ['dotnet',str(exe)]
  result=subprocess.run(command,cwd=w,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True).stdout
  (w/('native-'+tag+'.log')).write_text(result)
  print(tag,result.strip(),flush=True)
