All paths below are scratch evidence; no production or imported-test denominator changes.

CER (Framework4.8, X64 process on ARM64 OS): `CerDiagnostic.cs` emits a positive ordinary-method control and an anonymous DynamicMethod control. `cer-diagnostic.log` shows:

- ordinary method, first empty region retained: body;cctor;finally
- ordinary method, first empty region removed: cctor;body;finally
- DynamicMethod, either variant: body;cctor;finally

This establishes CER-marker reassociation for ordinary methods and no such preparation in the tested DynamicMethod runtime, consistent with historical primary-source IsIL exclusion. The production proposal nevertheless remains NET8_0_OR_GREATER only, preserving Framework/netstandard/unknown embedded targets.

Loop value-break: `LoopProbe.cs` builds `Lambda<Func<int>>(Loop(TryFinally(Break(label,31),Empty()),label))`. The System compiler returns31 on all three runtimes. Frozen e4 pre-PR and42f current FEC both reject the generated IL with InvalidProgramException (invocation on modern, compilation on Framework), Standard/Light, Default/NoInvocationLambdaInlining. Candidate returns31 on modern8/10, and preserves the old Framework rejection because optimization is disabled there. Full records: loop-net8.log, loop-net10.log, loop-net472.log. Initial discovery stack: baseline-invalid-loop-break.log.

The new modern-only native regression asserts the correct System result after optimization. Prototype baseline correctness excludes this newly added case using the EMPTY_FINALLY_ELIDED test-only symbol; it never asserts or blesses the old InvalidProgramException. All previous native/imported tests remain unchanged. This shape is excluded from before-versus-after performance comparisons because it never worked in the baseline.

The deterministic native regression proposal excludes ThreadAbort worker diagnostics. Those controls remain in scratch fixtures and pass on Framework (both current/candidate, Standard/Light); they are preservation controls because no Framework optimization is proposed.
