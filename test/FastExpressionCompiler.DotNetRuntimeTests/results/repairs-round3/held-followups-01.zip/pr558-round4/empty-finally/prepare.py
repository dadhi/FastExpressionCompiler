"""Export isolated source snapshots; does not build or execute them."""
from pathlib import Path
import subprocess, hashlib, json
w = Path(__file__).resolve().parent
repo = Path(r'C:/Data/Git/Github/FastExpressionCompiler')
ref = '42f9847843cec8edaaf11c00cb97a5dd576b82cf'
manifest = dict(baseline=ref, files={})
for version in ['current', 'candidate']:
 for light in [False, True]:
  d = w / (version + ('-light' if light else '')); d.mkdir(exist_ok=True)
  for name in ['FastExpressionCompiler.cs', 'ImTools.cs', 'ILReader.cs', 'TestTools.cs']:
   data = subprocess.check_output(['git','show',ref+':src/FastExpressionCompiler/'+name],cwd=repo)
   if version == 'candidate' and name == 'FastExpressionCompiler.cs':
    changes = [(b'return TryEmitTryCatchFinallyBlock((TryExpression)expr, il, ref context, parent | ParentFlags.TryCatch);', b'return TryEmitTryCatchFinallyBlock((TryExpression)expr, il, ref context, parent\r\n#if NETFRAMEWORK\r\n                                | ParentFlags.TryCatch\r\n#endif\r\n                                );')]
    anchor = b'''                if (context.IsEmittingExceptionFilter)\r\n                    return false;\r\n#if DEMIT\r\n                Debug.WriteLine("try {");'''
    replacement = b'''                if (context.IsEmittingExceptionFilter)\r\n                    return false;\r\n\r\n#if !NETFRAMEWORK\r\n                // Keep Framework EH regions: their position can participate in CER semantics.\r\n                // Collection, hosting and result temporary behavior remain unchanged.\r\n                var emptyFinally = tryExpr.Finally;\r\n                if (tryExpr.Handlers.Count == 0 && tryExpr.Fault == null &&\r\n                    emptyFinally is DefaultExpression && emptyFinally.Type == typeof(void)\r\n#if LIGHT_EXPRESSION\r\n                    && !emptyFinally.IsIntrinsic\r\n#endif\r\n                    )\r\n                {\r\n                    if (!TryEmit(tryExpr.Body, il, ref context, parent))\r\n                        return false;\r\n                    var emptyResultType = tryExpr.Type;\r\n                    if (emptyResultType != typeof(void) && !parent.IgnoresResult())\r\n                    {\r\n                        var resultLocal = il.GetNextLocalVarIndex(emptyResultType);\r\n                        EmitStoreLocalVariable(il, resultLocal);\r\n                        EmitLoadLocalVariable(il, resultLocal);\r\n                    }\r\n                    return true;\r\n                }\r\n#endif\r\n\r\n                parent |= ParentFlags.TryCatch;\r\n#if DEMIT\r\n                Debug.WriteLine("try {");'''
    replacement = replacement.replace(b'                }\r\n#endif\r\n\r\n                parent |= ParentFlags.TryCatch;\r\n#if DEMIT', b'                }\r\n\r\n                parent |= ParentFlags.TryCatch;\r\n#endif\r\n#if DEMIT')
    changes[0] = (changes[0][0], changes[0][1].replace(b'#if NETFRAMEWORK', b'#if !NET8_0_OR_GREATER'))
    replacement = replacement.replace(b'#if !NETFRAMEWORK', b'#if NET8_0_OR_GREATER')
    replacement = replacement.replace(b'                    return true;\r\n                }', b'                    context.LastEmitIsAddress = false; // Empty finally normally resets this.\r\n                    return true;\r\n                }')
    changes.append((anchor,replacement))
    for a,b in changes:
     if data.count(a) == 0 and b'\r\n' in a:
      a,b = a.replace(b'\r\n',b'\n'), b.replace(b'\r\n',b'\n')
     if data.count(a) != 1: raise RuntimeError('anchor count '+str(data.count(a))+': '+repr(a))
     data = data.replace(a,b)
   (d/name).write_bytes(data)
  if light:
   for name in ['Expression.cs','ExpressionVisitor.cs','FlatExpression.cs']:
    (d/name).write_bytes(subprocess.check_output(['git','show',ref+':src/FastExpressionCompiler.LightExpression/'+name],cwd=repo))
  (d/'Library.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><AssemblyName>EmptyFinally.'+version+('.Light' if light else '')+'</AssemblyName>'+('<DefineConstants>LIGHT_EXPRESSION</DefineConstants>' if light else '')+'</PropertyGroup></Project>')
  manifest['files'][d.name] = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.glob('*.cs')}
tests = ['NonExceptionThrowPolicyRegressionTests','ExceptionJumpValidationRegressionTests','ExceptionRegionValidationRegressionTests','InlinedRethrowBoundaryRegressionTests','NestedJumpArgumentRegressionTests','InvocationJumpArgumentRegressionTests']
for name in tests:
 (w/(name+'.cs')).write_bytes(subprocess.check_output(['git','show',ref+':test/FastExpressionCompiler.UnitTests/'+name+'.cs'],cwd=repo))
(w/'Fixture.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><OutputType>Exe</OutputType><LangVersion>latest</LangVersion><Optimize>true</Optimize><EnableDefaultCompileItems>false</EnableDefaultCompileItems><Light Condition="\'$(Light)\'==\'\'">false</Light><Variant Condition="\'$(Variant)\'==\'\'">candidate</Variant><AssemblyName>Fixture.$(Variant).$(Light)</AssemblyName><DefineConstants Condition="\'$(Light)\'==\'true\'">$(DefineConstants);LIGHT_EXPRESSION</DefineConstants></PropertyGroup><ItemGroup><Compile Include="Fixture.cs"/><Compile Include="EmptyFinallyRegressionTests.cs"/>'+''.join('<Compile Include="'+n+'.cs"/>' for n in tests)+'<ProjectReference Include="$(Variant)/Library.csproj" Condition="\'$(Light)\'!=\'true\'"/><ProjectReference Include="$(Variant)-light/Library.csproj" Condition="\'$(Light)\'==\'true\'"/></ItemGroup></Project>')
(w/'Fixture.cs').write_text('''using System;
#if LIGHT_EXPRESSION
using FastExpressionCompiler.LightExpression;
using FastExpressionCompiler.LightExpression.UnitTests;
#else
using FastExpressionCompiler;
using FastExpressionCompiler.UnitTests;
#endif
class Program { static void Main() { System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.GetCultureInfo("en-US"); var t = new TestRun();
'''+''.join('t.Run(new '+n+'());\n' for n in ['EmptyFinallyRegressionTests']+tests)+'''Console.WriteLine("TOTAL="+t.TotalTestCount+" FAILED="+t.FailedTestCount); Environment.ExitCode=t.FailedTestCount==0?0:1; }}''')
fixture=(w/'Fixture.csproj').read_text().replace('</PropertyGroup>', '<DefineConstants Condition="\'$(Variant)\'==\'candidate\'">$(DefineConstants);EMPTY_FINALLY_ELIDED</DefineConstants></PropertyGroup>')
(w/'Fixture.csproj').write_text(fixture)
(w/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('Prepared isolated empty-finally source snapshots; no builds/executions')
