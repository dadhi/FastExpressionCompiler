using System;
#if LIGHT_EXPRESSION
using FastExpressionCompiler.LightExpression;
using FastExpressionCompiler.LightExpression.UnitTests;
#else
using FastExpressionCompiler;
using FastExpressionCompiler.UnitTests;
#endif
class NativeFixture { static void Main() { System.Threading.Thread.CurrentThread.CurrentCulture=System.Globalization.CultureInfo.GetCultureInfo("en-US");var t=new TestRun();t.Run(new ExceptionRegionValidationRegressionTests());Console.WriteLine("TOTAL="+t.TotalTestCount+" FAILED="+t.FailedTestCount);Environment.ExitCode=t.FailedTestCount==0?0:1; }}
