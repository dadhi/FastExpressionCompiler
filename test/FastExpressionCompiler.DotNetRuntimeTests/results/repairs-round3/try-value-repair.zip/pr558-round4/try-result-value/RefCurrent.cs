extern alias Current;
using System;
using Current::FastExpressionCompiler.LightExpression;
namespace CurrentSide { static class Run { public static void Test(){try{var call=Expression.Call(typeof(RefProbe).GetMethod(nameof(RefProbe.GetRef)));Console.WriteLine("current Call.Type="+call.Type);var tree=Expression.Lambda<RefProbeGetter>(Expression.TryFinally(call,Expression.Empty()));var d=tree.CompileFast(true);RefProbe.Value=4;d()=8;Console.WriteLine("current Try.Type="+tree.Body.Type+" value="+RefProbe.Value);}catch(Exception e){Console.WriteLine("current "+e.GetType().FullName+": "+e.Message);}}}}
