from pathlib import Path
import subprocess, os
w=Path(__file__).resolve().parent
env=os.environ.copy();env['DOTNET_TieredCompilation']='0';env['DOTNET_ReadyToRun']='0'
shapes=['add','balanced256','try_finally','try_finally_real','try_catch','default_receiver','nested_eh32','nested_eh32_real','goto_empty','capture1','capture_try']
for light in ['false','true']:
 for tfm in ['net8.0','net10.0','net472']:
  tag=light+'-'+tfm;exe=w/'bench-runners'/tag/('Bench.'+light+('.exe' if tfm=='net472' else '.dll')); prefix=[str(exe)] if tfm=='net472' else ['dotnet',str(exe)]
  for r in range(2):
   with (w/('warm-'+tag+'-'+str(r)+'.csv')).open('w') as f,(w/('warm-'+tag+'-'+str(r)+'.log')).open('w') as err:
    subprocess.run(prefix+['pair',str(r)]+shapes,cwd=w,env=env,stdout=f,stderr=err,check=True)
   print('Warm '+tag+' round'+str(r),flush=True)
  for r in range(3):
   for shape in ['add','try_finally','try_finally_real','nested_eh32']:
    versions=['current','fixed','system'];versions=versions[r%3:]+versions[:r%3]
    if r%2:versions.reverse()
    for version in versions:
     name='cold-'+tag+'-'+str(r)+'-'+version+'-'+shape
     with (w/(name+'.csv')).open('w') as f,(w/(name+'.log')).open('w') as err:
      subprocess.run(prefix+['cold',version,shape],cwd=w,env=env,stdout=f,stderr=err,check=True)
   print('Cold '+tag+' repetition'+str(r),flush=True)
print('Measurements complete; CPU window released',flush=True)
