extern alias Fixed;
using System;
using Fixed::FastExpressionCompiler.LightExpression;
namespace FixedSide { static class Run { public static void Test(){try{var call=Expression.Call(typeof(RefProbe).GetMethod(nameof(RefProbe.GetRef)));Console.WriteLine("fixed Call.Type="+call.Type);var tree=Expression.Lambda<RefProbeGetter>(Expression.TryFinally(call,Expression.Empty()));var d=tree.CompileFast(true);RefProbe.Value=4;d()=8;Console.WriteLine("fixed Try.Type="+tree.Body.Type+" value="+RefProbe.Value);}catch(Exception e){Console.WriteLine("fixed "+e.GetType().FullName+": "+e.Message);}}}}
