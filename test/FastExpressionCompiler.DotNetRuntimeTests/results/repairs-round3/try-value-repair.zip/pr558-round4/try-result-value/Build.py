from pathlib import Path
import subprocess,shutil,json,hashlib
w=Path(__file__).resolve().parent
rows=[]
for light in ['false','true']:
 for tfm in ['net8.0','net10.0','net472']:
  tag=light+'-'+tfm
  with (w/('build-'+tag+'.log')).open('w') as f:subprocess.run(['dotnet','build','Fixture.csproj','-c','Release','-f',tfm,'-p:Light='+light,'-p:Variant=fixed','--nologo','-v:q'],cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True)
  out=w/'runners'/tag;out.mkdir(parents=True,exist_ok=True)
  for p in (w/'bin/Release'/tfm).glob('*'):
   if p.is_file():shutil.copy2(p,out/p.name)
  lib='TryResult.fixed'+('.Light' if light=='true' else '')+'.dll'
  shutil.copy2(w/('fixed'+('-light' if light=='true' else ''))/'bin/Release'/tfm/lib,out/lib)
  exe=out/('Fixture.fixed.'+light+('.exe' if tfm=='net472' else '.dll'))
  command=[str(exe)] if tfm=='net472' else ['dotnet',str(exe)]
  result=subprocess.run(command,cwd=w,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (w/('correctness-'+tag+'.log')).write_text(result.stdout)
  print(tag,result.stdout.strip(),flush=True)
  rows.append(dict(runtime=tfm,light=light,exitCode=result.returncode,output=result.stdout,SHA256=hashlib.sha256((out/lib).read_bytes()).hexdigest()))
  (w/'correctness.json').write_text(json.dumps(rows,indent=2))
  if result.returncode:raise SystemExit(result.returncode)
