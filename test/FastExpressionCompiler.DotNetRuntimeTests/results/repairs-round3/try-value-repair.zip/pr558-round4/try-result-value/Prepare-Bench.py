from pathlib import Path
w=Path(__file__).resolve().parent;old=w.parent/'empty-finally'
for name in ['Current.cs','Candidate.cs','System.cs','Runner.cs']:
 s=(old/name).read_text()
 s=s.replace('Candidate','Fixed').replace('candidate','fixed').replace('k<31','k<21')
 if name!='Runner.cs':
  s=s.replace('static object sink;', 'public struct BenchCounter { public int Value; public int Increment()=>++Value; }\n static object sink;')
  s=s.replace('case "try_catch":', 'case "default_receiver":body=S.Call(S.TryFinally(S.Default(typeof(BenchCounter)),S.Empty()),typeof(BenchCounter).GetMethod(nameof(BenchCounter.Increment)));break;\n   case "try_catch":')
 (w/('Fixed.cs' if name=='Candidate.cs' else name)).write_text(s)
project=(old/'Bench.csproj').read_text().replace('Candidate.cs','Fixed.cs').replace('candidate','fixed')
(w/'Bench.csproj').write_text(project)
build=(old/'Build-Bench.py').read_text().replace("subprocess.run(['python','Prepare-Bench.py'],cwd=w,check=True)","subprocess.run(['python','Prepare-Bench.py'],cwd=w,check=True)")
build=build.replace("['net8.0','net10.0']","['net8.0','net10.0','net472']").replace("['current','candidate']","['current','fixed']").replace("'EmptyFinally.'","'TryResult.'")
(w/'Build-Bench.py').write_text(build)
runner=(old/'Run-Bench.py').read_text().replace("['net8.0','net10.0']","['net8.0','net10.0','net472']").replace('range(5)','range(3)').replace("['current','candidate','system']","['current','fixed','system']")
runner=runner.replace("exe=w/'bench-runners'/tag/('Bench.'+light+'.dll')", "exe=w/'bench-runners'/tag/('Bench.'+light+('.exe' if tfm=='net472' else '.dll')); prefix=[str(exe)] if tfm=='net472' else ['dotnet',str(exe)]")
runner=runner.replace("['dotnet',str(exe),'pair',str(r)]", "prefix+['pair',str(r)]").replace("['dotnet',str(exe),'cold',version,shape]", "prefix+['cold',version,shape]")
runner=runner.replace("'try_catch','nested_eh32'", "'try_catch','default_receiver','nested_eh32'")
(w/'Run-Bench.py').write_text(runner)
analysis=(old/'Analyze.py').read_text().replace("'candidate'","'fixed'").replace("['net8.0','net10.0']","['net8.0','net10.0','net472']")
analysis=analysis.replace('NET8_0_OR_GREATER candidate; Framework/netstandard unchanged.','Try-value result normalization on all targets; genuine byref Try keeps original contract.').replace('5 cold samples','3 cold samples')
analysis=analysis.replace("count('PASS ')!=10", "count('PASS ')!=11")
(w/'Analyze.py').write_text(analysis)
print('Prepared all-target current/fixed/System measurement controls')
