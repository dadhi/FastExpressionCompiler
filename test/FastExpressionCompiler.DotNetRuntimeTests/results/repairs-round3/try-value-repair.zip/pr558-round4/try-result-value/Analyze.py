from pathlib import Path
import csv,json,statistics,collections
w=Path(__file__).resolve().parent
rows=[];errors=[]
for p in sorted(w.glob('warm-*.csv'))+sorted(w.glob('cold-*.csv')):
 parts=p.stem.split('-');light=parts[1];runtime=parts[2]
 with p.open() as f:
  for r in csv.reader(f):
   if len(r)!=8: errors.append(str(p)+': invalid record '+repr(r));continue
   scenario,phase,version,round_,sample,ops,ns,bytes_=r
   rows.append(dict(runtime=runtime,flavor='Light' if light=='true' else 'Standard',scenario=scenario,phase=phase,version=version,round=int(round_),repetition=int(parts[3]),sample=int(sample),operations=int(ops),ns=float(ns),bytes=float(bytes_),raw=p.name))
groups=collections.defaultdict(list)
for r in rows:groups[tuple(r[k] for k in ['runtime','flavor','scenario','phase','version'])].append(r)
summary=[]
for key,values in sorted(groups.items()):
 r=dict(zip(['runtime','flavor','scenario','phase','version'],key))
 r.update(ns=statistics.median(v['ns'] for v in values),bytes=statistics.median(v['bytes'] for v in values),samples=len(values),min_ns=min(v['ns'] for v in values),max_ns=max(v['ns'] for v in values),min_bytes=min(v['bytes'] for v in values),max_bytes=max(v['bytes'] for v in values))
 summary.append(r)
comparisons=[]
for r in summary:
 if r['version']!='fixed':continue
 before=next((b for b in summary if b['version']=='current' and all(b[k]==r[k] for k in ['runtime','flavor','scenario','phase'])),None)
 system=next((b for b in summary if b['version']=='system' and all(b[k]==r[k] for k in ['runtime','flavor','scenario','phase'])),None)
 if not before or not system:errors.append('Missing comparison '+repr(r));continue
 ratios=[]
 if not r['phase'].startswith('cold_'):
  current={(v['round'],v['sample']):v for v in groups[tuple(r[k] for k in ['runtime','flavor','scenario','phase'])+('current',)]}
  for v in groups[tuple(r[k] for k in ['runtime','flavor','scenario','phase'])+('fixed',)]:
   b=current[(v['round'],v['sample'])]
   if b['ns']:ratios.append(v['ns']/b['ns'])
 comparisons.append({k:r[k] for k in ['runtime','flavor','scenario','phase']}|dict(before_ns=before['ns'],candidate_ns=r['ns'],system_ns=system['ns'],time_ratio=r['ns']/before['ns'] if before['ns'] else None,paired_ratio=statistics.median(ratios) if ratios else None,before_bytes=before['bytes'],candidate_bytes=r['bytes'],system_bytes=system['bytes'],bytes_delta=r['bytes']-before['bytes'],before_samples=before['samples'],candidate_samples=r['samples'],system_samples=system['samples']))
for light in ['false','true']:
 for runtime in ['net8.0','net10.0','net472']:
  for round_ in range(2):
   p=w/f'warm-{light}-{runtime}-{round_}.log'
   if not p.exists():errors.append('Missing '+p.name)
   elif p.read_text().count('PASS ')!=11 or 'Exception' in p.read_text():errors.append('Incomplete/failed '+p.name)
data=dict(rows=rows,summary=summary,comparisons=comparisons,errors=errors,notes=['Try-value result normalization on all targets; genuine byref Try keeps original contract.','Current/candidate/System warm samples rotate order in same process; cold fresh process.','3 cold samples per version/shape: descriptive distributions, not universal parity.','Result temporary, collection, hosting and global EH spill flags retained.'])
(w/'analysis.json').write_text(json.dumps(data,indent=2))
(w/'summary.txt').write_text('\n'.join(f"{r['runtime']} {r['flavor']} {r['scenario']} {r['phase']}: {r['before_bytes']:g}->{r['candidate_bytes']:g}B; ratio={r['time_ratio']:.4f}; System={r['system_ns']:g}ns/{r['system_bytes']:g}B" for r in comparisons)+'\nERRORS='+repr(errors)+'\n')
print('Rows',len(rows),'groups',len(summary),'comparisons',len(comparisons),'errors',len(errors))
if errors:raise SystemExit(1)
