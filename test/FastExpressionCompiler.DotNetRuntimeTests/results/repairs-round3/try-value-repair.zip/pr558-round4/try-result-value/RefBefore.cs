extern alias Before;
using System;
using Before::FastExpressionCompiler.LightExpression;
namespace BeforeSide { static class Run { public static void Test(){try{var call=Expression.Call(typeof(RefProbe).GetMethod(nameof(RefProbe.GetRef)));Console.WriteLine("before Call.Type="+call.Type);var tree=Expression.Lambda<RefProbeGetter>(Expression.TryFinally(call,Expression.Empty()));var d=tree.CompileFast(true);RefProbe.Value=4;d()=8;Console.WriteLine("before Try.Type="+tree.Body.Type+" value="+RefProbe.Value);}catch(Exception e){Console.WriteLine("before "+e.GetType().FullName+": "+e.Message);}}}}
