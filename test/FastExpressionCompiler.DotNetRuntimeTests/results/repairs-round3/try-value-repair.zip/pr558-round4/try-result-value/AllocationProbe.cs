using System;
using System.Reflection;
using System.Reflection.Emit;
using System.Collections.Generic;
class AllocationProbe
{
    static readonly Func<long> Allocated=(Func<long>)Delegate.CreateDelegate(typeof(Func<long>),typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread"));
    static object F(object obj,string name) {for(var type=obj.GetType();type!=null;type=type.BaseType){var field=type.GetField(name,BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.DeclaredOnly);if(field!=null)return field.GetValue(obj);}return null;}
    static void Dump(string name,Delegate d,int depth=0)
    {
        Console.WriteLine(name+" method="+d.Method+" host="+d.Method.Module.Assembly.GetName().Name);
        var dm=d.Method as DynamicMethod??F(d.Method,"m_owner") as DynamicMethod;
        if(dm!=null){var resolver=F(dm,"m_resolver");foreach(var field in resolver.GetType().GetFields(BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public)){
            var data=field.GetValue(resolver);if(data is byte[] bytes)Console.WriteLine(name+" "+field.Name+"="+BitConverter.ToString(bytes));else if(field.FieldType.IsPrimitive)Console.WriteLine(name+" "+field.Name+"="+data);}}
        if(depth>2||d.Target==null)return;
        foreach(var field in d.Target.GetType().GetFields(BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public))if(field.GetValue(d.Target) is Delegate child)Dump(name+"."+field.Name,child,depth+1);
    }
    static Dictionary<string,Action<int>> Operations(Assembly asm,string side,string shape)=>(Dictionary<string,Action<int>>)asm.GetType(side+".Bench").GetMethod("Operations").Invoke(null,new object[]{shape});
    static void Main(string[] args)
    {
        var asm=Assembly.LoadFrom(args[0]);var sides=new[]{"Current","Fixed"};
        if(args.Length>1&&args[1]=="history")foreach(var shape in new[]{"add","balanced256","try_finally","try_finally_real","try_catch","default_receiver","nested_eh32","nested_eh32_real","goto_empty"})
            foreach(var side in sides)foreach(var op in Operations(asm,side,shape).Values)op(50);
        foreach(var shape in new[]{"capture1","capture_try"})foreach(var side in sides)
        {
            var op=Operations(asm,side,shape)["compile"];op(200);
            for(int s=0;s<5;s++){long b=Allocated();op(1000);Console.WriteLine(side+" "+shape+" sample="+s+" bytes="+((Allocated()-b)/1000.0));}
            var sink=asm.GetType(side+".Bench").GetField("sink",BindingFlags.Static|BindingFlags.NonPublic).GetValue(null);var factory=(Func<int,Func<int>>)sink;
            Dump(side+" "+shape+" outer",factory);Dump(side+" "+shape+" child",factory(3));
        }
    }
}
