using System;
public delegate ref int RefProbeGetter();
public class RefProbe { public static int Value;public static ref int GetRef()=>ref Value;static void Main(){
try {var call=System.Linq.Expressions.Expression.Call(typeof(RefProbe).GetMethod(nameof(GetRef)));Console.WriteLine("System Call.Type="+call.Type);var tree=System.Linq.Expressions.Expression.Lambda<RefProbeGetter>(System.Linq.Expressions.Expression.TryFinally(call,System.Linq.Expressions.Expression.Empty()));var d=tree.Compile();Value=4;d()=9;Console.WriteLine("System Try.Type="+tree.Body.Type+" value="+Value);}catch(Exception e){Console.WriteLine("System "+e.GetType().FullName+": "+e.Message);}
BeforeSide.Run.Test();CurrentSide.Run.Test();FixedSide.Run.Test();}}
