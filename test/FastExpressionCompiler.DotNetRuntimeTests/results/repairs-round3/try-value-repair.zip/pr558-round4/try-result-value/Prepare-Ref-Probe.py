from pathlib import Path
w=Path(__file__).resolve().parent
(w/'RefProbe.cs').write_text('''using System;
public delegate ref int RefProbeGetter();
public class RefProbe { public static int Value;public static ref int GetRef()=>ref Value;static void Main(){
try {var call=System.Linq.Expressions.Expression.Call(typeof(RefProbe).GetMethod(nameof(GetRef)));Console.WriteLine("System Call.Type="+call.Type);var tree=System.Linq.Expressions.Expression.Lambda<RefProbeGetter>(System.Linq.Expressions.Expression.TryFinally(call,System.Linq.Expressions.Expression.Empty()));var d=tree.Compile();Value=4;d()=9;Console.WriteLine("System Try.Type="+tree.Body.Type+" value="+Value);}catch(Exception e){Console.WriteLine("System "+e.GetType().FullName+": "+e.Message);}
BeforeSide.Run.Test();CurrentSide.Run.Test();FixedSide.Run.Test();}}
''')
template='''extern alias ALIAS;
using System;
using ALIAS::FastExpressionCompiler.LightExpression;
namespace SIDE { static class Run { public static void Test(){try{var call=Expression.Call(typeof(RefProbe).GetMethod(nameof(RefProbe.GetRef)));Console.WriteLine("VERSION Call.Type="+call.Type);var tree=Expression.Lambda<RefProbeGetter>(Expression.TryFinally(call,Expression.Empty()));var d=tree.CompileFast(true);RefProbe.Value=4;d()=8;Console.WriteLine("VERSION Try.Type="+tree.Body.Type+" value="+RefProbe.Value);}catch(Exception e){Console.WriteLine("VERSION "+e.GetType().FullName+": "+e.Message);}}}}
'''
for alias,side,version in [('Before','BeforeSide','before'),('Current','CurrentSide','current'),('Fixed','FixedSide','fixed')]:
 (w/('Ref'+alias+'.cs')).write_text(template.replace('ALIAS',alias).replace('SIDE',side).replace('VERSION',version))
(w/'RefProbe.csproj').write_text('''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><Optimize>true</Optimize><LangVersion>latest</LangVersion><EnableDefaultCompileItems>false</EnableDefaultCompileItems></PropertyGroup><ItemGroup><Compile Include="RefProbe.cs"/><Compile Include="RefBefore.cs"/><Compile Include="RefCurrent.cs"/><Compile Include="RefFixed.cs"/><Reference Include="RuntimeParity.before.light"><HintPath>../../pr558-round3/runtime-parity/light/before/bin/Release/$(TargetFramework)/RuntimeParity.before.light.dll</HintPath><Aliases>Before</Aliases></Reference><Reference Include="EmptyFinally.current.Light"><HintPath>../empty-finally/current-light/bin/Release/$(TargetFramework)/EmptyFinally.current.Light.dll</HintPath><Aliases>Current</Aliases></Reference><Reference Include="TryResult.fixed.Light"><HintPath>fixed-light/bin/Release/$(TargetFramework)/TryResult.fixed.Light.dll</HintPath><Aliases>Fixed</Aliases></Reference></ItemGroup></Project>''')
p=w/'RefProbe.csproj';p.write_text(p.read_text().replace('<Optimize>true</Optimize>','<Optimize>true</Optimize><AssemblySearchPaths>{HintPathFromItem};{TargetFrameworkDirectory};{RawFileName}</AssemblySearchPaths>'))
