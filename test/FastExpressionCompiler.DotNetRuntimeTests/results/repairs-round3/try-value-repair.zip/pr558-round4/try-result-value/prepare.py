from pathlib import Path
import hashlib,json,difflib
w=Path(__file__).resolve().parent
old=w.parent/'empty-finally'
manifest=dict(baseline='42f9847843cec8edaaf11c00cb97a5dd576b82cf',files={})
for version in ['current','fixed']:
 for light in [False,True]:
  d=w/(version+('-light' if light else ''));d.mkdir(exist_ok=True)
  source=old/('current'+('-light' if light else ''))
  for p in source.glob('*.cs'):
   data=p.read_bytes()
   if version=='fixed' and p.name=='FastExpressionCompiler.cs':
    start=data.index(b'            private static bool TryEmitTryCatchFinallyBlock(')
    end=data.index(b'            private static bool TryEmitHoistedCells(',start)
    before=data[start:end]
    chunk=before.replace(b'                il.BeginExceptionBlock();',b'                // Body and catch results are stored in a typed temporary, not used as\r\n                // the address requested by a surrounding member access or call.\r\n                var exprType = tryExpr.Type;\r\n                var returnsByRef = exprType.IsByRef;\r\n                var valueParent = returnsByRef ? parent :\r\n                    (parent & ~(ParentFlags.InstanceAccess | ParentFlags.MemberAccess |\r\n                        ParentFlags.AssignmentLeftValue | ParentFlags.AssignmentByRef | ParentFlags.DupIt |\r\n                        ParentFlags.LambdaCall | ParentFlags.ReturnByRef)) | ParentFlags.AssignmentRightValue;\r\n                il.BeginExceptionBlock();')
    # The former declaration comes after body emission; its new placement is
    # above the value-parent normalization.
    declaration=b'                var exprType = tryExpr.Type;'
    assert chunk.count(declaration)==2
    pos=chunk.rfind(declaration)
    chunk=chunk[:pos]+chunk[pos:].replace(declaration+b'\r\n',b'',1) if chunk[pos:].startswith(declaration+b'\r\n') else chunk[:pos]+chunk[pos:].replace(declaration+b'\n',b'',1)
    assert chunk.count(b'TryEmit(tryExpr.Body, il, ref context, parent)')==1
    assert chunk.count(b'TryEmit(catchBlock.Body, il, ref context, parent)')==1
    chunk=chunk.replace(b'TryEmit(tryExpr.Body, il, ref context, parent)',b'TryEmit(tryExpr.Body, il, ref context, valueParent)')
    chunk=chunk.replace(b'TryEmit(catchBlock.Body, il, ref context, parent)',b'TryEmit(catchBlock.Body, il, ref context, valueParent)')
    a=b'                return true;\r\n            }'
    if chunk.count(a)==0:a=a.replace(b'\r\n',b'\n')
    assert chunk.count(a)==1
    ending=b'                if (!returnsByRef)\r\n                    context.LastEmitIsAddress = false;\r\n'+a
    chunk=chunk.replace(a,ending)
    data=data[:start]+chunk+data[end:]
    (w/'production.diff').write_text(''.join(difflib.unified_diff(before.decode('utf-8').replace('\r\n','\n').splitlines(keepends=True),chunk.decode('utf-8').replace('\r\n','\n').splitlines(keepends=True),fromfile='a/TryEmitTryCatchFinallyBlock',tofile='b/TryEmitTryCatchFinallyBlock')))
   (d/p.name).write_bytes(data)
  (d/'Library.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><AssemblyName>TryResult.'+version+('.Light' if light else '')+'</AssemblyName>'+('<DefineConstants>LIGHT_EXPRESSION</DefineConstants>' if light else '')+'</PropertyGroup></Project>')
  manifest['files'][d.name]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.glob('*.cs')}
tests=['NonExceptionThrowPolicyRegressionTests','ExceptionJumpValidationRegressionTests','ExceptionRegionValidationRegressionTests','InlinedRethrowBoundaryRegressionTests','NestedJumpArgumentRegressionTests','InvocationJumpArgumentRegressionTests']
for name in tests:(w/(name+'.cs')).write_bytes((old/(name+'.cs')).read_bytes())
project=(old/'Fixture.csproj').read_text().replace('EmptyFinallyRegressionTests.cs','TryResultValueRegressionTests.cs').replace('candidate','fixed').replace(';EMPTY_FINALLY_ELIDED','')
(w/'Fixture.csproj').write_text(project)
(w/'Fixture.cs').write_text((old/'Fixture.cs').read_text().replace('EmptyFinallyRegressionTests','TryResultValueRegressionTests'))
(w/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('Prepared separate Try-value repair snapshots; no empty-finally optimization')
