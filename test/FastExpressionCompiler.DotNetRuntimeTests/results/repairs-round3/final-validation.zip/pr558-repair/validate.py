from pathlib import Path
import subprocess,json,shutil,hashlib,os
work=Path(__file__).resolve().parent
repo=Path(r'C:\Data\Git\Github\FastExpressionCompiler')
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
out=work/('validation-'+commit[:8]);out.mkdir(exist_ok=True)
codes={}
def assert_source():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==commit,'Source HEAD changed during validation'
 assert subprocess.run(['git','diff','--quiet','HEAD','--','src','test'],cwd=repo).returncode==0,'Source changed during validation'

def run(name,cmd):
 assert_source()
 print('Starting '+name,flush=True)
 with (out/(name+'.log')).open('w',encoding='utf-8') as log:
  p=subprocess.run([str(x) for x in cmd],cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 codes[name]=p.returncode
 (out/'codes.json').write_text(json.dumps(codes,indent=2))
 print(name+': '+str(p.returncode),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 assert_source()
for project in ['src/FastExpressionCompiler','src/FastExpressionCompiler.LightExpression']:
 run(project.split('/')[-1],['dotnet','build',project,'-c','Release','--no-restore','--disable-build-servers','-m:1'])
for fw in ['net10.0','net8.0']:
 run('native-'+fw,['dotnet','run','--project','test/FastExpressionCompiler.TestsRunner','-c','Release','-f',fw,'--no-restore','--disable-build-servers'])
run('framework-build',['dotnet','build','test/FastExpressionCompiler.TestsRunner.Net472','-c','Release','--no-restore','--disable-build-servers','-m:1'])
run('framework-run',[work.parent/'fec-fixes/FrameworkRunner/bin/Release/net472/FrameworkRunner.exe',repo/'test/FastExpressionCompiler.TestsRunner.Net472/bin/Release/net472/FastExpressionCompiler.TestsRunner.Net472.exe'])
run('imported-build',['dotnet','build','test/FastExpressionCompiler.DotNetRuntimeTests','-c','Release','-f','net10.0','--no-restore','--disable-build-servers','-m:1'])
frozen=work/('frozen-'+commit[:8]);assert not frozen.exists()
shutil.copytree(repo/'test/FastExpressionCompiler.DotNetRuntimeTests/bin/Release/net10.0',frozen)
(out/'snapshot.json').write_text(json.dumps({'commit':commit,'compilerSha256':hashlib.sha256((frozen/'FastExpressionCompiler.dll').read_bytes()).hexdigest(),'assemblySha256':hashlib.sha256((frozen/'FastExpressionCompiler.DotNetRuntimeTests.dll').read_bytes()).hexdigest()},indent=2))
run('imported-full',['python',work.parent/'fec-round12/Run-Full.py','--assembly',frozen/'FastExpressionCompiler.DotNetRuntimeTests.dll','--output-root',out/'suite','--jobs','2','--case-timeout','120'])
