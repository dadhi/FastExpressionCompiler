from pathlib import Path
import json, subprocess, re
w=Path(__file__).resolve().parent
repo=Path(r"C:\Data\Git\Github\FastExpressionCompiler")
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
f=w/('validation-'+head[:8]);codes=json.loads((f/'codes.json').read_text())
assert len(codes)==8 and all(x==0 for x in codes.values()), codes
r=json.loads((f/'suite/fec/run.json').read_text());bs=r['batches']
assert len(bs)==21 and not r['crashes']
assert all(b['status']=='Complete' and b['attempt']==1 for b in bs)
fields=['total','executed','passed','failed','error','timeout','aborted','notExecuted']
totals={k:sum(int(b['counters'].get(k,0)) for b in bs) for k in fields}
assert totals['passed']==35064 and all(totals[k]==0 for k in ['failed','error','timeout','aborted'])
result=dict(codeHead=head,codes=codes,imported=dict(batches=21,crashes=0,counters=totals,originalDenominator=35133,exclusions=69,newExclusions=0),native=dict(net10='All runner suites pass; legacy1712',net8='All runner suites pass; legacy1711',framework='TestX1037 plus legacy1595 pass'),priorAttempt=dict(head='6d397bc6',result='Interrupted after managed stack proved preexisting SmallMap16 promotion hang; fixed3be541d3; no Trycontrolflow regression'),snapshot=json.loads((f/'snapshot.json').read_text()))
(f/'validation.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
