using System;
using System.Globalization;
using System.Reflection;
class Program
{
    static int Main(string[] args)
    {
        var culture = CultureInfo.GetCultureInfo("en-US");
        CultureInfo.DefaultThreadCurrentCulture = culture;
        CultureInfo.DefaultThreadCurrentUICulture = culture;
        CultureInfo.CurrentCulture = culture;
        CultureInfo.CurrentUICulture = culture;
        Assembly.LoadFrom(args[0]).EntryPoint.Invoke(null, null);
        return Environment.ExitCode;
    }
}
