using System;using System.Linq;using S=System.Linq.Expressions.Expression;
public static class SharedShapes {
 public struct Counter { public int Value; public int Increment()=>++Value; }
 public static int FinallyCount; public static void Finish(){++FinallyCount;}
 public static System.Linq.Expressions.LambdaExpression Build(string name) {
 var x=S.Parameter(typeof(int),"x");System.Linq.Expressions.Expression body=x;
 switch(name){
 case "add":body=S.Add(x,S.Constant(1));break;
 case "decimal_eh1":case "decimal_eh64":{var d=S.Variable(typeof(decimal));System.Linq.Expressions.Expression value=d;int n=name=="decimal_eh1"?1:64;for(int i=0;i<n;i++)value=S.Add(value,d);body=S.Block(new[]{d},S.Assign(d,S.Convert(x,typeof(decimal))),S.Convert(S.TryFinally(value,S.Call(typeof(SharedShapes).GetMethod("Finish"))),typeof(int)));break;}
 case "try_catch":body=S.TryCatch(S.Divide(S.Constant(42),x),S.Catch(typeof(DivideByZeroException),S.Constant(-1)));break;
 case "try_finally_real":body=S.TryFinally(S.Add(x,S.Constant(1)),S.Call(typeof(SharedShapes).GetMethod("Finish")));break;
 case "default_receiver":body=S.Call(S.TryFinally(S.Default(typeof(Counter)),S.Call(typeof(SharedShapes).GetMethod("Finish"))),typeof(Counter).GetMethod("Increment"));break;
 case "capture1":return S.Lambda<Func<int,Func<int>>>(S.Lambda<Func<int>>(S.Add(x,S.Constant(1))),x);
 case "capture_mutable":return S.Lambda<Func<int,Func<int>>>(S.Lambda<Func<int>>(S.PreIncrementAssign(x)),x);
 case "capture8":{var vs=Enumerable.Range(0,8).Select(i=>S.Variable(typeof(int),"v"+i)).ToArray();System.Linq.Expressions.Expression sum=x;foreach(var v in vs)sum=S.Add(sum,v);return S.Lambda<Func<int,Func<int>>>(S.Block(vs,vs.Select(v=>(System.Linq.Expressions.Expression)S.Assign(v,x)).Concat(new System.Linq.Expressions.Expression[]{S.Lambda<Func<int>>(sum)})),x);}
 default:throw new ArgumentException(name);
 }return S.Lambda<Func<int,int>>(body,x);}}
