"""Prepare only: python Prepare.py --final COMMIT. Build/run are separate steps."""
from pathlib import Path
import argparse, hashlib, json, subprocess

w = Path(__file__).resolve().parent
repo = Path(r'C:\Data\Git\Github\FastExpressionCompiler')
old = w / 'Templates'
baseline = '42f9847843cec8edaaf11c00cb97a5dd576b82cf'
cases = ['add', 'decimal_eh1', 'decimal_eh64', 'try_catch', 'try_finally_real',
         'default_receiver', 'capture1', 'capture8', 'capture_mutable']
files = ['src/FastExpressionCompiler/FastExpressionCompiler.cs',
         'src/FastExpressionCompiler/ImTools.cs', 'src/FastExpressionCompiler/ILReader.cs',
         'src/FastExpressionCompiler/TestTools.cs']
lightfiles = ['src/FastExpressionCompiler.LightExpression/' + n for n in
              ['Expression.cs', 'ExpressionVisitor.cs', 'FlatExpression.cs']]

def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args])

def main():
    p = argparse.ArgumentParser(); p.add_argument('--final', required=True)
    final = git('rev-parse', p.parse_args().final + '^{commit}').decode().strip()
    if (w / 'manifest.json').exists():
        raise SystemExit('Frozen output already exists; use a fresh directory instead of overwriting.')
    manifest = dict(baseline=baseline, final=final, cases=cases, samples=21, files={})
    for version, commit in [('current', baseline), ('fixed', final)]:
        for light in [False, True]:
            folder = w / (version + ('-light' if light else '')); folder.mkdir()
            for path in files + (lightfiles if light else []):
                data = git('show', commit + ':' + path)
                (folder / Path(path).name).write_bytes(data)
            defines = '<DefineConstants>LIGHT_EXPRESSION</DefineConstants>' if light else ''
            (folder / 'Library.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup>'
                '<TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion>'
                '<Optimize>true</Optimize><AssemblyName>Combined.' + version + ('.Light' if light else '') +
                '</AssemblyName>' + defines + '</PropertyGroup></Project>')
            manifest['files'][folder.name] = {f.name: hashlib.sha256(f.read_bytes()).hexdigest()
                                              for f in folder.glob('*.cs')}
    # Each compiler receives the same shared System AST; Light conversion happens per compiler.
    for name in ['Current.cs', 'Fixed.cs', 'System.cs']:
        s = (old / name).read_text()
        s = s.replace('Operations(string name)', 'Operations(string name, System.Linq.Expressions.LambdaExpression original)')
        s = s.replace('var original=Build(name);var tree=Convert(original);var compiled=Compile(tree);',
                      'var tree=Convert(original);var compiled=Compile(tree);')
        s = s.replace('actions["invoke"]=n=>', 'actions[compiled is Func<int,Func<int>> ? "activation_first" : "invoke"]=n=>')
        s = s.replace(' public static void Cold(string name)', ' public static void Cold(string name)')
        (w / name).write_text(s)
    shared = '''using System;using System.Linq;using S=System.Linq.Expressions.Expression;
public static class SharedShapes {
 public struct Counter { public int Value; public int Increment()=>++Value; }
 public static int FinallyCount; public static void Finish(){++FinallyCount;}
 public static System.Linq.Expressions.LambdaExpression Build(string name) {
 var x=S.Parameter(typeof(int),"x");System.Linq.Expressions.Expression body=x;
 switch(name){
 case "add":body=S.Add(x,S.Constant(1));break;
 case "decimal_eh1":case "decimal_eh64":{var d=S.Variable(typeof(decimal));System.Linq.Expressions.Expression value=d;int n=name=="decimal_eh1"?1:64;for(int i=0;i<n;i++)value=S.Add(value,d);body=S.Block(new[]{d},S.Assign(d,S.Convert(x,typeof(decimal))),S.Convert(S.TryFinally(value,S.Call(typeof(SharedShapes).GetMethod("Finish"))),typeof(int)));break;}
 case "try_catch":body=S.TryCatch(S.Divide(S.Constant(42),x),S.Catch(typeof(DivideByZeroException),S.Constant(-1)));break;
 case "try_finally_real":body=S.TryFinally(S.Add(x,S.Constant(1)),S.Call(typeof(SharedShapes).GetMethod("Finish")));break;
 case "default_receiver":body=S.Call(S.TryFinally(S.Default(typeof(Counter)),S.Call(typeof(SharedShapes).GetMethod("Finish"))),typeof(Counter).GetMethod("Increment"));break;
 case "capture1":return S.Lambda<Func<int,Func<int>>>(S.Lambda<Func<int>>(S.Add(x,S.Constant(1))),x);
 case "capture_mutable":return S.Lambda<Func<int,Func<int>>>(S.Lambda<Func<int>>(S.PreIncrementAssign(x)),x);
 case "capture8":{var vs=Enumerable.Range(0,8).Select(i=>S.Variable(typeof(int),"v"+i)).ToArray();System.Linq.Expressions.Expression sum=x;foreach(var v in vs)sum=S.Add(sum,v);return S.Lambda<Func<int,Func<int>>>(S.Block(vs,vs.Select(v=>(System.Linq.Expressions.Expression)S.Assign(v,x)).Concat(new System.Linq.Expressions.Expression[]{S.Lambda<Func<int>>(sum)})),x);}
 default:throw new ArgumentException(name);
 }return S.Lambda<Func<int,int>>(body,x);}}
'''
    (w / 'SharedShapes.cs').write_text(shared)
    project = (old / 'Bench.csproj').read_text().replace('<Compile Include="Runner.cs"/>',
        '<Compile Include="Runner.cs"/><Compile Include="SharedShapes.cs"/>').replace('Bench.$(Light)', 'CombinedBench.$(Light)')
    (w / 'Bench.csproj').write_text(project)
    build = (old / 'Build-Bench.py').read_text()
    build = build.replace("subprocess.run(['python','Prepare-Bench.py'],cwd=w,check=True)", '')
    build = build.replace("'TryResult.'", "'Combined.'")
    (w / 'Build.py').write_text(build)
    manifest['harness'] = {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in w.glob('*') if f.is_file()}
    manifest['templates'] = {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in old.glob('*') if f.is_file()}
    (w / 'manifest.json').write_text(json.dumps(manifest, indent=2))
    print('Prepared fresh combined exports; no build or execution performed.')

if __name__ == '__main__': main()
