from pathlib import Path
repo=Path(r'C:\Data\Git\Github\FastExpressionCompiler')
s=(Path(__file__).parent/'Fix-SmallMap.py').read_text()
exec(s[s.index("p=repo/'test/"):])
