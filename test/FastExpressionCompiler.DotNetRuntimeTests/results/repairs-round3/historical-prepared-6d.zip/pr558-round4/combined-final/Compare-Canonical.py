from pathlib import Path
import json
w=Path(__file__).resolve().parent;rows=[]
for path in w.glob('canonical-*.jsonl'):
 for line in path.read_text().splitlines():
  data=json.loads(line)
  for name in sorted(set(data['Current'])|set(data['Fixed'])):
   a=data['Current'].get(name);b=data['Fixed'].get(name)
   known=a and b and a['Method'].get('Known') and b['Method'].get('Known')
   keys=['Signature','Instructions','Locals','EH','MaxStack','InitLocals','Host','MethodKind']
   changes=[key for key in keys if a and b and a['Method'].get(key)!=b['Method'].get(key)]
   if a and b and a['Target']!=b['Target']:changes+=['Target']
   rows.append(dict(Configuration=path.stem.replace('canonical-',''),Case=data['Name'],Path=name,Known=bool(known),Changes=changes,EqualWhenKnown=bool(known and not changes)))
(w/'canonical-analysis.json').write_text(json.dumps(rows,indent=2))
print('Canonical methods',len(rows),'known equal',sum(r['EqualWhenKnown'] for r in rows),'unknown',sum(not r['Known'] for r in rows))
for r in rows:
 if r['Changes']:print(r['Configuration'],r['Case'],r['Path'],','.join(r['Changes']))
