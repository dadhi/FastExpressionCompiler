Fresh bounded combined proof; source preparation only until the final commit is supplied and full validation completes.

Baseline: 42f9847843cec8edaaf11c00cb97a5dd576b82cf. Final: explicit immutable commit supplied to Prepare.py. Accepted changes: atomic-right arithmetic plus separate Try result-value correctness fix; no empty-finally optimization.

Nine cases: add, decimal_eh1, decimal_eh64, try_catch, try_finally_real, default_receiver, capture1, capture8, capture_mutable. Decimal and receiver cases use real cleanup calls. Ordinary Try catch is a real exception region. All three compilers receive the same System AST; Light libraries independently convert it. Reuse the established operation factories, correctness oracle, managed-allocation counter, and result sinks from the frozen Try-value harness.

Each phase has exactly 21 predeclared samples per compiler, rotating the three versions. Common operation count targets at least 30ms for the fastest version; raw operations and ns/op permit detection of shorter samples. Preserve all samples, absolute times, paired ratios and ratio-of-medians separately; no subtraction/filtering. Factory activation, first child call, and preactivated child calls are separate phases. Configurations: Standard/Light × net8.0/net10.0/net472. No cold matrix repeated.

Prepare.py exports Git objects and records all source hashes. Build.py is generated separately; it builds/finalizes six runners. Run only after an explicit exclusive timing grant. Existing isolated and runtime42f evidence stays untouched. Canonical IL comparisons, if needed, must identify this final source and preserve helper/host caveats; isolated candidate measurements are not relabeled as combined measurements.
