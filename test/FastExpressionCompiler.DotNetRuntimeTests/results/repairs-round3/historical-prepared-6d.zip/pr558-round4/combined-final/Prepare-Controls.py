from pathlib import Path
import hashlib,json
w=Path(__file__).resolve().parent
prior=w.parent.parent/'pr558-round3'/'runtime-parity'
s=(prior/'Canonical.cs').read_text()
start=s.index(' static string Normalize(');end=s.index('\n static string TypeName',start)
s=s[:start]+''' static string Normalize(string s)=>s==null?null:s.Replace("Combined.current.Light","CompilerSnapshot.Light").Replace("Combined.fixed.Light","CompilerSnapshot.Light").Replace("Combined.current","CompilerSnapshot").Replace("Combined.fixed","CompilerSnapshot");'''+s[end:]
s+='\n'+(prior/'Program.cs').read_text().split('static class Json {',1)[1].join(['static class Json {',''])
(w/'Canonical.cs').write_text(s)
for name in ['Current.cs','Fixed.cs','System.cs']:
 p=w/name;s=p.read_text();marker=' [MethodImpl(MethodImplOptions.NoInlining)]static Delegate Compile'
 s=s.replace(marker,' public static Delegate Compiled(System.Linq.Expressions.LambdaExpression tree)=>Compile(Convert(tree));\n'+marker)
 p.write_text(s)
p=w/'Bench.csproj';s=p.read_text().replace('<Compile Include="Runner.cs"/>','<Compile Include="Runner.cs"/><Compile Include="Canonical.cs"/>');p.write_text(s)
m=json.loads((w/'manifest.json').read_text());m['harness']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in w.glob('*') if p.is_file() and p.name!='manifest.json'}
(w/'manifest.json').write_text(json.dumps(m,indent=2))
