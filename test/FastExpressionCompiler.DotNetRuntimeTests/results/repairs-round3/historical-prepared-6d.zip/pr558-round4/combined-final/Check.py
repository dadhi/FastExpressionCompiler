from pathlib import Path
import json,subprocess
w=Path(__file__).resolve().parent;m=json.loads((w/'manifest.json').read_text())
for light in ['false','true']:
 for tfm in ['net8.0','net10.0','net472']:
  tag=light+'-'+tfm
  exe=w/'bench-runners'/tag/('CombinedBench.'+light+('.exe' if tfm=='net472' else '.dll'))
  prefix=[str(exe)] if tfm=='net472' else ['dotnet',str(exe)]
  with (w/('canonical-'+tag+'.jsonl')).open('w') as out,(w/('check-'+tag+'.log')).open('w') as err:
   subprocess.run(prefix+['--check']+m['cases'],cwd=w,stdout=out,stderr=err,check=True)
  print('Controls passed '+tag,flush=True)
