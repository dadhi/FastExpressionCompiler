from pathlib import Path
repo=Path(r'C:\Data\Git\Github\FastExpressionCompiler')
p=repo/'src/FastExpressionCompiler/ImTools.cs';s=p.read_bytes()
old=b'''        _capacityBitShift = DefaultHashesCapacityBitShift;\r
        _packedHashesAndIndexes = new int[1 << DefaultHashesCapacityBitShift];'''
new=b'''        _capacityBitShift = DefaultHashesCapacityBitShift;\r
        // Promotion also inserts one entry beyond the inline capacity.\r
        while ((1 << _capacityBitShift) <= StackEntries.Capacity)\r
            ++_capacityBitShift;\r
        _packedHashesAndIndexes = new int[1 << _capacityBitShift];'''
nl=b'\r\n' if b'\r\n' in s else b'\n'
old=old.replace(b'\r\n',nl);new=new.replace(b'\r\n',nl)
assert s.count(old)==2;s=s.replace(old,new)
start=s.index(b'    private void AddJustHashAndEntryIndexWithoutResizing(');end=s.index(b'    /// <summary>',start)
chunk=s[start:end];chunk=chunk.replace(b'        var hashIndex = hash & IndexMask;',b'        var indexMask = (1 << _capacityBitShift) - 1;'+nl+b'        var hashIndex = hash & indexMask;')
chunk=chunk.replace(b'& IndexMask',b'& indexMask').replace(b'(hash & HashMask)',b'(hash & HashAndIndexMask & ~indexMask)')
s=s[:start]+chunk+s[end:];p.write_bytes(s)
p=repo/'test/FastExpressionCompiler.IssueTests/Issue476_System_ExecutionEngineException_with_nullables_on_repeated_calls_to_ConcurrentDictionary.cs';s=p.read_bytes();nl=b'\r\n' if b'\r\n' in s else b'\n'
s=s.replace(b'        TestSmallMap_Lookup_SIMD(t);',b'        TestSmallMap_Lookup_SIMD(t);\r\n        SmallMap16_promotes_and_resizes(t, false);\r\n        SmallMap16_promotes_and_resizes(t, true);\r\n        SmallMap8_retains_initial_hash_capacity(t);')
addition='''
    public void SmallMap16_promotes_and_resizes(TestContext t, bool sureAbsent)
    {
        SmallMap16<int, int, IntEq> map = default;
        map.Map.AddOrGetValueRef(0, out _) = 0;
        ref var firstInlineValue = ref map.Map.TryGetValueRef(0, out _);
        for (var i = 1; i < 80; ++i)
        {
            // Collisions also exercise the displaced-entry hash/index mask.
            var key = i * 32;
            if (sureAbsent)
                map.Map.AddSureAbsentDefaultAndGetRef(key) = i;
            else
            {
                ref var value = ref map.Map.AddOrGetValueRef(key, out var found);
                t.IsFalse(found);
                value = i;
            }
            if (i == 16)
                t.AreEqual(32, map.Map.PackedHashesAndIndexes.Length);
        }
        t.AreEqual(80, map.Map.Count);
        firstInlineValue = -7;
        for (var i = 0; i < 80; ++i)
        {
            var value = map.Map.TryGetValueRef(i * 32, out var found);
            t.IsTrue(found);
            t.AreEqual(i == 0 ? -7 : i, value);
        }
        map.Map.TryGetValueRef(-1, out var missing);
        t.IsFalse(missing);
        ref var existing = ref map.Map.AddOrGetValueRef(32, out var alreadyPresent);
        t.IsTrue(alreadyPresent);
        t.AreEqual(1, existing);
        t.AreEqual(80, map.Map.Count);
    }

    public void SmallMap8_retains_initial_hash_capacity(TestContext t)
    {
        SmallMap8<int, int, IntEq> map = default;
        for (var i = 0; i < 9; ++i)
            map.Map.AddOrGetValueRef(i, out _) = i;
        t.AreEqual(16, map.Map.PackedHashesAndIndexes.Length);
        t.AreEqual(9, map.Map.Count);
    }
'''.replace('\n','\r\n').encode()
s=s.replace(b'\r\n',nl);addition=addition.replace(b'\r\n',nl)
last=s.rfind(b'}');assert last>0;s=s[:last]+addition+s[last:];p.write_bytes(s)
