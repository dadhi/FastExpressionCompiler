using System;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
class Runner {
 static readonly Func<long> Allocated=(Func<long>)Delegate.CreateDelegate(typeof(Func<long>),typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread"));
 public static void Row(string name,string phase,string version,int round,int sample,int operations,double ns,double bytes) => Console.WriteLine(name+","+phase+","+version+","+round+","+sample+","+operations+","+ns.ToString("R",CultureInfo.InvariantCulture)+","+bytes.ToString("R",CultureInfo.InvariantCulture));
 static void Measure(string name,string phase,string version,int round,int sample,Action<int> op,int n) {long b=Allocated(),t=Stopwatch.GetTimestamp();op(n);long e=Stopwatch.GetTimestamp()-t;Row(name,phase,version,round,sample,n,e*1e9/Stopwatch.Frequency/n,(Allocated()-b)/(double)n);}
 static int Calibrate(Action<int>[] actions,string phase) {
  int n=phase=="compile"?8:phase=="compile_first"?4:1024;
  for(int attempt=0;attempt<5;attempt++) {
   double fastest=double.MaxValue;
   foreach(var op in actions){long t=Stopwatch.GetTimestamp();op(n);fastest=Math.Min(fastest,(Stopwatch.GetTimestamp()-t)/(double)Stopwatch.Frequency);}
   if(fastest>=0.03)return n;
   n=(int)Math.Min(20000000,Math.Max(n+1,Math.Ceiling(n*0.04/Math.Max(fastest,0.00001))));
  }return n;
 }
 static void Main(string[] args) {
  bool check=args.Length>0&&args[0]=="--check";
  if(check)args=args.Skip(1).ToArray();
  var versions=new[]{"current","fixed","system"};
  foreach(var name in args) {
   var tree=SharedShapes.Build(name);
   var operations=new[]{Current.Bench.Operations(name,tree),Fixed.Bench.Operations(name,tree),SystemSide.Bench.Operations(name,tree)};
   if(check){
    foreach(var ops in operations)foreach(var op in ops.Values)op(1);
    Console.WriteLine(Json.Write(new {Name=name,Current=Canonical.Delegates(Current.Bench.Compiled(tree)),Fixed=Canonical.Delegates(Fixed.Bench.Compiled(tree)),System=Canonical.Delegates(SystemSide.Bench.Compiled(tree))}));
    Console.Error.WriteLine("PASS "+name);continue;
   }
   foreach(var phase in operations[0].Keys) {
    var actions=operations.Select(x=>x[phase]).ToArray();foreach(var op in actions)op(40);
    int n=Calibrate(actions,phase);Console.Error.WriteLine("COUNT "+name+" "+phase+" "+n);
    for(int k=0;k<21;k++) {
     if(k%7==0){GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();}
     for(int order=0;order<3;order++){int v=(k+order)%3;Measure(name,phase,versions[v],0,k,actions[v],n);}
    }
   }Console.Error.WriteLine("PASS "+name);
  }
 }
}
