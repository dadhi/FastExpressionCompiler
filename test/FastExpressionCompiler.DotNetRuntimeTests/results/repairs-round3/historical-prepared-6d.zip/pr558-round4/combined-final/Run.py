"""Execution requires an explicitly granted exclusive CPU window."""
from pathlib import Path
import argparse, json, subprocess, hashlib
w = Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--execute-exclusive-window',action='store_true')
if not p.parse_args().execute_exclusive_window:
    raise SystemExit('No execution requested; obtain the exclusive window, then pass --execute-exclusive-window.')
m=json.loads((w/'manifest.json').read_text())
for light in ['false','true']:
    for tfm in ['net8.0','net10.0','net472']:
        tag=light+'-'+tfm
        exe=w/'bench-runners'/tag/('CombinedBench.'+light+('.exe' if tfm=='net472' else '.dll'))
        prefix=[str(exe)] if tfm=='net472' else ['dotnet',str(exe)]
        csv=w/('paired-'+tag+'.csv');log=w/('paired-'+tag+'.log')
        if csv.exists() or log.exists():raise SystemExit('Refusing to overwrite existing measurement '+tag)
        with csv.open('w') as output,log.open('w') as errors:
            subprocess.run(prefix+m['cases'],cwd=w,stdout=output,stderr=errors,check=True)
        print('Finished '+tag,flush=True)
