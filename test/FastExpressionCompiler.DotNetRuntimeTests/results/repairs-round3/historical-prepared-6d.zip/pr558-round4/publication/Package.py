"""Stage supplemental evidence. Default inventories metadata only; finalization is opt-in.
Never builds/tests/measures, alters main, or replaces immutable round2/round3 inputs.
"""
from pathlib import Path
import argparse,os,json,hashlib,zipfile,subprocess,sys

out=Path(__file__).resolve().parent;work=out.parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--finalize',action='store_true')
parser.add_argument('--hash-only',action='store_true')
parser.add_argument('--quiet-window-confirmed',action='store_true')
parser.add_argument('--output-dir',type=Path)
args=parser.parse_args()
state=json.loads((out/'final-state.json').read_text(encoding='utf-8-sig'))
def statepath(key,default):
 p=Path(state.get(key) or default)
 return p if p.is_absolute() else work/p
partitions={
 'runtime-audit-42f':[work/'pr558-round3/runtime-parity',work/'pr558-round3/runtime-aa'],
 'accepted-arithmetic-44ee':[work/'pr558-round4/atomic-right-arithmetic'],
 'held-followups':[work/'pr558-round3/public-restore-guard',work/'pr558-round4/empty-finally'],
 'try-value-repair':[work/'pr558-round4/try-result-value'],
 'combined-final':[statepath('combined_path','pr558-round4/combined-final-bounded')],
 'historical-prepared-6d':[statepath('historical_combined_path','pr558-round4/combined-final')],
 'map-capacity':[statepath('map_capacity_path','pr558-round4/map-capacity')]+list((work/'pr558-round4/try-result-value').glob('*map17*'))+list((work/'pr558-round4/try-result-value').glob('Map17*')),
 'review-and-supported-host':[statepath('supported_host_path','pr558-round4/supported-eh-host')]+[work/p for p in state.get('review_reply_paths',[])],
 'final-validation':[statepath('validation_path','pr558-repair/validation-70f297cb')]+[work/p for p in state.get('validation_reproduction_paths',[])],
 'allocation-confirmation':[statepath('allocation_confirmation_path','allocation-confirmation-round4')],
}
exclude_dirs={'obj','.git','.vs','__pycache__','node_modules','artifacts'}
exclude_suffix={'.etlx','.zip','.dmp'}
def collect(roots):
 files={}
 for root in roots:
  if not root.exists():continue
  if root.is_dir() and (root.name in exclude_dirs or root.name.startswith(('obj-','obj.'))):continue
  if root.is_file():files[str(root.relative_to(work)).replace('\\','/')]=root;continue
  for directory,dirs,leaves in os.walk(root):
   dirs[:]=[x for x in dirs if x not in exclude_dirs and not x.startswith(('obj-','obj.'))]
   for name in leaves:
    p=Path(directory)/name
    if p.suffix.lower() not in exclude_suffix:files[str(p.relative_to(work)).replace('\\','/')]=p
 return files
allfiles={name:collect(roots) for name,roots in partitions.items()}
inventory=dict(status='metadata-only; no hash/compression/measurements',partitions={k:dict(roots=[str(x.relative_to(work)) for x in partitions[k]],files=len(v),uncompressedBytes=sum(x.stat().st_size for x in v.values())) for k,v in allfiles.items()},excludedDirectories=sorted(exclude_dirs),excludedSuffixes=sorted(exclude_suffix),separateUnchangedArtifact=dict(path='pr558-round3/held-experiments.zip',bytes=52418017,sha256='7e18a65f079f6a936e718a41cf02db322ce91f4cb6c52533ad4b6444b14a4421'),preservation='Prior immutable committed round2 and original round3 files are inputs only and are never rewritten.')
(out/'package-inventory.json').write_text(json.dumps(inventory,indent=2))
print(json.dumps(inventory,indent=2))
if args.hash_only:
 hashes={name:{rel:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for rel,p in sorted(files.items())} for name,files in allfiles.items()}
 (out/'hash-inventory.json').write_text(json.dumps(dict(status='Preparatory snapshot only; final packaging rehashes every input',partitions=hashes),indent=2))
 print('Preparatory SHA256 inventory written; no compression.')
if not args.finalize:raise SystemExit(0)
if state.get('allocation_confirmation_state','').startswith('Separate equal-count allocation-only confirmation pending'):raise SystemExit('Allocation confirmation is pending; root must review before final packaging.')
for configured in state.get('validation_reproduction_paths',[]):
 if not (work/configured).exists():raise SystemExit('Required validation reproduction input missing: '+configured)
if not args.quiet_window_confirmed:raise SystemExit('Refusing compression until the active measurement owner explicitly releases CPU; then pass --quiet-window-confirmed.')
state=json.loads((out/'final-state.json').read_text(encoding='utf-8-sig'))
if not state.get('final_code_head') or state.get('final_validation') is None:raise SystemExit('Root must supply final_code_head and final_validation in final-state.json before final packaging.')
if state.get('combined_expected') and not (statepath('combined_path','pr558-round4/combined-final-bounded')/'analysis.json').exists():raise SystemExit('Final combined analysis is pending; do not publish it as measured.')
if not (work/'pr558-round4/try-result-value/analysis.json').exists():raise SystemExit('Try-value final analysis is pending; do not silently publish a partial final package.')
destination=(args.output_dir or out/'artifacts').resolve()
if destination.exists():raise SystemExit('Use a new output directory to preserve earlier publication artifacts.')
destination.mkdir(parents=True)
subprocess.run([sys.executable,str(out/'GenerateReport.py')],check=True)
# Each partition also carries the concise report/scripts and its own immutable input manifest.
common={str(p.relative_to(work)).replace('\\','/'):p for p in out.iterdir() if p.is_file() and p.name not in {'archives.json'} and p.suffix not in {'.zip'}}
raw_cap=75*1024*1024;archive_cap=90*1024*1024
catalog=[]
for name,files in allfiles.items():
 merged=dict(files);merged.update(common)
 manifest=dict(partition=name,finalState=state,files={rel:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for rel,p in sorted(merged.items())},excludedDirectories=sorted(exclude_dirs),excludedSuffixes=sorted(exclude_suffix),scope='Archives preserve measured snapshots, raw rows, binaries and relative layouts. Frozen42f evidence is not relabeled as final combined code performance.')
 manifest_path=destination/(name+'-manifest.json');manifest_path.write_text(json.dumps(manifest,indent=2))
 chunks=[];current=[];size=0
 for rel,p in sorted(merged.items()):
  n=p.stat().st_size
  if current and size+n>raw_cap:chunks.append(current);current=[];size=0
  current.append((rel,p));size+=n
 if current:chunks.append(current)
 for index,chunk in enumerate(chunks,1):
  archive=destination/(name+(f'-{index:02d}' if len(chunks)>1 else '')+'.zip')
  with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
   for rel,p in chunk:z.write(p,rel)
   z.write(manifest_path,'pr558-round4/publication/'+manifest_path.name)
  if archive.stat().st_size>=archive_cap:raise SystemExit(f'Archive exceeds90MiB; split further before publishing: {archive}')
  catalog.append(dict(partition=name,part=index,parts=len(chunks),path=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),manifest=manifest_path.name,files=len(chunk)+1))
old=work/'pr558-round3/held-experiments.zip'
if old.stat().st_size!=52418017 or hashlib.sha256(old.read_bytes()).hexdigest()!=inventory['separateUnchangedArtifact']['sha256']:raise SystemExit('Original held archive identity changed; investigate rather than replacing it.')
result=dict(finalState=state,archives=catalog,separateUnchangedArtifact=inventory['separateUnchangedArtifact'],note='No prior round2 evidence was replaced. Extract all supplement parts under one common root to preserve cross-folder links. Sources with historical absolute references retain those references; reproduction notes identify them.')
(destination/'archives.json').write_text(json.dumps(result,indent=2))
(out/'archives.json').write_text(json.dumps(result,indent=2))
print('Finalized only new supplement artifacts:',destination)
