"""Render supplemental reports from retained evidence; no builds, tests or measurements."""
from pathlib import Path
import json,html,collections

out=Path(__file__).resolve().parent
work=out.parents[1]
r3=work/'pr558-round3';r4=work/'pr558-round4'
def load(p,default=None):
    return json.loads(p.read_text(encoding='utf-8-sig')) if p.exists() else default

def esc(x):return html.escape(str(x))
def num(x):
    if x is None:return '—'
    if isinstance(x,bool):return str(x)
    return f'{x:,.3f}' if isinstance(x,(float,int)) else str(x)
def table(headers,rows):
    return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+esc(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+esc(num(x))+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def detail(title,body,opened=False):return '<details'+(' open' if opened else '')+'><summary>'+esc(title)+'</summary>'+body+'</details>'
def link(path,label=None):return '<a href="'+esc(path)+'">'+esc(label or path)+'</a>'
def rel(p):return str(Path(__import__('os').path.relpath(p,out))).replace('\\','/')
def p(text):return '<p>'+text+'</p>'

state=load(out/'final-state.json',{})
atomic=r4/'atomic-right-arithmetic';am=load(atomic/'manifest.json',{})
aw=load(atomic/'warm-analysis.json',[]);ac=load(atomic/'cold-analysis.json',[])
parity=r3/'runtime-parity';pa=load(parity/'runtime-analysis.json',[])
aa=r3/'runtime-aa';aadata=load(aa/'analysis.json',[])
native=load(parity/'native-analysis.json',[])
held=r4/'empty-finally';hm=load(held/'manifest.json',{})
tryroot=r4/'try-result-value';tm=load(tryroot/'manifest.json',{})
tryanalysis=load(tryroot/'analysis.json')
def statepath(key,default):
 value=Path(state.get(key) or default)
 return value if value.is_absolute() else work/value
combinedroot=statepath('combined_path','pr558-round4/combined-final-bounded');combinedanalysis=load(combinedroot/'analysis.json')
combinedmanifest=load(combinedroot/'manifest.json',{});combinedhead=combinedmanifest.get('final') or state.get('combined_snapshot_head') or 'PENDING'

def target(file):return file.replace('warm-','').replace('runtime-','').replace('measure-','').replace('.jsonl','').replace('.csv','')

sections=[]
sections.append('<h1>PR558 supplemental evidence</h1>'+p('<strong>'+esc(state.get('status','Pending final state'))+'</strong>. Final code head: <code>'+esc(state.get('final_code_head') or 'PENDING')+'</code>. Arithmetic commit: <code>44ee17d7</code>.'))
sections.append(p('Universal compilation/runtime/allocation parity is <strong>not established</strong>. These measurements use several explicitly frozen sources; they are not silently relabeled as a final combined matrix. Immutable prior round2 evidence is unchanged. All raw rows, control costs and cold allocation modes remain retained.'))
sections.append('<h2>Measured sources and phases</h2>'+table(['Evidence','Exact before / after','Coverage / interpretation'],[
['Frozen runtime audit','e4c232da prePR →42f98478; System','15 shapes, six configurations; invoke, activation, activation+first, preactivated child;4950 raw samples.'],
['Same-current A/A','42f98478 A vs42f98478 B','Same AST and independent delegates;5 shapes/11 phases ×6;1452 raw samples. System correctness only.'],
['Native/source audit','e4c232da /42f98478','Separate diagnostic native dumps and exact helper-source hashes; not native addresses of timed processes.'],
['Accepted arithmetic','42f98478 →measured arithmetic candidate accepted as44ee17d7','21 matched pairs/phase; Std/Light8/10 and Framework. Real-finally decimal1/64 and scalar/try-catch/capture controls.'],
['Arithmetic cold','Same isolated arithmetic snapshots','Five fresh alternating paired reps;180 processes; decimal64/add/capture8 across six targets.'],
['Public restore guard — REJECTED','42f98478 →isolated guard','Std8/10 warm+fresh cold; Std/Light8/10/472 semantic proof. No main merge.'],
['Empty-finally — HOLD','42f98478 →isolated prototype','Modern measurements and Framework semantic controls; not rebased onto later Try-value correctness fix.'],
['Selected combined incremental matrix','42f98478 →'+combinedhead+' plus System',state.get('combined_measurements_state','Pending final source validation/measurement')],
['Try-value repair',str(tm.get('baseline','PENDING'))+' → '+str(state.get('try_value_commit') or 'frozen fixed source; commit PENDING'),'Separate correctness/performance record; final combined validation supplied by root, not inferred.']]))
sections.append(p('Compile excludes AST construction/Light conversion. Arithmetic construct rows rebuild the shared System AST for both versions; they do not measure a native Light AST builder. Modern compile+first adds first execution of the generated delegate; Framework restricted anonymous hosting can already JIT during compilation, so phase costs are not mechanically interchangeable. Framework arithmetic System timings are independent observations on the same prepared System AST; they are not paired arithmetic candidate ratios. “Invoke” for capture factories includes activation/first child use in the short arithmetic runner; sustained audit phases separate those operations.'))
sections.append(p('Environment: modern .NET8.0.28/.NET10.0.9 ARM64; Framework4.8.9325.0 X64 on ARM64 Windows. AnyCPU runner headers alone do not establish process architecture. Ratios above1 mean slower; paired medians and ratios of ns medians are shown separately, with no weighted application-speedup claim.'))

sections.append('<h2>Accepted arithmetic44ee17d7</h2>'+p('The general arithmetic emitter skips unnecessary EH-driven operand spills when the existing atomic-right proof permits it. Lifting flags are preserved; explicit methods accepting Nullable&lt;decimal&gt; without lifting were separately tested. No reflection query, new pass, cache or expression rewrite was added. Existing primitive fast-path layout is unchanged.'))
rows=[];tx=[]
for file in sorted({x['file'] for x in aw}):
    xs={x['phase']:x for x in aw if x['file']==file and x['case']=='decimal_eh64'}
    if not xs:continue
    b=xs['compile']['before']['bytes'];f=xs['compile']['fixed']['bytes']
    rows.append([target(file),xs['compile']['ratio'],xs['compile_first']['ratio'],xs['invoke']['ratio'],b,f])
    tx.append(f"{target(file):24} compile {xs['compile']['ratio']:.3f}; compile+first {xs['compile_first']['ratio']:.3f}; invoke {xs['invoke']['ratio']:.3f}; compile bytes {b:g}->{f:g}")
sections.append(table(['DecimalEH64 target','Compile paired','Compile+first paired','Invoke paired','Compile B before','Compile B candidate'],rows))
sections.append(p('All six semantic configurations passed decimal/user-defined-method, real finally/order, overflow, lifted-null evaluation, nonlifted Nullable formal methods, working byref-input and Light intrinsic hidden-EH controls. Proposed registered native fixture passed5 tests per Standard configuration and6 per Light configuration. Supplied-ref-operator diagnostics remain a separate unsupported boundary, never passing assertions of invalid behavior.'))
sections.append(p('Target compile allocation reductions: decimal1 saves104B modern/216B Framework; decimal64 saves5832B modern/14048B Framework. Warm allocation medians have no observed positive delta. Target speed gains do not erase control costs: .NET10 Standard capture8 compile paired ratio1.761 and invoke1.125, and .NET8 Standard capture invoke1.085, remain visible. The source change is outside that primitive arithmetic path; that does not conclusively establish the cause of each timing difference.'))
awrows=[]
for x in aw:
    b=x['before'];f=x['fixed'];sy=x.get('system',{})
    awrows.append([target(x['file']),x['case'],x['phase'],b['ns'],f['ns'],x['ratio'],f['ns']/b['ns'] if b['ns'] else None,b['bytes'],f['bytes'],sy.get('ns'),sy.get('bytes')])
sections.append(detail('All arithmetic warm phases and controls (unfiltered21-pair results)',table(['Target','Shape','Phase','Before ns median','Candidate ns median','Paired ratio','Ratio ns medians','Before B','Candidate B','System ns median','System B'],awrows)))
cr=[]
for x in ac:
    ns=x['CompileAndFirstNs'];bs=x['CompileAndFirstBytes']
    cr.append([x['runtime']+'-'+x['flavor'],x['case'],ns['before']['median']/1e6,ns['fixed']['median']/1e6,x['combinedPairedRatio'],ns['fixed']['median']/ns['before']['median'],bs['before']['median'],bs['fixed']['median'],str(x['combinedByteDeltas'])])
sections.append(detail('All arithmetic cold targets/controls; medians are never replaced by low modes',table(['Target','Shape','Before ms','Candidate ms','Paired ratio','Ratio medians','Before B median','Candidate B median','Five candidate-minus-before B deltas'],cr)))
sections.append(p('Historical isolated cold costs are mixed; they are not measurements of final70f after its supported-host change. Decimal64 Standard modern saves6880B in every fresh pair; Framework saves14048B in every pair. Light modern retains12336B allocation-mode variation, including a positive sampled .NET10 capture-control median. Framework Light decimal64 cold paired time ratio1.265 is retained. No universal cold parity claim is made. Full minima/maxima, phases and individual deltas are in '+link(rel(atomic/'cold-analysis.json'))+'.'))
sections.append(p('Exact source hashes, raw files, preserved measured Framework warm source, later cold CLI, native proof and an explicit reproduction script are in '+link(rel(atomic/'repro-manifest.json'),'arithmetic reproduction manifest')+' / '+link(rel(atomic/'REPRODUCTION.txt'))+'. Reproduction defaults to verification, preserves original observations and requires explicit new output plus build/measurement flags.'))

sections.append('<h2>Frozen runtime, A/A and native audit at42f</h2>'+p('The sustained audit uses11 samples rotating all six version orders, shared calibrated counts targeting40ms for the fastest delegate,4950 raw rows and90 correctness checks.25 samples below20ms remain flagged, not filtered. The separate A/A audit has1452 samples/66 phase rows and zero below20ms. It measures independent-target/context variation; its ratios are never subtracted from versioned measurements.'))
pr=[]
for x in pa:
    v=x['versions'];b=v['before'];c=v['current'];s=v['system']
    pr.append([target(x['file']),x['scenario'],x['phase'],b['nsMedian'],c['nsMedian'],s['nsMedian'],x['currentBeforePairedMedian'],x['currentBeforeRatioOfNsMedians'],x['currentSystemPairedMedian'],x['currentSystemRatioOfNsMedians'],str([b['bytesMedian'],c['bytesMedian'],s['bytesMedian']])])
sections.append(detail('All frozen42f vs prePR/System runtime phase rows',table(['Target','Shape','Phase','PrePR ns','42f ns','System ns','42f/prePR paired','42f/prePR medians','42f/System paired','42f/System medians','B prePR/42f/System'],pr)))
ar=[]
for x in aadata:
    a=x['versions']['current_A'];b=x['versions']['current_B']
    ar.append([target(x['file']),x['case'],x['phase'],a['nsMedian'],b['nsMedian'],x['pairedMedian'],x['ratioOfNsMedians'],a['bytesMedian'],b['bytesMedian']])
sections.append(detail('All same-current A/A rows; evidence of variation, not a correction factor',table(['Target','Shape','Phase','A ns','B ns','B/A paired','B/A medians','A B','B B'],ar)))
sections.append(p('Same-current Light capture8 nested B/A paired ratios1.281 on .NET8 and1.275 on .NET10 coexist with equal allocation medians and known canonical identity. This does not reproduce every versioned cost or prove all differences noise.'))
nr=[[x.get('runtime'),x.get('case'),x.get('method'),x.get('nativeTextDiffableEqual'),str(x.get('codeBytes')),x.get('caveat')] for x in native]
sections.append(detail('Separate pointer-normalized native diagnostics',table(['Runtime','Shape','Method','Diffable equal','Code bytes before/current','Limit'],nr)))
sections.append(p('For the tested ordinary scalar trees, canonical finalized IL/signatures/locals/EH match prePR. TryCatch includes the required catch-entry Pop; correct EH hosting can differ even where emitted body bytes match. Readonly capture child/curry bodies match, while outer factories remove a shared-wrapper write. Mutable-value capture changes storage and removes24B per child call; mutable-reference Length uses Callvirt for correct receiver behavior. Framework unresolved internal local-signature handles remain UNKNOWN. Exact helper-source equality is not a proof of arbitrary callee or timed native placement equality. See '+link(rel(parity/'REPORT.md'))+', '+link(rel(parity/'source-audit.json'))+' and '+link(rel(aa/'REPORT.md'))+'.'))

sections.append('<h2>Supported EH hosting correction and map-capacity repair</h2>')
sections.append(p('Supported host commit: <code>'+esc(state.get('supported_host_commit') or 'PENDING')+'</code>. Historical42f and isolated candidates used an anonymous-module constructor workaround on modern runtimes. It worked in tested release builds, but official .NET10 source explicitly forbids callers supplying that module; it is not a supported contract. The selected final source uses the public restricted anonymous constructor for exception-aware methods and ordinary owner hosting elsewhere. This legitimately moves JIT work into CreateDelegate, so compile-only is not comparable deferred-JIT work; compile+first, invocation and managed bytes remain separate.'))
sections.append(p('Official evidence: '+link(state.get('official_source_urls',[''])[0],'DynamicMethod.Init anonymous-module assertion')+'; '+link(state.get('official_source_urls',['',''])[1],'restricted CreateDelegate eager compilation')+'. Published acknowledgement: '+link('https://github.com/dadhi/FastExpressionCompiler/pull/558#discussion_r4319059045','reply4319059045 to dadhi')+'. Original request/reply JSON and focused proof are in the review-and-supported-host partition.'))
sections.append(p('Map-capacity commit: <code>'+esc(state.get('map_capacity_commit') or 'PENDING')+'</code>. The6d full native interruption reproduced in unchanged prePR/e4 and42f helper code with17 colliding keys; the promotion table lacked capacity for inline entries plus the new key. This is a separately repaired preexisting helper boundary, not evidence against the isolated Try-value mask fix. The map-capacity partition retains both-API collision proof and regression controls; no previous snapshot is overwritten.'))
sections.append('<h2>Held and rejected experiments</h2>'+table(['Experiment','Decision','Reason / limits'],[
['Public restore guard','REJECT','Scalar method-JIT avoidance was real, but balanced compilation regressed4.5–7.3%; no allocation improvement. All observations retained.'],
['Empty-finally elision','HOLD','Strong target improvements, but unexplained Light10 cold scalar+12336B mode; separate struct receiver/address defect exists in before/candidate. Prototype lacks later Try-value repair and needs rebase/fresh measurements before reconsideration.'],
['Empty-finally Framework policy','Unproved; unchanged','Prototype uses modern positive target gate, preserving Framework/CER semantics; do not infer Framework optimization acceptance.'],
['Earlier round3 held experiments','Unchanged archive','Nested binary/dispatcher and pending-goto evidence remain separate in original52.4MB held-experiments.zip. No new exclusions/imported denominator changes.']]))
sections.append(p('Public guard: '+link('../../pr558-round3/public-restore-guard/manifest.json')+'; empty-finally: '+link(rel(held/'manifest.json'))+' / '+link(rel(held/'analysis.json'))+'. Existing held archive: '+link('../../pr558-round3/held-experiments.zip')+'; original SHA2567e18a65f079f6a936e718a41cf02db322ce91f4cb6c52533ad4b6444b14a4421. Prior committed round2 evidence is not replaced.'))

sections.append('<h2>Try-value correctness repair and boundaries</h2>')
sections.append(p('Try-value commit: <code>'+esc(state.get('try_value_commit') or 'PENDING root commit metadata')+'</code>. Frozen source manifest: '+link(rel(tryroot/'manifest.json'))+'. Measurements below, if present, isolate that repair from42f; they do not include arithmetic unless exact source manifest says so.'))
def generic_summary(root,title):
    data=load(root/'analysis.json')
    if not data:return detail(title,p('PENDING: no final analysis at report generation.'))
    rows=[]
    for x in data.get('summary',[]) if isinstance(data,dict) else []:
        rows.append([x.get('runtime'),x.get('flavor'),x.get('scenario'),x.get('phase'),x.get('version'),x.get('ns'),x.get('bytes'),x.get('samples'),str([x.get('min_ns'),x.get('max_ns')]),str([x.get('min_bytes'),x.get('max_bytes')])])
    comparisons=[]
    for x in data.get('comparisons',[]):
        before=x.get('current_ns',x.get('before_ns'));fixed=x.get('fixed_ns',x.get('candidate_ns'));system=x.get('system_ns')
        comparisons.append([x.get('runtime'),x.get('flavor'),x.get('scenario'),x.get('phase'),before,fixed,system,x.get('paired_ratio'),x.get('time_ratio'),fixed/system if fixed is not None and system else None,x.get('current_bytes',x.get('before_bytes')),x.get('fixed_bytes',x.get('candidate_bytes')),x.get('system_bytes'),x.get('comparisonPolicy','See frozen runner/operation counts')])
    extra=table(['Runtime','Flavor','Shape','Phase','Before ns median','Fixed ns median','System ns median','FECpaired (common only)','Fixed/before medians','Fixed/System medians','Before B','Fixed B','System B','Count policy'],comparisons)
    counts=data.get('allocationRegressionCounts')
    if counts:extra+=p('Exact managed-byte marginal-median phase-group counts:')+table(['Configuration','Increased','Unchanged','Decreased'],[[k,v['increased'],v['unchanged'],v['decreased']] for k,v in counts.items()])
    if data.get('shortFlags') is not None:extra+=p('All retained short/count-cap flags: '+esc(json.dumps(data['shortFlags']))+'. No samples filtered.')
    return detail(title,extra+table(['Runtime','Flavor','Shape','Phase','Frozen version','ns median','B median','Samples','ns min/max','B min/max'],rows)+p('All comparisons/errors/notes remain in '+link(rel(root/'analysis.json'))+'.'))
sections.append(p('Try-only snapshot source SHA256 <code>6bf851820685392c12d413e94700c9189e80f75695d8bc725b04fb94aff3ecf1</code>, baseline42f; it excludes arithmetic44ee. Focused proof is40 cases per configuration (seven new methods plus33 existing EH cases), all six configurations passing. The separate paired record has28620 rows/294 comparisons,21 samples ×2 rounds and11 known-correct shapes; newly repaired wrong-output baseline trees remain correctness-only.'))
sections.append(p('Try-only warmed allocation residual: Framework Light capture1 compile4152→4344B and compile+first4336→4528B; capture_try compile4968→5160B and compile+first5152→5344B. Activation184B and nested call0B are unchanged; modern and Framework Standard warm bytes are unchanged. Isolated allocation checks match, while prior EH/receiver workload produces the+192B observation. Finalized outer/child IL and local-count/encoded-signature shape match; cross-assembly local types were not canonically decoded. Allocator remains UNKNOWN.'))
sections.append(generic_summary(tryroot,'Separate42f →Try-only phase summaries'))
sections.append(generic_summary(held,'Held empty-finally complete phase summaries'))
sections.append(p('New diagnostics remain separately classified: supplied-ref operator methods are factory-valid; prePR ignored the supplied method and produced wrong observable effects, while42f/arithmetic candidate honor it but emit invalid arguments. This boundary is neither “fully preexisting” nor repaired by arithmetic. Working byref-input/byvalue-operator forms match System. Ref-return Try-value controls have their own prePR/current/fixed/System logs; do not conflate them with supplied-ref operators.'))
sections.append(p('The pending-arithmetic/outward-goto reproducer predates this PR: System returns17 while all16 compared FEC version/flavor/runtime combinations throw InvalidProgramException. It remains documented outside the original imported denominator. The deep-tree crash remains deferred by user instruction, with no broad refactor. No new passing test asserts invalid behavior and no original test was silently excluded.'))
sections.append('<h2>Selected combined snapshot '+esc(combinedhead)+'</h2>'+p('This incremental comparison pins frozen42f vs the selected final snapshot plus System; its before baseline is not prePR. Arithmetic-isolated44ee and frozen e4/42f audit results remain historical records with their original sources. Exact source manifest: '+link(rel(combinedroot/'manifest.json'))+'. Old6d preparation remains immutable and unmeasured: its full native run was interrupted by an unchanged-prePR SmallMap promotion-capacity bug, not a Try-value control-flow regression.'))
sections.append(p('Final combined matrix is complete:12474 raw rows,198 phase groups and zero errors.109 samples under20ms and3027 under30ms remain retained. Compile-only uses independent30ms calibration per compiler; other FEC phases share counts, while System has its own calibration. No fresh-process final70f cold matrix was run; earlier cold allocation modes describe historical sources and unresolved risk, not measured final70f cold regressions.'))
sections.append(p('Primary managed-byte marginal medians:28 increased,139 unchanged,31 decreased phase groups.22 positive differences are fractional (&lt;0.324B/operation), with integer batch allocation events on both versions and differing compile counts; the exact allocators are not established. Six Framework Light capture1/capture8/mutable compile and compile+first groups retain approximately192B/operation. A separate equal-count allocation-only confirmation is preserved independently; it never replaces these primary observations.'))
highlights=[x for x in (combinedanalysis or {}).get('comparisons',[]) if x.get('runtime')=='net10.0' and x.get('flavor')=='Standard' and (x.get('scenario'),x.get('phase')) in [('add','compile'),('add','invoke'),('capture1','activate'),('capture1','nested_invoke'),('capture8','nested_invoke'),('capture_mutable','nested_invoke'),('decimal_eh64','compile'),('decimal_eh64','compile_first'),('decimal_eh64','invoke')]]
sections.append(p('Selected .NET10 Standard results show why phase separation matters: add compilation is about12.4× faster than System, while add invocation is1.072× System. Capture1 factory activation is0.097× System, but its preactivated child call is2.002× System; mutable child call is2.237× System and capture8 child call0.709× System. DecimalEH64 compile moves57.3× versus historical42f with its unsupported deferred host, while compile+first improves to0.703× historical42f and remains0.991× System. These are per-shape observations, not a general compiler ranking.'))
sections.append(table(['.NET10 Standard shape','Phase','Final/42f ns medians','Final/42f paired (common only)','Final/System ns medians','Final ns','Final B'],[[x['scenario'],x['phase'],x['time_ratio'],x.get('paired_ratio'),x['system_time_ratio'],x['fixed_ns'],x['fixed_bytes']] for x in highlights]))
sections.append(generic_summary(combinedroot,'Final combined exact-source phase summaries (all198 groups)'))
maproot=statepath('map_capacity_path','pr558-round4/map-capacity');mapdata=load(maproot/'analysis.json',{})
sections.append('<h2>Map-capacity causal microbenchmark</h2>'+p('Isolated6d→3be map fix:1122 raw rows,42 paired comparisons,zero errors,all managed-byte deltas zero. Map8 ratios span0.964–1.112; the .NET8 count12 sure-absent case is11.16% slower. This is not a universally cost-free change. Previously hanging Map16 transitions have fixed-only measurements and no finite baseline speedup claim. Actual sample durations remain recorded, including short drift.'))
sections.append(detail('All map comparisons',table(['Runtime','Map inline size','Count','API','Fixed/before paired','Managed B delta'],[[x.get('runtime'),x.get('size'),x.get('count'),x.get('api'),x.get('paired_ratio'),x.get('bytes_delta')] for x in mapdata.get('comparisons',[])])))
confirmationroot=statepath('allocation_confirmation_path','allocation-confirmation-round4')
sections.append(p('Equal-count allocation confirmation: '+esc(state.get('allocation_confirmation_state','Pending'))+' Source: '+link(rel(confirmationroot))+'. This supplementary allocation-only run uses exact frozen libraries and does not revise elapsed measurements.'))
confirmation=load(confirmationroot/'analysis.json',{})
sections.append(p('Of the primary28 positive groups, six remain positive in this separate check,21 are equal and one is lower. Two additional Framework Standard0.8B groups are retained, so the new total is eight positive; it is not a replacement count for the original28. The six Framework Light capture residual groups remain about192B, with batch variation. No precise allocator or universal allocation parity is established.'))
sections.append(detail('All198 equal-count allocation-only groups',table(['Runtime','Flavor','Shape','Phase','42f B median','70f B median','System B median','Delta B','Primary matrix delta B','Five paired B deltas'],[[x['runtime'],x['flavor'],x['scenario'],x['phase'],x['current_bytes'],x['fixed_bytes'],x['system_bytes'],x['managed_byte_delta'],x['primary_delta'],str(x['paired_deltas'])] for x in confirmation.get('comparisons',[])])))

sections.append(p('History-dependent+192B allocation observations in the Try-value follow-up remain observed costs with the exact allocator UNKNOWN. Framework has no ILGenerator reuse. Neither a pool/signature cause nor a leak is established; no low allocation mode replaces the recorded medians.'))
sections.append('<h2>Final combined validation and reproducibility</h2>'+p(esc(json.dumps(state.get('final_validation'),ensure_ascii=False,indent=2) if state.get('final_validation') is not None else 'PENDING: root will supply final combined code head and validation. No final combined benchmark is claimed.')))
sections.append(p('Packaging is opt-in after the timing owner releases CPU. Partitioned archives preserve relative directory layout, raw measurements, frozen sources/binaries and full SHA256 manifests, each below90MiB. The original held archive is published separately unchanged. '+link('README.txt')+' / '+link('package-inventory.json')+' / '+link('archives.json')+'.'))

css='''body{font:15px/1.5 system-ui,sans-serif;margin:2rem auto;max-width:1500px;padding:0 1rem;color:#202633;background:#fafbfc}h1,h2{line-height:1.2}h2{margin-top:2rem}table{border-collapse:collapse;min-width:100%;font-size:12px;background:white}th,td{padding:7px 9px;border:1px solid #dce1e8;text-align:right;vertical-align:top}th:first-child,td:first-child,td:nth-child(2),td:nth-child(3){text-align:left}th{background:#edf1f7;position:sticky;top:0}.scroll{overflow:auto;max-height:650px}details{margin:1rem 0;padding:.7rem;background:#f0f3f8;border-radius:6px}summary{cursor:pointer;font-weight:600}a{color:#1458a8}code{word-break:break-all}p{max-width:1200px}'''
(out/'report.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><title>PR558 supplemental evidence</title><style>'+css+'</style><body>'+''.join(sections)+'</body></html>',encoding='utf8')
text='''PR558 SUPPLEMENTAL EVIDENCE
Status: STATUS
Final combined code head: HEAD

No universal compilation/runtime/allocation parity claim. Frozen42f runtime
audits, isolated arithmetic44ee measurements, held experiments and separate
Try-value evidence retain their exact source identities. Prior immutable round2
results are unchanged; this supplement does not relabel them as final results.

ACCEPTED arithmetic44ee17d7 — real-finally decimalEH64 paired ratios
ARITHMETIC

21 unfiltered pairs/phase across Std/Light8/10/Framework. Decimal1 saves104B
modern/216B Framework; decimal64 saves5832B modern/14048B Framework at warm
compile. Six semantic/native configurations passed. Explicit Nullable formal
methods, ordering, lifted nulls, working byref inputs and hidden-EH intrinsics
were checked. No new reflection/cache/pass/tree rewrite was added.

All control outliers remain: net10 Standard capture8 compile1.761/invoke1.125,
net8 Standard capture invoke1.085. No warm allocation regression medians.
Cold5: Standard modern target saves6880B every pair; Framework14048B every
pair. Light modern12336B modes and positive net10capture median remain.
FrameworkLight target cold paired time1.265 remains. No universal cold parity.

FROZEN42f runtime audit vs prePR e4c232da and System
15 shapes/six configurations,4950 rows/90 correctness checks.25 samples<20ms
are flagged, retained. Same-current A/A:1452 rows/66 phases, none<20ms;
Lightcapture8 nested B/A1.281(net8)/1.275(net10) with equal bytes/canonical
identity demonstrates independent-context variation, not a correction factor.
Separate native diagnostics: scalar add20B identical on8/10; readonly child
and curry bodies match. Framework internal local signatures remain UNKNOWN.
Mutable-value child invocation removes24B; other timing costs remain visible.

DECISIONS
Public restore guard REJECTED: balanced compile+4.5–7.3%, bytes unchanged.
Empty-finally HOLD: strong targets, coldLight10scalar+12336B unexplained;
separate receiver/address correctness defect in before/candidate. Prototype
lacks later Try-value fix and requires rebase/fresh measurement before reuse.
Modern positive gating preserves unproved Framework/CER behavior. No variant
search, new exclusion or imported denominator change was made.

TRY-VALUE correctness accepted within6d (measured isolated from44ee)
Snapshot42f->Try-only:40 focused cases/configuration, all6 passing;
28620 raw rows/294 comparisons,21 samples x2rounds. FrameworkLight capture1
compile4152->4344B and capture_try4968->5160B (+192B); compile+first also+192B.
Activation184B/nested0B unchanged. Isolated checks equal; after priorEHhistory
+192B. Exact allocator UNKNOWN; Framework has no ILGenerator reuse. Modern
and FrameworkStandard warmed bytes unchanged. Cold modes/costs remain visible.

BOUNDARIES
Supplied-ref operators: prePR ignored Method (wrong effects);42f/arithmetic
honor Method but emit invalid arguments. Not fully preexisting or repaired.
Try-value/ref-return diagnostics remain separately classified with System.
Pending outward-goto arithmetic: prePR also InvalidProgramException while
System17; documented outside imported denominator. Deep-tree crash deferred.

REPRODUCIBILITY
See report.html for all target/control/System tables, explicit paired vs median
ratios and links to raw manifests/reproduction scripts. Arithmetic reproduction
verifies hashes by default and preserves original observations in a new output.
Package.py is metadata-only unless explicitly finalized after timing release.
Existing round3 held-experiments.zip stays separate unchanged(52.4MB; SHA256
7e18a65f079f6a936e718a41cf02db322ce91f4cb6c52533ad4b6444b14a4421).
Committed6d snapshot includes arithmetic44ee and the Try-value change, but
full native validation was interrupted by an unchanged-prePR map helper bug,
not a Try-value control-flow failure. Map3be repairs it. The6d preparation
remains immutable/unmeasured; selected final source/path and validation are in
final-state.json. Supported EH hosting70f replaces the anonymous-module
workaround using the public constructor, moving JIT into compile; report
compile-only, compile+first, invocation and bytes separately. History-dependent+192B observations
retain allocator UNKNOWN; Framework has no ILGenerator reuse. No pool/signature
cause is claimed.

FINAL70f COMBINED MATRIX
12474 raw rows /198 phase groups /0 errors;109 samples under20ms and3027
under30ms retained. Compile-only independently calibrated per compiler;
FEC compile+first/runtime use common counts; System independently calibrated.
Primary byte phase medians:28 higher,139 unchanged,31 lower.22 positives are
fractional <0.324B/op;6 FrameworkLight capture compile/first groups retain
approximately+192B/op. Separate equal-count allocation-only confirmation:2970 rows/198groups,
5samples x200ops after40warmups;164same/26lower/8higher. Six FrameworkLight
~192B groups plus two FrameworkStandard0.8B groups remain. Of primary28
positive groups six remain positive,21equal,one lower. Both raw datasets
are retained separately; confirmation does not replace primary medians. Exact allocator UNKNOWN.
All198 per-case/phase FEC/System median ratios are in report.html.
Map causal matrix:1122 rows/42 pairs/0 errors,all bytes delta0; Map8 ratios
0.964–1.112, including net8 count12 absent lookup +11.16%. No universally
cost-free map claim. Previously hanging transitions have no finite baseline.
Final70f full validation:35064 imported pass,0 fail/crash,21 batches;69 prior
exclusions unchanged. Native alltargets pass. No final70f fresh-process cold
matrix was run: historical cold data remain source-specific unresolved risk.
'''.replace('STATUS',state.get('status','PENDING')).replace('HEAD',str(state.get('final_code_head') or 'PENDING')).replace('ARITHMETIC','\n'.join(tx))
(out/'REPORT.txt').write_text(text,encoding='utf8')
(out/'report-data.json').write_text(json.dumps(dict(state=state,measuredBaselines=dict(runtime='e4c232da /42f98478 /System',arithmetic='42f98478 /measured44ee candidate',AA='42f/42f'),arithmeticWarmRows=len(aw),arithmeticColdRows=len(ac),runtimeRows=len(pa),AARows=len(aadata),nativeRows=len(native),tryValueAnalysisPresent=tryanalysis is not None,finalCombinedAnalysisPresent=combinedanalysis is not None),indent=2),encoding='utf8')
print('Rendered supplemental REPORT.txt/report.html without changing frozen evidence.')
