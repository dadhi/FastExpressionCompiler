# Supplemental evidence publication

Run GenerateReport.py to regenerate REPORT.txt and report.html from the frozen analyses. Update final-state.json only with the final code head/validation supplied by root. The generator records missing Try-value data as pending; it never manufactures final combined timings.

Package.py defaults to a metadata-only inventory. It does not hash large inputs, compress, run tests, change main, or modify prior round2/round3 evidence. After the measurement owner explicitly releases CPU, use --finalize --quiet-window-confirmed with a new --output-dir. Archives preserve work/pr558-round3 and work/pr558-round4 relative layouts, are split below90MiB, and carry SHA256 manifests. The existing round3 held-experiments.zip remains a separately published unchanged52.4MB artifact.

Publication partitions: frozen42f runtime-parity/A-A/native audit; accepted arithmetic44ee evidence and reproduction; rejected public restore guard and held empty-finally; separate Try-value correctness repair evidence when ready. All measured snapshots and raw rows are retained; derived obj/etlx/cache files are excluded. Prior immutable round2 evidence is referenced, never rewritten/replaced.

No benchmark, source fix, commit, upload or pull-request write is performed by these scripts.

After extracting supplemental parts into one directory, place the separately downloaded original held-experiments.zip at pr558-round3/held-experiments.zip to satisfy report links. Publish archives.json beside the report as the external SHA256 archive catalog; the archive hashes cannot recursively include their own final catalog.

Final selected code70f297cbd5b2f232fd16ec0753b52f5c9ef387a0 passed full validation.
Final combined12474rows/198groups and map1122rows/42pairs are complete; the
separate equal-count allocation-only confirmation is complete. Preserve its
separate source path allocation-confirmation-round4 when supplied. Primary
combined managed-byte counts28higher/139same/31lower must not be overwritten.
Historical6d prepared combined sources are unmeasured; validation hit a
preexisting SmallMap hang, repaired separately. Historical cold matrices are
not final70f cold startup measurements after the supported-host correction.
Validation partition carries raw logs/TRX/JSON, frozen imported binaries,
validate.py, summarize-validation.py, fec-round12/Run-Full.py and the culture
wrapper source. Reproduction notes preserve original absolute repo paths.
Do not finalize packages until root reviews the completed allocation confirmation.
