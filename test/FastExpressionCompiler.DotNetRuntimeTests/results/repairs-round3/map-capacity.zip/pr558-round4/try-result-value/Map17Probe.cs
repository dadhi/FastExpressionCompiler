extern alias Before;
extern alias Current;
using System;
class Map17Probe
{
    static void Main(string[] args)
    {
        if (args[0] == "before")
        {
            var map = new Before::FastExpressionCompiler.LightExpression.ImTools.SmallMap16<int,int,Before::FastExpressionCompiler.LightExpression.ImTools.IntEq>();
            for (int i=0;i<17;i++) { Console.WriteLine("before insert "+i); if (args.Length > 1) { ref int value = ref Before::FastExpressionCompiler.LightExpression.ImTools.SmallMap.AddSureAbsentDefaultAndGetRef(ref map.Map,i*16); value=i; } else { ref int value = ref Before::FastExpressionCompiler.LightExpression.ImTools.SmallMap.AddOrGetValueRef(ref map.Map,i*16,out _); value=i; } }
        }
        else
        {
            var map = new Current::FastExpressionCompiler.LightExpression.ImTools.SmallMap16<int,int,Current::FastExpressionCompiler.LightExpression.ImTools.IntEq>();
            for (int i=0;i<17;i++) { Console.WriteLine("current insert "+i); if (args.Length > 1) { ref int value = ref Current::FastExpressionCompiler.LightExpression.ImTools.SmallMap.AddSureAbsentDefaultAndGetRef(ref map.Map,i*16); value=i; } else { ref int value = ref Current::FastExpressionCompiler.LightExpression.ImTools.SmallMap.AddOrGetValueRef(ref map.Map,i*16,out _); value=i; } }
        }
        Console.WriteLine("COMPLETED");
    }
}
