from pathlib import Path
import json,hashlib
w=Path(__file__).resolve().parent
s=(w/'Runner.cs').read_bytes()
old=s.replace(b'using System.Globalization;\n',b'').replace(b'  CultureInfo.CurrentCulture=CultureInfo.InvariantCulture;\n  CultureInfo.CurrentUICulture=CultureInfo.InvariantCulture;\n',b'').replace(b'if(n>=1<<28)throw new Exception("Calibration exceeded268435456 operations without20ms");',b'')
(w/'Runner-before-culture.cs.txt').write_bytes(old)
(w/'harness-hashes-before-culture.json').write_text(json.dumps(dict(runnerSHA256=hashlib.sha256(old).hexdigest(),note='Previous Runner source reconstructed by reversing exact culture/calibration edit; previous assembly hashes in proof.json; no timing executed'),indent=2))
(w/'harness-hashes.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in w.glob('*') if p.is_file() and p.suffix in ['.cs','.csproj','.py']},indent=2))
