from pathlib import Path
import subprocess,os
w=Path(__file__).resolve().parent
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
if any((w/f'{t}.csv').exists() for t in ['net8.0','net10.0','net472']):
 raise SystemExit('Refusing to overwrite existing measurement CSV; preserve/archive it first.')
for t in ['net8.0','net10.0','net472']:
 p=w/'bin/Release'/t/('Runner.exe' if t=='net472' else 'Runner.dll')
 a=([str(p)] if t=='net472' else ['dotnet',str(p)])+['measure']
 with (w/f'{t}.csv').open('w') as f,(w/f'{t}.stderr.log').open('w') as e:
  subprocess.run(a,env=env,stdout=f,stderr=e,check=True,timeout=300)
subprocess.run(['python',str(w/'analyze.py')],check=True)
