extern alias Fixed;using System;using Fixed::FastExpressionCompiler.ImTools;static class FixedOps{public static long Run8(int count,bool absent,int repetitions) {long check=0;
for(int r=0;r<repetitions;r++) { var map=new SmallMap8<int,int,IntEq>();
for(int i=0;i<count;i++) { if(absent) {ref int v=ref map.Map.AddSureAbsentDefaultAndGetRef(i*16);v=i+1;} else {ref int v=ref map.Map.AddOrGetValueRef(i*16,out bool found);if(found)throw new Exception("unexpected");v=i+1;} }
for(int i=0;i<count;i++) {ref int v=ref map.Map.TryGetValueRef(i*16,out bool found);if(!found||v!=i+1)throw new Exception("lookup");check+=v;}
}return check;}public static void Proof8(bool absent) { var map=new SmallMap8<int,int,IntEq>();ref int first=ref map.Map.AddOrGetValueRef(0,out _);first=71;
for(int i=1;i<64;i++) {if(absent)map.Map.AddSureAbsentDefaultAndGetRef(i*16)=i;else map.Map.AddOrGetValueRef(i*16,out _)=i;}
if(first!=71)throw new Exception("ref lost");first=93;if(map.Map.TryGetValueRef(0,out bool found)!=93||!found)throw new Exception("ref stability");}public static long Run16(int count,bool absent,int repetitions) {long check=0;
for(int r=0;r<repetitions;r++) { var map=new SmallMap16<int,int,IntEq>();
for(int i=0;i<count;i++) { if(absent) {ref int v=ref map.Map.AddSureAbsentDefaultAndGetRef(i*16);v=i+1;} else {ref int v=ref map.Map.AddOrGetValueRef(i*16,out bool found);if(found)throw new Exception("unexpected");v=i+1;} }
for(int i=0;i<count;i++) {ref int v=ref map.Map.TryGetValueRef(i*16,out bool found);if(!found||v!=i+1)throw new Exception("lookup");check+=v;}
}return check;}public static void Proof16(bool absent) { var map=new SmallMap16<int,int,IntEq>();ref int first=ref map.Map.AddOrGetValueRef(0,out _);first=71;
for(int i=1;i<64;i++) {if(absent)map.Map.AddSureAbsentDefaultAndGetRef(i*16)=i;else map.Map.AddOrGetValueRef(i*16,out _)=i;}
if(first!=71)throw new Exception("ref lost");first=93;if(map.Map.TryGetValueRef(0,out bool found)!=93||!found)throw new Exception("ref stability");}}