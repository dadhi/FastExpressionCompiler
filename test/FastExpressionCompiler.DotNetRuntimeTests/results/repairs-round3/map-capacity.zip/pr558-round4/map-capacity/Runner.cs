using System;
using System.Diagnostics;
using System.Globalization;
class Program
{
 static readonly Func<long> Allocated=(Func<long>)Delegate.CreateDelegate(typeof(Func<long>),typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread",Type.EmptyTypes));
 static void Main(string[] args)
 {
  CultureInfo.CurrentCulture=CultureInfo.InvariantCulture;
  CultureInfo.CurrentUICulture=CultureInfo.InvariantCulture;
  if(args.Length==0)throw new Exception("Explicit proof or measure argument required");
  if(args[0]=="proof") {foreach(bool a in new[]{false,true}){FixedOps.Proof8(a);FixedOps.Proof16(a);}Console.WriteLine("PROOF PASS");return;}
  if(args[0]!="measure")throw new Exception("Unknown mode");
  foreach(int size in new[]{8,16}) foreach(int count in size==8?new[]{0,8,9,12,32}:new[]{0,16,17,32,64}) foreach(bool absent in new[]{false,true})
  {
   int versions=size==16&&count>16?1:2;
   int n=1;
   // Calibration belongs only to explicit measurement mode. Require the faster
   // variant to reach20ms, using one common count for both versions.
   while(true) {long shortest=long.MaxValue; for(int v=0;v<versions;v++) {Func<int,bool,int,long> calibration=v==0?(size==8?FixedOps.Run8:FixedOps.Run16):(size==8?BeforeOps.Run8:BeforeOps.Run16);long t=Stopwatch.GetTimestamp();calibration(count,absent,n);shortest=Math.Min(shortest,Stopwatch.GetTimestamp()-t);} if(shortest>=Stopwatch.Frequency/50)break;if(n>=1<<28)throw new Exception("Calibration exceeded268435456 operations without20ms");n=checked(n*2);}
   for(int sample=-1;sample<11;sample++)for(int offset=0;offset<versions;offset++)
   {
    bool fix=versions==1||(offset+Math.Max(sample,0))%2==1;
    Func<int,bool,int,long> op=fix?(size==8?FixedOps.Run8:FixedOps.Run16):(size==8?BeforeOps.Run8:BeforeOps.Run16);
    long b=Allocated();long start=Stopwatch.GetTimestamp();long sum=op(count,absent,n);long elapsed=Stopwatch.GetTimestamp()-start;long bytes=Allocated()-b;
    if(sample>=0)Console.WriteLine("{0},{1},{2},{3},{4},{5:F4},{6:F4},{7},{8},{9:F6}",fix?"fixed":"before",size,count,absent?"absent":"lookup",sample,elapsed*1e9/Stopwatch.Frequency/n,bytes/(double)n,sum,n,elapsed*1000.0/Stopwatch.Frequency);
   }
  }
 }
}
