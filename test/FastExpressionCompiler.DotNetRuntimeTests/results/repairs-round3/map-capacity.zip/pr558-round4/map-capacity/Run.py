from pathlib import Path
import subprocess
w=Path(__file__).resolve().parent
for light in ['false','true']:
 for tfm in ['net8.0','net10.0','net472']:
  tag=light+'-'+tfm
  with (w/('build-'+tag+'.log')).open('w') as f:
   subprocess.run(['dotnet','build','Fixture.csproj','-c','Release','-f',tfm,'-p:Light='+light,'--nologo','-v:q'],cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True)
  exe=w/'bin'/'Release'/tfm/('Fixture.exe' if tfm=='net472' else 'Fixture.dll')
  cmd=[str(exe)] if tfm=='net472' else ['dotnet',str(exe)]
  with (w/('check-'+tag+'.log')).open('w') as f:subprocess.run(cmd,cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=30)
  print('PASS '+tag,flush=True)
