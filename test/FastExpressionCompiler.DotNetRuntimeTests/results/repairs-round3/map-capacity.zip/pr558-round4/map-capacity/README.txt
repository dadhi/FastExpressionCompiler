Prepared source only; STOP before measurement until parent grants exclusive window.
python prepare.py FINAL_COMMIT
Build Before/Library.csproj, Fixed/Library.csproj, Runner.csproj (Release).
Run Runner proof before measurement, all three targets.
Run Runner measure exclusively, DOTNET_TieredCompilation=0 / ReadyToRun=0.
CSV fields version,size,count,API,sample,ns,bytes,checksum,operations,duration_ms.
Eleven alternating pairs; common operation count calibrated so the faster
variant reaches20ms. Actual sample durations retained. Complete insertion and
lookup per construction. Fixed-only transitions have no finite baseline claim.
Reference stability: hold first inline ref across64 insertions, then write and
read through map. Both APIs and sizes checked. Collision keys i*16.
This is a narrow collection microbenchmark, not expression compile/runtime.
python measure.py runs all three targets sequentially then strict analysis;
do not run until the exclusive timing window is granted.
