using System;
#if LIGHT_EXPRESSION
using FastExpressionCompiler.LightExpression;
using FastExpressionCompiler.LightExpression.IssueTests;
#else
using FastExpressionCompiler;
using FastExpressionCompiler.IssueTests;
#endif
class Program {
 static void Main(){var t=new TestRun(TestFlags.RethrowException);t.Run(new Issue476_System_ExecutionEngineException_with_nullables_on_repeated_calls_to_ConcurrentDictionary());if(t.FailedTestCount!=0)throw new Exception("Map fixture failed");Console.WriteLine("MAP FIXTURE PASS");}
}
