from pathlib import Path
import subprocess,json,hashlib,sys
w=Path(__file__).resolve().parent
repo=Path(r'C:\Data\Git\Github\FastExpressionCompiler')
fixed=sys.argv[1] if len(sys.argv)>1 else None
if not fixed: raise SystemExit('Usage: python prepare.py FINAL_COMMIT (exports/build preparation only; does not execute timings)')
base='6d397bc6'
manifest={'baseline':base,'fixed':fixed,'files':{}}
for label,commit in [('Before',base),('Fixed',fixed)]:
 p=w/label;p.mkdir(exist_ok=True)
 for name in ['FastExpressionCompiler.cs','ImTools.cs','ILReader.cs','TestTools.cs']:
  data=subprocess.check_output(['git','-C',str(repo),'show',f'{commit}:src/FastExpressionCompiler/{name}'])
  (p/name).write_bytes(data);manifest['files'][f'{label}/{name}']=hashlib.sha256(data).hexdigest()
 (p/'Library.csproj').write_text(f'<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><AssemblyName>MapCapacity.{label}</AssemblyName></PropertyGroup></Project>')
 methods=[]
 for size in [8,16]:
  methods.append(f'''public static long Run{size}(int count,bool absent,int repetitions) {{long check=0;
for(int r=0;r<repetitions;r++) {{ var map=new SmallMap{size}<int,int,IntEq>();
for(int i=0;i<count;i++) {{ if(absent) {{ref int v=ref map.Map.AddSureAbsentDefaultAndGetRef(i*16);v=i+1;}} else {{ref int v=ref map.Map.AddOrGetValueRef(i*16,out bool found);if(found)throw new Exception("unexpected");v=i+1;}} }}
for(int i=0;i<count;i++) {{ref int v=ref map.Map.TryGetValueRef(i*16,out bool found);if(!found||v!=i+1)throw new Exception("lookup");check+=v;}}
}}return check;}}''')
  methods.append(f'''public static void Proof{size}(bool absent) {{ var map=new SmallMap{size}<int,int,IntEq>();ref int first=ref map.Map.AddOrGetValueRef(0,out _);first=71;
for(int i=1;i<64;i++) {{if(absent)map.Map.AddSureAbsentDefaultAndGetRef(i*16)=i;else map.Map.AddOrGetValueRef(i*16,out _)=i;}}
if(first!=71)throw new Exception("ref lost");first=93;if(map.Map.TryGetValueRef(0,out bool found)!=93||!found)throw new Exception("ref stability");}}''')
 (w/f'{label}.cs').write_text(f'extern alias {label};using System;using {label}::FastExpressionCompiler.ImTools;static class {label}Ops{{'+''.join(methods)+'}')
refs=''.join(f'<Reference Include="MapCapacity.{v}"><HintPath>{v}/bin/Release/$(TargetFramework)/MapCapacity.{v}.dll</HintPath><Aliases>{v}</Aliases></Reference>' for v in ['Before','Fixed'])
(w/'Runner.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><EnableDefaultCompileItems>false</EnableDefaultCompileItems><AssemblySearchPaths>{HintPathFromItem};{TargetFrameworkDirectory};{RawFileName}</AssemblySearchPaths></PropertyGroup><ItemGroup><Compile Include="Runner.cs"/><Compile Include="Before.cs"/><Compile Include="Fixed.cs"/>'+refs+'</ItemGroup></Project>')
(w/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('Source exported. Build libraries then Runner. No measurement executed.')
