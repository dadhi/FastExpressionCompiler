from pathlib import Path
import csv,json,statistics,hashlib
w=Path(__file__).resolve().parent
errors=[];rows=[];summaries=[];comparisons=[]
for tfm in ['net8.0','net10.0','net472']:
 p=w/f'{tfm}.csv'
 if not p.exists(): errors.append('missing '+str(p));continue
 with p.open() as f:
  for r in csv.reader(f):
   if len(r)!=10:errors.append(f'{tfm}: invalid row {r}');continue
   v,size,count,api,sample,ns,b,checksum,n,ms=r
   row=dict(runtime=tfm,version=v,size=int(size),count=int(count),api=api,sample=int(sample),ns=float(ns),bytes=float(b),checksum=int(checksum),operations=int(n),duration_ms=float(ms));rows.append(row)
   if row['checksum']!=row['operations']*row['count']*(row['count']+1)//2:errors.append('checksum '+str(row))
 group={}
 for r in rows:
  if r['runtime']==tfm:group.setdefault((r['size'],r['count'],r['api'],r['version']),[]).append(r)
 if len([r for r in rows if r['runtime']==tfm])!=374:errors.append(tfm+' expected374 samples')
 for key,g in group.items():
  if sorted(r['sample'] for r in g)!=list(range(11)):errors.append(str(key)+' missing/duplicate sample')
  size,count,api,v=key
  summaries.append(dict(runtime=tfm,size=size,count=count,api=api,version=v,ns=statistics.median(r['ns'] for r in g),bytes=statistics.median(r['bytes'] for r in g),samples=len(g),min_duration_ms=min(r['duration_ms'] for r in g),max_duration_ms=max(r['duration_ms'] for r in g)))
 for key,g in list(group.items()):
  size,count,api,v=key
  if v!='before':continue
  other=group.get((size,count,api,'fixed'))
  if not other:errors.append('missing fixed '+str(key));continue
  ratios=[a['ns']/b['ns'] for a,b in zip(sorted(other,key=lambda r:r['sample']),sorted(g,key=lambda r:r['sample']))]
  comparisons.append(dict(runtime=tfm,size=size,count=count,api=api,paired_ratio=statistics.median(ratios),bytes_delta=statistics.median(r['bytes'] for r in other)-statistics.median(r['bytes'] for r in g)))
data=dict(errors=errors,rows=rows,summaries=summaries,comparisons=comparisons,provenance=json.loads((w/'manifest.json').read_text()),limitations=['Collection microbenchmark; not expression compile or delegate runtime.','Map16 transition cases fixed-only; broken baseline has no valid finite timing.','Actual duration per sample retained, including calibration drift below20ms.'])
(w/'analysis.json').write_text(json.dumps(data,indent=2))
(w/'artifact-hashes.json').write_text(json.dumps({str(p.relative_to(w)):hashlib.sha256(p.read_bytes()).hexdigest() for p in w.glob('*') if p.is_file() and p.name!='artifact-hashes.json'},indent=2))
print(f'rows={len(rows)} comparisons={len(comparisons)} errors={len(errors)}')
if errors:print('\n'.join(errors));raise SystemExit(1)
