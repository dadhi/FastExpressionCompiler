"""Inventory now; finalize/compress only after the timing owner releases CPU.

No build, test, benchmark, publication, git mutation or prior-artifact write.
"""
from pathlib import Path
import argparse,os,json,hashlib,zipfile

p=argparse.ArgumentParser();p.add_argument('--finalize',action='store_true');args=p.parse_args()
out=Path(__file__).resolve().parent;work=out.parent;r2=work/'pr558-round2'
names=['nested-terminal','binary-region-private','binary-region-dispatcher',
 'binary-region-dispatcher-A-dispatcher-terminals','binary-region-dispatcher-B-dispatcher-region',
 'pending-operand-triage']
roots=[r2/name for name in names]
roots.append(r2/'jit-reader')
# The preexisting reproducer's Run.py loads these frozen historical libraries.
roots += [r2/'integrated'/v/f for v in ['before','published','fixed'] for f in ['standard','light']]
excluded_dirs={'obj','.git','.vs','node_modules','__pycache__'}
excluded_suffixes={'.etlx','.etl','.zip','.dmp'}
files={}
for root in roots:
 if not root.exists():continue
 for directory,dirs,leaves in os.walk(root):
  dirs[:]=[d for d in dirs if d not in excluded_dirs]
  for leaf in leaves:
   f=Path(directory)/leaf
   if f.suffix.lower() not in excluded_suffixes:files[str(f.relative_to(work))]=f
# Include the source-only setup/template dependency chain without copying
# unrelated old benchmark results or their binaries.
for folder in ['binary-region','binary-region-preserve','binary-region-noinline']:
 for f in (r2/folder).glob('*'):
  if f.is_file() and f.suffix in ['.py','.ps1','.cs','.csproj','.txt']:
   files[str(f.relative_to(work))]=f
for rel in ['pr558-repair/cold-start/Program.cs','pr558-repair/paired/Program.cs',
 'pr558-round2/trivial-binary-light/Cold.cs','pr558-round2/trivial-binary-light/BenchBefore.cs',
 'pr558-round2/trivial-binary-light/BenchAfter.cs','pr558-round2/trivial-binary-light/Paired.cs']:
 f=work/rel
 if not f.exists():raise RuntimeError('Missing setup/template dependency '+rel)
 files[rel]=f
captured=Path(r'C:/Data/Git/Github/FastExpressionCompiler/test/FastExpressionCompiler.UnitTests/CapturedValueRefRegressionTests.cs')
files['pr558-round2/nested-terminal/CapturedValueRefRegressionTests.cs']=captured
portable=out/'Fixture.portable.csproj'
portable.write_text((r2/'nested-terminal/Fixture.csproj').read_text().replace('C:/Data/Git/Github/FastExpressionCompiler/test/FastExpressionCompiler.UnitTests/CapturedValueRefRegressionTests.cs','CapturedValueRefRegressionTests.cs'))
files['pr558-round2/nested-terminal/Fixture.portable.csproj']=portable
inventory=dict(status='DRAFT_FINAL_AB_PENDING' if not args.finalize else 'FINALIZING',
 roots=[str(p.relative_to(work)) for p in roots],files={k:dict(bytes=f.stat().st_size) for k,f in sorted(files.items())},
 excluded_directories=sorted(excluded_dirs),excluded_suffixes=sorted(excluded_suffixes),
 source_note='Snapshot sources, measured binaries and raw .nettrace inputs are retained; obj/cache/derived .etlx files are excluded. Reproduce within the extracted pr558-round2 relative directory layout. Projects retain original absolute paths where used; see reproduction notes.')
(out/'inventory.json').write_text(json.dumps(inventory,indent=2))
print('Inventory:',len(files),'files',sum(f.stat().st_size for f in files.values()),'uncompressed bytes')
if not args.finalize:raise SystemExit(0)
# Fail closed until both experiments have explicit held/rejected decisions.
decisions=[]
for name in names[3:5]:
 candidates=list((r2/name).glob('*DECISION*'))+list((r2/name).glob('*decision*'))
 if not candidates:raise RuntimeError('Missing final A/B decision: '+name)
 texts='\n'.join(f.read_text(errors='replace') for f in candidates)
 verdict_lines=[line.upper() for line in texts.splitlines() if line.strip() and (line.lstrip().startswith('#') or line.lstrip().upper().startswith('DECISION:'))]
 if not any(any(word in line for word in ['HOLD','HELD','REJECT']) for line in verdict_lines) or any('ACCEPT' in line and 'NOT ACCEPT' not in line for line in verdict_lines):
  raise RuntimeError('A/B final held/rejected verdict is not explicit; source/validation scope needs review: '+name)
 decisions.append(dict(experiment=name,paths=[str(f.relative_to(work)) for f in candidates]))
report=out/'REPORT.txt'
if not report.exists():raise RuntimeError('Write final REPORT.txt after A/B outcomes before compression')
files[str(report.relative_to(work))]=report
for f in [out/'package-supplement.py',out/'REPRODUCTION.txt']: 
 if f.exists():files[str(f.relative_to(work))]=f
manifest=dict(decisions=decisions,files={k:dict(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for k,f in sorted(files.items())})
manifest_path=out/'manifest.json';manifest_path.write_text(json.dumps(manifest,indent=2))
archive=out/'held-experiments.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for rel,f in sorted(files.items()):z.write(f,rel)
 z.write(manifest_path,str(manifest_path.relative_to(work)))
if archive.stat().st_size>=90*1024*1024:raise RuntimeError('Archive too large for routine Git evidence; split before publication')
(out/'archive.json').write_text(json.dumps(dict(path=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),file_count=len(files)+1),indent=2))
print('Archive:',archive,archive.stat().st_size,'bytes')
