from pathlib import Path
import subprocess,json,hashlib
p=Path(__file__).resolve().parent;w=p.parent
versions={'before':'e4c232da108d98790f0ca73f23ec90756da0cad7','published':'6487c9b2380d24709ddf2b31361374773c6b3ecf','fixed':'db640cba760028d1c49ad5e4abf67f38fe683bbf','candidate':'42f98478-private-entry-prototype'}
manifest={'versions':versions,'probeSHA256':hashlib.sha256((p/'Program.cs').read_bytes()).hexdigest(),'assemblies':{}};rows=[]
with (p/'results.jsonl').open('w',encoding='utf-8') as out:
 for runtime in ['net8.0','net10.0']:
  probe=p/'bin/Release'/runtime/'Probe.dll'
  for flavor in ['standard','light']:
   for version,sha in versions.items():
    library=w/('binary-region-private/'+flavor+'/fixed' if version=='candidate' else 'integrated/'+version+'/'+flavor)/'bin/Release'/runtime/('FecBinaryRegion.'+flavor+'.fixed.dll' if version=='candidate' else 'Round2Matrix.'+flavor+'.dll')
    manifest['assemblies'][str(library)]=hashlib.sha256(library.read_bytes()).hexdigest()
    for shape in ['pending','multi','onelevel']:
     raw=subprocess.check_output(['dotnet',str(probe),str(library.resolve()),sha,flavor,shape],text=True,encoding='utf-8');row=json.loads(raw);rows.append(row);out.write(json.dumps(row)+'\n');out.flush()
    print(runtime,flavor,version,[(x['Shape'],x['Actual'],x['Exception']) for x in rows[-3:]],flush=True)
(p/'manifest.json').write_text(json.dumps(manifest,indent=2))
assert len(rows)==48
pending=[x for x in rows if x['Shape']=='pending'];safe=[x for x in rows if x['Shape']!='pending']
(p/'classification.json').write_text(json.dumps({'classification':'PREEXISTING_BEFORE_PR','pendingRows':len(pending),'pendingExceptions':sorted(set(x['Exception'] for x in pending)),'safeRows':len(safe),'safeAllMatchSystem':all(x['Actual']==x['Expected'] and x['Exception'] is None for x in safe),'importedDenominatorChanged':False,'rows':rows},indent=2))
