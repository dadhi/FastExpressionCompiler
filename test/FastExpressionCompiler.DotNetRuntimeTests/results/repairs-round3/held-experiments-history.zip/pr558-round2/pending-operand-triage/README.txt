PREEXISTING BEFORE #558: exact pending-operand/outward-goto tree fails with InvalidProgramException in all16 flavor/runtime/version combinations; System17.
Current/published/candidate safe multi-parent and one-level controls all match System. Pre-PR Light has additional failures on those shapes, preserved in raw rows.
48 fresh-process records; SHA256 library provenance in manifest.json. No original imported denominator or exclusion list changed.
