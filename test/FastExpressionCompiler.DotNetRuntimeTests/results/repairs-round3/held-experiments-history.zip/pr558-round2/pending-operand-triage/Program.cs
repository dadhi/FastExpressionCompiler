using System;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text.Json;
using E=System.Linq.Expressions.Expression;
class Program {
 static void Main(string[] args){
  var target=E.Label(typeof(int),"outward");Expression jump=E.Goto(target,E.Constant(5),typeof(int));
  if(args[3]=="pending")jump=E.Add(E.Constant(4),jump);
  var block=E.Block(jump,E.Label(target,E.Constant(9)));
  Expression body=E.Add(E.Constant(1),E.Multiply(E.Constant(2),E.Add(E.Constant(3),block)));
  if(args[3]=="onelevel")body=E.Add(E.Constant(1),block);
  var tree=E.Lambda<Func<int>>(body);int expected=tree.Compile()();string stage="load";string exception=null,message=null;int? actual=null;
  try{
   var asm=Assembly.LoadFrom(args[0]);var name=args[2]=="light"?"FastExpressionCompiler.LightExpression":"FastExpressionCompiler";var compiler=asm.GetType(name+".ExpressionCompiler",true);object input=tree;
   if(args[2]=="light") {stage="convert";var convert=compiler.GetMethods().Single(m=>m.Name=="FromSysExpression"&&!m.IsGenericMethod&&m.GetParameters().Length==1);input=convert.Invoke(null,new object[]{tree});}
   var parameterName=args[2]=="light"?name+".LambdaExpression":typeof(LambdaExpression).FullName;
   var compile=compiler.GetMethods().Single(m=>m.Name=="CompileFast"&&!m.IsGenericMethod&&m.GetParameters().Length==3&&m.GetParameters()[0].ParameterType.FullName==parameterName);
   stage="compile";var flags=Enum.ToObject(compile.GetParameters()[2].ParameterType,0);var d=(Func<int>)compile.Invoke(null,new object[]{input,true,flags});stage="invoke";actual=d();stage="complete";
  }catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;exception=e.GetType().FullName;message=e.Message;}
  Console.WriteLine(JsonSerializer.Serialize(new{Version=args[1],Flavor=args[2],Shape=args[3],Runtime=Environment.Version.ToString(),Expected=expected,Actual=actual,Stage=stage,Exception=exception,Message=message,AssemblyPath=args[0]}));
 }
}
