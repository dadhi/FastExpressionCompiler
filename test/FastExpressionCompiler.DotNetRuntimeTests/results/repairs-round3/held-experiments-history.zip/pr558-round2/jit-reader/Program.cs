using Microsoft.Diagnostics.Tracing;
using System.Text.Json;
using var source=new EventPipeEventSource(args[0]);
var starts=new Dictionary<long,(double Time,string Name,int IL)>();
source.Clr.MethodJittingStarted+=e=>{starts[e.MethodID]=(e.TimeStampRelativeMSec,e.MethodNamespace+"."+e.MethodName+" "+e.MethodSignature,e.MethodILSize);};
source.Clr.MethodLoadVerbose+=e=>{
 if(starts.Remove(e.MethodID,out var start))
  Console.WriteLine(JsonSerializer.Serialize(new {start.Name,start.IL,Milliseconds=e.TimeStampRelativeMSec-start.Time,Native=e.MethodSize}));
};
source.Process();
