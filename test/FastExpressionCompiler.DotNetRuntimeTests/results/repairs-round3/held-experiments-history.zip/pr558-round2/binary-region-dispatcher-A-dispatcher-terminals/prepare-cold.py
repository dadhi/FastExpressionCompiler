from pathlib import Path
p=Path(__file__).resolve().parent;w=p.parent
for flavor,origin in [('standard',w.parent/'pr558-repair/cold-start/Program.cs'),('light',w/'trivial-binary-light/Cold.cs')]:
 s=origin.read_text(encoding='utf-8');s=s.replace('   case "add":','   case "arithmetic64":for(int i=0;i<64;i++)body=S.Add(body,S.Constant(i));break;\n   case "add":',1);(p/('Cold-'+flavor+'.cs')).write_text(s,encoding='utf-8')
 for v in ['before','fixed']:
  name='Cold-'+flavor+'-'+v
  (p/(name+'.csproj')).write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFrameworks>net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><EnableDefaultCompileItems>false</EnableDefaultCompileItems><BaseIntermediateOutputPath>obj/'+name+'/</BaseIntermediateOutputPath><OutputPath>bin/'+name+'/</OutputPath></PropertyGroup><ItemGroup><Compile Include="Cold-'+flavor+'.cs"/><ProjectReference Include="'+flavor+'/'+v+'/Library.csproj"/></ItemGroup></Project>')

# Standalone terminal cold controls, without changing invocation/oracle code.
for flavor in ['standard','light']:
 file=p/('Cold-'+flavor+'.cs');text=file.read_text()
 marker='   case "add":'
 assert text.count(marker)==1
 text=text.replace(marker,'   case "constant":body=S.Constant(37);break;\n   case "parameter":body=x;break;\n   case "default":body=S.Default(typeof(int));break;\n'+marker,1)
 file.write_text(text)
