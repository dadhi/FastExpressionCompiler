$ErrorActionPreference='Stop'
foreach($project in @('Standard','Light','Controls-standard-before','Controls-standard-fixed','Controls-light-before','Controls-light-fixed')) {
 dotnet build (Join-Path $PSScriptRoot "$project.csproj") -c Release --nologo -v:q -m:1 -nodeReuse:false *> (Join-Path $PSScriptRoot "build-$project.log")
 if($LASTEXITCODE){Get-Content (Join-Path $PSScriptRoot "build-$project.log");throw "Build failed: $project"}
}
foreach($flavor in @('standard','light')) { foreach($version in @('before','fixed')) { foreach($runtime in @('net8.0','net10.0')) {
 $project="Controls-$flavor-$version"
 dotnet (Join-Path $PSScriptRoot "bin/$project/$runtime/$project.dll") *> (Join-Path $PSScriptRoot "controls-$flavor-$version-$runtime.log")
 if($LASTEXITCODE){Get-Content (Join-Path $PSScriptRoot "controls-$flavor-$version-$runtime.log");throw "Controls failed: $project $runtime"}
} } }
Write-Output 'All builds and eight correctness controls passed; no elapsed benchmarks.'
