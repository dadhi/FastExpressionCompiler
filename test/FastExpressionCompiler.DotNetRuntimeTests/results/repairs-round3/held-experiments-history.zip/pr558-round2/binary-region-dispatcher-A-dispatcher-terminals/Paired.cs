using System;
using System.Linq;
using System.Diagnostics;
using System.Text.Json;
public static class Paired {
 record Sample(string Runtime,string Scenario,string Phase,string Version,int Round,int SampleIndex,int Operations,double NsPerOp,double BytesPerOp);
 static void Pair(string name,string phase,int round,Action<int> before,Action<int> after) {
  before(40);after(40);
  int n=phase=="invoke"||phase=="nested_invoke"?100000:phase=="construct"?1000:phase=="activate"?1000:phase=="compile_first"?16:64;
  for(int k=0;k<101;k++) {
   if(k%8==0){GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();}
   for(int order=0;order<2;order++) {
   bool isBefore=(k+round+order)%2==0;var op=isBefore?before:after;
   long bytes=GC.GetAllocatedBytesForCurrentThread(),t=Stopwatch.GetTimestamp();op(n);long end=Stopwatch.GetTimestamp();bytes=GC.GetAllocatedBytesForCurrentThread()-bytes;
   Console.WriteLine(JsonSerializer.Serialize(new Sample(Environment.Version.ToString(),name,phase,isBefore?"before":"fixed",round,k,n,(end-t)*1e9/Stopwatch.Frequency/n,bytes/(double)n)));
  }}
 }

 public static void Main(string[] args) {
 int round=int.Parse(args[0]);
 foreach(var name in args.Skip(1)) {
  var before=BeforeBench.Program.Operations(name);var after=AfterBench.Program.Operations(name);
  Console.Error.WriteLine("PASS "+name);
  foreach(var phase in before.Keys)Pair(name,phase,round,before[phase],after[phase]);
 }
 }
}
