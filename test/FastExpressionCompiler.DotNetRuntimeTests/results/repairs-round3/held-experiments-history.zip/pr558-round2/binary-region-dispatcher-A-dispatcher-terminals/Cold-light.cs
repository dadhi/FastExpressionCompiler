using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Text.Json;
using FastExpressionCompiler.LightExpression;
using Expression = System.Linq.Expressions.Expression;
using LambdaExpression = System.Linq.Expressions.LambdaExpression;
using S = System.Linq.Expressions.Expression;
internal static class Program {
 static Expression Balanced(Expression x,int n)=>n==0?x:S.Add(Balanced(x,n-1),Balanced(x,n-1));
 static LambdaExpression Build(string name){
  var x=S.Parameter(typeof(int),"x");Expression body=x;
  switch(name){
   case "arithmetic64":for(int i=0;i<64;i++)body=S.Add(body,S.Constant(i));break;
   case "constant":body=S.Constant(37);break;
   case "parameter":body=x;break;
   case "default":body=S.Default(typeof(int));break;
   case "add":body=S.Add(x,S.Constant(1));break;
   case "balanced256":body=Balanced(x,8);break;
   case "blocks32":{var blocks=new List<Expression>();for(int i=0;i<32;i++){var v=S.Variable(typeof(int),"v"+i);blocks.Add(S.Block(new[]{v},S.Assign(v,x),S.Add(v,S.Constant(i))));}body=S.Block(blocks);break;}
   case "nested_mixed128":for(int i=0;i<128;i++)body=S.Condition(S.GreaterThan(x,S.Constant(-9)),S.Block(body),S.Constant(0));break;
   case "try_catch":body=S.TryCatch(S.Divide(S.Constant(42),x),S.Catch(typeof(DivideByZeroException),S.Constant(-1)));break;
   case "try_finally":body=S.TryFinally(S.Add(x,S.Constant(1)),S.Empty());break;
   case "capture1":return S.Lambda<Func<int,Func<int>>>(S.Lambda<Func<int>>(S.Add(x,S.Constant(1))),x);
   case "capture8":{var vs=Enumerable.Range(0,8).Select(i=>S.Variable(typeof(int),"v"+i)).ToArray();Expression sum=x;foreach(var v in vs)sum=S.Add(sum,v);return S.Lambda<Func<int,Func<int>>>(S.Block(vs,vs.Select(v=>(Expression)S.Assign(v,x)).Concat(new Expression[]{S.Lambda<Func<int>>(sum)})),x);}
   case "capture_mutable":return S.Lambda<Func<int,Func<int>>>(S.Lambda<Func<int>>(S.PreIncrementAssign(x)),x);
   case "capture_mutable_reference":{var v=S.Variable(typeof(string),"text");var update=S.Assign(v,S.Condition(S.Equal(v,S.Constant("first")),S.Constant("second"),S.Constant("first")));return S.Lambda<Func<int,Func<int>>>(S.Block(new[]{v},S.Assign(v,S.Constant("first")),S.Lambda<Func<int>>(S.Block(update,S.Property(v,"Length")))),x);}
   default:throw new ArgumentException(name);
  }return S.Lambda<Func<int,int>>(body,x);
 }
 // The FEC boundary is not JIT-compiled before measurement; no earlier code calls FEC.
 [MethodImpl(MethodImplOptions.NoInlining)]static Delegate CompileFirst(FastExpressionCompiler.LightExpression.LambdaExpression tree)=>FastExpressionCompiler.LightExpression.ExpressionCompiler.CompileFast(tree,true)??throw new InvalidOperationException("Strict FEC returned null");
 [MethodImpl(MethodImplOptions.NoInlining)]static Delegate SystemCompileFirst(LambdaExpression tree)=>tree.Compile();
 // No Driver/Action closure allocation. Capture cases include owner activation and first child call.
 [MethodImpl(MethodImplOptions.NoInlining)]static int InvokeOnce(Delegate d)=>d is Func<int,int> scalar?scalar(3):((Func<int,Func<int>>)d)(3)();
 static string Verify(Delegate d){var values=new List<string>();foreach(int x in new[]{-2,0,3}){if(d is Func<int,int> scalar)values.Add(scalar(x).ToString());else{var child=((Func<int,Func<int>>)d)(x);values.Add(child()+":"+child());}}return string.Join("|",values);}
 static void Main(string[] args){
  bool system=args[0]=="system";
  var original=Build(args[2]);
  var tree=original.ToLightExpression();
  // Warm measurement infrastructure only, before the first FEC method/type initialization.
  _=Stopwatch.GetTimestamp();_=Stopwatch.Frequency;_=GC.GetAllocatedBytesForCurrentThread();_=GC.CollectionCount(0);
  int c0=GC.CollectionCount(0),c1=GC.CollectionCount(1),c2=GC.CollectionCount(2);
  long cb=GC.GetAllocatedBytesForCurrentThread(),cs=Stopwatch.GetTimestamp();
  var compiled=system?SystemCompileFirst(original):CompileFirst(tree);
  long ce=Stopwatch.GetTimestamp();cb=GC.GetAllocatedBytesForCurrentThread()-cb;c0=GC.CollectionCount(0)-c0;c1=GC.CollectionCount(1)-c1;c2=GC.CollectionCount(2)-c2;
  int i0=GC.CollectionCount(0),i1=GC.CollectionCount(1),i2=GC.CollectionCount(2);
  long ib=GC.GetAllocatedBytesForCurrentThread(),ins=Stopwatch.GetTimestamp();
  int first=InvokeOnce(compiled);
  long ine=Stopwatch.GetTimestamp();ib=GC.GetAllocatedBytesForCurrentThread()-ib;i0=GC.CollectionCount(0)-i0;i1=GC.CollectionCount(1)-i1;i2=GC.CollectionCount(2)-i2;
  // System compilation and all correctness checking happen after both recorded phases.
  var oracle=original.Compile();int expectedFirst=InvokeOnce(oracle);string expected=Verify(oracle),actual=Verify(compiled);
  if(first!=expectedFirst||actual!=expected)throw new InvalidOperationException("Mismatch "+args[2]+" "+actual+" expected "+expected);
  double compileNs=(ce-cs)*1e9/Stopwatch.Frequency,firstNs=(ine-ins)*1e9/Stopwatch.Frequency;
  Console.WriteLine(JsonSerializer.Serialize(new{Version=args[0],Commit=args[1],Runtime=Environment.Version.ToString(),Flavor="light",TieredCompilation=Environment.GetEnvironmentVariable("DOTNET_TieredCompilation"),ReadyToRun=Environment.GetEnvironmentVariable("DOTNET_ReadyToRun"),Scenario=args[2],Repetition=int.Parse(args[3]),CompileNs=compileNs,CompileBytes=cb,FirstInvokeNs=firstNs,FirstInvokeBytes=ib,CompileAndFirstNs=compileNs+firstNs,CompileAndFirstBytes=cb+ib,CompileGen0=c0,CompileGen1=c1,CompileGen2=c2,FirstInvokeGen0=i0,FirstInvokeGen1=i1,FirstInvokeGen2=i2,FirstValue=first,Verification=actual}));
  GC.KeepAlive(compiled);
 }
}
