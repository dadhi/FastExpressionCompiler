from pathlib import Path
import sys

p=Path(__file__).resolve().parent
for stage in ['A-dispatcher-terminals','B-dispatcher-region']:
 d=p.parent/('binary-region-dispatcher-'+stage)
 for name in ['Standard.cs','BenchBefore.cs','BenchAfter.cs']:
  f=d/name;s=f.read_text(encoding='utf-8');marker='   case "add":'
  assert s.count(marker)==1
  s=s.replace('   case "constant":body=E.Constant(37);break;\n','')
  addition=''
  for key,body in [('parameter','x'),('default','E.Default(typeof(int))')]:
   if 'case "'+key+'":' not in s:addition+='   case "'+key+'":body='+body+';break;\n'
  s=s.replace(marker,addition+marker,1)
  f.write_text(s,encoding='utf-8')
 measure=(p.parent/'binary-region/Run-Measure.py').read_text(encoding='utf-8')
 measure=measure.replace("names=['add','balanced256','arithmetic64','blocks32','nested_mixed128','try_finally','capture8']", "names=['constant','parameter','default','add','balanced256','arithmetic64','blocks32','capture8','try_finally']")
 measure=measure.replace("['balanced256','arithmetic64','try_finally','add']", "['add','constant','parameter','default','balanced256','try_finally']")
 measure=measure.replace('for repeat in range(9):',"for repeat in range(9 if name in ['add','try_finally'] else 3):")
 measure=measure.replace("version,'binary-region',name", "version,'dispatcher-"+stage+"',name")
 (d/'Run-Measure.py').write_text(measure,encoding='utf-8')
 print('Prepared focused warm/cold schedule for',stage)
