"""PREPARED ONLY: run after the parent releases exports/builds.
Creates independent A (dispatcher/terminals) and B (+binary region) snapshots.
"""
from pathlib import Path
import hashlib, json, re, sys

p = Path(__file__).resolve().parent
w = p.parent
assert '--revision' not in sys.argv, 'This final experiment is pinned to 42f98478.'
sys.argv.extend(['--revision', '42f98478'])

def rename_six(source):
    # Six-argument internal calls and definition only; public/callback four-arg
    # collection remains a boundary. Expressions here have no string literals.
    replacements = []
    for m in re.finditer(r'(?<![.\w])TryCollectInfo\(', source):
        i = m.end(); depth = 1; count = 1
        while depth:
            ch = source[i]
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
            elif ch == ',' and depth == 1:
                count += 1
            i += 1
        if count == 6:
            replacements.append((m.start(), m.start() + len('TryCollectInfo')))
    for a, b in reversed(replacements):
        source = source[:a] + 'TryCollectInfoCore' + source[b:]
    return source, len(replacements)

dispatcher = '''        [MethodImpl(MethodImplOptions.NoInlining)]
        private static Result TryCollectInfo(ref CompilerContext context, Expression expr,
            NestedLambdaInfo nestedLambda, ref SmallList<NestedLambdaInfo> rootNestedLambdas,
            bool directBlockChild = false, bool switchBody = false)
        {
            var scopeDepth = context.LabelScopeDepth;
            if (scopeDepth == 0 && expr != null
#if LIGHT_EXPRESSION
                && !expr.IsIntrinsic
#endif
                )
            {
                if (expr is ConstantExpression || expr is ParameterExpression || expr is DefaultExpression)
                    return TryCollectTerminalInfo(ref context, expr, expr.NodeType, nestedLambda, ref rootNestedLambdas);
REGION_GATE
            }
            return TryCollectInfoCore(ref context, expr, nestedLambda, ref rootNestedLambdas, directBlockChild, switchBody);
        }

'''
region_gate = '''                if (nestedLambda == null && expr is BinaryExpression binary &&
                    TryCollectBinaryRegionRoot(ref context, binary, ref rootNestedLambdas, out var result))
                    return RestoreScopeAndReturn(ref context, scopeDepth, result);'''

for stage in ['A-dispatcher-terminals', 'B-dispatcher-region']:
    # The inherited setup scripts resolve their templates as siblings of the
    # destination. Keep stage snapshots separate siblings under round2.
    dest = w / ('binary-region-dispatcher-' + stage)
    dest.mkdir(parents=True, exist_ok=True)
    # Reuse export/project preparation, never its final candidate source.
    (dest/'NestedControls.cs.txt').write_text((w/'binary-region-private/NestedControls.cs.txt').read_text())
    exec(compile((w/'binary-region-private/setup.py').read_text(), str(w/'binary-region-private/setup.py'), 'exec'),
         {'__file__':str(dest/'setup.py'), '__name__':'__main__'})
    base = (dest/'standard/before/FastExpressionCompiler.cs').read_text()
    old = (dest/'standard/fixed/FastExpressionCompiler.cs').read_text()
    a = old.index('        // Pure binary regions')
    b = old.index('    }', old.index('return TryCollectInfo(ref context, expression, null, ref rootNestedLambdas, false, false);', a))
    b = old.index('\n', b) + 1
    region = old[a:b].replace('return TryCollectInfo(ref context, expression, null,', 'return TryCollectInfoCore(ref context, expression, null,')
    fixed, renamed = rename_six(base)
    # The only six-argument call remaining at the public boundary must dispatch.
    public_start = fixed.index('        public static Result TryCollectInfo(')
    public_end = fixed.index('        [MethodImpl((MethodImplOptions)256)]\n        private static Result RestoreScopeAndReturn', public_start)
    public = fixed[public_start:public_end]
    assert public.count('TryCollectInfoCore(') == 1
    fixed = fixed[:public_start] + public.replace('TryCollectInfoCore(', 'TryCollectInfo(') + fixed[public_end:]
    marker = '        private static Result TryCollectInfoCore('
    assert fixed.count(marker) == 1
    gate = region_gate if stage.startswith('B-') else ''
    fixed = fixed.replace(marker, dispatcher.replace('REGION_GATE', gate) + marker, 1)
    if stage.startswith('B-'):
        outer_end = fixed.rfind('    }', 0, fixed.index('    public static class Tools'))
        fixed = fixed[:outer_end] + region + '\n' + fixed[outer_end:]
    assert fixed[fixed.index('        public static Result TryCollectInfo('):fixed.index('        [MethodImpl((MethodImplOptions)256)]\n        private static Result RestoreScopeAndReturn')] == base[base.index('        public static Result TryCollectInfo('):base.index('        [MethodImpl((MethodImplOptions)256)]\n        private static Result RestoreScopeAndReturn')]
    scalar = '        private static bool TryCollectSimpleBinary('
    terminal = '        private static Result TryCollectTerminalInfo('
    assert base[base.index(scalar):base.index(terminal)] == fixed[fixed.index(scalar):fixed.index(terminal)]
    for flavor in ['standard','light']:
        (dest/flavor/'fixed/FastExpressionCompiler.cs').write_text(fixed)
    controls = dest/'Controls.cs'
    text = controls.read_text(); anchor = '  Console.WriteLine("PASS binary regions'
    assert text.count(anchor) == 1
    controls.write_text(text.replace(anchor, (p/'TerminalControls.cs.txt').read_text() + anchor))
    (dest/'Build-Controls.ps1').write_text((w/'binary-region-private/Build-Controls.ps1').read_text())
    cold_setup = (w/'binary-region-private/prepare-cold.py').read_text()
    cold_setup += '''
# Standalone terminal cold controls, without changing invocation/oracle code.
for flavor in ['standard','light']:
 file=p/('Cold-'+flavor+'.cs');text=file.read_text()
 marker='   case "add":'
 assert text.count(marker)==1
 text=text.replace(marker,'   case "constant":body=S.Constant(37);break;\\n   case "parameter":body=x;break;\\n   case "default":body=S.Default(typeof(int));break;\\n'+marker,1)
 file.write_text(text)
'''
    (dest/'prepare-cold.py').write_text(cold_setup)
    manifest = json.loads((dest/'manifest.json').read_text())
    manifest.update(stage=stage, entryPlacement='NoInlining private6 dispatcher; recursive/helper calls direct Core6',
        coreCallSitesRenamed=renamed, candidateCoreSHA256=hashlib.sha256(fixed.encode()).hexdigest(),
        built=False, executed=False, terminalRootRoute=True, regionEnabled=stage.startswith('B-'))
    (dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Export/preparation complete. Neither builds nor controls have been run.')
