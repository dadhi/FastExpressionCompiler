# Final dispatcher placement: prepared only

Preparation was subsequently released by the parent. `setup.py` pins baseline 42f98478; stage evidence records actual execution and final decisions.

Reproduction in PowerShell requires UTF-8 Python text I/O: `$env:PYTHONUTF8='1'`. Run setup.py, each stage's prepare-cold.py and Build-Controls.ps1, Prepare-Measurements.py, Build-Measurements.ps1, then Collect-Jit.py. Only after all builds/diagnostics stop, run each stage's Run-Measure.py separately in an exclusive CPU window. Final decisions retain every raw row.

Two independent before/fixed snapshots will be produced as sibling folders under round2 (`binary-region-dispatcher-A-dispatcher-terminals` and `binary-region-dispatcher-B-dispatcher-region`):

- A: explicitly NoInlining private-six-argument dispatcher, ordinary physical-root Constant/Parameter/Default routed to the existing terminal helper, original visitor renamed Core6.
- B: identical A plus the previously controlled binary-region traversal and lazy scoped fallback.

All original recursive/helper six-argument calls are renamed to Core6. Only the unchanged public-four-argument boundary calls the dispatcher. Intrinsic APIs stay unchanged. Region fallback calls Core6 after creating the original Lambda/Expression scope prefix; region success restores the original depth. The actual nested-lambda argument is forwarded for terminal roots. Explicit Light intrinsics fall through to Core6 and its existing terminal helper behavior.

Source-only preparation assertions compare public wrapper and scalar helper text with baseline; stage manifests record separate source hashes after export. Prior late fallback, constant-count, error-order, intrinsic and nested-label controls are retained, with terminal result/filter/identity/default/nested-capture controls added.

Prepared cold-project generation also adds standalone constant/parameter/default scenarios, preserving the existing invocation and System oracle code. Measurement scripts must explicitly include these terminal scenarios when execution is released; no elapsed schedule is launched by setup.

Hazards to verify on release: accidental six-argument routing through dispatcher during recursion; accidentally renaming public/callback four-argument APIs; scope restoration after partially collected region; preserving first-error ordering; hoisting with actual nestedLambda; standalone terminals may gain a dispatcher call while avoiding the larger visitor JIT. Public/source/native-size equality is insufficient to promise cold wall-time equality. Both stage A attribution and stage B control costs must remain visible. The preexisting pending-operand outward-goto InvalidProgramException remains separately documented in ../pending-operand-triage and must not be hidden.

This is the final placement experiment. No further variants are planned.
