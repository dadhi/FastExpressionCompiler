from pathlib import Path
import subprocess,os,json,hashlib
p=Path(__file__).resolve().parent;w=p.parent
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
trace=w.parent/'pr558-repair/tools/dotnet-trace.exe'
reader=w/'jit-reader/bin/Release/net10.0/Reader.dll'
for stage in ['A-dispatcher-terminals','B-dispatcher-region']:
 d=w/('binary-region-dispatcher-'+stage);proof=[]
 for runtime in ['net8.0','net10.0']:
  for flavor in ['standard','light']:
   for version in ['before','fixed']:
    tag='jit-'+runtime+'-'+flavor+'-'+version
    project='Cold-'+flavor+'-'+version
    with (d/(tag+'.log')).open('w',encoding='utf-8') as log:
     subprocess.run([str(trace),'collect','--providers','Microsoft-Windows-DotNETRuntime:0x10:5','--output',str(d/(tag+'.nettrace')),'--','dotnet',str(d/'bin'/project/runtime/(project+'.dll')),version,stage,'add','0'],env=env,stdout=log,stderr=log,check=True)
    with (d/(tag+'.jsonl')).open('w',encoding='utf-8') as out:
     subprocess.run(['dotnet',str(reader),str(d/(tag+'.nettrace'))],stdout=out,check=True)
    rows=[json.loads(s) for s in (d/(tag+'.jsonl')).read_text(encoding='utf-8').splitlines()]
    entries=[x for x in rows if 'ExpressionCompiler.TryCollectInfo' in x['Name'] or 'ExpressionCompiler.TryCollectSimpleBinary' in x['Name'] or 'ExpressionCompiler.TryCollectBinaryRegion' in x['Name'] or 'ExpressionCompiler.IsSimpleBinaryOperation' in x['Name']]
    assert not any('TryCollectInfoCore' in x['Name'] or 'TryCollectBinaryRegion' in x['Name'] or 'IsSimpleBinaryOperation' in x['Name'] for x in entries),(stage,runtime,flavor,version,entries)
    proof.append(dict(stage=stage,runtime=runtime,flavor=flavor,version=version,entries=entries))
 (d/'scalar-jit-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
 for flavor in ['standard','light']:
  before=(d/flavor/'before/FastExpressionCompiler.cs').read_text(encoding='utf-8')
  fixed=(d/flavor/'fixed/FastExpressionCompiler.cs').read_text(encoding='utf-8')
  start='        private static Result TryCollectInfo(';end='        private static bool TryCollectSimpleBinary('
  old=before[before.index(start):before.index(end)]
  current=fixed[fixed.index(start.replace('TryCollectInfo(','TryCollectInfoCore(')):fixed.index(end)].replace('TryCollectInfoCore(','TryCollectInfo(')
  assert old==current,'Core visitor must be identical except renamed references'
 print('Scalar JIT and Core-text diagnostics complete:',stage,flush=True)
