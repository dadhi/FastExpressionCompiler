from pathlib import Path
from collections import defaultdict
import json,statistics,hashlib
p=Path(__file__).resolve().parent
summary=[]
for stage in ['A-dispatcher-terminals','B-dispatcher-region']:
 d=p.parent/('binary-region-dispatcher-'+stage)
 warm=json.loads((d/'warm-analysis.json').read_text(encoding='utf-8'))
 cold=[json.loads(s) for s in (d/'cold.jsonl').read_text(encoding='utf-8').splitlines()]
 groups=defaultdict(dict)
 for row in cold:
  groups[(row['Runtime'],row['Flavor'],row['Scenario'])].setdefault(row['Version'],{})[row['Repetition']]=row
 distributions=[]
 for (runtime,flavor,case),versions in sorted(groups.items()):
  b=versions['before'];f=versions['fixed'];assert set(b)==set(f)
  fields={}
  for key in ['CompileNs','FirstInvokeNs','CompileAndFirstNs','CompileBytes','FirstInvokeBytes','CompileAndFirstBytes']:
   bv=[b[i][key] for i in sorted(b)];fv=[f[i][key] for i in sorted(f)]
   bm=statistics.median(bv);fm=statistics.median(fv)
   fields[key]=dict(before=bv,fixed=fv,beforeMedian=bm,fixedMedian=fm,medianRatio=fm/bm if bm else None,
      pairedRatios=[y/x if x else None for x,y in zip(bv,fv)])
  distributions.append(dict(runtime=runtime,flavor=flavor,case=case,pairs=len(b),fields=fields))
 (d/'cold-distributions.json').write_text(json.dumps(distributions,indent=2)+'\n',encoding='utf-8')
 warm_differences=[r for r in warm if r['beforeBytes']!=r['fixedBytes']]
 nonconstruct_differences=[r for r in warm_differences if r['phase']!='construct']
 runtime_rows=[r for r in warm if r['phase'] in ['invoke','activate','nested_invoke']]
 cold_allocation_modes=[dict(runtime=r['runtime'],flavor=r['flavor'],case=r['case'],
      before=sorted(set(r['fields']['CompileAndFirstBytes']['before'])),fixed=sorted(set(r['fields']['CompileAndFirstBytes']['fixed']))) for r in distributions
      if set(r['fields']['CompileAndFirstBytes']['before'])!=set(r['fields']['CompileAndFirstBytes']['fixed'])]
 metrics=dict(stage=stage,decision='HOLD',warmSummaryRows=len(warm),coldRows=len(cold),
   warmAllocationDifferences=warm_differences,nonconstructionWarmAllocationDifferences=nonconstruct_differences,
   coldAllocationModeDifferences=cold_allocation_modes,runtimeRows=runtime_rows,
   coldRatios=[dict(runtime=r['runtime'],flavor=r['flavor'],case=r['case'],ratio=r['fields']['CompileAndFirstNs']['medianRatio']) for r in distributions])
 (d/'analysis.json').write_text(json.dumps(metrics,indent=2)+'\n',encoding='utf-8')
 manifest=json.loads((d/'manifest.json').read_text(encoding='utf-8'))
 manifest.update(built=True,executed=True,decision='HOLD',warmSummaryRows=len(warm),coldRows=len(cold),
   helperLines=65 if stage.startswith('B-') else 0,complexEntryNoInlining=stage.startswith('B-'),dispatcherNoInlining=True,
   pairedDriverCoverage={'standard':['constant','add','balanced256','arithmetic64','blocks32','capture8','try_finally'],
     'light':['constant','parameter','default','add','balanced256','arithmetic64','blocks32','capture8','try_finally']},
   correctnessConfigurations=8,coreSourceVerbatimApartFromNames=True,
   scalarPublicAndHelperILNativeSizesEqual=True,scalarNoCoreOrRegionJitEvents=True,
   architecture='ARM64 .NET 8/10 processes on ARM64 Windows',
   artifactHashes={str(f.relative_to(d)):hashlib.sha256(f.read_bytes()).hexdigest() for f in d.glob('*/*/FastExpressionCompiler.cs')},
   harnessHashes={name:hashlib.sha256((d/name).read_bytes()).hexdigest() for name in ['Standard.cs','BenchBefore.cs','BenchAfter.cs','Controls.cs','Run-Measure.py']})
 (d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
 why=('Terminal cold medians improve in 11/12 flavor/runtime/case combinations, but Default Standard8 is +36.3%. '
      'Cold controls include Light8 add +17.9%, Standard8 try_finally +18.8%, and Standard10 balanced +18.4%. '
      'Warm compiler controls include Light8 capture8 +3.0%. Runtime controls retain Standard8 nested-invoke +11.2%, Light8 balanced invocation +7.2%, and Standard10 activation +4.5%. '
      if stage.startswith('A-') else
      'Warm balanced compilation improves 11.2-15.4%, arithmetic 3.3-5.5%. '
      'Standard10 controls worsen: blocks32 +4.5%, capture8 +6.25%; Light10 capture8 +3.25%. Cold controls retain Standard10 add +8.55%, Standard8 try_finally +17.5%, and Standard8 balanced +10.6%; Standard8 capture8 nested-invoke is +10.5% warm. ')
 text='# '+stage+': HOLD\n\n'+why+'These measured costs prevent acceptance under the agreed conservative control rule. No further placement variants or repeats were run. No main edits or candidate commits.\n\n'
 text+='Eight correctness configurations passed, including undefined parameter/filter contracts, terminal boxed/reference identity, Default values, nested terminal capture, intrinsic callbacks/scopes, late unsupported fallback, exact constant use counts and nested valid/invalid label controls. The preexisting pending-operand outward-goto InvalidProgramException remains separately documented in ../pending-operand-triage; no imported denominator was changed.\n\n'
 text+=f'Coverage: {len(warm)} warm summary rows, 101 alternating pairs per executed scenario/phase; {len(cold)} fresh-process cold rows. Standard paired driver filters out parameter/default scenarios; they execute in Standard cold/correctness and all Light phases. Cold add/try_finally use nine pairs; constant/parameter/default/balanced use three. Both original phase samples and all distributions are retained without filtering, subtraction or timing corrections.\n\n'
 text+=f'Allocation facts: {len(nonconstruct_differences)} compiler/compile-first/runtime warm allocation differences; {len(warm_differences)} total warm differences including unchanged construction harness; {len(cold_allocation_modes)} cold raw allocation-mode differences. Inspect analysis.json and cold-distributions.json for exact values rather than assuming every raw allocation matches.\n\n'
 text+='Public wrapper and scalar helper source, IL size and native size match baseline all four flavor/runtime combinations. Scalar add traces show no Core/region JIT events. Original Core source is identical after renaming its six-argument calls. Those diagnostics do not establish equal wall time: placement, process variation and cold costs remain visible in the measured distributions.\n\n'
 text+='Evidence: manifest.json, analysis.json, warm-analysis.json, warm-*.jsonl, cold.jsonl, cold-distributions.json, scalar-jit-proof.json, jit-*.nettrace/jsonl, controls-*.log and complete.json. Measurements complete; exclusive window released.\n'
 (d/'DECISION.md').write_text(text,encoding='utf-8')
 summary.append(metrics)
 print(stage,'warm rows',len(warm),'cold rows',len(cold),'nonconstruct alloc differences',len(nonconstruct_differences),'cold modes',len(cold_allocation_modes))
 print('Cold medians:',metrics['coldRatios'])
 print('Runtime controls:',[(r['runtime'],r['flavor'],r['case'],r['phase'],round(r['ratio'],4)) for r in runtime_rows if r['ratio']>1.025])
(p/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
