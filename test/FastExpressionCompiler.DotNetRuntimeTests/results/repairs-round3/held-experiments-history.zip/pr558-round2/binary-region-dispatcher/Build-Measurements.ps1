$ErrorActionPreference='Stop'
foreach($stage in @('A-dispatcher-terminals','B-dispatcher-region')) {
 $folder=Join-Path (Split-Path $PSScriptRoot -Parent) "binary-region-dispatcher-$stage"
 foreach($project in @('Standard','Light','Cold-standard-before','Cold-standard-fixed','Cold-light-before','Cold-light-fixed')) {
  dotnet build (Join-Path $folder "$project.csproj") -c Release --nologo -v:q -m:1 -nodeReuse:false *> (Join-Path $folder "build-$project.log")
  if($LASTEXITCODE){Get-Content (Join-Path $folder "build-$project.log");throw "Build failed: $stage $project"}
 }
}
Write-Output 'All final measurement projects built; no elapsed measurements started.'
