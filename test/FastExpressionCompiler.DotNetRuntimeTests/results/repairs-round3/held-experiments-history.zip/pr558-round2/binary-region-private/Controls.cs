using System;
using System.Collections.Generic;
using System.Reflection;
#if LIGHT
using FastExpressionCompiler.LightExpression;
using E=FastExpressionCompiler.LightExpression.Expression;
using C=FastExpressionCompiler.LightExpression.ExpressionCompiler;
using Roots=FastExpressionCompiler.LightExpression.ImTools.SmallList<FastExpressionCompiler.LightExpression.ExpressionCompiler.NestedLambdaInfo>;
#else
using FastExpressionCompiler;
using System.Linq.Expressions;
using E=System.Linq.Expressions.Expression;
using C=FastExpressionCompiler.ExpressionCompiler;
using Roots=FastExpressionCompiler.ImTools.SmallList<FastExpressionCompiler.ExpressionCompiler.NestedLambdaInfo>;
#endif
public sealed class MutableValue { public int Value; }
static class Controls {
 static void Check(bool okay,string name){if(!okay)throw new Exception(name);}
 static int Depth(C.CompilerContext context)=>(int)typeof(C.CompilerContext).GetField("LabelScopeDepth",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(context);
 static C.Result Collect(Expression body,ParameterExpression[] parameters,out C.CompilerContext context){
  var lambda=E.Lambda(body,parameters);
#if LIGHT
  context=new C.CompilerContext(C.ClosureStatus.ToBeCollected,lambda,CompilerFlags.Default);
#else
  context=new C.CompilerContext(C.ClosureStatus.ToBeCollected,lambda.Parameters,CompilerFlags.Default);
#endif
  Roots roots=default;var result=C.TryCollectInfo(ref context,body,null,ref roots);Check(Depth(context)==0,"public cleanup");return result;
 }
 static Expression Balanced(Expression x,int depth)=>depth==0?x:E.Add(Balanced(x,depth-1),Balanced(x,depth-1));
 static void Main(){
  var x=E.Parameter(typeof(int),"x");
  foreach(var body in new[]{Balanced(x,8),E.Add(E.Constant(1),E.Block(E.Multiply(x,E.Constant(2))))}){
   var f=E.Lambda<Func<int,int>>(body,x).CompileFast(true);Check(f!=null&&f(3)==(ReferenceEquals(body,x)?3:body is BinaryExpression b&&b.Left is ConstantExpression?7:768),"balanced/late complex correctness");
  }
  Expression arithmetic=x;for(int i=0;i<64;i++)arithmetic=E.Add(arithmetic,E.Constant(1));
  Check(E.Lambda<Func<int,int>>(arithmetic,x).CompileFast(true)(3)==67,"arithmetic64");
  var target=E.Label(typeof(int),"local");var scoped=E.Add(E.Constant(1),E.Block(E.Goto(target,E.Constant(5),typeof(int)),E.Label(target,E.Constant(2))));
  Check(E.Lambda<Func<int>>(scoped).CompileFast(true)()==6,"late scoped label");
  var invalidTarget=E.Label(typeof(int),"outside");
  var invalid=E.Add(E.Goto(invalidTarget,E.Constant(3),typeof(int)),E.Block(E.Label(invalidTarget,E.Constant(1))));
  bool rejected=false;try{E.Lambda<Func<int>>(invalid).CompileFast(true,CompilerFlags.ThrowOnNotSupportedExpression);}catch(InvalidOperationException){rejected=true;}
  Check(rejected,"typed jump from outside target scope remains invalid");
  var nestedTarget=E.Label(typeof(int),"nested-outward");
  var lateBlock=E.Block(E.Goto(nestedTarget,E.Constant(5),typeof(int)),E.Label(nestedTarget,E.Constant(9)));
  var nestedBody=E.Add(E.Constant(1),E.Multiply(E.Constant(2),E.Add(E.Constant(3),lateBlock)));
  var nestedLambda=E.Lambda<Func<int>>(nestedBody);
  int systemNested=nestedLambda.CompileSys()();
  Check(systemNested==17&&nestedLambda.CompileFast(true)()==systemNested,"nested binary outward goto matches System");
  var crossTarget=E.Label(typeof(int),"nested-cross-entry");
  var crossBody=E.Add(E.Add(E.Constant(1),E.Goto(crossTarget,E.Constant(3),typeof(int))),
      E.Block(E.Add(E.Constant(2),E.Multiply(E.Constant(3),E.Label(crossTarget,E.Constant(4))))));
  var crossLambda=E.Lambda<Func<int>>(crossBody);
  bool systemCrossRejected=false;try{crossLambda.CompileSys();}catch(InvalidOperationException){systemCrossRejected=true;}
  bool fastCrossRejected=false;try{crossLambda.CompileFast(true,CompilerFlags.ThrowOnNotSupportedExpression);}catch(InvalidOperationException){fastCrossRejected=true;}
  Check(systemCrossRejected&&fastCrossRejected,"nested binary cross-expression entry rejected like System");
  var token=new MutableValue{Value=3};var constant=E.Constant(token);
  var equality=E.Equal(constant,E.Block(constant));C.CompilerContext context;
  Check(Collect(equality,new ParameterExpression[0],out context)==C.Result.OK,"constant collect");
  Check(context.Constants.Count==1&&context.ConstantUsageThenVarIndex.Count==1&&context.ConstantUsageThenVarIndex.GetSurePresentRef(0)==2,"no duplicate constant usage after late block fallback");
  var coalesce=E.Equal(constant,E.Coalesce(E.Constant(null,typeof(MutableValue)),constant));
  Check(Collect(coalesce,new ParameterExpression[0],out context)==C.Result.OK&&context.ConstantUsageThenVarIndex.GetSurePresentRef(0)==2,"no restart on unsupported right binary");
  var read=E.Lambda<Func<int>>(E.Add(E.Constant(1),E.Field(constant,nameof(MutableValue.Value)))).CompileFast(true);
  Check(read()==4,"constant initial value");token.Value=8;Check(read()==9,"mutable constant identity");
  var missing=E.Parameter(typeof(int),"missing");Check(Collect(E.Add(missing,E.Constant(1)),new ParameterExpression[0],out context)==C.Result.ParameterIsNotVariableNorInPassedParameters,"unbound error");
#if LIGHT
  Calls.Clear();var custom=new Probe("late");
  Check(Collect(E.Add(E.Add(x,E.Constant(1)),custom),new[]{x},out context)==C.Result.OK&&Calls.Count==1&&Calls[0]=="late:2","late intrinsic original scope");
  Calls.Clear();Check(Collect(E.Add(new Probe("left",true),new Probe("right")),new[]{x},out context)==C.Result.NotSupported_Quote&&Calls.Count==1&&Calls[0]=="left:2","left-first intrinsic error");
  Calls.Clear();Check(Collect(E.Add(missing,new Probe("right")),new ParameterExpression[0],out context)==C.Result.ParameterIsNotVariableNorInPassedParameters&&Calls.Count==0,"unbound left precedes right callback");
  Calls.Clear();Check(Collect(new IntrinsicBinary(),new ParameterExpression[0],out context)==C.Result.OK&&Calls.Count==1&&Calls[0]=="root:2","intrinsic root original scope");
#endif
  Console.WriteLine("PASS binary regions, late scoped/complex fallback, constant identity/usage, error order, cleanup and intrinsic controls");
 }
#if LIGHT
 static readonly List<string> Calls=new List<string>();
 sealed class Probe:ConstantExpression {
  readonly string name;readonly bool fail;internal Probe(string name,bool fail=false){this.name=name;this.fail=fail;}
  public override object Value=>1;public override Type Type=>typeof(int);public override bool IsIntrinsic=>true;
  public override C.Result TryCollectInfo(ref C.CompilerContext context,C.NestedLambdaInfo nested,ref Roots roots){Calls.Add(name+":"+Depth(context));return fail?C.Result.NotSupported_Quote:C.Result.OK;}
 }
 sealed class IntrinsicBinary:BinaryExpression {
  internal IntrinsicBinary():base(E.Constant(1),E.Constant(2)){}
  public override Type Type=>typeof(int);public override System.Linq.Expressions.ExpressionType NodeType=>System.Linq.Expressions.ExpressionType.Add;public override bool IsIntrinsic=>true;
  public override C.Result TryCollectInfo(ref C.CompilerContext context,C.NestedLambdaInfo nested,ref Roots roots){Calls.Add("root:"+Depth(context));return C.Result.OK;}
 }
#endif
}
