# Private-entry binary-region candidate: HOLD

Baseline: production-equivalent documentation commit 42f9847843cec8edaaf11c00cb97a5dd576b82cf. No main changes or candidate commits.

All eight correctness configurations passed. The additional pending-operand outward-goto reproducer fails before PR558 and on every later compared version; its complete separate triage remains in ../pending-operand-triage and is not removed from any imported denominator.

Warm: 101 alternating pairs for each scenario/flavor/runtime. Balanced compile medians improve 6.9-14.3%, arithmetic 3.5-7.0%. Controls remain mixed: Standard net8 blocks32 +4.8%, Light net8 capture8 +6.9%. Compiler, compile+first and runtime allocation values match. Six Light construction rows differ by 0.16-0.168 B/op in the unchanged construction harness; those raw values are retained. Raw rows and distributions are retained without filtering/subtraction.

Cold: nine fresh pairs for add/try_finally and three for balanced256, all four flavor/runtime combinations (168 rows). Light add medians worsen 28.2%/28.5% on net8/net10; Standard add improves. These differences cannot be assigned to changed scalar code: public wrapper and scalar helper text/IL/native sizes match and add JIT traces contain no region/private6 events. Process durations are highly unstable; Light10 balanced baseline median is 1.90 seconds. No claim of scalar cold neutrality or universal benefit is justified. Cold allocation medians match. Raw Light10 distributions retain the previously observed 12,336 B mode: add baseline [29,864,42,200] versus fixed [42,200], and try_finally baseline [31,784] versus fixed [31,784,44,120]. These mode differences are preserved; no universal raw allocation-equality claim is made.

Decision: HOLD this placement. Do not integrate based on target wins while control results remain unresolved. Measurement window completed and explicitly released. Further thin-dispatch placement is read-only assessment only, not implemented here.

Evidence: warm-analysis.json, warm-*.jsonl, cold.jsonl, cold-distributions.json, measurement-summary.log, complete.json, scalar-jit-proof.json, controls-*.log and manifest.json.
