from pathlib import Path
import json,hashlib,sys
p=Path(__file__).resolve().parent;w=p.parent
# Reuse the reproducible export/harness setup, with a documentation-only newer baseline.
if '--revision' not in sys.argv:sys.argv.extend(['--revision','42f98478'])
exec(compile((w/'binary-region-noinline/setup.py').read_text(encoding='utf-8'),str(w/'binary-region-noinline/setup.py'),'exec'),{'__file__':str(p/'setup.py'),'__name__':'__main__'})
base=(p/'standard/before/FastExpressionCompiler.cs').read_text(encoding='utf-8');prior=(p/'standard/fixed/FastExpressionCompiler.cs').read_text(encoding='utf-8')
a=prior.index('        // Pure binary regions');b=prior.index('    }',prior.index('return TryCollectInfo(ref context, expression, null, ref rootNestedLambdas, false, false);',a))
# The first close after the fallback return is its method close; preserve the method block.
b=prior.index('\n',b)+1;helpers=prior[a:b]
assert '[MethodImpl(MethodImplOptions.NoInlining)]' in helpers
old='''            var scopeDepth = context.LabelScopeDepth;
            if (scopeDepth == 0)
                context.PushLabelScope(LabelScopeKind.Lambda);'''
new='''            var scopeDepth = context.LabelScopeDepth;
            // The public scalar path remains unchanged. Only physical complex roots
            // enter the region collector, before their first lexical frame is pushed.
            if (scopeDepth == 0 && nestedLambda == null && expr is BinaryExpression binary
#if LIGHT_EXPRESSION
                && !binary.IsIntrinsic
#endif
                && TryCollectBinaryRegionRoot(ref context, binary, ref rootNestedLambdas, out var regionResult))
                return RestoreScopeAndReturn(ref context, scopeDepth, regionResult);
            if (scopeDepth == 0)
                context.PushLabelScope(LabelScopeKind.Lambda);'''
assert base.count(old)==1;fixed=base.replace(old,new,1)
outerEnd=fixed.rfind('    }',0,fixed.index('    public static class Tools'));fixed=fixed[:outerEnd]+helpers+'\n'+fixed[outerEnd:]
for flavor in ['standard','light']:(p/flavor/'fixed/FastExpressionCompiler.cs').write_text(fixed,encoding='utf-8')
public='        public static Result TryCollectInfo(';end='        [MethodImpl((MethodImplOptions)256)]\n        private static Result RestoreScopeAndReturn'
assert base[base.index(public):base.index(end)]==fixed[fixed.index(public):fixed.index(end)]
scalar='        private static bool TryCollectSimpleBinary(';terminal='        private static Result TryCollectTerminalInfo('
assert base[base.index(scalar):base.index(terminal)]==fixed[fixed.index(scalar):fixed.index(terminal)]
measure=(w/'binary-region/Run-Measure.py').read_text(encoding='utf-8');measure=measure.replace("names=['add','balanced256','arithmetic64','blocks32','nested_mixed128','try_finally','capture8']","names=['add','balanced256','arithmetic64','blocks32','capture8','try_finally']");measure=measure.replace("['balanced256','arithmetic64','try_finally','add']","['add','balanced256','try_finally']");measure=measure.replace('for repeat in range(9):',"for repeat in range(9 if name=='add' else 3):");measure=measure.replace("version,'binary-region',name","version,'binary-region-private',name");(p/'Run-Measure.py').write_text(measure,encoding='utf-8')
m=json.loads((p/'manifest.json').read_text());m.update(candidateCoreSHA256=hashlib.sha256(fixed.encode()).hexdigest(),publicWrapperVerbatim=True,scalarHelperVerbatim=True,entryPlacement='private6 physical root before Lambda push',scalarColdRepetitions=9,complexColdRepetitions=3);(p/'manifest.json').write_text(json.dumps(m,indent=2))
print('Private-entry-only prototype exported; public/scalar bodies identical.')

controls=p/'Controls.cs';cs=controls.read_text(encoding='utf-8');anchor='  var token=new MutableValue{Value=3};';assert cs.count(anchor)==1;controls.write_text(cs.replace(anchor,(p/'NestedControls.cs.txt').read_text(encoding='utf-8')+anchor),encoding='utf-8')
