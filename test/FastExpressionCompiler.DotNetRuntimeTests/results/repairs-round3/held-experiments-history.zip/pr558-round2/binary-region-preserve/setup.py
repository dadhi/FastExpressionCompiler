from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent;w=p.parent
builder=(w/'binary-region/setup.py').read_text(encoding='utf-8').replace("default='4eac9c2a'", "default='db640cba'")
exec(compile(builder,str(w/'binary-region/setup.py'),'exec'),{'__file__':str(p/'setup.py'),'__name__':'__main__'})
base=(p/'standard/before/FastExpressionCompiler.cs').read_text(encoding='utf-8');region=(p/'standard/fixed/FastExpressionCompiler.cs').read_text(encoding='utf-8')
a=region.index('        // Pure binary regions');b=region.index('        private static Result TryCollectTerminalInfo(',a)
helpers=region[a:b].replace('private static bool TryCollectSimpleBinary(', 'private static bool TryCollectBinaryRegionRoot(',1)
start=base.index('                if (scopeDepth == 0 && nestedLambda == null && expr is BinaryExpression binary &&')
end=base.index('                return TryCollectInfo(ref context, expr, nestedLambda, ref rootNestedLambdas, false, false);',start)
entry='''                if (scopeDepth == 0 && nestedLambda == null && expr is BinaryExpression binary
#if LIGHT_EXPRESSION
                    && !binary.IsIntrinsic
#endif
                    )
                {
                    if ((binary.Left is ParameterExpression || binary.Left is ConstantExpression) &&
                        (binary.Right is ParameterExpression || binary.Right is ConstantExpression))
                    {
                        // Keep the existing scalar path and helper verbatim.
                        // Unsupported scalar opcodes fall straight to the original collector.
                        if (
#if LIGHT_EXPRESSION
                            !binary.Left.IsIntrinsic && !binary.Right.IsIntrinsic &&
#endif
                            TryCollectSimpleBinary(ref context, binary, ref rootNestedLambdas, out var scalarResult))
                            return scalarResult;
                    }
                    else if (TryCollectBinaryRegionRoot(ref context, binary, ref rootNestedLambdas, out var regionResult))
                        return regionResult;
                }
'''
fixed=base[:start]+entry+base[end:]
outerEnd=fixed.rfind('    }',0,fixed.index('    public static class Tools'))
fixed=fixed[:outerEnd]+helpers+fixed[outerEnd:]
for flavor in ['standard','light']:(p/flavor/'fixed/FastExpressionCompiler.cs').write_text(fixed,encoding='utf-8')
# Existing scalar helper is byte-for-byte equal after newline normalization.
marker='        private static bool TryCollectSimpleBinary(';terminal='        private static Result TryCollectTerminalInfo('
assert base[base.index(marker):base.index(terminal)]==fixed[fixed.index(marker):fixed.index(terminal)]
for name in ['Controls.cs','Build-Controls.ps1','prepare-cold.py']:(p/name).write_bytes((w/'binary-region'/name).read_bytes())
exec(compile((p/'prepare-cold.py').read_text(encoding='utf-8'),str(p/'prepare-cold.py'),'exec'))
measure=(w/'binary-region/Run-Measure.py').read_text(encoding='utf-8')
measure=measure.replace("names=['add','balanced256','arithmetic64','blocks32','nested_mixed128','try_finally','capture8']", "names=['add','balanced256','arithmetic64','capture8']")
measure=measure.replace("['balanced256','arithmetic64','try_finally','add']", "['add','try_finally','balanced256']")
measure=measure.replace('for repeat in range(9):', "for repeat in range(3 if name=='balanced256' else 9):")
(p/'Run-Measure.py').write_text(measure,encoding='utf-8')
m=json.loads((p/'manifest.json').read_text());m.update(candidateCoreSHA256=hashlib.sha256(fixed.encode()).hexdigest(),preservedScalarHelper=True,helperPlacement='Appended before the original outer ExpressionCompiler class closes');(p/'manifest.json').write_text(json.dumps(m,indent=2))
print('Preserved-terminal variant prepared at '+str(p))
