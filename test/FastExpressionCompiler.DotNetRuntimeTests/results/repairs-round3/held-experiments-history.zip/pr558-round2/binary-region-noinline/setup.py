from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parent;w=p.parent
exec(compile((w/'binary-region-preserve/setup.py').read_text(encoding='utf-8'),str(w/'binary-region-preserve/setup.py'),'exec'),{'__file__':str(p/'setup.py'),'__name__':'__main__'})
marker='        private static bool TryCollectBinaryRegionRoot('
for flavor in ['standard','light']:
 file=p/flavor/'fixed/FastExpressionCompiler.cs';s=file.read_text(encoding='utf-8');assert s.count(marker)==1;s=s.replace(marker,'        [MethodImpl(MethodImplOptions.NoInlining)]\n'+marker,1);file.write_text(s,encoding='utf-8')
m=json.loads((p/'manifest.json').read_text());m['candidateCoreSHA256']=hashlib.sha256((p/'standard/fixed/FastExpressionCompiler.cs').read_bytes()).hexdigest();m['complexEntryNoInlining']=True;(p/'manifest.json').write_text(json.dumps(m,indent=2))
