# B-dispatcher-region: HOLD

Warm balanced compilation improves 11.2-15.4%, arithmetic 3.3-5.5%. Standard10 controls worsen: blocks32 +4.5%, capture8 +6.25%; Light10 capture8 +3.25%. Cold controls retain Standard10 add +8.55%, Standard8 try_finally +17.5%, and Standard8 balanced +10.6%; Standard8 capture8 nested-invoke is +10.5% warm. These measured costs prevent acceptance under the agreed conservative control rule. No further placement variants or repeats were run. No main edits or candidate commits.

Eight correctness configurations passed, including undefined parameter/filter contracts, terminal boxed/reference identity, Default values, nested terminal capture, intrinsic callbacks/scopes, late unsupported fallback, exact constant use counts and nested valid/invalid label controls. The preexisting pending-operand outward-goto InvalidProgramException remains separately documented in ../pending-operand-triage; no imported denominator was changed.

Coverage: 132 warm summary rows, 101 alternating pairs per executed scenario/phase; 240 fresh-process cold rows. Standard paired driver filters out parameter/default scenarios; they execute in Standard cold/correctness and all Light phases. Cold add/try_finally use nine pairs; constant/parameter/default/balanced use three. Both original phase samples and all distributions are retained without filtering, subtraction or timing corrections.

Allocation facts: 0 compiler/compile-first/runtime warm allocation differences; 6 total warm differences including unchanged construction harness; 3 cold raw allocation-mode differences. Inspect analysis.json and cold-distributions.json for exact values rather than assuming every raw allocation matches.

Public wrapper and scalar helper source, IL size and native size match baseline all four flavor/runtime combinations. Scalar add traces show no Core/region JIT events. Original Core source is identical after renaming its six-argument calls. Those diagnostics do not establish equal wall time: placement, process variation and cold costs remain visible in the measured distributions.

Evidence: manifest.json, analysis.json, warm-analysis.json, warm-*.jsonl, cold.jsonl, cold-distributions.json, scalar-jit-proof.json, jit-*.nettrace/jsonl, controls-*.log and complete.json. Measurements complete; exclusive window released.
