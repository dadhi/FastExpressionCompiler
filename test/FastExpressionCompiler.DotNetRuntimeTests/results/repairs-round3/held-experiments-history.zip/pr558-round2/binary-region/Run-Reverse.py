from pathlib import Path
from collections import defaultdict
import subprocess,os,json,statistics
p=Path(__file__).resolve().parent;env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0');summary=[]
for flavor,project in [('standard','StandardReverse'),('light','LightReverse')]:
 file=p/('reverse-'+flavor+'-net10.0.jsonl');print('START '+flavor,flush=True)
 with file.open('w',encoding='utf-8') as out,file.with_suffix('.log').open('w',encoding='utf-8') as log:
  subprocess.run(['dotnet',str(p/'bin'/project/'net10.0'/(project+'.dll')),'1','capture8','blocks32','balanced256'],env=env,stdout=out,stderr=log,check=True)
 pairs=defaultdict(dict)
 for line in file.read_text().splitlines():
  row=json.loads(line);pairs[(row['Scenario'],row['Phase'],row['SampleIndex'])][row['Version']]=row
 groups=defaultdict(list)
 for (case,phase,index),values in pairs.items():assert set(values)=={'before','fixed'};groups[(case,phase)].append(values)
 for (case,phase),values in groups.items():
  assert len(values)==101
  row=dict(runtime='net10.0',flavor=flavor,case=case,phase=phase,pairs=101,ratio=statistics.median(x['fixed']['NsPerOp']/x['before']['NsPerOp'] for x in values),beforeBytes=statistics.median(x['before']['BytesPerOp'] for x in values),fixedBytes=statistics.median(x['fixed']['BytesPerOp'] for x in values))
  summary.append(row)
  if phase in ['compile','compile_first','invoke']:print(row,flush=True)
 (p/'reverse-analysis.json').write_text(json.dumps(summary,indent=2))
