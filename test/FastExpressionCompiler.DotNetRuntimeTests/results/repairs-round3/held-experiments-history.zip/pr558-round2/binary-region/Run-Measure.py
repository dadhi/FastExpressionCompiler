from pathlib import Path
from collections import defaultdict
import os,subprocess,json,statistics
p=Path(__file__).resolve().parent
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
names=['add','balanced256','arithmetic64','blocks32','nested_mixed128','try_finally','capture8']
warm=[]
for runtime in ['net8.0','net10.0']:
 for flavor,project in [('standard','Standard'),('light','Light')]:
  tag=f'warm-{flavor}-{runtime}';print('START '+tag,flush=True)
  with (p/(tag+'.jsonl')).open('w',encoding='utf-8') as out,(p/(tag+'.log')).open('w',encoding='utf-8') as log:
   subprocess.run(['dotnet',str(p/'bin'/project/runtime/(project+'.dll')),'0',*names],env=env,stdout=out,stderr=log,check=True)
  pairs=defaultdict(dict)
  for line in (p/(tag+'.jsonl')).read_text().splitlines():
   row=json.loads(line);pairs[(row['Scenario'],row['Phase'],row['SampleIndex'])][row['Version']]=row
  groups=defaultdict(list)
  for (case,phase,index),versions in pairs.items():
   assert set(versions)=={'before','fixed'};groups[(case,phase)].append(versions)
  for (case,phase),values in groups.items():
   assert len(values)==101
   row=dict(runtime=runtime,flavor=flavor,case=case,phase=phase,pairs=101,ratio=statistics.median(x['fixed']['NsPerOp']/x['before']['NsPerOp'] for x in values),beforeBytes=statistics.median(x['before']['BytesPerOp'] for x in values),fixedBytes=statistics.median(x['fixed']['BytesPerOp'] for x in values))
   warm.append(row)
   if phase in ['compile','compile_first']:print(row,flush=True)
  (p/'warm-analysis.json').write_text(json.dumps(warm,indent=2))
cold=[]
with (p/'cold.jsonl').open('w',encoding='utf-8') as out:
 for runtime in ['net8.0','net10.0']:
  for flavor in ['standard','light']:
   for name in ['balanced256','arithmetic64','try_finally','add']:
    for repeat in range(9):
     for version in (['before','fixed'] if repeat%2==0 else ['fixed','before']):
      project='Cold-'+flavor+'-'+version
      result=subprocess.run(['dotnet',str(p/'bin'/project/runtime/(project+'.dll')),version,'binary-region',name,str(repeat)],env=env,capture_output=True,text=True,check=True)
      row=json.loads(result.stdout);row['CandidateFlavor']=flavor;cold.append(row);out.write(json.dumps(row)+'\n');out.flush()
    values={v:[x for x in cold if x['CandidateFlavor']==flavor and x['Scenario']==name and x['Runtime'].startswith(runtime[3:].split('.')[0]+'.') and x['Version']==v] for v in ['before','fixed']}
    row={'runtime':runtime,'flavor':flavor,'case':name}
    for key in ['CompileAndFirstNs','CompileAndFirstBytes']:
     b=statistics.median(x[key] for x in values['before']);f=statistics.median(x[key] for x in values['fixed']);row[key]=[b,f,f/b]
    print(row,flush=True)
(p/'complete.json').write_text(json.dumps({'warmSummaryRows':len(warm),'coldRows':len(cold),'completed':True},indent=2))
