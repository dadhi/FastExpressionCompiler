SOURCE ONLY: recursive binary region prototype
Baseline4eac9c2a; no main source changes. setup.py exports exact four-core + Light files.
65-line helper block; root-only eligibility rejects unsupported opcodes/conversions before any operand.
Recurses Left, loops Right to preserve original tail-depth behavior. Each operand collected once.
First complex/intrinsic child lazily establishes Lambda+Expression and invokes ORIGINAL private collector.
After partial collection there is no false/restart path, so constants are not double-counted.
Public root/finally unchanged; callback scopes and left-first errors explicitly covered in Controls.cs.

Prepared Std/Light paired harnesses for net8/net10; no build/execution authorized yet.
After release, build Standard.csproj, Light.csproj, and Controls-{standard|light}-{before|fixed}.csproj.
Paired examples (only during an authorized quiet window):
 dotnet bin/Standard/net10.0/Standard.dll 0 balanced256 arithmetic64 nested_mixed32 nested_mixed128
 dotnet bin/Light/net10.0/Light.dll 0 balanced256 arithmetic64 nested_mixed32 nested_mixed128
Use the Controls executables before timing for labels, late complex fallback, usage counts, identity, intrinsic callbacks, errors, cleanup.
