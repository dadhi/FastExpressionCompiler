from pathlib import Path
import subprocess,hashlib,json,argparse
p=argparse.ArgumentParser();p.add_argument('--revision',default='4eac9c2a');a=p.parse_args()
d=Path(__file__).resolve().parent;r=Path(r'C:\Data\Git\Github\FastExpressionCompiler');w=d.parent
sha=subprocess.check_output(['git','rev-parse',a.revision],cwd=r,encoding='utf-8').strip()
core=subprocess.check_output(['git','show',sha+':src/FastExpressionCompiler/FastExpressionCompiler.cs'],cwd=r).decode('utf-8')
old='''                if (scopeDepth == 0 && nestedLambda == null && expr is BinaryExpression binary &&
                    (binary.Left is ParameterExpression || binary.Left is ConstantExpression) &&
                    (binary.Right is ParameterExpression || binary.Right is ConstantExpression) &&
#if LIGHT_EXPRESSION
                    !binary.IsIntrinsic && !binary.Left.IsIntrinsic && !binary.Right.IsIntrinsic &&
#endif
                    TryCollectSimpleBinary(ref context, binary, ref rootNestedLambdas, out var simpleResult))'''
normalized=core.replace('\r\n','\n');assert normalized.count(old)==1
new='''                if (scopeDepth == 0 && nestedLambda == null && expr is BinaryExpression binary &&
#if LIGHT_EXPRESSION
                    !binary.IsIntrinsic &&
#endif
                    TryCollectSimpleBinary(ref context, binary, ref rootNestedLambdas, out var simpleResult))'''
fixed=normalized.replace(old,new,1)
start=fixed.index('        // Root binary operations with terminal operands')
end=fixed.index('        private static Result TryCollectTerminalInfo(',start)
helpers='''        // Pure binary regions share the original single Expression parent scope.
        // Create that scope only before a child requiring the ordinary collector.
        private static bool TryCollectSimpleBinary(ref CompilerContext context, BinaryExpression binary,
            ref SmallList<NestedLambdaInfo> rootNestedLambdas, out Result result)
        {
            result = Result.OK;
            if (binary.Conversion != null || !IsSimpleBinaryOperation(binary.NodeType)) return false;
            result = TryCollectBinaryRegion(ref context, binary, ref rootNestedLambdas);
            return true;
        }

        private static bool IsSimpleBinaryOperation(ExpressionType nodeType)
        {
            switch (nodeType)
            {
                case ExpressionType.Add: case ExpressionType.AddChecked:
                case ExpressionType.Subtract: case ExpressionType.SubtractChecked:
                case ExpressionType.Multiply: case ExpressionType.MultiplyChecked:
                case ExpressionType.Divide: case ExpressionType.Modulo: case ExpressionType.Power:
                case ExpressionType.And: case ExpressionType.Or: case ExpressionType.ExclusiveOr:
                case ExpressionType.LeftShift: case ExpressionType.RightShift:
                case ExpressionType.Equal: case ExpressionType.NotEqual:
                case ExpressionType.LessThan: case ExpressionType.LessThanOrEqual:
                case ExpressionType.GreaterThan: case ExpressionType.GreaterThanOrEqual:
                case ExpressionType.ArrayIndex:
                    return true;
                default:
                    return false;
            }
        }

        private static Result TryCollectBinaryRegion(ref CompilerContext context, Expression expression,
            ref SmallList<NestedLambdaInfo> rootNestedLambdas)
        {
            // Preserve the original binary collector's right-tail traversal.
            while (true)
            {
#if LIGHT_EXPRESSION
                if (expression != null && expression.IsIntrinsic)
                    return TryCollectBinaryRegionFallback(ref context, expression, ref rootNestedLambdas);
#endif
                if (expression is ParameterExpression || expression is ConstantExpression)
                    return TryCollectTerminalInfo(ref context, expression, expression.NodeType, null, ref rootNestedLambdas);
                if (expression is BinaryExpression binary && binary.Conversion == null && IsSimpleBinaryOperation(binary.NodeType))
                {
                    var result = TryCollectBinaryRegion(ref context, binary.Left, ref rootNestedLambdas);
                    if (result != Result.OK) return result;
                    expression = binary.Right;
                    continue;
                }
                return TryCollectBinaryRegionFallback(ref context, expression, ref rootNestedLambdas);
            }
        }

        private static Result TryCollectBinaryRegionFallback(ref CompilerContext context, Expression expression,
            ref SmallList<NestedLambdaInfo> rootNestedLambdas)
        {
            if (context.LabelScopeDepth == 0)
            {
                context.PushLabelScope(LabelScopeKind.Lambda);
                context.PushLabelScope(LabelScopeKind.Expression);
            }
            return TryCollectInfo(ref context, expression, null, ref rootNestedLambdas, false, false);
        }

'''
fixed=fixed[:start]+helpers+fixed[end:]
for flavor in ['standard','light']:
 for version in ['before','fixed']:
  target=d/flavor/version;target.mkdir(parents=True,exist_ok=True)
  for name in ['FastExpressionCompiler.cs','ImTools.cs','ILReader.cs','TestTools.cs']:
   raw=subprocess.check_output(['git','show',sha+':src/FastExpressionCompiler/'+name],cwd=r)
   if version=='fixed' and name=='FastExpressionCompiler.cs':raw=fixed.encode('utf-8')
   (target/name).write_bytes(raw)
  if flavor=='light':
   for name in ['Expression.cs','ExpressionVisitor.cs','FlatExpression.cs']:
    (target/name).write_bytes(subprocess.check_output(['git','show',sha+':src/FastExpressionCompiler.LightExpression/'+name],cwd=r))
  defines='<DefineConstants>$(DefineConstants);LIGHT_EXPRESSION</DefineConstants>' if flavor=='light' else ''
  (target/'Library.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize>'+defines+'<AssemblyName>FecBinaryRegion.'+flavor+'.'+version+'</AssemblyName></PropertyGroup></Project>')
# Reuse established paired harnesses, preserving paired phase/allocation counters.
(d/'Standard.cs').write_bytes((w.parent/'pr558-repair/paired/Program.cs').read_bytes())
for file in ['BenchBefore.cs','BenchAfter.cs','Paired.cs']:(d/file).write_bytes((w/'trivial-binary-light'/file).read_bytes())
for project,sources,flavor in [('Standard',['Standard.cs'],'standard'),('Light',['BenchBefore.cs','BenchAfter.cs','Paired.cs'],'light')]:
 includes=''.join('<Compile Include="'+src+'"/>' for src in sources)
 refs=''.join('<ProjectReference Include="'+flavor+'/'+v+'/Library.csproj" Aliases="'+alias+'"/>' for v,alias in [('before','Before'),('fixed','After')])
 (d/(project+'.csproj')).write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFrameworks>net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><EnableDefaultCompileItems>false</EnableDefaultCompileItems><BaseIntermediateOutputPath>obj/'+project+'/</BaseIntermediateOutputPath><OutputPath>bin/'+project+'/</OutputPath></PropertyGroup><ItemGroup>'+includes+refs+'</ItemGroup></Project>')
lightProject=d/'Light.csproj';ls=lightProject.read_text(encoding='utf-8');lightProject.write_text(ls.replace('<Optimize>true</Optimize>','<Optimize>true</Optimize><DefineConstants>$(DefineConstants);LIGHT</DefineConstants>'))
for flavor in ['standard','light']:
 for version in ['before','fixed']:
  project='Controls-'+flavor+'-'+version;defines='<DefineConstants>$(DefineConstants);LIGHT</DefineConstants>' if flavor=='light' else ''
  (d/(project+'.csproj')).write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFrameworks>net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize>'+defines+'<EnableDefaultCompileItems>false</EnableDefaultCompileItems><BaseIntermediateOutputPath>obj/'+project+'/</BaseIntermediateOutputPath><OutputPath>bin/'+project+'/</OutputPath></PropertyGroup><ItemGroup><Compile Include="Controls.cs"/><ProjectReference Include="'+flavor+'/'+version+'/Library.csproj"/></ItemGroup></Project>')
(d/'manifest.json').write_text(json.dumps({'baseline':sha,'candidateCoreSHA256':hashlib.sha256(fixed.encode()).hexdigest(),'helperLines':len(helpers.splitlines()),'built':False,'executed':False},indent=2))
print('Prepared binary-region source-only candidate; helper lines='+str(len(helpers.splitlines())))
