using System;
#if LIGHT_EXPRESSION
using FastExpressionCompiler.LightExpression;
using FastExpressionCompiler.LightExpression.UnitTests;
#else
using FastExpressionCompiler;
using FastExpressionCompiler.UnitTests;
#endif
class Program
{
    static void Main()
    {
        var tests = new TestRun();
        tests.Run(new NestedTerminalBinaryRegressionTests());
        tests.Run(new CapturedValueRefRegressionTests());
        Console.WriteLine("Focused fixtures: tests=" + tests.TotalTestCount + " failed=" + tests.FailedTestCount);
        Environment.ExitCode = tests.FailedTestCount == 0 ? 0 : 1;
    }
}
