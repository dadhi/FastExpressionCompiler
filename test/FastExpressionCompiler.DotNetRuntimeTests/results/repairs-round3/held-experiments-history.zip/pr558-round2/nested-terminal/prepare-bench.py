from pathlib import Path
w=Path(__file__).resolve().parent
source=(w/'BenchSide.template').read_text()
for alias,side,version in [('Before','Current','current'),('After','Candidate','candidate')]:
 (w/(side+'.cs')).write_text(source.replace('ALIAS',alias).replace('SIDE',side).replace('VERSION',version))
(w/'Bench.csproj').write_text('''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><OutputType>Exe</OutputType><LangVersion>latest</LangVersion><Optimize>true</Optimize><EnableDefaultCompileItems>false</EnableDefaultCompileItems><Light Condition="'$(Light)'==''">false</Light><AssemblyName>Bench.$(Light)</AssemblyName><DefineConstants Condition="'$(Light)'=='true'">$(DefineConstants);LIGHT</DefineConstants></PropertyGroup><ItemGroup><Compile Include="Runner.cs"/><Compile Include="Current.cs"/><Compile Include="Candidate.cs"/><ProjectReference Include="current/Library.csproj" Aliases="Before" Condition="'$(Light)'!='true'"/><ProjectReference Include="candidate/Library.csproj" Aliases="After" Condition="'$(Light)'!='true'"/><ProjectReference Include="current-light/Library.csproj" Aliases="Before" Condition="'$(Light)'=='true'"/><ProjectReference Include="candidate-light/Library.csproj" Aliases="After" Condition="'$(Light)'=='true'"/></ItemGroup></Project>''')
print('Prepared harness only')
