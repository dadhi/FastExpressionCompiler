using System;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
class Runner {
 static readonly Func<long> Allocated=(Func<long>)Delegate.CreateDelegate(typeof(Func<long>),typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread"));
 public static void Row(string name,string phase,string version,int round,int sample,int operations,double ns,double bytes){
  Console.WriteLine(name+","+phase+","+version+","+round+","+sample+","+operations+","+ns.ToString("R",CultureInfo.InvariantCulture)+","+bytes.ToString("R",CultureInfo.InvariantCulture));
 }
 static void Measure(string name,string phase,string version,int round,int sample,Action<int> op,int n){long b=Allocated(),t=Stopwatch.GetTimestamp();op(n);long e=Stopwatch.GetTimestamp()-t;long bytes=Allocated()-b;Row(name,phase,version,round,sample,n,e*1e9/Stopwatch.Frequency/n,bytes/(double)n);}
 static int Count(string phase)=>phase=="compile"?64:phase=="compile_first"?16:phase=="activate"?1000:100000;
 static void Main(string[] args){
  if(args[0]=="cold"){if(args[1]=="current")Current.Bench.Cold(args[2]);else Candidate.Bench.Cold(args[2]);return;}
  int round=int.Parse(args[1]);bool pair=args[0]=="pair";
  foreach(var name in args.Skip(pair?2:3)){
   var before=pair||args[2]=="current"?Current.Bench.Operations(name):null;
   var after=pair||args[2]=="candidate"?Candidate.Bench.Operations(name):null;
   var phases=before!=null?before.Keys:after.Keys;
   foreach(var phase in phases){
    int n=Count(phase);if(before!=null)before[phase](40);if(after!=null)after[phase](40);
    for(int k=0;k<51;k++){
     if(k%8==0){GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();}
     if(pair){for(int order=0;order<2;order++){bool first=(k+round+order)%2==0;Measure(name,phase,first?"current":"candidate",round,k,first?before[phase]:after[phase],n);}}
     else Measure(name,phase,args[2],round,k,before!=null?before[phase]:after[phase],n);
    }
   } Console.Error.WriteLine("PASS "+name);
  }
 }
}
