from pathlib import Path
import subprocess,os,json,statistics,csv,hashlib
w=Path(__file__).resolve().parent
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
rows=[]
shapes=['add','capture1','capture_repeat','capture_mutable','balanced256','try_finally','capture_try']
def launch(light,runtime,args,tag):
 p=w/('runner-'+light)/runtime/('Bench.'+light+('.exe' if runtime=='net472' else '.dll'))
 cmd=[str(p)] if runtime=='net472' else ['dotnet',str(p)]
 saved=w/(tag+'.csv'); log=w/(tag+'.log')
 if saved.exists() and saved.stat().st_size and log.exists() and 'Exception' not in log.read_text():
  output=saved.read_text()
 else:
  r=subprocess.run(cmd+args,capture_output=True,text=True,env=env)
  saved.write_text(r.stdout);log.write_text(r.stderr)
  if r.returncode: raise RuntimeError(tag+' failed: '+r.stderr+r.stdout)
  output=r.stdout
 for line in csv.reader(output.splitlines()):
  if len(line)!=8: raise RuntimeError('Unexpected row '+str(line))
  name,phase,version,round_,sample,n,ns,b=line
  rows.append(dict(flavor='Light' if light=='true' else 'Standard',runtime=runtime,scenario=name,phase=phase,version=version,round=int(round_),sample=int(sample),operations=int(n),ns=float(ns),bytes=float(b),input=tag+'.csv'))
for light in ['false','true']:
 for runtime in ['net8.0','net10.0','net472']:
  for round_ in range(2):
   if runtime=='net472':
    for version in (['current','candidate'] if round_==0 else ['candidate','current']):
     launch(light,runtime,['warm',str(round_),version]+shapes,f'warm-{light}-{runtime}-{round_}-{version}')
   else:launch(light,runtime,['pair',str(round_)]+shapes,f'paired-{light}-{runtime}-{round_}')
  for rep in range(3):
   for shape in ['add','capture1','capture_repeat','try_finally']:
    for version in (['current','candidate'] if rep%2==0 else ['candidate','current']):
     start=len(rows);launch(light,runtime,['cold',version,shape],f'cold-{light}-{runtime}-{rep}-{version}-{shape}')
     for row in rows[start:]:row['repetition']=rep
  print('Finished',light,runtime,flush=True)
summaries=[]
keys=sorted({(r['flavor'],r['runtime'],r['scenario'],r['phase']) for r in rows})
for flavor,runtime,scenario,phase in keys:
 selected=[r for r in rows if (r['flavor'],r['runtime'],r['scenario'],r['phase'])==(flavor,runtime,scenario,phase)]
 parts={v:[r for r in selected if r['version']==v] for v in ['current','candidate']}
 summary=dict(flavor=flavor,runtime=runtime,scenario=scenario,phase=phase)
 for v,rs in parts.items():summary[v]=dict(ns=statistics.median(r['ns'] for r in rs),bytes=statistics.median(r['bytes'] for r in rs),bytes_min=min(r['bytes'] for r in rs),bytes_max=max(r['bytes'] for r in rs),samples=len(rs))
 summary['allocation_delta']=summary['candidate']['bytes']-summary['current']['bytes']
 summary['median_time_ratio']=summary['candidate']['ns']/summary['current']['ns']
 if runtime!='net472' and not phase.startswith('cold'):
  pairs={(r['round'],r['sample'],r['version']):r for r in selected}
  summary['median_paired_ratio']=statistics.median(pairs[round_,sample,'candidate']['ns']/pairs[round_,sample,'current']['ns'] for round_,sample in {(r['round'],r['sample']) for r in selected})
 summaries.append(summary)
result=dict(manifest=json.loads((w/'manifest.json').read_text()),rows=rows,summary=summaries,caveats=['Modern warm samples alternate both versions in one process; median_paired_ratio is matched by round/sample.','Framework uses separate one-variant fresh processes in opposite version orders to avoid known cross-variant permission-allocation contamination.','Cold uses three fresh processes per version/runtime/flavor/scenario; expression build/conversion excluded, oracle verification occurs after measured phases.','Time variation in unchanged scalar/fallback controls is retained; no universal parity claim.'],artifacts={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in w.iterdir() if p.is_file() and p.suffix in ['.csv','.log']})
(w/'measurements.json').write_text(json.dumps(result,indent=2))
for r in summaries:
 if r['phase'] in ['compile','compile_first','cold_compile_first']:print(r)
