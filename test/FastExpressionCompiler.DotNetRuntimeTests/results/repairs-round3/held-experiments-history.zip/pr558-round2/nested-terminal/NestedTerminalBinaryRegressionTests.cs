using System;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using SysExpr = System.Linq.Expressions.Expression;
#if !LIGHT_EXPRESSION
using System.Linq.Expressions;
#endif
#if LIGHT_EXPRESSION
namespace FastExpressionCompiler.LightExpression.UnitTests;
#else
namespace FastExpressionCompiler.UnitTests;
#endif

public struct NestedTerminalBinaryRegressionTests : ITestX
{
    public void Run(TestRun t)
    {
        Shared_mutation_and_repeated_operands(t);
        Reference_constants_and_array_operands(t);
        Undefined_capture_order_is_preserved(t);
        Quotes_and_runtime_variables_keep_cells_live(t);
#if LIGHT_EXPRESSION
        Intrinsic_terminal_callbacks_keep_nested_scope(t);
#endif
    }

    public void Shared_mutation_and_repeated_operands(TestContext t)
    {
        foreach (var flags in new[] { CompilerFlags.Default, CompilerFlags.NoInvocationLambdaInlining, CompilerFlags.EnableDelegateDebugInfo })
        foreach (var reverse in new[] { false, true })
        {
            var x = SysExpr.Parameter(typeof(int), "outer");
            var plus = SysExpr.Lambda<Func<int>>(SysExpr.Add(x, SysExpr.Constant(1)));
            var twice = SysExpr.Lambda<Func<int>>(SysExpr.Add(x, x));
            var update = SysExpr.Lambda<Func<int>>(SysExpr.PreIncrementAssign(x));
            var ctor = typeof(Tuple<Func<int>, Func<int>, Func<int>>).GetConstructors()[0];
            var source = SysExpr.Lambda<Func<int, Tuple<Func<int>, Func<int>, Func<int>>>>(
                SysExpr.New(ctor, reverse ? twice : plus, reverse ? plus : twice, update), x);
            var factory = source.FromSysExpression().CompileFast(true, flags);
            var actual = factory(3);
            var reader = reverse ? actual.Item2 : actual.Item1;
            var duplicate = reverse ? actual.Item1 : actual.Item2;
            t.AreEqual(4, reader()); t.AreEqual(6, duplicate());
            t.AreEqual(4, actual.Item3()); t.AreEqual(5, reader()); t.AreEqual(8, duplicate());
            var separate = factory(9); t.AreEqual(10, separate.Item3());
            t.AreEqual(5, reader()); t.AreEqual(8, duplicate());
        }
    }

    public void Reference_constants_and_array_operands(TestContext t)
    {
        var shared = new object();
        var x = SysExpr.Parameter(typeof(object));
        var constant = SysExpr.Constant(shared);
        var ctor = typeof(Tuple<Func<bool>, Func<bool>>).GetConstructors()[0];
        var source = SysExpr.Lambda<Func<object, Tuple<Func<bool>, Func<bool>>>>(SysExpr.New(ctor,
            SysExpr.Lambda<Func<bool>>(SysExpr.ReferenceEqual(x, constant)),
            SysExpr.Lambda<Func<bool>>(SysExpr.ReferenceEqual(constant, constant))), x);
        var factory = source.FromSysExpression().CompileFast(true);
        var same = factory(shared); var other = factory(new object());
        t.IsTrue(same.Item1()); t.IsTrue(same.Item2());
        t.IsTrue(!other.Item1()); t.IsTrue(other.Item2());
        var array = SysExpr.Parameter(typeof(int[]));
        var read = SysExpr.Lambda<Func<int[], Func<int>>>(SysExpr.Lambda<Func<int>>(
            SysExpr.ArrayIndex(array, SysExpr.Constant(1))), array).FromSysExpression().CompileFast(true);
        var values = new[] { 2, 3 }; var child = read(values);
        t.AreEqual(3, child()); values[1] = 7; t.AreEqual(7, child());
    }

    public void Undefined_capture_order_is_preserved(TestContext t)
    {
        var left = SysExpr.Parameter(typeof(int), "missing-left");
        var right = SysExpr.Parameter(typeof(int), "missing-right");
        var source = SysExpr.Lambda<Func<Func<int>>>(SysExpr.Lambda<Func<int>>(SysExpr.Add(left, right))).FromSysExpression();
#if LIGHT_EXPRESSION
        var context = new ExpressionCompiler.CompilerContext(ExpressionCompiler.ClosureStatus.ToBeCollected, source, CompilerFlags.Default);
#else
        var context = new ExpressionCompiler.CompilerContext(ExpressionCompiler.ClosureStatus.ToBeCollected, source.Parameters, CompilerFlags.Default);
#endif
        var result = ExpressionCompiler.TryCollectInfo(ref context, source.Body, null, ref context.NestedLambdas);
        t.AreEqual(ExpressionCompiler.Result.ParameterIsNotVariableNorInPassedParameters, result);
        var info = context.NestedLambdas.GetSurePresentRef(0);
        var body = (BinaryExpression)info.LambdaExpression.Body;
        t.AreEqual(2, info.NonPassedParameters.Count);
        t.IsTrue(ReferenceEquals(body.Left, info.NonPassedParameters.GetSurePresentRef(0)));
        t.IsTrue(ReferenceEquals(body.Right, info.NonPassedParameters.GetSurePresentRef(1)));
        t.IsTrue(source.CompileFast(true) == null);
    }

    public void Quotes_and_runtime_variables_keep_cells_live(TestContext t)
    {
        foreach (var flags in new[] { CompilerFlags.Default, CompilerFlags.NoInvocationLambdaInlining, CompilerFlags.EnableDelegateDebugInfo })
        {
            var x = SysExpr.Parameter(typeof(int));
            var ctor = typeof(Tuple<Func<int>, System.Linq.Expressions.Expression<Func<int>>, IRuntimeVariables>).GetConstructors()[0];
            var source = SysExpr.Lambda<Func<int, Tuple<Func<int>, System.Linq.Expressions.Expression<Func<int>>, IRuntimeVariables>>>(
                SysExpr.New(ctor, SysExpr.Lambda<Func<int>>(SysExpr.Add(x, SysExpr.Constant(1))),
                    SysExpr.Quote(SysExpr.Lambda<Func<int>>(SysExpr.Add(x, x))), SysExpr.RuntimeVariables(x)), x);
            var actual = source.FromSysExpression().CompileFast(true, flags)(3);
            t.AreEqual(4, actual.Item1()); t.AreEqual(6, actual.Item2.Compile()());
            actual.Item3[0] = 9;
            t.AreEqual(10, actual.Item1()); t.AreEqual(18, actual.Item2.Compile()());
        }
    }

#if LIGHT_EXPRESSION
    private sealed class IntrinsicRead : ConstantExpression
    {
        private readonly Expression _read;
        internal bool SawNested, SawScope;
        internal IntrinsicRead(Expression read) => _read = read;
        public override Type Type => _read.Type;
        public override object Value => this;
        public override bool IsIntrinsic => true;
        public override ExpressionCompiler.Result TryCollectInfo(ref ExpressionCompiler.CompilerContext context,
            ExpressionCompiler.NestedLambdaInfo nestedLambda, ref ImTools.SmallList<ExpressionCompiler.NestedLambdaInfo> rootNestedLambdas)
        {
            SawNested |= nestedLambda != null;
            var field = typeof(ExpressionCompiler.CompilerContext).GetField("LabelScopeDepth", BindingFlags.NonPublic | BindingFlags.Instance);
            var before = (int)field.GetValue(context);
            SawScope |= before != 0;
            var result = ExpressionCompiler.TryCollectInfo(ref context, _read, nestedLambda, ref rootNestedLambdas);
            if ((int)field.GetValue(context) != before) throw new InvalidOperationException("Callback changed caller scope depth.");
            return result;
        }
        public override bool TryEmit(ref ExpressionCompiler.CompilerContext context, ILGenerator il,
            ExpressionCompiler.ParentFlags parent, int byRefIndex = -1) =>
            ExpressionCompiler.EmittingVisitor.TryEmit(_read, il, ref context, parent, byRefIndex);
    }

    public void Intrinsic_terminal_callbacks_keep_nested_scope(TestContext t)
    {
        foreach (var right in new[] { false, true })
        {
            var x = Expression.Parameter(typeof(object));
            var y = Expression.Parameter(typeof(object));
            var intrinsic = new IntrinsicRead(x);
            var body = right ? Expression.ReferenceEqual(y, intrinsic) : Expression.ReferenceEqual(intrinsic, y);
            var source = Expression.Lambda<Func<object, Func<object, bool>>>(Expression.Lambda<Func<object, bool>>(body, y), x);
            var factory = source.CompileFast(true);
            var shared = new object(); var child = factory(shared);
            t.IsTrue(child(shared)); t.IsTrue(!child(new object()));
            t.IsTrue(intrinsic.SawNested); t.IsTrue(intrinsic.SawScope);
        }
    }
#endif
}
