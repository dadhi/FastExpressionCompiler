"""Export isolated sources/prototype only. Never compiles or executes them."""
from pathlib import Path
import subprocess,hashlib,json
w=Path(__file__).resolve().parent
repo=Path(r'C:/Data/Git/Github/FastExpressionCompiler')
ref='42f9847843cec8edaaf11c00cb97a5dd576b82cf'
manifest=dict(baseline=ref,files={})
for version in ['current','candidate']:
 for light in [False,True]:
  d=w/(version+('-light' if light else ''));d.mkdir(exist_ok=True)
  for name in ['FastExpressionCompiler.cs','ImTools.cs','ILReader.cs','TestTools.cs']:
   data=subprocess.check_output(['git','show',ref+':src/FastExpressionCompiler/'+name],cwd=repo)
   if version=='candidate' and name=='FastExpressionCompiler.cs':
    changes=[(b'scopeDepth == 0 && nestedLambda == null && expr is BinaryExpression binary',b'scopeDepth == 0 && expr is BinaryExpression binary'),
     (b'TryCollectSimpleBinary(ref context, binary, ref rootNestedLambdas, out var simpleResult)',b'TryCollectSimpleBinary(ref context, binary, nestedLambda, ref rootNestedLambdas, out var simpleResult)'),
     (b'private static bool TryCollectSimpleBinary(ref CompilerContext context, BinaryExpression binary,',b'private static bool TryCollectSimpleBinary(ref CompilerContext context, BinaryExpression binary, NestedLambdaInfo nestedLambda,'),
     (b'TryCollectTerminalInfo(ref context, left, left.NodeType, null, ref rootNestedLambdas)',b'TryCollectTerminalInfo(ref context, left, left.NodeType, nestedLambda, ref rootNestedLambdas)'),
     (b'TryCollectTerminalInfo(ref context, right, right.NodeType, null, ref rootNestedLambdas)',b'TryCollectTerminalInfo(ref context, right, right.NodeType, nestedLambda, ref rootNestedLambdas)')]
    for before,after in changes:
     if data.count(before)!=1: raise RuntimeError('Prototype anchor count '+str(data.count(before))+': '+str(before))
     data=data.replace(before,after)
   (d/name).write_bytes(data)
  if light:
   for name in ['Expression.cs','ExpressionVisitor.cs','FlatExpression.cs']:
    (d/name).write_bytes(subprocess.check_output(['git','show',ref+':src/FastExpressionCompiler.LightExpression/'+name],cwd=repo))
  (d/'Library.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><AssemblyName>NestedTerminal.'+version+('.Light' if light else '')+'</AssemblyName>'+('<DefineConstants>LIGHT_EXPRESSION</DefineConstants>' if light else '')+'</PropertyGroup></Project>')
  manifest['files'][d.name]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.glob('*.cs')}
(w/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('Prepared isolated source snapshots; no build/execution')
