using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.IO;
class Architecture {
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool IsWow64Process2(IntPtr process,out ushort processMachine,out ushort nativeMachine);
 [StructLayout(LayoutKind.Sequential)]struct MachineInfo { public ushort Machine,Reserved;public uint Attributes; }
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetProcessInformation(IntPtr process,int infoClass,out MachineInfo info,uint size);
 static string Name(ushort machine)=>machine==0xaa64?"Arm64":machine==0x8664?"X64":machine==0xa641?"Arm64EC":machine==0xa64e?"Arm64X":machine==0x14c?"X86":machine==0x1c4?"Arm":"0x"+machine.ToString("x");
 static void Main(string[] args){
  var process=Process.GetCurrentProcess(); ushort pm,nm;
  Console.WriteLine("DiagnosticProcessId="+process.Id);
  Console.WriteLine("Executable="+process.MainModule.FileName);
  Console.WriteLine("CLR="+Environment.Version);
  Console.WriteLine("Is64BitProcess="+Environment.Is64BitProcess);
  Console.WriteLine("Is64BitOperatingSystem="+Environment.Is64BitOperatingSystem);
  if(IsWow64Process2(process.Handle,out pm,out nm)){Console.WriteLine("OSArchitecture="+Name(nm));Console.WriteLine("IsWow64Process2.ProcessMachine="+Name(pm));Console.WriteLine("IsWow64Process2.NativeMachine="+Name(nm));}
  else Console.WriteLine("IsWow64Process2Error="+Marshal.GetLastWin32Error());
  MachineInfo mi;if(GetProcessInformation(process.Handle,9,out mi,(uint)Marshal.SizeOf(typeof(MachineInfo))))Console.WriteLine("ProcessMachineTypeInfo="+Name(mi.Machine)+"; Attributes="+mi.Attributes);else Console.WriteLine("ProcessMachineTypeInfoError="+Marshal.GetLastWin32Error());
  foreach(ProcessModule module in process.Modules){var name=module.ModuleName.ToLowerInvariant();if(name=="clr.dll"||name=="coreclr.dll"||name=="clrjit.dll"){using(var file=File.OpenRead(module.FileName))using(var reader=new BinaryReader(file)){file.Position=0x3c;int pe=reader.ReadInt32();file.Position=pe+4;Console.WriteLine("RuntimeModule="+module.FileName+"; PEMachine="+Name(reader.ReadUInt16()));}}}
  var runtimeInfo=typeof(object).Assembly.GetType("System.Runtime.InteropServices.RuntimeInformation")??Type.GetType("System.Runtime.InteropServices.RuntimeInformation, System.Runtime.InteropServices.RuntimeInformation",false);
  if(runtimeInfo!=null)foreach(var name in new[]{"OSArchitecture","ProcessArchitecture","FrameworkDescription","OSDescription"}){var p=runtimeInfo.GetProperty(name,BindingFlags.Static|BindingFlags.Public);if(p!=null)Console.WriteLine("RuntimeInformation."+name+"="+p.GetValue(null,null));}
  Console.WriteLine("PROCESSOR_ARCHITECTURE="+Environment.GetEnvironmentVariable("PROCESSOR_ARCHITECTURE"));
  Console.WriteLine("PROCESSOR_ARCHITEW6432="+Environment.GetEnvironmentVariable("PROCESSOR_ARCHITEW6432"));
  Console.WriteLine("DOTNET_ROOT="+Environment.GetEnvironmentVariable("DOTNET_ROOT"));
  foreach(var path in args){var asm=Assembly.LoadFrom(path);PortableExecutableKinds kinds;ImageFileMachine machine;asm.ManifestModule.GetPEKind(out kinds,out machine);Console.WriteLine("MeasuredRunner="+path+"; PEKind="+kinds+"; ImageFileMachine="+machine);}
 }
}
