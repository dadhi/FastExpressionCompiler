extern alias Before;
extern alias After;
extern alias LightBefore;
extern alias LightAfter;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Linq.Expressions;
using S=System.Linq.Expressions.Expression;
public delegate decimal DecimalInput(ref decimal value);
public struct Number {
 public decimal Value; public Number(decimal value){Value=value;}
 public static Number operator +(Number a,Number b){Arithmetic.Events.Add("op");return new Number(a.Value+b.Value);}
 public override string ToString()=>Value.ToString(System.Globalization.CultureInfo.InvariantCulture);
}
public static class Arithmetic {
 public static readonly List<string> Events=new List<string>();
 public static decimal DecimalLeft(){Events.Add("left");return 7;}
 public static decimal DecimalRight(){Events.Add("right");return 11;}
 public static Number NumberLeft(){Events.Add("left");return new Number(7);}
 public static Number NumberRight(){Events.Add("right");return new Number(11);}
 public static void Finally(){Events.Add("finally");}
 public static decimal? NullableValues(decimal? a,decimal? b){Events.Add("nullableop");return (a??10m)+(b??20m);}
 public static decimal RefDecimal(ref decimal a,ref decimal b){Events.Add("refop");a+=b;return a;}
 public static Number RefNumber(ref Number a,ref Number b){Events.Add("refop");a=new Number(a.Value+b.Value);return a;}
 static MethodInfo M(string n)=>typeof(Arithmetic).GetMethod(n);
 static string Outcome(Delegate f,object[] args){Events.Clear();try{return "value:"+f.DynamicInvoke(args)+"|"+string.Join(",",Events);}catch(Exception e){while(e is TargetInvocationException&&e.InnerException!=null)e=e.InnerException;return e.GetType().FullName+"|"+string.Join(",",Events);}}
 static void One(string name,LambdaExpression tree,params object[] args){
  string oracle=Outcome(tree.Compile(),(object[])args.Clone());
  var versions=new Dictionary<string,Delegate>{
   ["before"]=Before::FastExpressionCompiler.ExpressionCompiler.CompileFast(tree,true),
   ["fixed"]=After::FastExpressionCompiler.ExpressionCompiler.CompileFast(tree,true),
   ["light-before"]=LightBefore::FastExpressionCompiler.LightExpression.ExpressionCompiler.CompileFast(LightBefore::FastExpressionCompiler.LightExpression.FromSysExpressionConverter.ToLightExpression(tree),true),
   ["light-fixed"]=LightAfter::FastExpressionCompiler.LightExpression.ExpressionCompiler.CompileFast(LightAfter::FastExpressionCompiler.LightExpression.FromSysExpressionConverter.ToLightExpression(tree),true)};
  foreach(var v in versions){if(v.Value==null)throw new Exception(name+" unsupported "+v.Key);string actual=Outcome(v.Value,(object[])args.Clone());Console.WriteLine(name+" "+v.Key+" "+actual+" oracle "+oracle);if(actual!=oracle)throw new Exception("Arithmetic mismatch "+name+" "+v.Key);}
 }
 static Expression EH(Expression body)=>S.TryFinally(body,S.Call(M(nameof(Finally))));
 public static void Check(){
  var d=S.Parameter(typeof(decimal),"d");var n=S.Parameter(typeof(Number),"n");
  One("decimal-left-EH-right-param",S.Lambda<Func<decimal,decimal>>(S.Add(EH(S.Call(M(nameof(DecimalLeft)))),d),d),11m);
  One("decimal-prior-EH-right-constant",S.Lambda<Func<decimal,decimal>>(S.Block(EH(S.Empty()),S.Add(d,S.Constant(11m))),d),7m);
  Expression chain=d;for(int i=0;i<64;i++)chain=S.Add(chain,d);
  One("decimal64-EH",S.Lambda<Func<decimal,decimal>>(EH(chain),d),2m);
  One("decimal-right-EH",S.Lambda<Func<decimal,decimal>>(S.Add(S.Call(M(nameof(DecimalLeft))),EH(S.Call(M(nameof(DecimalRight))))),d),2m);
  One("decimal-complex-right",S.Lambda<Func<decimal,decimal>>(S.Block(EH(S.Empty()),S.Add(S.Call(M(nameof(DecimalLeft))),S.Call(M(nameof(DecimalRight))))),d),2m);
  One("decimal-overflow",S.Lambda<Func<decimal,decimal>>(S.Block(EH(S.Empty()),S.Add(d,S.Constant(1m))),d),decimal.MaxValue);
  One("operator-left-EH",S.Lambda<Func<Number,Number>>(S.Add(EH(S.Call(M(nameof(NumberLeft)))),n),n),new Number(11));
  One("operator-complex-right",S.Lambda<Func<Number,Number>>(S.Block(EH(S.Empty()),S.Add(S.Call(M(nameof(NumberLeft))),S.Call(M(nameof(NumberRight))))),n),new Number(11));
  var nullable=S.Parameter(typeof(decimal?),"nullable");
  One("nullable-null-right-EH",S.Lambda<Func<decimal?,decimal?>>(S.Add(nullable,EH(S.Convert(S.Call(M(nameof(DecimalRight))),typeof(decimal?)))),nullable),new object[]{null});
  One("nullable-value-right-EH",S.Lambda<Func<decimal?,decimal?>>(S.Add(nullable,EH(S.Convert(S.Call(M(nameof(DecimalRight))),typeof(decimal?)))),nullable),7m);
  var refInput=S.Parameter(typeof(decimal).MakeByRefType(),"refInput");
  One("byref-input-atomic-right",S.Lambda<DecimalInput>(S.Block(EH(S.Empty()),S.Add(refInput,S.Constant(11m))),refInput),7m);
  One("byref-input-atomic-left",S.Lambda<DecimalInput>(S.Block(EH(S.Empty()),S.Add(S.Constant(11m),refInput)),refInput),7m);
  var nullableRight=S.Parameter(typeof(decimal?),"nullableRight");
  var explicitNullable=S.Lambda<Func<decimal?,decimal?,decimal?>>(S.Add(EH(nullable),nullableRight,M(nameof(NullableValues))),nullable,nullableRight);
  One("explicit-nullable-null-null",explicitNullable,new object[]{null,null});
  One("explicit-nullable-value-null",explicitNullable,new object[]{7m,null});
  One("explicit-nullable-null-value",explicitNullable,new object[]{null,11m});
  One("explicit-nullable-value-value",explicitNullable,7m,11m);
  ByRef("RefDecimal",typeof(decimal),7m,11m);ByRef("RefNumber",typeof(Number),new Number(7),new Number(11));
 }
 // Exploratory contract record: factory-valid byref methods may expose an existing emitter limitation.
 // Compare before/fixed acceptance and outcomes; never treat baseline mismatch as a candidate pass.
 static void ByRef(string method,Type type,object a,object b){
  var x=S.Parameter(type,"a");var y=S.Parameter(type,"b");LambdaExpression tree;
  try{tree=S.Lambda(S.Block(EH(S.Empty()),S.Add(x,y,M(method))),x,y);}catch(Exception e){Console.WriteLine("byref factory rejected "+method+" "+e.GetType().FullName);return;}
  string oracle;
  try{oracle=Outcome(tree.Compile(),new[]{a,b});}catch(Exception e){oracle="compile:"+e.GetType().FullName;}
  Console.WriteLine("byref factory accepted "+method+" System "+oracle);
  foreach(var pair in new[]{new[]{"before","fixed"},new[]{"light-before","light-fixed"}}){
   string before=CompileOutcome(tree,pair[0],new[]{a,b}),after=CompileOutcome(tree,pair[1],new[]{a,b});
   Console.WriteLine("byref "+method+" "+pair[0]+" "+before+" "+pair[1]+" "+after);
   if(before==oracle&&after!=oracle)throw new Exception("Previously working byref form regressed");
   if(before!=oracle)Console.WriteLine("BYREF BASELINE LIMITATION, outside imported denominator: "+method+" "+pair[0]);
  }
 }
 static string CompileOutcome(LambdaExpression tree,string version,object[] args){try{
  Delegate f;
  switch(version){
   case "before":f=Before::FastExpressionCompiler.ExpressionCompiler.CompileFast(tree,true);break;
   case "fixed":f=After::FastExpressionCompiler.ExpressionCompiler.CompileFast(tree,true);break;
   case "light-before":f=LightBefore::FastExpressionCompiler.LightExpression.ExpressionCompiler.CompileFast(LightBefore::FastExpressionCompiler.LightExpression.FromSysExpressionConverter.ToLightExpression(tree),true);break;
   default:f=LightAfter::FastExpressionCompiler.LightExpression.ExpressionCompiler.CompileFast(LightAfter::FastExpressionCompiler.LightExpression.FromSysExpressionConverter.ToLightExpression(tree),true);break;
  }
  return f==null?"unsupported":Outcome(f,args);
 }catch(Exception e){return "compile:"+e.GetType().FullName;}}

}
