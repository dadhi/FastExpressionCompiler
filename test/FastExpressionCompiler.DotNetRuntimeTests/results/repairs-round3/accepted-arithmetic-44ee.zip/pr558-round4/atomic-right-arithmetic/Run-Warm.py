from pathlib import Path
import subprocess,os,json,csv
p=Path(__file__).resolve().parent
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
cases=['decimal_eh1','decimal_eh64','add','try_catch','capture8']
for runtime in ['net8.0','net10.0','net472']:
 for flavor in ['standard','light']:
  tag='warm-'+runtime+'-'+flavor
  if runtime=='net472':
   command=[str(p/'frame/bin'/flavor/'net472'/(flavor+'.exe')),'0']+cases;ext='csv'
  else:
   project='Runner' if flavor=='standard' else 'RunnerLight'
   command=['dotnet',str(p/'bin'/project/runtime/(project+'.dll')),'0']+cases;ext='jsonl'
  print('START '+tag,flush=True)
  with (p/(tag+'.'+ext)).open('w',encoding='utf8') as out,(p/(tag+'.log')).open('w',encoding='utf8') as log:
   subprocess.run(command,env=env,stdout=out,stderr=log,check=True,timeout=180)
  print('END '+tag,flush=True)
print('ALL TIMINGS STOPPED',flush=True)
