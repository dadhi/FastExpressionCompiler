from pathlib import Path
p=Path(__file__).resolve().parent
b=(p/"before/FastExpressionCompiler.cs").read_bytes()
old=b'leftValueVar == -1 && (rightIsNullable || context.HasExceptionBlock || right.IsComplexExpression())'
new=b'leftValueVar == -1 && (rightIsNullable ||\n                        context.HasExceptionBlock && (leftIsNullable || !IsAtomicArithmeticOperand(right)) ||\n                        right.IsComplexExpression())'
assert b.count(old)==1
assert b.replace(old,new,1)==(p/"fixed/FastExpressionCompiler.cs").read_bytes()
print("Exact atomic-right edit verified")
