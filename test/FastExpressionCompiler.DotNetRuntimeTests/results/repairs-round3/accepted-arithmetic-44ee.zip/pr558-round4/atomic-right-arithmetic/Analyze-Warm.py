from pathlib import Path
import json,csv,collections,statistics
p=Path(__file__).resolve().parent;results=[]
for file in sorted(p.glob('warm-*')):
 if file.suffix not in ['.jsonl','.csv']:continue
 if file.suffix=='.csv':
  rows=list(csv.DictReader(file.open(),fieldnames=['Runtime','Scenario','Phase','Version','Round','SampleIndex','Operations','NsPerOp','BytesPerOp']))
  for x in rows:
   for key in ['SampleIndex','NsPerOp','BytesPerOp']:x[key]=float(x[key])
 else:rows=[json.loads(x) for x in file.read_text().splitlines()]
 groups=collections.defaultdict(list)
 for x in rows:groups[x['Scenario'],x['Phase']].append(x)
 for (case,phase),vs in groups.items():
  pairs=collections.defaultdict(dict)
  for x in vs:
   if x['Version']!='system':pairs[x['SampleIndex']][x['Version']]=x
  assert len(pairs)==21
  ratio=statistics.median(v['fixed']['NsPerOp']/v['before']['NsPerOp'] for v in pairs.values())
  r=dict(file=file.name,case=case,phase=phase,ratio=ratio)
  for version in ['before','fixed','system']:
   selected=[x for x in vs if x['Version']==version]
   if selected:r[version]=dict(ns=statistics.median(x['NsPerOp'] for x in selected),bytes=statistics.median(x['BytesPerOp'] for x in selected))
  results.append(r)
  if phase in ['compile','compile_first','invoke'] and case.startswith('decimal'):print(r)
(p/'warm-analysis.json').write_text(json.dumps(results,indent=2))
print('ALLOCATION REGRESSIONS',[x for x in results if x['fixed']['bytes']>x['before']['bytes']])
print('CONTROL COMPILE',[(x['file'],x['case'],round(x['ratio'],3)) for x in results if not x['case'].startswith('decimal') and x['phase']=='compile'])
