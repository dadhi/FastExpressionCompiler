from pathlib import Path
import json,statistics,collections
p=Path(__file__).resolve().parent;rows=[json.loads(x) for x in (p/'cold-five.jsonl').read_text().splitlines()];groups=collections.defaultdict(list)
for x in rows:groups[x['Target'],x['Flavor'],x['Scenario']].append(x)
out=[]
for (runtime,flavor,case),xs in groups.items():
 r=dict(runtime=runtime,flavor=flavor,case=case)
 versions={v:[x for x in xs if x['Version']==v] for v in ['before','fixed']}
 for key in ['CompileNs','FirstInvokeNs','CompileAndFirstNs','CompileBytes','FirstInvokeBytes','CompileAndFirstBytes']:
  r[key]={v:dict(median=statistics.median(x[key] for x in vs),min=min(x[key] for x in vs),max=max(x[key] for x in vs)) for v,vs in versions.items()}
 pairs=collections.defaultdict(dict)
 for x in xs:pairs[x['Repetition']][x['Version']]=x
 assert len(pairs)==5
 r['combinedPairedRatio']=statistics.median(v['fixed']['CompileAndFirstNs']/v['before']['CompileAndFirstNs'] for v in pairs.values());r['combinedByteDeltas']=[v['fixed']['CompileAndFirstBytes']-v['before']['CompileAndFirstBytes'] for v in pairs.values()]
 out.append(r)
 print(runtime,flavor,case,'pairedNsRatio',round(r['combinedPairedRatio'],3),'combinedMs',[round(r['CompileAndFirstNs'][v]['median']/1e6,2) for v in ['before','fixed']],'byteMedians',[r['CompileAndFirstBytes'][v]['median'] for v in ['before','fixed']],'byteDeltas',r['combinedByteDeltas'])
(p/'cold-analysis.json').write_text(json.dumps(out,indent=2))
