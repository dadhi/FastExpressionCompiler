param(
    [string]$OutputDirectory,
    [switch]$Build,
    [switch]$Correctness,
    [switch]$Warm,
    [switch]$Cold
)
$ErrorActionPreference = 'Stop'
$taskSource = Split-Path -Parent $PSCommandPath
$taskManifest = Get-Content -LiteralPath (Join-Path $taskSource 'repro-manifest.json') -Raw | ConvertFrom-Json
foreach ($taskEntry in $taskManifest.files) {
    $taskFile = Join-Path $taskSource $taskEntry.path
    $taskActual = (Get-FileHash -LiteralPath $taskFile -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($taskActual -ne $taskEntry.sha256) { throw "Evidence hash mismatch: $($taskEntry.path)" }
}
Write-Output "Verified $($taskManifest.files.Count) evidence files; accepted commit $($taskManifest.acceptedCommit)."
if (-not ($Build -or $Correctness -or $Warm -or $Cold)) { return }
if (-not $OutputDirectory) { throw 'Specify a new -OutputDirectory to preserve the original measurements.' }
$taskRun = [IO.Path]::GetFullPath($OutputDirectory)
if (Test-Path -LiteralPath $taskRun) { throw 'OutputDirectory must not already exist.' }
New-Item -ItemType Directory -Path $taskRun | Out-Null
foreach ($taskEntry in $taskManifest.files) {
    $taskDestination = Join-Path $taskRun $taskEntry.path
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $taskDestination) | Out-Null
    Copy-Item -LiteralPath (Join-Path $taskSource $taskEntry.path) -Destination $taskDestination
}
function Invoke-CheckedBuild([string]$project) {
    & dotnet build (Join-Path $taskRun $project) -c Release
    if ($LASTEXITCODE -ne 0) { throw "Build failed: $project" }
}
function Invoke-CheckedPython([string]$script) {
    & python (Join-Path $taskRun $script)
    if ($LASTEXITCODE -ne 0) { throw "Script failed: $script" }
}
Invoke-CheckedPython 'Reproduce-Edit.py'
if ($Build) {
    foreach ($taskProject in @('Checks.csproj','Runner.csproj','RunnerLight.csproj','Coldbefore.csproj','Coldfixed.csproj','ColdLightbefore.csproj','ColdLightfixed.csproj','frame/standard.csproj','frame/light.csproj','native-fixture/standard/Native.csproj','native-fixture/light/Native.csproj')) {
        Invoke-CheckedBuild $taskProject
    }
}
if ($Correctness) {
    foreach ($taskRuntime in @('net8.0','net10.0','net472')) {
        if ($taskRuntime -eq 'net472') { & (Join-Path $taskRun "bin/Checks/$taskRuntime/Checks.exe") }
        else { & dotnet (Join-Path $taskRun "bin/Checks/$taskRuntime/Checks.dll") }
        if ($LASTEXITCODE -ne 0) { throw "Correctness failed: $taskRuntime" }
        foreach ($taskFlavor in @('standard','light')) {
            if ($taskRuntime -eq 'net472') { & (Join-Path $taskRun "native-fixture/$taskFlavor/bin/Release/$taskRuntime/Native.exe") }
            else { & dotnet (Join-Path $taskRun "native-fixture/$taskFlavor/bin/Release/$taskRuntime/Native.dll") }
            if ($LASTEXITCODE -ne 0) { throw "Native fixture failed: $taskFlavor/$taskRuntime" }
        }
    }
}
if ($Warm) {
    $taskOriginalFrame = @{}
    try {
        foreach ($taskFlavor in @('standard','light')) {
            $taskProgram = Join-Path $taskRun "frame/Program-$taskFlavor.cs"
            $taskOriginalFrame[$taskFlavor] = [IO.File]::ReadAllBytes($taskProgram)
            Copy-Item -LiteralPath (Join-Path $taskRun "frame/Measured-Warm-Program-$taskFlavor.cs") -Destination $taskProgram
            Invoke-CheckedBuild "frame/$taskFlavor.csproj"
        }
        Invoke-CheckedPython 'Run-Warm.py'
        Invoke-CheckedPython 'Analyze-Warm.py'
    }
    finally {
        foreach ($taskFlavor in $taskOriginalFrame.Keys) {
            [IO.File]::WriteAllBytes((Join-Path $taskRun "frame/Program-$taskFlavor.cs"), $taskOriginalFrame[$taskFlavor])
        }
    }
}
if ($Cold) {
    foreach ($taskFlavor in @('standard','light')) { Invoke-CheckedBuild "frame/$taskFlavor.csproj" }
    Invoke-CheckedPython 'Run-Cold.py'
    Invoke-CheckedPython 'Analyze-Cold.py'
}
Write-Output "Reproduction saved to $taskRun. Original evidence was preserved."
