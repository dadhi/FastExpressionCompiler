from pathlib import Path
import os,json,subprocess,csv
p=Path(__file__).resolve().parent;env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
with (p/'cold-five.jsonl').open('w',encoding='utf8') as out:
 for runtime in ['net8.0','net10.0','net472']:
  for flavor in ['standard','light']:
   for case in ['decimal_eh64','add','capture8']:
    for sample in range(5):
     for version in (['before','fixed'] if sample%2==0 else ['fixed','before']):
      if runtime=='net472':
       exe=p/'frame/bin'/flavor/runtime/(flavor+'.exe');raw=subprocess.check_output([str(exe),'cold',version,case],env=env,text=True,timeout=30)
       values=next(csv.reader(raw.splitlines()));row=dict(Version=values[0],Scenario=values[1],CompileNs=float(values[2]),CompileBytes=int(values[3]),FirstInvokeNs=float(values[4]),FirstInvokeBytes=int(values[5]),CompileAndFirstNs=float(values[6]),CompileAndFirstBytes=int(values[7]),FirstValue=int(values[8]))
      else:
       project=('Cold' if flavor=='standard' else 'ColdLight')+version
       raw=subprocess.check_output(['dotnet',str(p/'bin'/project/runtime/(project+'.dll')),version,'42f-atomic',case,str(sample)],env=env,text=True,timeout=30);row=json.loads(raw)
      row.update(Target=runtime,Flavor=flavor,Repetition=sample);out.write(json.dumps(row)+'\n');out.flush()
    print('DONE '+runtime+' '+flavor+' '+case,flush=True)
print('ALL COLD TIMINGS STOPPED',flush=True)
