from pathlib import Path
import subprocess,json,hashlib
w=Path(__file__).resolve().parent;repo=Path(r'C:\Data\Git\Github\FastExpressionCompiler')
manifest={'head':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD']).decode().strip(),'source':{}}
for path in ['src/FastExpressionCompiler/FastExpressionCompiler.cs','src/FastExpressionCompiler/ImTools.cs']:
 manifest['source'][path]=hashlib.sha256((repo/path).read_bytes()).hexdigest()
(w/'source-manifest.json').write_text(json.dumps(manifest,indent=2))
for light in ['false','true']:
 for tfm in ['net8.0','net10.0','net472']:
  tag=light+'-'+tfm
  with (w/('build-'+tag+'.log')).open('w') as f:
   subprocess.run(['dotnet','build','Fixture.csproj','-c','Release','-f',tfm,'-p:Light='+light,'--nologo','-v:q'],cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True)
  exe=w/'bin'/'Release'/tfm/('Fixture.exe' if tfm=='net472' else 'Fixture.dll')
  cmd=[str(exe)] if tfm=='net472' else ['dotnet',str(exe)]
  with (w/('check-'+tag+'.log')).open('w') as f:subprocess.run(cmd,cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=90)
  print('PASS '+tag,flush=True)
