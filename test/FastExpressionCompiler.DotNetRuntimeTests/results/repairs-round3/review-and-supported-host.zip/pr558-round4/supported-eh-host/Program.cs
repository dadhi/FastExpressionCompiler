using System;
#if LIGHT_EXPRESSION
using FastExpressionCompiler.LightExpression;
using FastExpressionCompiler.LightExpression.UnitTests;
#else
using FastExpressionCompiler;
using FastExpressionCompiler.UnitTests;
#endif
class Program {
 static void Main(){var t=new TestRun(TestFlags.RethrowException);t.Run(new NonExceptionThrowPolicyRegressionTests());Console.WriteLine("PASS NonExceptionThrowPolicy");t.Run(new ExceptionRegionValidationRegressionTests());Console.WriteLine("PASS ExceptionRegionValidation");t.Run(new TryResultValueRegressionTests());Console.WriteLine("PASS TryResultValue");if(t.FailedTestCount!=0)throw new Exception("Host fixture failed");Console.WriteLine("SUPPORTED HOST FIXTURES PASS");}
}
