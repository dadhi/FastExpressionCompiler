using System;

#if LIGHT_EXPRESSION
using FastExpressionCompiler.LightExpression.ImTools;
using static FastExpressionCompiler.LightExpression.Expression;
namespace FastExpressionCompiler.LightExpression.IssueTests;
#else
using System.Linq.Expressions;
using static System.Linq.Expressions.Expression;
namespace FastExpressionCompiler.IssueTests;
#endif

public struct Issue480_CLR_detected_an_invalid_program_exception : ITestX
{
    public void Run(TestRun t)
    {
        Reduced_conditional_emit(t);
        Modified_case(t);
        Original_case(t);
        Reduced_conditional_interpretation(t);
    }

    public void Original_case(TestContext t)
    {
        var p1 = Condition(Equal(Constant(true), Constant(true)), Constant(null, typeof(bool?)), Constant(null, typeof(bool?)));
        var p2 = Condition(Equal(Constant(true), Constant(true)), Constant(null, typeof(bool?)), Constant(null, typeof(bool?)));
        var exp = Convert(OrElse(p1, p2), typeof(object));
        var expr = Lambda<Func<object>>(exp);

        expr.PrintCSharp();
        // var @cs = (Func<object>)(() => //object
        //     (object)(((true) ? (bool?)null : (bool?)null) || ((true) ? (bool?)null : (bool?)null)));

        var fs = expr.CompileSys();
        fs.PrintIL(format: ILDecoder.ILFormat.AssertOpCodes);
        var a = fs();
        t.IsNull(a);

        var ff = expr.CompileFast(true);
        ff.PrintIL(format: ILDecoder.ILFormat.AssertOpCodes);
        var b = ff();
        t.IsNull(b);
    }

    public void Modified_case(TestContext t)
    {
        var p1 = Condition(Equal(Constant(true), Constant(true)), Constant(null, typeof(bool?)), Constant(null, typeof(bool?)));
        var p2 = Condition(Equal(Constant(true), Constant(true)), Constant(true, // adding true to see if left null is correspond to false
            typeof(bool?)), Constant(null, typeof(bool?)));
        var exp = Convert(OrElse(p1, p2), typeof(object));
        var expr = Lambda<Func<object>>(exp);

        expr.PrintCSharp();

        var fs = expr.CompileSys();
        fs.PrintIL(format: ILDecoder.ILFormat.AssertOpCodes);
        var a = fs();
        t.IsTrue((bool)a);

        var ff = expr.CompileFast(true);
        ff.PrintIL(format: ILDecoder.ILFormat.AssertOpCodes);
        var b = ff();
        t.IsTrue((bool)b);
    }

    public void Reduced_conditional_interpretation(TestContext t)
    {
        var p1 = Condition(Equal(Constant(true), Constant(true)), Constant(false), Constant(true));
        var p2 = Condition(Equal(Constant(true), Constant(true)), Constant(true), Constant(false));
        var exp = Convert(OrElse(p1, p2), typeof(object));
        var expr = Lambda<Func<object>>(exp);

        expr.PrintCSharp();

        var fs = expr.CompileSys();
        fs.PrintIL(format: ILDecoder.ILFormat.AssertOpCodes);
        var a = fs();
        t.IsTrue((bool)a);

        var ff = expr.CompileFast(true);
        ff.PrintIL(format: ILDecoder.ILFormat.AssertOpCodes);
        var b = ff();
        t.IsTrue((bool)b);
    }

    public void Reduced_conditional_emit(TestContext t)
    {
        var input = Parameter(typeof(bool), "input");
        var p1 = Condition(Equal(Constant(true), Constant(true)), input, Constant(true));
        var p2 = Condition(Equal(Constant(true), Constant(true)), input, Constant(false));
        var exp = Convert(OrElse(p1, p2), typeof(object));
        var expr = Lambda<Func<bool, object>>(exp, input);

        expr.PrintCSharp();

        var fs = expr.CompileSys();
        fs.PrintIL(format: ILDecoder.ILFormat.AssertOpCodes);
        var a = fs(true);
        t.IsTrue((bool)a);

        var ff = expr.CompileFast(true);
        ff.PrintIL(format: ILDecoder.ILFormat.AssertOpCodes);
        var b = ff(true);
        t.IsTrue((bool)b);
    }
}