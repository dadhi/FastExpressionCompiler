using System;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Text.Json;
using S=System.Linq.Expressions.Expression;
internal static class Program
{
 static Expression Balanced(Expression x,int n)=>n==0?x:S.Add(Balanced(x,n-1),Balanced(x,n-1));
 static LambdaExpression Build(string scenario)
 {
  var x=S.Parameter(typeof(int),"x");
  if(scenario=="quote") return S.Lambda<Func<int,Expression<Func<int>>>>(S.Quote(S.Lambda<Func<int>>(S.Add(x,S.Constant(1)))),x);
  if(scenario=="quote_rv") return S.Lambda<Func<int,Expression<Func<int>>>>(S.Quote(S.Lambda<Func<int>>(S.Block(S.RuntimeVariables(x),S.Add(x,S.Constant(1))))),x);
  if(scenario=="rv") return S.Lambda<Func<int,IRuntimeVariables>>(S.RuntimeVariables(x),x);
  return S.Lambda<Func<int,int>>(scenario=="add"?S.Add(x,S.Constant(1)):Balanced(x,8),x);
 }
 [MethodImpl(MethodImplOptions.NoInlining)] static Delegate Compile(LambdaExpression tree)=>FastExpressionCompiler.ExpressionCompiler.CompileFast(tree,true)??throw new InvalidOperationException("Strict FEC returned null");
 struct Activation {internal int Scalar;internal object Feature;}
 [MethodImpl(MethodImplOptions.NoInlining)] static Activation Invoke(Delegate d,string scenario)
 {
  if(scenario=="quote"||scenario=="quote_rv")return new Activation{Feature=((Func<int,Expression<Func<int>>>)d)(3)};
  if(scenario=="rv")return new Activation{Feature=((Func<int,IRuntimeVariables>)d)(3)};
  return new Activation{Scalar=((Func<int,int>)d)(3)};
 }
 static void Verify(Activation a,string scenario)
 {
  if(scenario=="quote"||scenario=="quote_rv") {if(((Expression<Func<int>>)a.Feature).Compile()()!=4)throw new Exception("quote mismatch");}
  else if(scenario=="rv") {var v=(IRuntimeVariables)a.Feature;if(v.Count!=1||(int)v[0]!=3)throw new Exception("RV mismatch");v[0]=19;if((int)v[0]!=19)throw new Exception("RV mutation mismatch");}
  else if(a.Scalar!=(scenario=="add"?4:768))throw new Exception("scalar mismatch");
 }
 static void Main(string[] args)
 {
  var tree=Build(args[1]);_=GC.GetAllocatedBytesForCurrentThread();_=GC.CollectionCount(0);
  long start=GC.GetAllocatedBytesForCurrentThread();var d=Compile(tree);long cold=GC.GetAllocatedBytesForCurrentThread()-start;
  start=GC.GetAllocatedBytesForCurrentThread();var first=Invoke(d,args[1]);long invoke=GC.GetAllocatedBytesForCurrentThread()-start;
  Verify(first,args[1]);
  for(int i=0;i<32;i++)GC.KeepAlive(Compile(tree));
  start=GC.GetAllocatedBytesForCurrentThread();for(int i=0;i<64;i++)GC.KeepAlive(Compile(tree));long warmCompile=GC.GetAllocatedBytesForCurrentThread()-start;
  for(int i=0;i<32;i++)_ = Invoke(d,args[1]);
  start=GC.GetAllocatedBytesForCurrentThread();Activation last=default;for(int i=0;i<256;i++)last=Invoke(d,args[1]);long warmInvoke=GC.GetAllocatedBytesForCurrentThread()-start;
  Verify(last,args[1]);
  Console.WriteLine(JsonSerializer.Serialize(new{Version=args[0],Scenario=args[1],Repetition=int.Parse(args[2]),Runtime=Environment.Version.ToString(),ColdCompileBytes=cold,FirstInvokeBytes=invoke,WarmCompileBytes=warmCompile,WarmCompileCount=64,WarmInvokeBytes=warmInvoke,WarmInvokeCount=256}));
  GC.KeepAlive(d);
 }
}
