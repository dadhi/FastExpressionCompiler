from pathlib import Path
from collections import defaultdict
import statistics as s,json,csv,re
p=Path(__file__).resolve().parent/'bench'
g=defaultdict(list);errors=[];checks={}
for f in p.glob('net*.jsonl'):
 for l in f.read_text().splitlines():
  r=json.loads(l);g[tuple(r[k] for k in ['Runtime','Flavor','Scenario','Phase','Version'])].append(r)
for f in p.glob('net*.log'):
 for l in f.read_text().splitlines():
  if l.startswith('FAIL '):
   if not ('strict FEC returned null' in l and ' before ' in l and any(v in l for v in ['quote_closed','quote_capture','runtime_variables'])):errors.append([f.name,l])
source=(p/'Program.cs').read_text()
names=re.findall(r'"([a-z0-9_]+)"',re.search(r'string\[\] names=\{([^}]+)\}',source).group(1))
names+=re.findall(r'"([a-z0-9_]+)"',re.search(r'names=names.Concat\(new\[\]\{([^}]+)\}',source).group(1))
for runtime in ('8.0.28','10.0.9'):
 for flavor in ('standard','light'):
  for version in ('before','reviewed','fixed','system'):
   for name in names:
    if version=='before' and name in ('quote_closed','quote_capture','runtime_variables'):continue
    if version=='before' and name in ('capture_byref_call','capture_struct','capture_large_struct'):continue
    for phase in ('construct','compile','compile_first','invoke'):
     values=g.get((runtime,flavor,name,phase,version),[])
     if len(values)!=14 or {x['Round'] for x in values}!={0,1}:
      errors.append(['incomplete',runtime,flavor,version,name,phase,len(values)])
rows=[]
for k,v in sorted(g.items()):
 r=dict(zip(['runtime','flavor','scenario','phase','version'],k))
 r.update(ns=s.median(x['NsPerOp'] for x in v),bytes=s.median(x['BytesPerOp'] for x in v),samples=len(v),rounds={str(n):s.median(x['NsPerOp'] for x in v if x['Round']==n) for n in sorted({x['Round'] for x in v})})
 rows.append(r)
(p/'final-analysis.json').write_text(json.dumps({'errors':errors,'rows':rows},indent=2))
i={tuple(r[k] for k in ['runtime','flavor','scenario','phase','version']):r for r in rows}
for key,a in i.items():
 if key[-1]!='fixed':continue
 b=i.get(key[:-1]+('before',))
 if not b:continue
 ratio=a['ns']/b['ns']
 if a['bytes']-b['bytes']>1 or (ratio>1.10 and a['ns']-b['ns']>10):
  print('/'.join(key[:-1]),f"time {b['ns']:.1f}->{a['ns']:.1f}ns {ratio:.2f}x; bytes {b['bytes']:.1f}->{a['bytes']:.1f}")
print('Groups',len(rows),'errors',errors)
