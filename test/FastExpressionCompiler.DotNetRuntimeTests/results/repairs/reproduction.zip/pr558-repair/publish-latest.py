"""Publish already completed, strictly validated measurements. Never runs benchmarks.

Run only after final-pipeline.py succeeds. Sources/projects are archived, never
copied loose below the SDK test project's results directory. No commit or push.
"""
from pathlib import Path
from collections import defaultdict
import argparse, csv, gzip, hashlib, html, json, re, shutil, statistics, subprocess, sys, tempfile, zipfile

W = Path(__file__).resolve().parent
REPO = Path(r'C:\Data\Git\Github\FastExpressionCompiler')
OUT = W.parents[1] / 'outputs/fec-pr558-repairs'
TARGET = REPO / 'test/FastExpressionCompiler.DotNetRuntimeTests/results/repairs'

def obj(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()
def require(ok, message):
    if not ok: raise SystemExit(message)
def write_json(p, value): p.write_text(json.dumps(value, indent=2), encoding='utf-8')
def zip_paths(destination, paths, root=W):
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED) as archive:
        for p in sorted(set(paths)):
            if p.is_file(): archive.write(p, str(p.relative_to(root)))
def tree_files(folder, sources=False):
    if not folder.exists(): return []
    return [p for p in folder.rglob('*') if p.is_file()
            and not any(x in {'bin','obj','.git','.vs'} for x in p.relative_to(folder).parts)
            and (sources or p.suffix.lower() not in {'.dll','.exe','.pdb'})]
def fmt(x): return 'N/A' if x is None else f'{x:,.2f}'
def table(rows, fields):
    return '<table><thead><tr>'+''.join('<th>'+html.escape(k)+'</th>' for k in fields)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(r.get(k,'')))+'</td>' for k in fields)+'</tr>' for r in rows)+'</tbody></table>'

def prepare():
    source = obj(W/'latest-source.json'); sha = source['source']
    require(git('rev-parse','HEAD') == sha, 'HEAD differs from latest source manifest')
    require(subprocess.run(['git','diff','--quiet','HEAD','--','src','test'], cwd=REPO).returncode == 0, 'Source/test tree changed since pipeline')
    runs = obj(W/'latest-runs.json')
    expected = {'validation','modern-build','paired-prepare','paired-build','framework-build','cold-build','modern-matrix','paired-net8.0','paired-net10.0','framework-current','cold','modern-analysis','paired-analysis','extra-analysis','actual-inner-il'}
    require(expected <= runs.keys() and all(runs[k]['exitCode']==0 for k in expected), 'Final pipeline is incomplete or failed')
    extra = obj(W/'extra-analysis.json'); modern = obj(W/'bench/final-analysis.json')
    require(extra['expected_fixed_commit']==sha and extra['complete'] and not extra['errors'] and not extra['pending'], 'Latest strict extra analysis is not clean')
    require(not modern['errors'], 'Modern matrix contains errors')
    require(modern['rows'] and all(r['samples']==14 for r in modern['rows']), 'Modern matrix has incomplete phase sample groups')
    for name, info in extra['inputs'].items():
        require(digest(W/name)==info['sha256'], 'Analysis input changed: '+name)
    require(obj(W/'bench/commits.json')['fixed']==sha, 'Modern measurements use different fixed source')
    v = W/('validation-'+sha[:8]); codes = obj(v/'codes.json'); snap = obj(v/'snapshot.json'); run = obj(v/'suite/fec/run.json')
    require(snap['commit']==sha and codes and all(x==0 for x in codes.values()), 'Validation failed or source mismatched')
    require(run['batches'] and not run['crashes'] and all(b['status']=='Complete' and int(b['counters']['failed'])==0 for b in run['batches']), 'Imported suite failed/incomplete')
    counts = dict(passed=sum(int(b['counters']['passed']) for b in run['batches']), failed=sum(int(b['counters']['failed']) for b in run['batches']), crashes=len(run['crashes']), batches=len(run['batches']))
    native = {}
    for name in ['native-net10.0','native-net8.0','framework-run']:
        text=(v/(name+'.log')).read_text(encoding='utf-8-sig')
        found=re.findall(r'ALL\s+(\d+)\s+tests are passing', text)
        require(found, 'Missing legacy passing count: '+name)
        native[name]={'legacy_passed':int(found[-1]), 'registered_TestX_passed':[int(x) for x in re.findall(r'TestX:\s*(\d+)\s+tests are passing',text)]}
    il=W/'capture8-finalized-latest'
    require(il.exists() and any(il.glob('*il.txt')), 'Latest actual finalized-delegate IL proof missing')
    fwrun=obj(W/'framework-phase/results/final-current/run.json')
    require('TimingCaveat' in fwrun and 'SourceRuns' in fwrun, 'Framework control provenance missing')
    return source, runs, extra, modern, v, dict(source=snap,codes=codes,imported=counts,native=native,importedRun=run), fwrun

def publish(destination, source, runs, extra, modern, validation_dir, validation, fwrun):
    sha=source['source']; destination.mkdir(parents=True, exist_ok=True)
    # Generates source text only. Never runs its generated benchmark script.
    subprocess.run([sys.executable, str(W/'portable.py')], check=True)
    require(repr(sha) in (W/'measure-portable.py').read_text(), 'Portable runner does not embed final fixed SHA')
    def copy(p, name=None):
        require(p.exists(), 'Required artifact missing: '+str(p))
        shutil.copy2(p, destination/(name or p.name))
    for p in [W/'latest-source.json',W/'latest-runs.json',W/'extra-analysis.json',W/'bench/final-analysis.json']:
        copy(p, 'modern-analysis.json' if p.name=='final-analysis.json' else None)
    write_json(destination/'validation.json',validation)
    framework_provenance=dict(fwrun)
    old_framework_hashes=W/'historical-20d/framework-phase/hashes-final.json'
    require(old_framework_hashes.exists(), 'Original measured Framework control hashes missing')
    framework_provenance['MeasuredControlAssemblyHashes']={'archive':'historical-20d.zip','path':str(old_framework_hashes.relative_to(W)),'manifestSha256':digest(old_framework_hashes),'hashes':obj(old_framework_hashes)}
    framework_provenance['RebuiltSnapshotWarning']='Framework Prepare rebuilt before/current binaries. Latest assembly hashes identify the freshly measured current binary; latest rebuilt-before hashes do not identify the old measured before/System controls or their MVID. Original measured-control hashes are the historical manifest above.'
    write_json(destination/'framework-control-provenance.json',framework_provenance)
    for p in validation_dir.glob('*.log'): copy(p)
    (destination/'repair-commits.txt').write_text(git('log','--reverse','--format=%H %s',source['published']+'..'+sha)+'\n',encoding='utf-8')
    cold_allocations=defaultdict(list)
    for line in (W/'cold-start/cold-final-latest.jsonl').read_text(encoding='utf-8-sig').splitlines():
        if not line.strip():continue
        point=json.loads(line)
        for phase,field in [('cold_compile','CompileBytes'),('cold_first_invoke','FirstInvokeBytes'),('cold_compile_first','CompileAndFirstBytes')]:
            cold_allocations[(point['Runtime'],point['Scenario'],phase,point['Version'])].append(point[field])
    cold_ranges=[dict(runtime=k[0],scenario=k[1],phase=k[2],version=k[3],bytes_min=min(v),bytes_max=max(v),bytes_samples=v) for k,v in sorted(cold_allocations.items())]
    write_json(destination/'cold-allocation-ranges.json',cold_ranges)
    rows=[]
    for section, values in [('modern',modern['rows']),('framework',extra['framework']),('cold',extra['cold'])]:
        for original in values:
            r=dict(original,section=section)
            r['sourceCommit']={'before':source['baseline'],'reviewed':source['published'],'fixed':sha,'system':'System.Linq.Expressions'}[r['version']]
            r['timingProvenance']='earlier independent-process before/System controls; current latest' if section=='framework' else 'latest run'
            rows.append(r)
    write_json(destination/'all-phase-measurements.json', rows)
    with (destination/'all-phase-measurements.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,['section','runtime','flavor','scenario','phase','version','ns','bytes','samples','sourceCommit','timingProvenance'],extrasaction='ignore'); writer.writeheader();writer.writerows(rows)
    (destination/'Program.cs.txt').write_bytes((W/'bench/Program.cs').read_bytes())
    raw=[*sorted((W/'bench').glob('net*.jsonl')),*sorted((W/'bench').glob('net*.log')),*sorted((W/'paired').glob('final-net*.jsonl')), W/'cold-start/cold-final-latest.jsonl',*sorted((W/'framework-phase/results/final-current').glob('*'))]
    zip_paths(destination/'raw-latest.zip',raw)
    # Full historical failure records remain historical: never merge their rows into latest.
    historical=tree_files(W/'historical-20d')
    require(historical, 'Historical 20d archive missing')
    zip_paths(destination/'historical-20d.zip',historical)
    evidence={
        'framework-eh-proof.zip':tree_files(W/'framework-eh-allocation'),
        'framework-reference-slot-proof.zip':tree_files(W/'frame-capture-il-proof'),
        'capture8-finalized-il.zip':tree_files(W/'capture8-finalized-latest')+tree_files(W/'capture8-finalized-resolver'),
        'shared-cache-causal-proof.zip':tree_files(W/'lazy-quote-metadata/work/shared-cold-allocation'),
        'rejected-three-holder-proof.zip':tree_files(W/'lazy-quote-metadata/work/cold-allocation'),
        'compact-scope-causal-proof.zip':tree_files(W/'compact-scope-alloc'),
        'root-intrinsic-proof.zip':tree_files(W/'opaque-root-probe')+tree_files(W/'terminal-intrinsic-probe'),
    }
    for name,files in evidence.items():
        require(files,'Missing proof '+name);zip_paths(destination/name, files)
    scripts=[W/name for name in ['final-pipeline.py','resume-analysis.py','validate.py','bench.py','check.py','paired-setup.py','paired-analyze.py','analyze-extra.py','analyze-latest.py','publish-latest.py','portable.py','measure-portable.py','prepare-paired-portable.py']]
    scripts += [W.parent/'fec-round12/Run-Full.py',W.parent/'fec-fixes/FrameworkRunner/Program.cs',W.parent/'fec-fixes/FrameworkRunner/FrameworkRunner.csproj',W.parent/'pr558-perf/Program.cs']
    for folder,names in {'bench':['Program.cs','commits.json'], 'paired':['Program.cs','Runner.csproj','final-commits.json'], 'cold-start':['Program.cs','Prepare.ps1','Invoke-Cold.ps1','README.txt','commits.json','harness-hashes.json','binary-hashes.json'], 'framework-phase':['Program.cs','Prepare.ps1','Run-Paired.ps1','Run-Current.ps1','cases.json','manifest.json','hashes-final.json']}.items():
        scripts += [W/folder/name for name in names]
    scripts += [p for p in (W/'tools').iterdir() if p.is_file() and p.suffix in {'.ps1','.py','.cs','.csproj','.txt'}]
    require(all(p.exists() for p in scripts), 'Reproduction file missing')
    # Extract at a work/ directory: sibling dependency paths then match validate.py.
    zip_paths(destination/'reproduction.zip',scripts,root=W.parent)
    with zipfile.ZipFile(destination/'reproduction.zip','a',zipfile.ZIP_DEFLATED) as z:
        for p,name in [(W/'bench/Program.cs','Program.cs'),(W/'paired/Program.cs','PairedProgram.cs'),(W/'paired/Runner.csproj','PairedRunner.csproj'),(W/'paired/final-commits.json','paired-commits.json')]:
            z.write(p,'pr558-repair/'+name)
    # Source snapshot: only tracked source/configuration, zipped to avoid SDK globbing.
    with zipfile.ZipFile(destination/'source-snapshot.zip','w',zipfile.ZIP_DEFLATED) as z:
        names=git('ls-files','src','test','Directory.Build.props','global.json').splitlines()
        for name in names:
            if '/results/' not in name and (REPO/name).is_file(): z.write(REPO/name,name)
    hashes={'source':sha,'baseline':source['baseline'],'published':source['published'],'validation':validation['source'],'analysisInputs':extra['inputs'],'assemblies':{},'frameworkMeasuredControlHashes':framework_provenance['MeasuredControlAssemblyHashes'],'frameworkSnapshotWarning':framework_provenance['RebuiltSnapshotWarning']}
    for folder,patterns in [('bench',['**/bin/Release/**/*.dll']),('paired',['bin/Release/**/*.dll']),('cold-start',['latest-assembly-hashes.json']),('framework-phase',['latest-assembly-hashes.json'])]:
        for pattern in patterns:
            for p in (W/folder).glob(pattern): hashes['assemblies'][str(p.relative_to(W))]=digest(p) if p.suffix=='.dll' else obj(p)
    write_json(destination/'source-assembly-hashes.json', hashes)
    # Exact actual data, including positive residuals. Across-shape medians are descriptive.
    paired=extra['paired_summaries']; residuals=[]
    for r in paired:
        if r.get('paired_time_ratio',0)>1 or r.get('fixed_before_allocation_delta',0)>0.5: residuals.append(r)
    write_json(destination/'paired-residuals.json',residuals)
    totals=[]
    for rt in sorted({r['runtime'] for r in paired}):
        for phase in sorted({r['phase'] for r in paired}):
            values=[r for r in paired if r['runtime']==rt and r['phase']==phase]
            ratios=[r['paired_time_ratio'] for r in values if r.get('paired_time_ratio') is not None]
            deltas=[r['fixed_before_allocation_delta'] for r in values if r.get('fixed_before_allocation_delta') is not None]
            if values:totals.append({'runtime':rt,'phase':phase,'comparisons':len(values),'median paired ratio':f'{statistics.median(ratios):.4f}' if ratios else 'N/A','time ratios >1.03':sum(x>1.03 for x in ratios),'allocation increases':sum(x>0.5 for x in deltas),'allocation decreases':sum(x<-.5 for x in deltas)})
    cold=[{'runtime':r['runtime'],'scenario':r['scenario'],'phase':r['phase'],'version':r['version'],'median ns':fmt(r['ns']),'min–max ns':fmt(r['ns_min'])+'–'+fmt(r['ns_max']),'median B':fmt(r['bytes']),'min–max B':fmt(min(cold_allocations[(r['runtime'],r['scenario'],r['phase'],r['version'])]))+'–'+fmt(max(cold_allocations[(r['runtime'],r['scenario'],r['phase'],r['version'])])),'samples':r['samples']} for r in extra['cold']]
    selected=[dict(runtime=r['runtime'],scenario=r['scenario'],phase=r['phase'],ratio=f"{r['paired_time_ratio']:.4f}" if r.get('paired_time_ratio') is not None else 'N/A',**{'delta B':fmt(r.get('fixed_before_allocation_delta'))}) for r in paired if r['scenario'] in {'capture8','capture_mutable','blocks32','try_catch','try_finally'} and r['phase'] in {'compile','nested_invoke','compile_first'}]
    verdict='Substantial repairs pass validation; before-PR performance and allocation parity is not achieved.'
    framework_costs=[{'runtime':r['runtime'],'flavor':r['flavor'],'scenario':r['scenario'],'before B':fmt(r['before_bytes']),'fixed B':fmt(r['fixed_bytes']),'delta B':fmt(r['fixed_before_allocation_delta'])} for r in extra['comparisons']['framework'] if r['phase']=='compile' and r.get('fixed_before_allocation_delta',0)>8]
    cold_costs=[{'runtime':r['runtime'],'scenario':r['scenario'],'before B':fmt(r['before_bytes']),'fixed B':fmt(r['fixed_bytes']),'delta B':fmt(r['fixed_before_allocation_delta']),'time ratio':f"{r['fixed_before_time_ratio']:.4f}"} for r in extra['comparisons']['cold'] if r['phase']=='cold_compile_first' and r.get('fixed_before_allocation_delta',0)>.5]
    cold_totals=[{'runtime':r['runtime'],'phase':'cold compile + first invoke','median scenario time ratio':f"{r['median_scenario_time_ratio']:.4f}",'allocation increases':str(r['allocation_increases'])+'/'+str(r['before_fixed_comparisons'])} for r in extra['totals'] if r['section']=='cold' and r['phase']=='cold_compile_first']
    write_json(destination/'remaining-costs.json',dict(framework_compile=framework_costs,cold_compile_first=cold_costs,cold_totals=cold_totals,modern_paired_totals=totals))
    retry_note='The initial paired-analysis parser rejected PASS marker lines in the saved paired JSONL. The scratch parser was corrected; resume-analysis.py reran analysis and actual finalized-delegate IL extraction only. No benchmark was remeasured and the raw measurement inputs remained unchanged. Strict analysis now passes; input hashes and raw samples are archived.\n'
    (destination/'analysis-retry.txt').write_text(retry_note,encoding='utf-8')
    decisions=f'''Source: {sha}\n{verdict}\n\nAll current strict measurement errors: 0. Imported: {validation['imported']}. Native counts are parsed from the frozen validation logs in validation.json. The existing imported exclusions and user-deferred deep-tree cases remain; no new exclusion is inferred here.\n\nModern paired results use matched alternating before/fixed samples. Full modern independent-process matrix includes published and System. Framework before/System controls are preserved from the earlier final20d run; current samples are fresh. Their time ratios are descriptive, not paired causal estimates. Cold points are fresh processes; compile plus first invocation must be considered together. Managed allocation excludes native/JIT and retained memory.\n\nAccepted repairs retain the direct IL emitter and object[] closure layout: lazy per-compilation metadata sharing, conservative capture analysis, native boxed live value cells on modern runtimes (typed cells retained for quotes/runtime variables/unknown roots and Framework), private reference proof, allocation-free Light array operand access, typed reference casts for the Framework verified host, collector/scope state sharing and bounded cleared pools. Logical commits are archived separately.\n\nThe historical20d broad matrix found four Framework capture_try failures (two flavors/two rounds) and Light private array-capture +352 B. Historical raw data and errors are preserved; the final source/matrix supersede those cases, never silently overwrite them. The Frame reference casts repair verified object[] loads; no host/security-policy workaround was used.\n\nFramework EH +16 B per compile was isolated with same-assembly constructor controls: restricted anonymous DynamicMethod captures CompressedStack. Earlier +128 B reports were stale; finally IL was byte identical. No security-policy change accepted.\n\nShared lazy metadata cache causal and cold-allocation controls are packaged separately. The three-holder alternative introduced +192 B cold storage and was rejected. Cross-compilation weak cache (~135 B fresh-type cost), custom Framework module (~2.7 KB), and additional whole-tree scope scans were rejected. Historical explanatory files are not latest measurement claims.\n\nActual finalized-delegate resolver IL is in capture8-finalized-il.zip. The obsolete pooled ILGenerator dump is excluded; matching managed IL does not prove identical native code or eliminate a measured runtime residual.\n\nNo commit, push, or GitHub write is performed by this publisher.\n'''
    (destination/'DECISIONS.txt').write_text(decisions,encoding='utf-8')
    with (destination/'DECISIONS.txt').open('a',encoding='utf-8') as f:
        f.write('\nProminent remaining costs (latest measured source)\n'+json.dumps(dict(framework_compile=framework_costs,cold_compile_first=cold_costs,cold_totals=cold_totals),indent=2)+'\nFramework capture allocation costs are additional to the isolated EH host +16 B: mutable capture approximately +896 B, capture8 approximately +289–291 B, reference/call captures +144 B, capture_try +184 B, capture_array +48 B. Framework retains typed StrongBox cells for verifier correctness; the modern boxed-value optimization is not applied there. Fractional per-operation noise is preserved separately from these material changes. Cold compile-plus-first allocation increases affect 3/10 shapes on each runtime: nested_mixed128 +10,328 B and EH shapes +1,248 B (.NET 8) / +1,224 B (.NET 10). Cold time ratios are descriptive independent-process observations, not causal paired estimates.\n'+retry_note)
    (destination/'REPRODUCE.txt').write_text('Source SHA: '+sha+'\nExtract reproduction.zip into a work/ directory: it includes pr558-repair/, fec-round12/Run-Full.py, fec-fixes/FrameworkRunner sources and the pr558-perf base harness. These sibling paths are used by validation and benchmark preparation. First build work/fec-fixes/FrameworkRunner/FrameworkRunner.csproj in Release; the pipeline expects its net472 executable. Restore source-snapshot.zip into an isolated checkout, or checkout the recorded source commit. Scripts document the original Windows repository path; edit paths if relocating. final-pipeline.py builds and runs validation/modern/paired/Framework/cold sequentially; it is intentionally expensive. Requires installed .NET 8/10 SDK/runtimes, Framework 4.8.1 and Python/PowerShell. DOTNET_TieredCompilation=0 and DOTNET_ReadyToRun=0. The regenerated measure-portable.py embeds the final SHA and reads its sibling Program.cs; prepare-paired-portable.py receives matching source/config aliases. Framework historical controls remain identified in framework-control-provenance.json. Run analyze-latest.py strictly, then publish-latest.py. Inputs, source and assemblies are hashed. No benchmark executes from the HTML report.\n',encoding='utf-8')
    page='''<!doctype html><html><meta charset="utf-8"><title>PR 558 repairs: final evidence</title><style>body{font:15px system-ui;max-width:1450px;margin:32px auto;padding:0 24px;color:#18252e}p{line-height:1.55}table{border-collapse:collapse;width:100%;font-size:13px}td,th{padding:7px;border-bottom:1px solid #ddd;text-align:right}td:first-child,th:first-child{text-align:left}th{background:#edf2f5}.note{padding:16px;background:#edf2f5}select{margin:6px;padding:8px}code{overflow-wrap:anywhere}.bad{background:#fff1ef}</style><h1>PR #558: regression repairs</h1>'''
    page+='<p class="note"><strong>'+verdict+'</strong><br>Final measured and validated source: <code>'+sha+'</code>. Current strict analysis reports 0 errors and no pending samples. Nothing is pushed by this report.</p>'
    page+='<section class="note"><h2>Remaining costs: the all-metrics goal is unmet</h2><p>Modern Standard paired compilation has 0 allocation increases across 41 common shapes per runtime (14 decreases, 27 unchanged), but compilation CPU remains higher in the median shape. The exact paired ratios and residuals are below. <strong>Framework capture costs are larger than the isolated +16 B exception-host cost:</strong> mutable capture is about +896 B, capture8 +289–291 B, reference/call captures +144 B, capture_try +184 B and capture_array +48 B per compile. Framework keeps typed StrongBox cells for verifier correctness; the modern boxed-value optimization is unavailable there.</p>'+table(framework_costs,['runtime','flavor','scenario','before B','fixed B','delta B'])+'<p>These material allocation increases are shown with the raw fractional per-operation measurement noise retained. Framework before/System controls were recorded earlier than fixed; its time ratios are not paired causal estimates.</p><h3>Cold compile plus first invocation</h3><p>Allocation increases remain in 3/10 cold shapes on each runtime. nested_mixed128 adds 10,328 B; try/catch and try/finally add 1,248 B on .NET 8 or 1,224 B on .NET 10. Median scenario time ratios are approximately 1.485× and 1.569×. These independent fresh-process observations include compiler JIT/initialization and host variability; they are not causal paired timing estimates.</p>'+table(cold_totals,['runtime','phase','median scenario time ratio','allocation increases'])+table(cold_costs,['runtime','scenario','before B','fixed B','delta B','time ratio'])+'</section>'
    page+='<p>Modern Standard paired compile summary (a median across shapes, not an application score):</p>'+table([r for r in totals if r['phase']=='compile'],['runtime','comparisons','median paired ratio','time ratios >1.03','allocation increases','allocation decreases'])
    page+='<p>Parsing here means expression analysis and IL compilation; tree construction is a separate construct phase. Captures separate activation and nested invocation. All sampled outputs are checked against the compiled System result. Unsupported or invalid baseline cases are unavailable comparisons, never speedup claims.</p>'
    page+='<p>101 alternating matched pairs per common Standard shape on each modern runtime; prefer these paired ratios to independent process timing ratios. Ratios above 1 mean slower. Across-shape medians are descriptive, not an application score. Managed bytes exclude native/JIT and retained memory. Cold startup includes first compiler JIT/initialization after tree construction and must be assessed with compile plus first invocation.</p>'
    page+='<p><strong>Framework provenance:</strong> '+html.escape(fwrun['TimingCaveat'])+' The +16 B EH constructor cost is separately isolated; see the proof archive. No host/security-policy workaround was used.</p>'
    page+='<p>Imported validation: '+html.escape(str(validation['imported']))+'. Native counts: '+html.escape(str(validation['native']))+'. Existing exclusions and deferred deep-tree cases remain documented in the validation evidence.</p>'
    links=['all-phase-measurements.csv','extra-analysis.json','validation.json','repair-commits.txt','DECISIONS.txt','paired-residuals.json','raw-latest.zip','historical-20d.zip','capture8-finalized-il.zip','framework-eh-proof.zip','framework-reference-slot-proof.zip','shared-cache-causal-proof.zip','rejected-three-holder-proof.zip','compact-scope-causal-proof.zip','reproduction.zip','source-snapshot.zip','source-assembly-hashes.json','artifact-sha256.json','REPRODUCE.txt']
    links+=['remaining-costs.json','analysis-retry.txt','cold-allocation-ranges.json','artifact-sizes.json']
    page+='<p>'+' · '.join('<a href="'+x+'">'+x+'</a>' for x in links)+'</p><h2>Paired results, including remaining regressions</h2>'+table(totals,['runtime','phase','comparisons','median paired ratio','time ratios >1.03','allocation increases','allocation decreases'])+table(selected,['runtime','scenario','phase','ratio','delta B'])
    page+='<h2>Full phase matrix</h2><p>Modern independent-process medians include before/published/fixed/System. Framework controls have the chronological caveat above. Cold is Standard only. All rows retain source and section provenance.</p><select id="section"></select><select id="runtime"></select><select id="flavor"></select><select id="phase"></select><table><thead><tr><th>Scenario</th><th>Before ns / B</th><th>Published ns / B</th><th>Fixed ns / B</th><th>System ns / B</th><th>Fixed / before</th><th>Delta B</th></tr></thead><tbody id="matrix"></tbody></table>'
    page+='<h2>Cold fresh-process ranges</h2><p>Every point uses nine fresh processes. Both time and allocation min/max are shown, including bimodal first-use allocation events; compile-only phase shifts are not overall startup improvements. Exact allocation samples are in cold-allocation-ranges.json.</p>'+table(cold,['runtime','scenario','phase','version','median ns','min–max ns','median B','min–max B','samples'])
    page+='<h2>Repairs and limits</h2><pre style="white-space:pre-wrap">'+html.escape(decisions)+'</pre>'
    page+='''<script>const DATA=__ROWS__;const ids=['section','runtime','flavor','phase'];for(const id of ids){const e=document.getElementById(id);for(const v of [...new Set(DATA.map(r=>r[id]))])e.add(new Option(v,v));e.onchange=show;}document.getElementById('phase').value='compile';function show(){const rows=DATA.filter(r=>ids.every(id=>r[id]===document.getElementById(id).value));let text='';for(const n of [...new Set(rows.map(r=>r.scenario))].sort()){const get=v=>rows.find(r=>r.scenario===n&&r.version===v),b=get('before'),f=get('fixed'),fmt=r=>r?`${r.ns.toFixed(2)} / ${r.bytes.toFixed(2)}`:'N/A';text+=`<tr><td>${n}</td>${['before','reviewed','fixed','system'].map(v=>`<td>${fmt(get(v))}</td>`).join('')}<td>${b&&f?(f.ns/b.ns).toFixed(3)+'×':'N/A'}</td><td>${b&&f?(f.bytes-b.bytes).toFixed(2):'N/A'}</td></tr>`;}document.getElementById('matrix').innerHTML=text;}show();</script></html>'''.replace('__ROWS__',json.dumps(rows).replace('</','<\\/'))
    (destination/'report.html').write_text(page,encoding='utf-8')
    require(not any(p.suffix.lower() in {'.cs','.csproj'} for p in destination.rglob('*')), 'Loose SDK source/project in evidence')
    sizes={str(p.relative_to(destination)):p.stat().st_size for p in destination.rglob('*') if p.is_file()}
    require(all(size<95*1024*1024 for size in sizes.values()), 'Evidence file approaches GitHub 100 MB limit: '+str({p:s for p,s in sizes.items() if s>=95*1024*1024}))
    write_json(destination/'artifact-sizes.json',sizes)
    write_json(destination/'artifact-sha256.json',{str(p.relative_to(destination)):digest(p) for p in sorted(destination.rglob('*')) if p.is_file() and p.name!='artifact-sha256.json'})

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--check-only',action='store_true');args=parser.parse_args()
    evidence=prepare()
    if args.check_only: print('Ready to publish source '+evidence[0]['source']);return
    # Construct and validate the package before replacing either destination.
    with tempfile.TemporaryDirectory(prefix='fec-pr558-publish-') as tmp:
        stage=Path(tmp)/'evidence';publish(stage,*evidence)
        for target in [OUT,TARGET]:
            require(target.resolve()==target.absolute(), 'Evidence destination resolves through a link: '+str(target))
            target.mkdir(parents=True,exist_ok=True)
            # Replace only files previously inside this named generated-evidence directory.
            for p in target.iterdir():
                if p.is_dir():shutil.rmtree(p)
                else:p.unlink()
            shutil.copytree(stage,target,dirs_exist_ok=True)
    print('Published '+evidence[0]['source']+'\n'+str(OUT)+'\n'+str(TARGET))

if __name__=='__main__':main()
