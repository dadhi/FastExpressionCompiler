from pathlib import Path
from collections import defaultdict
import json,statistics as stats,sys

for filename in sys.argv[1:]:
 path=Path(filename)
 pairs=defaultdict(dict)
 for line in path.read_text().splitlines():
  if line.startswith('PASS '):continue
  row=json.loads(line)
  pairs[(row['Runtime'],row['Scenario'],row['Phase'],row['Round'],row['SampleIndex'])][row['Version']]=row
 groups=defaultdict(list)
 for key,values in pairs.items():
  if set(values)!={'before','fixed'}:raise ValueError(('incomplete pair',key))
  groups[key[:3]].append(values)
 result=[]
 for key,values in sorted(groups.items()):
  row=dict(zip(('runtime','scenario','phase'),key))
  row['pairs']=len(values)
  for version in ('before','fixed'):
   row[version+'_ns']=stats.median(x[version]['NsPerOp'] for x in values)
   row[version+'_bytes']=stats.median(x[version]['BytesPerOp'] for x in values)
  ratios=[x['fixed']['NsPerOp']/x['before']['NsPerOp'] for x in values]
  row['paired_time_ratio']=stats.median(ratios)
  row['allocation_change']=row['fixed_bytes']-row['before_bytes']
  result.append(row)
  if key[-1]=='compile':print(key[0],key[1],f"{row['before_ns']:.1f}->{row['fixed_ns']:.1f}ns paired {row['paired_time_ratio']:.3f}x, {row['before_bytes']:.1f}->{row['fixed_bytes']:.1f}B")
 path.with_suffix('.analysis.json').write_text(json.dumps(result,indent=2))
