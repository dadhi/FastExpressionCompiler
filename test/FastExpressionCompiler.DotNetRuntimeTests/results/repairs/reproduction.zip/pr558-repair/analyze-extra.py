"""Validate/summarize saved measurements only. Never starts a compiler or benchmark.

Default: strict final-run validation. --allow-pending permits an explicitly incomplete
progress snapshot, but never hides malformed data or unexpected behavioral failures.
"""
from pathlib import Path
from collections import defaultdict
import argparse
import csv
import hashlib
import json
import math
import re
import statistics as st
import sys

ROOT = Path(__file__).resolve().parent
BASELINE = "e4c232da108d98790f0ca73f23ec90756da0cad7"
FIXED = "20d3174b52c86a680ce47f9a5e3454e8a39f5fcd"
COLD_NAMES = "add balanced256 blocks32 nested_mixed128 try_catch try_finally capture1 capture8 capture_mutable capture_mutable_reference".split()
BASELINE_NA = set("capture_byref_call capture_struct capture_large_struct quote_closed quote_capture runtime_variables".split())
BASE_PHASES = {"construct", "compile", "compile_first", "invoke"}


class Audit:
    def __init__(self):
        self.errors, self.pending, self.inputs = [], [], {}

    def need(self, condition, message):
        if not condition:
            self.pending.append(message)

    def check(self, condition, message):
        if not condition:
            self.errors.append(message)

    def text(self, path):
        if not path.exists():
            self.pending.append(f"Missing {path.relative_to(ROOT)}")
            return None
        data = path.read_bytes()
        self.inputs[str(path.relative_to(ROOT))] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
        return data.decode("utf-8-sig")

    def obj(self, path):
        text = self.text(path)
        return json.loads(text) if text is not None else None

    def jsonl(self, path, status=False):
        text = self.text(path)
        if text is None:
            return [], []
        rows, diagnostic = [], []
        lines = text.splitlines()
        for number, line in enumerate(lines, 1):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                if status:
                    diagnostic.append(line)
                elif number == len(lines) and not text.endswith("\n"):
                    self.pending.append(f"Incomplete trailing JSON at {path.name}:{number}")
                else:
                    self.errors.append(f"Malformed JSON at {path.name}:{number}: {line[:160]}")
        return rows, diagnostic


def number(audit, value, where):
    audit.check(isinstance(value, (int, float)) and math.isfinite(value) and value >= 0, f"Invalid measurement {where}: {value}")


def summarize(raw):
    groups = defaultdict(list)
    for r in raw:
        groups[tuple(r[k] for k in ("runtime", "flavor", "scenario", "phase", "version"))].append(r)
    out = []
    for key, values in sorted(groups.items()):
        times, allocations = [r["ns"] for r in values], [r["bytes"] for r in values]
        quartiles = st.quantiles(times, n=4, method="inclusive") if len(times) > 1 else [times[0]] * 3
        row = dict(zip(("runtime", "flavor", "scenario", "phase", "version"), key))
        row.update(ns=st.median(times), bytes=st.median(allocations), samples=len(values),
                   ns_min=min(times), ns_p25=quartiles[0], ns_p75=quartiles[2], ns_max=max(times))
        out.append(row)
    return out


def compare(rows, paired=None):
    groups = defaultdict(dict)
    for r in rows:
        groups[tuple(r[k] for k in ("runtime", "flavor", "scenario", "phase"))][r["version"]] = r
    out = []
    for key, versions in sorted(groups.items()):
        row = dict(zip(("runtime", "flavor", "scenario", "phase"), key))
        for v, value in versions.items():
            row[v + "_ns"] = value["ns"]
            row[v + "_bytes"] = value["bytes"]
        for other in ("before", "system"):
            if "fixed" in versions and other in versions:
                row["fixed_" + other + "_time_ratio"] = versions["fixed"]["ns"] / versions[other]["ns"] if versions[other]["ns"] else None
                row["fixed_" + other + "_allocation_delta"] = versions["fixed"]["bytes"] - versions[other]["bytes"]
        if paired and key in paired:
            row.update(paired[key])
        out.append(row)
    return out


def cold(a, path, repetitions):
    manifest = a.obj(ROOT / "cold-start/commits.json")
    if manifest:
        a.check(manifest.get("before") == BASELINE and manifest.get("fixed") == FIXED, "Cold manifest is not the frozen final comparison")
    rows, _ = a.jsonl(path)
    seen, raw, checks = set(), [], defaultdict(set)
    for r in rows:
        version, runtime, name, rep = r["Version"], r["Runtime"], r["Scenario"], r["Repetition"]
        major = runtime.split(".")[0]
        key = (major, name, rep, version)
        a.check(key not in seen, f"Duplicate cold point {key}")
        seen.add(key)
        a.check(r.get("TieredCompilation") == "0" and r.get("ReadyToRun") == "0", f"Cold environment mismatch {key}")
        a.check(r["Commit"] == {"before": BASELINE, "fixed": FIXED, "system": "System.Linq.Expressions"}.get(version), f"Cold commit mismatch {key}")
        checks[(runtime, name)].add((r["FirstValue"], r["Verification"]))
        a.check(math.isclose(r["CompileAndFirstNs"], r["CompileNs"] + r["FirstInvokeNs"], rel_tol=1e-12), f"Cold time sum mismatch {key}")
        a.check(r["CompileAndFirstBytes"] == r["CompileBytes"] + r["FirstInvokeBytes"], f"Cold allocation sum mismatch {key}")
        for phase, ns_key, bytes_key in (("cold_compile", "CompileNs", "CompileBytes"), ("cold_first_invoke", "FirstInvokeNs", "FirstInvokeBytes"), ("cold_compile_first", "CompileAndFirstNs", "CompileAndFirstBytes")):
            number(a, r[ns_key], f"{key}/{phase}/time")
            number(a, r[bytes_key], f"{key}/{phase}/allocation")
            raw.append(dict(runtime=runtime, flavor="standard", scenario=name, phase=phase, version=version, ns=r[ns_key], bytes=r[bytes_key]))
    expected = {(m, n, i, v) for m in ("8", "10") for n in COLD_NAMES for i in range(repetitions) for v in ("before", "fixed", "system")}
    a.need(seen == expected, f"Cold points {len(seen)}/{len(expected)}, missing={len(expected-seen)}, unexpected={len(seen-expected)}")
    for key, values in checks.items():
        a.check(len(values) == 1, f"Cold behavior disagreement {key}: {values}")
    summary = summarize(raw)
    return dict(points=len(rows), expected_points=len(expected), medians=summary, comparisons=compare(summary))


def paired(a, rounds):
    commits = a.obj(ROOT / "paired/final-commits.json")
    if commits:
        a.check(commits.get("before") == BASELINE and commits.get("fixed") == FIXED, "Paired manifest is not the frozen final comparison")
    source = (ROOT / "paired/Program.cs").read_text(encoding="utf-8-sig")
    names = re.findall(r'"([a-z0-9_]+)"', re.search(r"string\[\] names=new\[\]\{([^}]+)\}", source).group(1))
    result = []
    for tfm in ("net8.0", "net10.0"):
        path = ROOT / f"paired/final-{tfm}.jsonl"
        rows, diagnostics = a.jsonl(path, status=True)
        pass_names = []
        for line in diagnostics:
            match = re.fullmatch(r"PASS ([a-z0-9_]+) .+", line)
            a.check(match is not None, f"Unexpected paired diagnostic {tfm}: {line}")
            if match:
                pass_names.append(match.group(1))
        a.check(sorted(pass_names) == sorted(names), f"Paired correctness markers missing/duplicate {tfm}")
        pairs, raw = defaultdict(dict), []
        for r in rows:
            key = tuple(r[k] for k in ("Runtime", "Scenario", "Phase", "Round", "SampleIndex"))
            a.check(r["Version"] not in pairs[key], f"Duplicate paired row {tfm} {key} {r['Version']}")
            pairs[key][r["Version"]] = r
            number(a, r["NsPerOp"], str(key))
            number(a, r["BytesPerOp"], str(key))
            raw.append(dict(runtime=r["Runtime"], flavor="standard", scenario=r["Scenario"], phase=r["Phase"], version=r["Version"], ns=r["NsPerOp"], bytes=r["BytesPerOp"]))
        expected = {(n, p, rnd, i) for n in names for p in (BASE_PHASES | ({"activate", "nested_invoke"} if n.startswith("capture") else set())) for rnd in range(rounds) for i in range(101)}
        present = {(k[1], k[2], k[3], k[4]) for k in pairs}
        a.need(present == expected, f"Paired {tfm} groups {len(present)}/{len(expected)}, missing={len(expected-present)}, unexpected={len(present-expected)}")
        ratios = defaultdict(list)
        for key, versions in pairs.items():
            a.need(set(versions) == {"before", "fixed"}, f"Incomplete pair {tfm} {key}")
            if set(versions) != {"before", "fixed"}:
                continue
            b, f = versions["before"], versions["fixed"]
            a.check(b["Operations"] == f["Operations"] and b["Operations"] > 0, f"Paired operation mismatch {key}")
            a.check(key[0].split(".")[0] == tfm[3:].split(".")[0], f"Wrong runtime in {tfm}: {key[0]}")
            if b["NsPerOp"]:
                ratios[(key[0], "standard", key[1], key[2])].append(f["NsPerOp"] / b["NsPerOp"])
        pair_stats = {key: dict(pairs=len(v), paired_time_ratio=st.median(v)) for key, v in ratios.items()}
        medians = summarize(raw)
        comparisons = compare(medians, pair_stats)
        sidecar = path.with_suffix(".analysis.json")
        if not sidecar.exists():
            sidecar = Path(str(path) + ".analysis.json")
        if sidecar.exists():
            existing = a.obj(sidecar)
            index = {(r["runtime"], r["scenario"], r["phase"]): r for r in comparisons}
            a.need(len(existing) == len(index), f"Paired sidecar incomplete {sidecar.name}")
            for old in existing:
                key = (old["runtime"], old["scenario"], old["phase"])
                current = index.get(key)
                a.check(current is not None, f"Unexpected sidecar row {key}")
                if current:
                    for field in ("before_ns", "fixed_ns", "before_bytes", "fixed_bytes", "paired_time_ratio"):
                        a.check(math.isclose(old[field], current[field], rel_tol=1e-9, abs_tol=1e-9), f"Paired sidecar disagreement {key}/{field}")
        log = ROOT / f"paired/final-{tfm}.log"
        if not log.exists():
            log = ROOT / f"paired/final-{tfm}.stderr.log"
        log_text = a.text(log)
        if log_text:
            a.check("FAIL" not in log_text and "Unhandled" not in log_text, f"Unexpected paired failure log {tfm}")
        result.append(dict(target=tfm, rows=len(rows), expected_pairs=len(expected), medians=medians, comparisons=comparisons))
    return result


def framework(a, directory):
    config = a.obj(directory / "run.json")
    manifest = a.obj(directory / "manifest.json")
    if not config:
        return dict(medians=[], comparisons=[], statuses=[])
    if manifest:
        a.check(manifest.get("Before") == BASELINE and manifest.get("Current") == FIXED, "Framework manifest is not the frozen final comparison")
    a.need((directory / "completed-utc.txt").exists(), "Framework run lacks completion marker")
    a.check(not config.get("VerifyOnly"), "Framework run contains verification only, not phase measurements")
    versions = ["before", "current"] + (["system"] if config.get("IncludeSystem") else [])
    raw, statuses, clr_versions = [], [], set()
    for rnd in range(config["Rounds"]):
        for flavor in config["Flavors"]:
            for name in config["Names"]:
                for version in versions:
                    stem = f"net472-{flavor}-{rnd}-{version}-{name}"
                    status_rows, diagnostic = a.jsonl(directory / (stem + ".status.jsonl"), status=True)
                    rows, _ = a.jsonl(directory / (stem + ".jsonl"))
                    a.need(bool(status_rows), f"Framework missing status {stem}")
                    if not status_rows:
                        continue
                    status = status_rows[-1]
                    statuses.append(dict(round=rnd, **status))
                    flag = status["Status"]
                    a.check(flag in {"PASS", "N/A", "ORACLE_N/A"}, f"Unexpected Framework status {stem}: {status}")
                    if flag == "N/A":
                        a.check(version == "before" and name in BASELINE_NA, f"Unexpected baseline exclusion {stem}: {status}")
                    if flag != "PASS":
                        a.check(not rows, f"Excluded Framework case retained partial samples {stem}")
                        continue
                    a.check(not diagnostic, f"Framework PASS has raw failure diagnostics {stem}: {diagnostic[:2]}")
                    expected = {(p, i) for p in (BASE_PHASES | ({"activate", "nested_invoke"} if name.startswith("capture") else set())) for i in range(7)}
                    found = set()
                    for r in rows:
                        key = (r["Phase"], r["SampleIndex"])
                        a.check(key not in found, f"Duplicate Framework sample {stem}/{key}")
                        found.add(key)
                        a.check((r["Version"], r["Flavor"], r["Scenario"], r["Round"]) == (version, flavor, name, rnd), f"Wrong Framework identity {stem}")
                        number(a, r["NsPerOp"], stem)
                        number(a, r["BytesPerOp"], stem)
                        clr_versions.add(r["Runtime"])
                        raw.append(dict(runtime=".NET Framework 4.8.1", flavor=flavor, scenario=name, phase=r["Phase"], version="fixed" if version == "current" else version, ns=r["NsPerOp"], bytes=r["BytesPerOp"]))
                    a.need(found == expected, f"Framework samples {stem}: {len(found)}/{len(expected)}")
    medians = summarize(raw)
    return dict(reported_clr_versions=sorted(clr_versions), statuses=statuses, medians=medians, comparisons=compare(medians))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cold", type=Path, default=ROOT / "cold-start/cold-final20d.jsonl")
    parser.add_argument("--cold-repetitions", type=int, default=9)
    parser.add_argument("--paired-rounds", type=int, default=1)
    parser.add_argument("--framework-dir", type=Path, default=ROOT / "framework-phase/results/final20d")
    parser.add_argument("--output", type=Path, default=ROOT / "extra-analysis")
    parser.add_argument("--integration-output", type=Path, default=ROOT / "extra-analysis.json")
    parser.add_argument("--allow-pending", action="store_true")
    parser.add_argument("--time-threshold", type=float, default=1.03)
    args = parser.parse_args()
    audit = Audit()
    sections = {}
    for name, action in (("cold", lambda: cold(audit, args.cold, args.cold_repetitions)), ("framework", lambda: framework(audit, args.framework_dir)), ("paired", lambda: paired(audit, args.paired_rounds))):
        try:
            sections[name] = action()
        except Exception as exc:
            audit.errors.append(f"{name}: {type(exc).__name__}: {exc}")
    residuals, comparison_groups = [], defaultdict(list)
    for section, data in sections.items():
        for part in data if isinstance(data, list) else [data]:
            for r in part.get("comparisons", []):
                comparison_groups[(section, r["runtime"], r["flavor"], r["phase"])].append(r)
                ratio = r.get("paired_time_ratio", r.get("fixed_before_time_ratio"))
                delta = r.get("fixed_before_allocation_delta")
                if (ratio is not None and ratio > 1) or (delta is not None and delta > 0.5):
                    residuals.append(dict(section=section, **r, time_above_threshold=ratio is not None and ratio > args.time_threshold,
                                          allocation_increase=delta is not None and delta > 0.5))
    totals = []
    for key, values in sorted(comparison_groups.items()):
        matched = [r for r in values if "fixed_before_allocation_delta" in r]
        ratios = [r.get("paired_time_ratio", r.get("fixed_before_time_ratio")) for r in matched]
        ratios = [r for r in ratios if r is not None]
        totals.append(dict(zip(("section", "runtime", "flavor", "phase"), key), scenarios=len(values),
                           before_fixed_comparisons=len(matched), time_above_threshold=sum(r > args.time_threshold for r in ratios),
                           median_scenario_time_ratio=st.median(ratios) if ratios else None,
                           allocation_increases=sum(r["fixed_before_allocation_delta"] > 0.5 for r in matched),
                           allocation_decreases=sum(r["fixed_before_allocation_delta"] < -0.5 for r in matched),
                           allocation_unchanged=sum(abs(r["fixed_before_allocation_delta"]) <= 0.5 for r in matched)))
    complete = not audit.errors and not audit.pending
    report = dict(complete=complete, allow_pending=args.allow_pending, expected_fixed_commit=FIXED,
                  errors=audit.errors, pending=audit.pending, inputs=audit.inputs, sections=sections, residuals=residuals, totals=totals,
                  caveats=["Cold and Framework ratios are ratios of medians from separate processes; paired_time_ratio is a median of matched sample ratios.",
                           "A measured ratio above one is an observed residual, not by itself proof of a repeatable regression. Construct phase is harness tree creation.",
                           "Cold compile_and_first reports phase shifts honestly; compile-only changes are not overall startup improvements.",
                           "Framework +16B EH constructor cost was independently isolated; see framework-eh-allocation/RESULTS.txt."])
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "summary.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    integration = dict(schema_version=1, complete=complete, expected_fixed_commit=FIXED,
                       errors=audit.errors, pending=audit.pending, inputs=audit.inputs,
                       cold=sections.get("cold", {}).get("medians", []),
                       framework=sections.get("framework", {}).get("medians", []),
                       paired=[r for part in sections.get("paired", []) for r in part["medians"]],
                       paired_summaries=[r for part in sections.get("paired", []) for r in part["comparisons"]],
                       comparisons=dict(cold=sections.get("cold", {}).get("comparisons", []),
                                        framework=sections.get("framework", {}).get("comparisons", [])),
                       framework_statuses=sections.get("framework", {}).get("statuses", []),
                       framework_reported_clr_versions=sections.get("framework", {}).get("reported_clr_versions", []),
                       residuals=residuals, totals=totals, caveats=report["caveats"])
    args.integration_output.write_text(json.dumps(integration, indent=2), encoding="utf-8")
    for section, data in sections.items():
        (args.output / (section + ".json")).write_text(json.dumps(data, indent=2), encoding="utf-8")
    (args.output / "residuals.json").write_text(json.dumps(residuals, indent=2), encoding="utf-8")
    fields = ["section", "runtime", "flavor", "scenario", "phase", "before_ns", "fixed_ns", "system_ns", "before_bytes", "fixed_bytes", "system_bytes", "fixed_before_time_ratio", "paired_time_ratio", "fixed_before_allocation_delta", "time_above_threshold", "allocation_increase"]
    with (args.output / "residuals.csv").open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(residuals)
    print(f"complete={complete} errors={len(audit.errors)} pending={len(audit.pending)} residual_rows={len(residuals)}")
    print(f"Saved {args.output / 'summary.json'}")
    print(f"Saved integration rows {args.integration_output}")
    for message in (audit.errors + audit.pending)[:12]:
        print(message)
    return 1 if audit.errors or (audit.pending and not args.allow_pending) else 0


if __name__ == "__main__":
    sys.exit(main())
