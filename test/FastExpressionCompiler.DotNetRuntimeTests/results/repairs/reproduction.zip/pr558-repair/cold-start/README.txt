Cold first-call diagnostic (standard expressions; .NET 8 and .NET 10)

Prepare.ps1 -FixedCommit <final-hash>
Builds frozen before-PR e4c232da and selected fixed sources only. It runs no measurements.

For a quiet execution window, set these in the caller, matching the warm paired runs:
$env:DOTNET_TieredCompilation='0'
$env:DOTNET_ReadyToRun='0'
./Invoke-Cold.ps1 -IncludeSystem -Repetitions 9 -Output cold-final.jsonl

Invoke-Cold refuses an existing output file and requires those environment values.
It rotates and reverses version launch order, but every version/scenario/sample gets a new process.
The selected commit hashes are recorded in commits.json and every result row.

Construction uses only System.Linq.Expressions and precedes measurement.
FEC versions enter their first compiler call behind an uninlined boundary inside the compile phase.
-IncludeSystem adds a separate SystemCompileFirst uninlined path using the fixed runner.
The System point never calls FEC; its Version is system and Commit is System.Linq.Expressions.
Measurement includes genuine one-time FEC initialization, reflection, pools and module/JIT costs.
No FEC warmup, anonymous-EH workaround, assembly-policy alteration or hidden warm run occurs.
Process launch itself and tree construction are outside the measured phases.
Clock/allocation-counter infrastructure is touched before either measured phase.

FirstInvoke includes the uninlined typed invocation wrapper's first call and dynamic-method JIT.
For capture cases it includes owner activation, child closure/delegate allocation and first child call.
It allocates no Driver/Action wrapper closure. System oracle compilation and validation happen afterward.
All shapes are shared with the baseline-valid warm benchmark matrix.

Report Compile, FirstInvoke and CompileAndFirst together: movement of cost between phases is not
an overall improvement. Cold samples are noisy diagnostics; show medians/spread and allocations,
not a single run as a precision performance claim. Warm and cold costs are separate results.
