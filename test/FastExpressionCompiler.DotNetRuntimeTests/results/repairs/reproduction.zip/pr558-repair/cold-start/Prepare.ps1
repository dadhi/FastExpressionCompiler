param([string]$FixedCommit='HEAD',[string]$BaselineCommit='e4c232da',[string]$Repository='C:\Data\Git\Github\FastExpressionCompiler')
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$manifest=@{system='System.Linq.Expressions'}
foreach($entry in @(@('before',$BaselineCommit),@('fixed',$FixedCommit))){
 $version=$entry[0]
 $commit=(& git -C $Repository rev-parse $entry[1]).Trim()
 if($LASTEXITCODE -ne 0){throw "Cannot resolve $($entry[1])"}
 $manifest[$version]=$commit
 $library=Join-Path $root "$version/library"
 New-Item -ItemType Directory -Force $library|Out-Null
 foreach($name in @('FastExpressionCompiler.cs','ImTools.cs','ILReader.cs','TestTools.cs')){
  $source=& git -C $Repository show "${commit}:src/FastExpressionCompiler/$name"
  if($LASTEXITCODE -ne 0){throw "Cannot export $name from $commit"}
  [IO.File]::WriteAllText((Join-Path $library $name),($source -join "`n"))
 }
 '<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><AssemblyName>FecCold.{VERSION}</AssemblyName></PropertyGroup></Project>'.Replace('{VERSION}',$version)|Set-Content (Join-Path $library 'Library.csproj')
 '<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFrameworks>net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><EnableDefaultCompileItems>false</EnableDefaultCompileItems></PropertyGroup><ItemGroup><Compile Include="../Program.cs"/><ProjectReference Include="library/Library.csproj"/></ItemGroup></Project>'|Set-Content (Join-Path $root "$version/Runner.csproj")
 & dotnet build (Join-Path $root "$version/Runner.csproj") -c Release --nologo -v:q -m:1 -nodeReuse:false *> (Join-Path $root "build-$version.log")
 if($LASTEXITCODE -ne 0){Get-Content (Join-Path $root "build-$version.log") -Tail 30;throw "Build failed for $version"}
}
$manifest|ConvertTo-Json|Set-Content (Join-Path $root 'commits.json')
Write-Output 'Cold diagnostic built only; no benchmark processes executed.'
