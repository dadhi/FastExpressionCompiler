param([switch]$IncludeSystem,[int]$Repetitions=9,[string[]]$Runtimes=@('net8.0','net10.0'),[string[]]$Scenarios=@('add','balanced256','blocks32','nested_mixed128','try_catch','try_finally','capture1','capture8','capture_mutable','capture_mutable_reference'),[string]$Output='cold-results.jsonl')
$ErrorActionPreference='Stop'
if($env:DOTNET_TieredCompilation -ne '0' -or $env:DOTNET_ReadyToRun -ne '0'){throw 'Caller must set DOTNET_TieredCompilation=0 and DOTNET_ReadyToRun=0 to match the warm benchmark environment.'}
$root=$PSScriptRoot
$commits=Get-Content (Join-Path $root 'commits.json') -Raw|ConvertFrom-Json
$outputPath=if([IO.Path]::IsPathRooted($Output)){$Output}else{Join-Path $root $Output}
if(Test-Path -LiteralPath $outputPath){throw "Output already exists: $outputPath"}
foreach($runtime in $Runtimes){foreach($scenario in $Scenarios){for($repetition=0;$repetition -lt $Repetitions;++$repetition){
 # Rotate and reverse launch order; every point still uses a fresh process.
 $baseVersions=if($IncludeSystem){@('before','fixed','system')}else{@('before','fixed')}
 $versions=@(for($position=0;$position -lt $baseVersions.Count;++$position){$baseVersions[($position+$repetition)%$baseVersions.Count]})
 if($IncludeSystem -and $repetition%2 -eq 1){[Array]::Reverse($versions)}
 foreach($version in $versions){
  $runnerVersion=if($version -eq 'system'){'fixed'}else{$version}
  $commit=if($version -eq 'system'){'System.Linq.Expressions'}else{$commits.$version}
  $runner=Join-Path $root "$runnerVersion/bin/Release/$runtime/Runner.dll"
  $row=& dotnet $runner $version $commit $scenario $repetition
  if($LASTEXITCODE -ne 0){throw "Cold probe failed: $runtime $scenario $version repetition=$repetition"}
  $row|Add-Content -LiteralPath $outputPath
 }
};Write-Output "Completed $runtime $scenario"}}
Write-Output "Saved $outputPath"
