from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
w=Path(__file__).resolve().parent
repo=Path(r'C:\Data\Git\Github\FastExpressionCompiler')
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()==''
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
codes={}
def step(name,cmd,outfile=None,allow_failure=False):
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==sha
 assert subprocess.run(['git','diff','--quiet','HEAD','--','src','test'],cwd=repo).returncode==0
 print('Starting '+name,flush=True);start=time.time()
 with (outfile or w/('latest-'+name+'.log')).open('w',encoding='utf-8') as out:
  p=subprocess.run([str(x) for x in cmd],cwd=w.parents[1],env=env,stdout=out,stderr=subprocess.STDOUT)
 codes[name]={'exitCode':p.returncode,'seconds':time.time()-start}
 (w/'latest-runs.json').write_text(json.dumps(codes,indent=2))
 print(name+': '+str(codes[name]),flush=True)
 if p.returncode and not allow_failure:raise SystemExit(p.returncode)

(w/'latest-source.json').write_text(json.dumps({'source':sha,'baseline':'e4c232da108d98790f0ca73f23ec90756da0cad7','published':'b8f8b38bc44367f129b49a55b2b2043e81b04ccb','startedUtc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())},indent=2))
step('validation',['python',w/'validate.py'])
# Immutable before/published binaries are retained; rebuild only the changed version.
s=(w/'bench.py').read_text().replace(' for version,commit in commits.items():\n',' for version,commit in commits.items():\n  if version != "fixed":continue\n')
(w/'build-latest.py').write_text(s)
step('modern-build',['python',w/'build-latest.py','build'])
step('paired-prepare',['python',w/'paired-setup.py','--micro','--before=e4c232da','--fixed='+sha])
shutil.copy2(w/'paired/commits.json',w/'paired/final-commits.json')
step('paired-build',['dotnet','build',w/'paired/Runner.csproj','-c','Release','--nologo','-v:q','-m:1','-nodeReuse:false'])
step('framework-build',['pwsh','-NoProfile','-File',w/'framework-phase/Prepare.ps1','-CurrentCommit',sha])
step('cold-build',['pwsh','-NoProfile','-File',w/'cold-start/Prepare.ps1','-FixedCommit',sha])
for folder in ['cold-start','framework-phase']:
 hashes={str(p.relative_to(w/folder)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (w/folder).rglob('*') if p.is_file() and p.suffix in ('.exe','.dll') and 'bin' in p.parts and 'obj' not in p.parts}
 (w/folder/'latest-assembly-hashes.json').write_text(json.dumps(hashes,indent=2))
 (w/folder/('binary-hashes.json' if folder=='cold-start' else 'hashes-final.json')).write_text(json.dumps(hashes,indent=2))
step('modern-matrix',['python',w/'bench.py','run'])
for runtime in ['net8.0','net10.0']:
 step('paired-'+runtime,['dotnet',w/('paired/bin/Release/'+runtime+'/Runner.dll'),'0'],w/('paired/final-'+runtime+'.jsonl'))
# Remeasure every changed Framework case. Before/System controls are immutable
# independent-process samples from the original broad pass, preserved unchanged.
s=(w/'framework-phase/Run-Paired.ps1').read_text().replace("if ($IncludeSystem) { $versions += 'system' }","$versions = @('current')")
(w/'framework-phase/Run-Current.ps1').write_text(s)
step('framework-current',['pwsh','-NoProfile','-File',w/'framework-phase/Run-Current.ps1','-Rounds','2','-RunLabel','latest-current'])
combined=w/'framework-phase/results/final-current';combined.mkdir(exist_ok=True)
old=w/'framework-phase/results/final20d';new=w/'framework-phase/results/latest-current'
for p in old.glob('*jsonl'):
 if '-before-' in p.name or '-system-' in p.name:shutil.copy2(p,combined/p.name)
for p in new.glob('*jsonl'):shutil.copy2(p,combined/p.name)
shutil.copy2(new/'manifest.json',combined/'manifest.json')
manifest=json.loads((old/'run.json').read_text(encoding='utf-8-sig'))
manifest['SourceRuns']={'beforeAndSystem':'final20d (earlier independent-process controls; unchanged binaries)','current':'latest-current (fresh processes, source '+sha+')'}
manifest['TimingCaveat']='Before/System controls and current were measured in separate chronological runs; Framework time ratios are descriptive, not paired causal estimates.'
(combined/'run.json').write_text(json.dumps(manifest,indent=2))
shutil.copy2(new/'completed-utc.txt',combined/'completed-utc.txt')
step('cold',['pwsh','-NoProfile','-File',w/'cold-start/Invoke-Cold.ps1','-Repetitions','9','-IncludeSystem','-Output','cold-final-latest.jsonl'])
step('modern-analysis',['python',w/'check.py'])
step('paired-analysis',['python',w/'paired-analyze.py',w/'paired/final-net8.0.jsonl',w/'paired/final-net10.0.jsonl'])
s=(w/'analyze-extra.py').read_text().replace('FIXED = "20d3174b52c86a680ce47f9a5e3454e8a39f5fcd"','FIXED = '+repr(sha)).replace('framework-phase/results/final20d','framework-phase/results/final-current').replace('cold-start/cold-final20d.jsonl','cold-start/cold-final-latest.jsonl')
(w/'analyze-latest.py').write_text(s)
step('extra-analysis',['python',w/'analyze-latest.py'])
step('actual-inner-il',['pwsh','-NoProfile','-File',w/'tools/Dump-Capture8-Inner.ps1','-OutputDirectory',w/'capture8-finalized-latest'])
print('FINAL SOURCE '+sha,flush=True)
