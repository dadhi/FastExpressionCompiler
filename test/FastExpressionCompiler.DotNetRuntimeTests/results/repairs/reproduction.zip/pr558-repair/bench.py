from pathlib import Path
import subprocess,json,os,sys,time,re
root=Path(__file__).resolve().parent/'bench';root.mkdir(exist_ok=True)
repo=Path(r'C:\Data\Git\Github\FastExpressionCompiler')
commits={'before':'e4c232da108d98790f0ca73f23ec90756da0cad7','reviewed':'b8f8b38bc44367f129b49a55b2b2043e81b04ccb','fixed':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()}
def save(path,data):
 if isinstance(data,str):data=data.encode()
 if not path.exists() or path.read_bytes()!=data:path.write_bytes(data)
def build():
 source=(root.parents[1]/'pr558-perf'/'Program.cs').read_text()
 source=source.replace('case "nested_blocks8":','case "nested_mixed32":case "nested_mixed128":{int n=int.Parse(name.Substring("nested_mixed".Length));for(int i=0;i<n;i++)body=E.Condition(E.GreaterThan(x,E.Constant(-9)),E.Block(body),E.Constant(0));break;}\n   case "nested_eh8":case "nested_eh32":{int n=int.Parse(name.Substring("nested_eh".Length));for(int i=0;i<n;i++)body=E.TryFinally(body,E.Empty());break;}\n   case "nested_blocks8":')
 source=source.replace('"nested_blocks128"}).ToArray()', '"nested_blocks128","nested_mixed32","nested_mixed128","nested_eh8","nested_eh32"}).ToArray()')
 source=source.replace('public int Add(int x)=>Value+x;', 'public int Add(int x)=>Value+x; public static int Read(Box b)=>b.Value;')
 source=source.replace('public static class Program {', 'public class Holder { public Box Box; public Holder(Box box){Box=box;} }\npublic static class Program {')
 source=source.replace('case "capture_reference":', '''case "capture_call":case "capture_ctor":case "capture_invoke":case "capture_try":case "capture_array":{
   var v=E.Variable(typeof(Box),"box");X read=E.Field(v,"Value");
   if(name=="capture_call")read=E.Call(typeof(Box).GetMethod("Read"),v);
   if(name=="capture_ctor")read=E.Field(E.Field(E.New(typeof(Holder).GetConstructor(new[]{typeof(Box)}),v),"Box"),"Value");
   if(name=="capture_invoke")read=E.Invoke(E.Constant((Func<Box,int>)Box.Read),v);
   if(name=="capture_try")read=E.TryFinally(read,E.Empty());
   if(name=="capture_array")read=E.Field(E.ArrayIndex(E.NewArrayInit(typeof(Box),v),E.Constant(0)),"Value");
   return E.Lambda<Func<int,Func<int>>>(E.Block(new[]{v},E.Assign(v,E.Constant(new Box(7))),E.Lambda<Func<int>>(read)),x);
   }
   case "capture_reference":''')
 source=source.replace('"nested_eh32"}).ToArray()', '"nested_eh32","capture_call","capture_ctor","capture_invoke","capture_try","capture_array"}).ToArray()')
 source=source.replace('case "capture1":', 'case "capture_mutable": return E.Lambda<Func<int,Func<int>>>(E.Lambda<Func<int>>(E.PreIncrementAssign(x)),x);\n   case "capture1":')
 source=source.replace('"capture_array"}).ToArray()', '"capture_array","capture_mutable"}).ToArray()')
 source=source.replace('if(result is Func<int> nested) result=nested();', 'if(result is Func<int> nested) result=nested()+":"+nested();')
 source=source.replace('Measure(version,flavor,name,"invoke",round,Driver(d));', '''Measure(version,flavor,name,"invoke",round,Driver(d));
    if(d is Func<int,Func<int>> factory) {
     Action<int> activate=n=>{for(int i=0;i<n;i++)sink=factory(3);};
     var inner=factory(3); Action<int> nestedInvoke=n=>{long sum=0;for(int i=0;i<n;i++)sum+=inner();checksum=sum;};
     Measure(version,flavor,name,"activate",round,activate);
     Measure(version,flavor,name,"nested_invoke",round,nestedInvoke);
    }''')
 source=source.replace('public class Holder {', 'public struct Counter { public int Value; public Counter(int value){Value=value;} public int Increment()=>++Value; }\npublic struct LargeCounter { public int Value; public long A,B,C,D; public LargeCounter(int value){this=default;Value=value;} public int Increment()=>++Value; }\npublic class Holder {')
 source=source.replace('static object sink;', 'public static int AddRef(ref int value)=>++value;\n static object sink;')
 source=source.replace('case "capture_mutable":', '''case "capture_byref_call": return E.Lambda<Func<int,Func<int>>>(E.Lambda<Func<int>>(E.Call(typeof(Program).GetMethod("AddRef"),x)),x);
   case "capture_struct":case "capture_large_struct":{
    var type=name=="capture_struct"?typeof(Counter):typeof(LargeCounter);var v=E.Variable(type);
    return E.Lambda<Func<int,Func<int>>>(E.Block(new[]{v},E.Assign(v,E.New(type.GetConstructor(new[]{typeof(int)}),x)),E.Lambda<Func<int>>(E.Call(v,type.GetMethod("Increment")))),x);
   }
   case "capture_mutable":''')
 source=source.replace('"capture_mutable"}).ToArray()', '"capture_mutable","capture_byref_call","capture_struct","capture_large_struct"}).ToArray()')
 source=source.replace('public class Holder {', 'public class DelegateHolder { public readonly Func<int> Reader; public DelegateHolder(Func<int> reader){Reader=reader;} }\npublic class Holder {')
 source=source.replace('case "capture_mutable":', '''case "capture_mutable_reference":case "capture_mutable_reference_ctor":case "capture_mutable_reference_array":{
    var v=E.Variable(typeof(string),"text");
    var toggle=E.Assign(v,E.Condition(E.Equal(v,E.Constant("first")),E.Constant("second"),E.Constant("first")));
    X child=E.Lambda<Func<int>>(E.Block(toggle,E.Property(v,"Length")));
    if(name=="capture_mutable_reference_ctor")child=E.Field(E.New(typeof(DelegateHolder).GetConstructors()[0],child),"Reader");
    if(name=="capture_mutable_reference_array")child=E.ArrayIndex(E.NewArrayInit(typeof(Func<int>),child),E.Constant(0));
    return E.Lambda<Func<int,Func<int>>>(E.Block(new[]{v},E.Assign(v,E.Constant("first")),child),x);
   }
   case "capture_mutable":''')
 source=source.replace('"capture_large_struct"}).ToArray()', '"capture_large_struct","capture_mutable_reference","capture_mutable_reference_ctor","capture_mutable_reference_array"}).ToArray()')
 save(root/'Program.cs',source)
 if '--source-only' in sys.argv:return
 for version,commit in commits.items():
  for flavor in ('standard','light'):
   dest=root/version/flavor;dest.mkdir(parents=True,exist_ok=True)
   paths=['src/FastExpressionCompiler/'+f for f in ('FastExpressionCompiler.cs','ImTools.cs','ILReader.cs','TestTools.cs')]
   if flavor=='light':paths+=['src/FastExpressionCompiler.LightExpression/'+f for f in ('Expression.cs','ExpressionVisitor.cs','FlatExpression.cs')]
   for p in paths:save(dest/Path(p).name,subprocess.check_output(['git','show',commit+':'+p],cwd=repo))
   save(dest/'Library.csproj','<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><AssemblyName>FecSnapshot.'+flavor+'</AssemblyName><Optimize>true</Optimize>'+('<DefineConstants>LIGHT_EXPRESSION</DefineConstants>' if flavor=='light' else '')+'</PropertyGroup></Project>')
   save(dest/'Harness.csproj','<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFrameworks>net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><EnableDefaultCompileItems>false</EnableDefaultCompileItems><Optimize>true</Optimize>'+('<DefineConstants>LIGHT</DefineConstants>' if flavor=='light' else '')+'</PropertyGroup><ItemGroup><Compile Include="../../Program.cs"/><ProjectReference Include="Library.csproj"/></ItemGroup></Project>')
   with (dest/'build.log').open('w') as log:p=subprocess.run(['dotnet','build',str(dest/'Harness.csproj'),'-c','Release','--nologo','-v:q','-m:1'],stdout=log,stderr=subprocess.STDOUT)
   print('built',version,flavor,p.returncode,flush=True)
   if p.returncode:print((dest/'build.log').read_text());raise SystemExit(1)
 (root/'commits.json').write_text(json.dumps(commits,indent=2))
def run():
 env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
 names=sys.argv[2:]
 if not names:
  source=(root/'Program.cs').read_text()
  names=re.findall(r'"([a-z0-9_]+)"',re.search(r'string\[\] names=\{([^}]+)\}',source).group(1))
  names+=re.findall(r'"([a-z0-9_]+)"',re.search(r'names=names.Concat\(new\[\]\{([^}]+)\}',source).group(1))
 for runtime in ('net10.0','net8.0'):
  for flavor in ('standard','light'):
   for round,versions in enumerate([('before','reviewed','fixed','system'),('system','fixed','reviewed','before')]):
    for version in versions:
     tag=f'{runtime}-{flavor}-{round}-{version}';folder=root/('fixed' if version=='system' else version)/flavor/'bin'/'Release'/runtime
     with (root/(tag+'.jsonl')).open('w') as out,(root/(tag+'.log')).open('w') as log:
      start=time.time();p=subprocess.run(['dotnet',str(folder/'Harness.dll'),version,flavor,str(round)]+[n for n in names if version!='before' or n not in ('capture_byref_call','capture_struct','capture_large_struct')],stdout=out,stderr=log,env=env)
     print(tag,p.returncode,f'{time.time()-start:.1f}s',flush=True)
     if p.returncode:raise SystemExit(p.returncode)
if sys.argv[1]=='build':build()
else:run()
