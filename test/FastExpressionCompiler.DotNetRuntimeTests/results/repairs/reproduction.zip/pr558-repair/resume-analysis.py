from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'final-pipeline.py').read_text()
s=s.replace('codes={}',"codes=json.loads((w/'latest-runs.json').read_text())")
a=s.index("(w/'latest-source.json').write_text")
b=s.index("step('paired-analysis'")
s=s[:a]+s[b:]
exec(compile(s,str(p/'final-pipeline.py'),'exec'))
