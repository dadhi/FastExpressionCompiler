from pathlib import Path
import json
p=Path(__file__).resolve().parent
s=(p/'bench.py').read_text()
start=s.index(' source=(root.parents[1]')
end=s.index(" save(root/'Program.cs',source)",start)
s=s[:start]+" source=(Path(__file__).resolve().parent/'Program.cs').read_text()\n"+s[end:]
s=s.replace("root=Path(__file__).resolve().parent/'bench';root.mkdir(exist_ok=True)","root=Path.cwd()/'fec-pr558-measurements';root.mkdir(exist_ok=True)")
s=s.replace("repo=Path(r'C:\\Data\\Git\\Github\\FastExpressionCompiler')","repo=Path(subprocess.check_output(['git','rev-parse','--show-toplevel'],text=True).strip())")
fixed=json.loads((p/'bench/commits.json').read_text())['fixed']
s=s.replace("'fixed':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()","'fixed':"+repr(fixed))
(p/'measure-portable.py').write_text(s)
