param(
    [string]$RunnerDirectory = (Join-Path $PSScriptRoot '../paired/bin/Release/net8.0'),
    [string]$OutputDirectory = (Join-Path $PSScriptRoot '../capture8-inner-dump')
)
$ErrorActionPreference = 'Stop'
$runnerPath = [IO.Path]::GetFullPath($RunnerDirectory)
$outputPath = [IO.Path]::GetFullPath($OutputDirectory)
[IO.Directory]::CreateDirectory($outputPath) | Out-Null
$flags = [Reflection.BindingFlags]'Public, NonPublic, Static, Instance'
# Use a fresh pwsh process so previous assembly loads cannot select stale snapshots.
$before = [Reflection.Assembly]::LoadFrom((Join-Path $runnerPath 'FecPaired.before.dll'))
$fixed = [Reflection.Assembly]::LoadFrom((Join-Path $runnerPath 'FecPaired.fixed.dll'))
$runner = [Reflection.Assembly]::LoadFrom((Join-Path $runnerPath 'Runner.dll'))
$build = $runner.GetType('Program', $true).GetMethod('Build', $flags)
$tree = $build.Invoke($null, [object[]]@('capture8'))
$lines = [Collections.Generic.List[string]]::new()
$lines.Add('Runtime=' + [Environment]::Version)
$lines.Add('Runner=' + $runnerPath)
function Format-ScopeToken([object]$token) {
    if ($null -eq $token) { return '<null>' }
    if ($token -is [Type]) { return 'TYPE ' + $token.FullName }
    if ($token -is [Reflection.MemberInfo]) { return 'MEMBER ' + $token.DeclaringType.FullName + '::' + $token.ToString() }
    if ($token -is [RuntimeTypeHandle]) { return 'TYPE ' + [Type]::GetTypeFromHandle($token).FullName }
    if ($token -is [RuntimeFieldHandle]) { return 'FIELD ' + [Reflection.FieldInfo]::GetFieldFromHandle($token).ToString() }
    if ($token -is [RuntimeMethodHandle]) { return 'METHOD ' + [Reflection.MethodBase]::GetMethodFromHandle($token).ToString() }
    if ($token -is [byte[]]) { return 'SIGNATURE ' + [Convert]::ToHexString($token) }
    $privateFields = @($token.GetType().GetFields([Reflection.BindingFlags]'Instance,Public,NonPublic'))
    $contextField = @($privateFields | Where-Object FieldType -eq ([RuntimeTypeHandle]))
    $fieldHandle = @($privateFields | Where-Object FieldType -eq ([RuntimeFieldHandle]))
    $methodHandle = @($privateFields | Where-Object FieldType -eq ([RuntimeMethodHandle]))
    if ($contextField.Count -eq 1 -and $fieldHandle.Count -eq 1) {
        $fieldInfo = [Reflection.FieldInfo]::GetFieldFromHandle($fieldHandle[0].GetValue($token), $contextField[0].GetValue($token))
        return 'FIELD ' + $fieldInfo.DeclaringType.FullName + '::' + $fieldInfo.ToString()
    }
    if ($contextField.Count -eq 1 -and $methodHandle.Count -eq 1) {
        $methodInfo = [Reflection.MethodBase]::GetMethodFromHandle($methodHandle[0].GetValue($token), $contextField[0].GetValue($token))
        return 'METHOD ' + $methodInfo.DeclaringType.FullName + '::' + $methodInfo.ToString()
    }
    return $token.GetType().FullName + ': ' + $token.ToString()
}
function Get-ReferencedTokens([byte[]]$code) {
    $opcodes = @{}
    foreach ($f in [Reflection.Emit.OpCodes].GetFields([Reflection.BindingFlags]'Public,Static')) {
        if ($f.FieldType -eq [Reflection.Emit.OpCode]) {
            $op = [Reflection.Emit.OpCode]$f.GetValue($null)
            $opcodes[([int]$op.Value -band 65535)] = $op
        }
    }
    $used = [Collections.Generic.HashSet[int]]::new()
    for ($offset=0; $offset -lt $code.Length;) {
        $number = [int]$code[$offset]; ++$offset
        if ($number -eq 254) { $number = 65024 -bor [int]$code[$offset]; ++$offset }
        if (-not $opcodes.ContainsKey($number)) { throw "Unknown opcode $number" }
        $operand = $opcodes[$number].OperandType.ToString()
        switch ($operand) {
            'InlineNone' { }
            { $_ -in @('ShortInlineBrTarget','ShortInlineI','ShortInlineVar') } { ++$offset }
            'InlineVar' { $offset += 2 }
            { $_ -in @('InlineI','InlineBrTarget','ShortInlineR') } { $offset += 4 }
            { $_ -in @('InlineI8','InlineR') } { $offset += 8 }
            'InlineSwitch' { $count = [BitConverter]::ToInt32($code,$offset); $offset += 4 + 4 * $count }
            { $_ -in @('InlineField','InlineMethod','InlineSig','InlineString','InlineTok','InlineType') } {
                $used.Add([BitConverter]::ToInt32($code,$offset) -band 16777215) | Out-Null
                $offset += 4
            }
            default { throw "Unsupported operand $operand" }
        }
    }
    return @($used | Sort-Object)
}
function Get-FinalizedMethodText([Reflection.MethodInfo]$method) {
    $resolver = $null
    foreach ($fieldName in @('_resolver','m_resolver')) {
        $field = $method.GetType().GetField($fieldName, [Reflection.BindingFlags]'Instance,NonPublic')
        if ($null -ne $field) { $resolver = $field.GetValue($method); break }
    }
    if ($null -eq $resolver) { throw 'No finalized DynamicMethod resolver found' }
    $resolverFields = @($resolver.GetType().GetFields([Reflection.BindingFlags]'Instance,NonPublic,Public'))
    $codeField = @($resolverFields | Where-Object { $_.Name -in @('m_code','_code') })
    $scopeField = @($resolverFields | Where-Object { $_.Name -in @('m_scope','_scope') })
    if ($codeField.Count -ne 1 -or $scopeField.Count -ne 1) { throw ('Resolver fields: ' + (($resolverFields.Name) -join ',')) }
    $code = [byte[]]$codeField[0].GetValue($resolver)
    $scope = $scopeField[0].GetValue($resolver)
    $tokenFields = @($scope.GetType().GetFields([Reflection.BindingFlags]'Instance,NonPublic,Public') | Where-Object { $_.Name -in @('m_tokens','_tokens') })
    if ($tokenFields.Count -ne 1) { throw 'No finalized DynamicScope token list' }
    $tokens = $tokenFields[0].GetValue($scope)
    $result = [Collections.Generic.List[string]]::new()
    $result.Add('FINALIZED RESOLVER CODE; no ILGenerator reads')
    $result.Add('CodeLength=' + $code.Length)
    $result.Add('CodeHex=' + [Convert]::ToHexString($code))
    for ($i=0; $i -lt $tokens.Count; ++$i) { $result.Add('Token[' + $i + ']=' + (Format-ScopeToken $tokens[$i])) }
    $referenced = @(Get-ReferencedTokens $code)
    $result.Add('ReferencedTokenIndexes=' + ($referenced -join ','))
    $comparison = [Collections.Generic.List[string]]::new()
    $comparison.Add('CodeHex=' + [Convert]::ToHexString($code))
    $comparison.Add('Signature=' + $method.ReturnType.FullName + '(' + (($method.GetParameters() | ForEach-Object { $_.ParameterType.FullName }) -join ',') + ')')
    foreach ($tokenIndex in $referenced) { $comparison.Add('Token[' + $tokenIndex + ']=' + (Format-ScopeToken $tokens[$tokenIndex])) }
    $result.Add('Comparison uses finalized code + referenced normalized tokens + textual method signature. Unreferenced raw signature tokens may embed different runtime type-handle addresses.')
    return @{ Raw = ($result -join [Environment]::NewLine); Normalized = ($comparison -join [Environment]::NewLine) }
}
$normalized = @{}
foreach ($entry in @(@('before', $before), @('fixed', $fixed))) {
    $name = [string]$entry[0]
    $assembly = [Reflection.Assembly]$entry[1]
    $compiler = $assembly.GetType('FastExpressionCompiler.ExpressionCompiler', $true)
    $compileMethods = @($compiler.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object {
        $_.Name -eq 'CompileFast' -and -not $_.IsGenericMethod -and $_.GetParameters().Count -eq 3 -and
        $_.GetParameters()[0].ParameterType -eq [Linq.Expressions.LambdaExpression]
    })
    if ($compileMethods.Count -ne 1) { throw "Expected one nongeneric CompileFast for $name" }
    $compile = $compileMethods[0]
    $compilerFlags = [Enum]::ToObject($compile.GetParameters()[2].ParameterType, 0)
    $outer = [Delegate]$compile.Invoke($null, [object[]]@($tree, $true, $compilerFlags))
    if ($null -eq $outer) { throw "Compilation returned null for $name" }
    $inner = [Delegate]$outer.DynamicInvoke([object[]]@([int]3))
    $value = $inner.DynamicInvoke([object[]]@())
    if ($value -ne 27) { throw "Unexpected capture8 result for ${name}: $value" }
    $reader = $assembly.GetType('FastExpressionCompiler.ILDecoder.ILReaderFactory', $true)
    $dump = @($reader.GetMethods([Reflection.BindingFlags]'Public,Static') | Where-Object {
        $_.Name -eq 'ToILString' -and $_.GetParameters().Count -eq 3 -and
        $_.GetParameters()[0].ParameterType -eq [Reflection.MethodInfo]
    })[0]
    $format = [Enum]::ToObject($dump.GetParameters()[1].ParameterType, 0)
    $lines.Add('VERSION=' + $name)
    $lines.Add('Assembly=' + $assembly.FullName)
    $lines.Add('Result=' + $value)
    $lines.Add('OuterTarget=' + $outer.Target.GetType().AssemblyQualifiedName)
    $normalized[$name] = @{}
    $queue = [Collections.Generic.Queue[object]]::new()
    $queue.Enqueue(@{ Delegate = $inner; Path = 'inner' })
    $seen = [Collections.Generic.List[Delegate]]::new()
    while ($queue.Count -ne 0) {
        $item = $queue.Dequeue()
        $current = [Delegate]$item.Delegate
        $path = [string]$item.Path
        $visited = $false
        foreach ($previous in $seen) {
            if ([object]::ReferenceEquals($previous, $current)) { $visited = $true; break }
        }
        if ($visited) { $lines.Add('RepeatedDelegatePath=' + $path); continue }
        $seen.Add($current)
        $method = $current.Method
        if ($method -is [Reflection.Emit.DynamicMethod]) {
            $finalized = Get-FinalizedMethodText $method
            $text = $finalized.Raw
            $comparisonText = $finalized.Normalized
        } else {
            $text = $dump.Invoke($null, [object[]]@($method, $format, $null)).ToString()
            $comparisonText = $text
        }
        $filePath = $path -replace '[^a-zA-Z0-9_.-]', '_'
        [IO.File]::WriteAllText((Join-Path $outputPath ($name + '-' + $filePath + '.il.txt')), $text)
        $normalized[$name][$path] = $comparisonText -replace 'FecPaired\.(before|fixed)', 'FecPaired.SNAPSHOT'
        $lines.Add('DelegatePath=' + $path)
        $lines.Add('DelegateType=' + $current.GetType().AssemblyQualifiedName)
        $lines.Add('TargetType=' + $(if ($null -eq $current.Target) { '<null>' } else { $current.Target.GetType().AssemblyQualifiedName }))
        $lines.Add('MethodType=' + $method.GetType().FullName)
        $lines.Add('ReturnType=' + $method.ReturnType.AssemblyQualifiedName)
        $lines.Add('Parameters=' + (($method.GetParameters() | ForEach-Object { $_.ParameterType.AssemblyQualifiedName }) -join '; '))
        $init = $method.GetType().GetProperty('InitLocals', $flags)
        if ($null -ne $init) { $lines.Add('InitLocals=' + $init.GetValue($method)) }
        try {
            $body = $method.GetMethodBody()
            if ($null -ne $body) {
                $lines.Add('Locals=' + (($body.LocalVariables | ForEach-Object { $_.ToString() }) -join '; '))
                $lines.Add('MaxStack=' + $body.MaxStackSize)
            }
        } catch { $lines.Add('MethodBodyUnavailable=' + $_.Exception.GetType().Name) }
        foreach ($resolverName in @('_resolver', 'm_resolver')) {
            $resolverField = $method.GetType().GetField($resolverName, $flags)
            if ($null -eq $resolverField) { continue }
            $resolver = $resolverField.GetValue($method)
            if ($null -eq $resolver) { continue }
            foreach ($signatureName in @('_localSignature', 'm_localSignature')) {
                $signatureField = $resolver.GetType().GetField($signatureName, $flags)
                if ($null -ne $signatureField) {
                    $signature = [byte[]]$signatureField.GetValue($resolver)
                    $lines.Add('LocalSignatureBytes=' + [Convert]::ToHexString($signature))
                }
            }
        }
        $children = 0
        if ($null -ne $current.Target) {
            foreach ($field in $current.Target.GetType().GetFields([Reflection.BindingFlags]'Instance,Public,NonPublic')) {
                $fieldValue = $field.GetValue($current.Target)
                if ($fieldValue -is [Delegate]) {
                    ++$children
                    $lines.Add('DelegateField=' + $field.Name)
                    $queue.Enqueue(@{ Delegate = $fieldValue; Path = $path + '.' + $field.Name })
                }
            }
        }
        $lines.Add('LeafDelegate=' + ($children -eq 0))
    }
}
$paths = @(@($normalized['before'].Keys) + @($normalized['fixed'].Keys) | Sort-Object -Unique)
foreach ($path in $paths) {
    $equal = $normalized['before'].ContainsKey($path) -and $normalized['fixed'].ContainsKey($path) -and
        ($normalized['before'][$path] -ceq $normalized['fixed'][$path])
    $lines.Add('NormalizedILTextEqual[' + $path + ']=' + $equal)
}
$lines.Add('The inner path is the curry wrapper. Follow inner.f (or further delegate fields) to the generated capture body.')
$lines.Add('Dynamic leaves use finalized resolver code + normalized scope tokens. Pooled ILGenerator/ILReader output is not used for leaves.')
$lines.Add('Equal IL does not establish equal native code or explain a timing difference.')
$metadata = $lines -join [Environment]::NewLine
[IO.File]::WriteAllText((Join-Path $outputPath 'metadata.txt'), $metadata)
Write-Output $metadata
