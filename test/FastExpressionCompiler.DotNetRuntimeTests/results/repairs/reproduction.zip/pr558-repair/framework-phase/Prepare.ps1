param(
    [string]$CurrentCommit = '0d337dcc',
    [string]$BeforeCommit = 'e4c232da108d98790f0ca73f23ec90756da0cad7',
    [string]$Repository = 'C:\Data\Git\Github\FastExpressionCompiler'
)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$revisions = @{ before = (git -C $Repository rev-parse "$BeforeCommit^{commit}").Trim(); current = (git -C $Repository rev-parse "$CurrentCommit^{commit}").Trim() }
$coreFiles = @('FastExpressionCompiler.cs', 'ImTools.cs', 'ILReader.cs', 'TestTools.cs')
$lightFiles = @('Expression.cs', 'ExpressionVisitor.cs', 'FlatExpression.cs')
foreach ($version in @('before', 'current')) {
    foreach ($flavor in @('standard', 'light')) {
        $directory = Join-Path $root "snapshots\$version\$flavor"
        $library = Join-Path $directory 'library'
        New-Item -ItemType Directory -Force -Path $library | Out-Null
        foreach ($name in $coreFiles) {
            git -C $Repository show "$($revisions[$version]):src/FastExpressionCompiler/$name" | Set-Content -LiteralPath (Join-Path $library $name) -Encoding utf8
            if ($LASTEXITCODE) { throw "Cannot extract $version $name" }
        }
        if ($flavor -eq 'light') {
            foreach ($name in $lightFiles) {
                git -C $Repository show "$($revisions[$version]):src/FastExpressionCompiler.LightExpression/$name" | Set-Content -LiteralPath (Join-Path $library $name) -Encoding utf8
                if ($LASTEXITCODE) { throw "Cannot extract $version $name" }
            }
        }
        $defines = if ($flavor -eq 'light') { '<DefineConstants>LIGHT_EXPRESSION</DefineConstants>' } else { '' }
        Set-Content -LiteralPath (Join-Path $library 'Library.csproj') -Value "<Project Sdk=`"Microsoft.NET.Sdk`"><PropertyGroup><TargetFramework>net472</TargetFramework><LangVersion>latest</LangVersion><Optimize>true</Optimize><AssemblyName>FecFrameworkSnapshot.$flavor</AssemblyName>$defines</PropertyGroup></Project>"
        $defines = if ($flavor -eq 'light') { '<DefineConstants>LIGHT</DefineConstants>' } else { '' }
        Set-Content -LiteralPath (Join-Path $directory 'Harness.csproj') -Value "<Project Sdk=`"Microsoft.NET.Sdk`"><PropertyGroup><TargetFramework>net472</TargetFramework><OutputType>Exe</OutputType><LangVersion>latest</LangVersion><Optimize>true</Optimize><EnableDefaultCompileItems>false</EnableDefaultCompileItems>$defines</PropertyGroup><ItemGroup><Compile Include=`"../../../Program.cs`"/><ProjectReference Include=`"library/Library.csproj`"/></ItemGroup></Project>"
        dotnet build (Join-Path $directory 'Harness.csproj') -c Release -v:q *> (Join-Path $directory 'build.log')
        if ($LASTEXITCODE) { Get-Content (Join-Path $directory 'build.log'); throw "Build failed: $version/$flavor" }
    }
}
$frameworkRelease = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -ErrorAction SilentlyContinue).Release
@{ Before = $revisions.before; Current = $revisions.current; HarnessSHA256 = (Get-FileHash (Join-Path $root 'Program.cs')).Hash; FrameworkRelease = $frameworkRelease; PreparedUTC = [DateTime]::UtcNow.ToString('o'); Hosting = 'Unmodified production source: no custom hosting or factory substitutions' } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $root 'manifest.json')
Write-Output 'Prepared and built all four Framework snapshots. No benchmark process was executed.'
