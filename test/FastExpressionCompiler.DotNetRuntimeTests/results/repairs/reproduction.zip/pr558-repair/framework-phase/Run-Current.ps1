param(
    [int]$Rounds = 2,
    [string[]]$Flavors = @('standard', 'light'),
    [string[]]$Names,
    [string]$RunLabel = 'final',
    [switch]$VerifyOnly,
    [switch]$IncludeSystem
)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
if (!$Names) { $Names = @(Get-Content -LiteralPath (Join-Path $root 'cases.json') -Raw | ConvertFrom-Json) }
if ($RunLabel -notmatch '^[a-zA-Z0-9_-]+$') { throw 'Invalid run label' }
$output = Join-Path $root "results\$RunLabel"
New-Item -ItemType Directory -Force -Path $output | Out-Null
Copy-Item -LiteralPath (Join-Path $root 'manifest.json') -Destination (Join-Path $output 'manifest.json')
@{ Rounds=$Rounds; Flavors=$Flavors; Names=$Names; VerifyOnly=[bool]$VerifyOnly; IncludeSystem=[bool]$IncludeSystem; StartedUTC=[DateTime]::UtcNow.ToString('o'); ProcessIsolation='One fresh native Framework process per version/flavor/case/round' } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $output 'run.json')
for ($round = 0; $round -lt $Rounds; ++$round) {
    foreach ($flavor in $Flavors) {
        if ($flavor -notin @('standard','light')) { throw "Invalid flavor $flavor" }
        foreach ($name in $Names) {
            if ($name -notmatch '^[a-z0-9_]+$') { throw "Invalid scenario $name" }
            $versions = if ($round % 2 -eq 0) { @('before','current') } else { @('current','before') }
            $versions = @('current')
            foreach ($version in $versions) {
                $snapshot = if ($version -eq 'system') { 'current' } else { $version }
                $exe = Join-Path $root "snapshots\$snapshot\$flavor\bin\Release\net472\Harness.exe"
                $stem = "net472-$flavor-$round-$version-$name"
                $samples = Join-Path $output "$stem.jsonl"
                $status = Join-Path $output "$stem.status.jsonl"
                $arguments = @($version, $flavor, "$round", $name)
                if ($VerifyOnly) { $arguments += '--verify-only' }
                & $exe @arguments 1> $samples 2> $status
                $exitCode = $LASTEXITCODE
                if ($exitCode -ne 0) {
                    # A fatal baseline CLR failure invalidates every phase for this case.
                    # Keep its diagnostic text, but never retain partial timing samples.
                    Set-Content -LiteralPath $samples -Value ''
                    @{Version=$version;Flavor=$flavor;Scenario=$name;Status=if($version -eq 'before'){'N/A'}else{'FAIL'};ExitCode=$exitCode;Reason='Native process failed; partial samples discarded'} | ConvertTo-Json -Compress | Add-Content -LiteralPath $status
                }
                Write-Output "$stem exit=$exitCode"
            }
        }
    }
}
[DateTime]::UtcNow.ToString('o') | Set-Content -LiteralPath (Join-Path $output 'completed-utc.txt')
