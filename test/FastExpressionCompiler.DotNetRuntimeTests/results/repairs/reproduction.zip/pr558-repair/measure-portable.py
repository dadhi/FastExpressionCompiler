from pathlib import Path
import subprocess,json,os,sys,time,re
root=Path.cwd()/'fec-pr558-measurements';root.mkdir(exist_ok=True)
repo=Path(subprocess.check_output(['git','rev-parse','--show-toplevel'],text=True).strip())
commits={'before':'e4c232da108d98790f0ca73f23ec90756da0cad7','reviewed':'b8f8b38bc44367f129b49a55b2b2043e81b04ccb','fixed':'6676ab49b27c9fc13220eb20980282b5597b438f'}
def save(path,data):
 if isinstance(data,str):data=data.encode()
 if not path.exists() or path.read_bytes()!=data:path.write_bytes(data)
def build():
 source=(Path(__file__).resolve().parent/'Program.cs').read_text()
 save(root/'Program.cs',source)
 if '--source-only' in sys.argv:return
 for version,commit in commits.items():
  for flavor in ('standard','light'):
   dest=root/version/flavor;dest.mkdir(parents=True,exist_ok=True)
   paths=['src/FastExpressionCompiler/'+f for f in ('FastExpressionCompiler.cs','ImTools.cs','ILReader.cs','TestTools.cs')]
   if flavor=='light':paths+=['src/FastExpressionCompiler.LightExpression/'+f for f in ('Expression.cs','ExpressionVisitor.cs','FlatExpression.cs')]
   for p in paths:save(dest/Path(p).name,subprocess.check_output(['git','show',commit+':'+p],cwd=repo))
   save(dest/'Library.csproj','<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><AssemblyName>FecSnapshot.'+flavor+'</AssemblyName><Optimize>true</Optimize>'+('<DefineConstants>LIGHT_EXPRESSION</DefineConstants>' if flavor=='light' else '')+'</PropertyGroup></Project>')
   save(dest/'Harness.csproj','<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFrameworks>net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><EnableDefaultCompileItems>false</EnableDefaultCompileItems><Optimize>true</Optimize>'+('<DefineConstants>LIGHT</DefineConstants>' if flavor=='light' else '')+'</PropertyGroup><ItemGroup><Compile Include="../../Program.cs"/><ProjectReference Include="Library.csproj"/></ItemGroup></Project>')
   with (dest/'build.log').open('w') as log:p=subprocess.run(['dotnet','build',str(dest/'Harness.csproj'),'-c','Release','--nologo','-v:q','-m:1'],stdout=log,stderr=subprocess.STDOUT)
   print('built',version,flavor,p.returncode,flush=True)
   if p.returncode:print((dest/'build.log').read_text());raise SystemExit(1)
 (root/'commits.json').write_text(json.dumps(commits,indent=2))
def run():
 env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
 names=sys.argv[2:]
 if not names:
  source=(root/'Program.cs').read_text()
  names=re.findall(r'"([a-z0-9_]+)"',re.search(r'string\[\] names=\{([^}]+)\}',source).group(1))
  names+=re.findall(r'"([a-z0-9_]+)"',re.search(r'names=names.Concat\(new\[\]\{([^}]+)\}',source).group(1))
 for runtime in ('net10.0','net8.0'):
  for flavor in ('standard','light'):
   for round,versions in enumerate([('before','reviewed','fixed','system'),('system','fixed','reviewed','before')]):
    for version in versions:
     tag=f'{runtime}-{flavor}-{round}-{version}';folder=root/('fixed' if version=='system' else version)/flavor/'bin'/'Release'/runtime
     with (root/(tag+'.jsonl')).open('w') as out,(root/(tag+'.log')).open('w') as log:
      start=time.time();p=subprocess.run(['dotnet',str(folder/'Harness.dll'),version,flavor,str(round)]+[n for n in names if version!='before' or n not in ('capture_byref_call','capture_struct','capture_large_struct')],stdout=out,stderr=log,env=env)
     print(tag,p.returncode,f'{time.time()-start:.1f}s',flush=True)
     if p.returncode:raise SystemExit(p.returncode)
if sys.argv[1]=='build':build()
else:run()
