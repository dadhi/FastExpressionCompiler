from pathlib import Path
import json,subprocess

root=Path(__file__).resolve().parent
repo=Path(subprocess.check_output(['git','rev-parse','--show-toplevel'],text=True).strip())
dest=root/'paired';dest.mkdir(exist_ok=True)
commits=json.loads((root/'paired-commits.json').read_text())
for version in ('before','fixed'):
 d=dest/version;d.mkdir(exist_ok=True)
 for name in ('FastExpressionCompiler.cs','ImTools.cs','ILReader.cs','TestTools.cs'):
  (d/name).write_bytes(subprocess.check_output(['git','show',commits[version]+':src/FastExpressionCompiler/'+name],cwd=repo))
 (d/'Library.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><AssemblyName>FecPaired.'+version+'</AssemblyName></PropertyGroup></Project>')
(dest/'Program.cs').write_bytes((root/'PairedProgram.cs').read_bytes())
(dest/'Runner.csproj').write_bytes((root/'PairedRunner.csproj').read_bytes())
subprocess.run(['dotnet','build',str(dest/'Runner.csproj'),'-c','Release','-m:1','--nologo'],check=True)
print('Built only. Set DOTNET_TieredCompilation=0 and DOTNET_ReadyToRun=0 before running each runtime sequentially.')
