from pathlib import Path
import re,subprocess,json,sys,hashlib
w=Path(__file__).resolve().parent;d=w/'paired';d.mkdir(exist_ok=True)
r=Path(r'C:\Data\Git\Github\FastExpressionCompiler')
versions={'before':'e4c232da108d98790f0ca73f23ec90756da0cad7','fixed':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()}
if '--compare-current' in sys.argv: versions['before']=versions['fixed']
for key in ('before','fixed'):
 option='--'+key+'='
 for arg in sys.argv:
  if arg.startswith(option): versions[key]=subprocess.check_output(['git','rev-parse',arg[len(option):]],cwd=r,text=True).strip()
for v,c in versions.items():
 p=d/v;p.mkdir(exist_ok=True)
 for name in ['FastExpressionCompiler.cs','ImTools.cs','ILReader.cs','TestTools.cs']:
  data=subprocess.check_output(['git','show',c+':src/FastExpressionCompiler/'+name],cwd=r)
  if not (p/name).exists() or (p/name).read_bytes()!=data:(p/name).write_bytes(data)
 (p/'Library.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><AssemblyName>FecPaired.'+v+'</AssemblyName></PropertyGroup></Project>')
candidate_refs=['e85bc329','47f79a6a'] if '--candidates' in sys.argv else []
candidate_refs += [arg.split('=',1)[1] for arg in sys.argv if arg.startswith('--merge=')]
if candidate_refs:
 scratch=w/'merge-candidates';scratch.mkdir(exist_ok=True)
 target=d/'fixed/FastExpressionCompiler.cs'
 for candidate in candidate_refs:
  base=scratch/(candidate+'-base.txt');theirs=scratch/(candidate+'-source.txt')
  base.write_bytes(subprocess.check_output(['git','show',candidate+'^:src/FastExpressionCompiler/FastExpressionCompiler.cs'],cwd=r))
  theirs.write_bytes(subprocess.check_output(['git','show',candidate+':src/FastExpressionCompiler/FastExpressionCompiler.cs'],cwd=r))
  merged=subprocess.run(['git','merge-file','-p',str(target),str(base),str(theirs)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  assert merged.returncode==0,merged.stderr.decode()
  target.write_bytes(merged.stdout)
 versions['candidates']=candidate_refs
 versions['candidateSourceSha256']=hashlib.sha256(target.read_bytes()).hexdigest()
(d/'Runner.csproj').write_text('''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFrameworks>net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><EnableDefaultCompileItems>false</EnableDefaultCompileItems></PropertyGroup><ItemGroup><Compile Include="Program.cs"/><ProjectReference Include="before/Library.csproj" Aliases="Before"/><ProjectReference Include="fixed/Library.csproj" Aliases="After"/></ItemGroup></Project>''')
s=(w/'bench/Program.cs').read_text()
prefix=s[:s.index(' static Delegate Compile(')].replace('using FastExpressionCompiler;','')
verify=s[s.index(' static string Verify('):s.index(' record Sample(')]
names=re.findall(r'"([a-z0-9_]+)"',re.search(r'string\[\] names=\{([^}]+)\}',s).group(1))+re.findall(r'"([a-z0-9_]+)"',re.search(r'names=names.Concat\(new\[\]\{([^}]+)\}',s).group(1))
if '--all-cases' not in sys.argv:
 names=[n for n in names if n not in ['capture_byref_call','capture_struct','capture_large_struct','quote_closed','quote_capture','runtime_variables']]
main=r'''
 record Sample(string Runtime,string Scenario,string Phase,string Version,int Round,int SampleIndex,int Operations,double NsPerOp,double BytesPerOp);
 static void Pair(string name,string phase,int round,Action<int> before,Action<int> after) {
  before(40);after(40);int n=phase=="invoke"||phase=="nested_invoke"?100000:100;
  var sw=Stopwatch.StartNew();before(n);after(n);sw.Stop();
  n=(int)Math.Clamp(n*16.0/Math.Max(sw.Elapsed.TotalMilliseconds,0.01),phase=="invoke"||phase=="nested_invoke"?1000:10,phase=="invoke"||phase=="nested_invoke"?1000000:2000);
  for(int k=0;k<15;k++) for(int order=0;order<2;order++) {
   bool isBefore=(k+round+order)%2==0;var op=isBefore?before:after;
   GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();
   long bytes=GC.GetAllocatedBytesForCurrentThread(),t=Stopwatch.GetTimestamp();op(n);long end=Stopwatch.GetTimestamp();bytes=GC.GetAllocatedBytesForCurrentThread()-bytes;
   Console.WriteLine(JsonSerializer.Serialize(new Sample(Environment.Version.ToString(),name,phase,isBefore?"before":"fixed",round,k,n,(end-t)*1e9/Stopwatch.Frequency/n,bytes/(double)n)));
  }
 }
 static Action<int> First(Func<Delegate> compile)=>n=>{for(int i=0;i<n;i++){var c=compile();if(c is Func<int,int> f)checksum=f(3);else if(c is Func<int,Func<int>> ff){var inner=ff(3);sink=inner;checksum=inner();}else if(c is Func<int,IRuntimeVariables> fr)sink=fr(3);else sink=((Func<int,System.Linq.Expressions.Expression<Func<int>>>)c)(3);}};
 public static void Main(string[] args) {
  if(args[0]=="profile") {
   var expr=Build(args[2]);Func<Delegate> compile=args[1]=="before"?()=>Before::FastExpressionCompiler.ExpressionCompiler.CompileFast(expr,true):()=>After::FastExpressionCompiler.ExpressionCompiler.CompileFast(expr,true);
   int count=int.Parse(args[3]);for(int i=0;i<count;i++)sink=compile();GC.KeepAlive(sink);return;
  }
  if(args[0]=="dump") {
   var expr=Build(args[1]);var before=Before::FastExpressionCompiler.ExpressionCompiler.CompileFast(expr,true);var after=After::FastExpressionCompiler.ExpressionCompiler.CompileFast(expr,true);
   Console.WriteLine("BEFORE\n"+Before::FastExpressionCompiler.ILDecoder.ILReaderFactory.ToILString(before.Method));
   Console.WriteLine("AFTER\n"+After::FastExpressionCompiler.ILDecoder.ILReaderFactory.ToILString(after.Method));return;
  }
  int round=int.Parse(args[0]);string[] names=__NAMES__;
  if(args.Length>1)names=names.Where(n=>args.Skip(1).Contains(n)).ToArray();
  foreach(var name in names){
   var tree=Build(name);
   Func<Delegate> before=()=>Before::FastExpressionCompiler.ExpressionCompiler.CompileFast(tree,true)??throw new Exception("before unsupported "+name);
   Func<Delegate> after=()=>After::FastExpressionCompiler.ExpressionCompiler.CompileFast(tree,true)??throw new Exception("after unsupported "+name);
   var b=before();var a=after();var expected=Verify(tree.Compile());
   if(Verify(b)!=expected||Verify(a)!=expected)throw new Exception("behavior "+name);
   Console.Error.WriteLine("PASS "+name+" "+expected);
   Pair(name,"construct",round,n=>{for(int i=0;i<n;i++)sink=Build(name);},n=>{for(int i=0;i<n;i++)sink=Build(name);});
   Pair(name,"compile",round,n=>{for(int i=0;i<n;i++)sink=before();},n=>{for(int i=0;i<n;i++)sink=after();});
   Pair(name,"compile_first",round,First(before),First(after));
   Pair(name,"invoke",round,Driver(b),Driver(a));
   if(b is Func<int,Func<int>> bf&&a is Func<int,Func<int>> af){
    Pair(name,"activate",round,n=>{for(int i=0;i<n;i++)sink=bf(3);},n=>{for(int i=0;i<n;i++)sink=af(3);});
    var bi=bf(3);var ai=af(3);
    Pair(name,"nested_invoke",round,n=>{long sum=0;for(int i=0;i<n;i++)sum+=bi();checksum=sum;},n=>{long sum=0;for(int i=0;i<n;i++)sum+=ai();checksum=sum;});
   }
  }
  GC.KeepAlive(sink);GC.KeepAlive(checksum);
 }
}
'''.replace('__NAMES__','new[]{'+','.join(json.dumps(n) for n in names)+'}')
(d/'Program.cs').write_text('extern alias Before;\nextern alias After;\n'+prefix+verify+main)
(d/'commits.json').write_text(json.dumps(versions,indent=2))
print('Prepared paired source',versions)

if '--micro' in sys.argv:
 source=(d/'Program.cs').read_text()
 start=source.index('  before(40);after(40);int n=')
 end=source.index('   long bytes=GC.GetAllocatedBytesForCurrentThread()',start)
 source=source[:start]+'''  before(40);after(40);
  int n=phase=="invoke"||phase=="nested_invoke"?100000:phase=="construct"?1000:phase=="activate"?1000:phase=="compile_first"?16:64;
  for(int k=0;k<101;k++) {
   if(k%8==0){GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();}
   for(int order=0;order<2;order++) {
   bool isBefore=(k+round+order)%2==0;var op=isBefore?before:after;
'''+source[end:]
 source=source.replace('  }\n }\n static Action<int> First','  }}\n }\n static Action<int> First')
 (d/'Program.cs').write_text(source)
