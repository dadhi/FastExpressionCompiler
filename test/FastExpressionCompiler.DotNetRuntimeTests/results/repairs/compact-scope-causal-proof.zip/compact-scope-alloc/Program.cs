extern alias Before;
extern alias After;
using System;
using System.Linq.Expressions;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Text.Json;
#if LIGHT
using FastExpressionCompiler.LightExpression;
using E = FastExpressionCompiler.LightExpression.Expression;
using X = FastExpressionCompiler.LightExpression.Expression;
using L = FastExpressionCompiler.LightExpression.LambdaExpression;
#else

using E = System.Linq.Expressions.Expression;
using X = System.Linq.Expressions.Expression;
using L = System.Linq.Expressions.LambdaExpression;
#endif
public class Box { public int Value; public Box(int x) { Value=x; } public int Add(int x)=>Value+x; public static int Read(Box b)=>b.Value; }
public struct Counter { public int Value; public Counter(int value){Value=value;} public int Increment()=>++Value; }
public struct LargeCounter { public int Value; public long A,B,C,D; public LargeCounter(int value){this=default;Value=value;} public int Increment()=>++Value; }
public class DelegateHolder { public readonly Func<int> Reader; public DelegateHolder(Func<int> reader){Reader=reader;} }
public class Holder { public Box Box; public Holder(Box box){Box=box;} }
public static class Program {
 public static int AddRef(ref int value)=>++value;
 static object sink; static long checksum;
#if LIGHT
 static L systemSource;
 static System.Linq.Expressions.LambdaExpression systemPrepared;
#endif
 record Scenario(string Name, Func<L> Build);
 static X Balanced(X x,int depth) => depth==0?x:E.Add(Balanced(x,depth-1),Balanced(x,depth-1));
 static L Build(string name) {
  var x=E.Parameter(typeof(int),"x"); X body=x;
  switch(name) {
   case "constant": body=E.Constant(42);break;
   case "add": body=E.Add(x,E.Constant(1));break;
   case "arithmetic64": for(int i=0;i<64;i++)body=E.Add(body,E.Constant(i));break;
   case "balanced256":body=Balanced(x,8);break;
   case "conditional":body=E.Condition(E.LessThan(x,E.Constant(0)),E.Negate(x),x);break;
   case "nullable":body=E.Coalesce(E.Convert(x,typeof(int?)),E.Constant(7));break;
   case "new_member":body=E.Field(E.New(typeof(Box).GetConstructor(new[]{typeof(int)}),x),"Value");break;
   case "constant_object":body=E.Call(E.Constant(new Box(7)),typeof(Box).GetMethod("Add"),x);break;
   case "array":body=E.ArrayIndex(E.Constant(new[]{2,3,5,7}),E.And(x,E.Constant(3)));break;
   case "new_array":body=E.ArrayLength(E.NewArrayInit(typeof(int),x,x,x));break;
   case "interned_string":body=E.Property(E.Constant("fixed literal"),"Length");break;
   case "noninterned_string":body=E.Property(E.Constant(new string('z',37)),"Length");break;
   case "try_catch":body=E.TryCatch(E.Divide(E.Constant(42),x),E.Catch(typeof(DivideByZeroException),E.Constant(-1)));break;
   case "try_finally":body=E.TryFinally(E.Add(x,E.Constant(1)),E.Empty());break;
   case "switch":body=E.Switch(x,E.Constant(8),E.SwitchCase(E.Constant(3),E.Constant(0)),E.SwitchCase(E.Constant(4),E.Constant(1)));break;
   case "goto":{var t=E.Label(typeof(int));body=E.Block(E.Return(t,x),E.Label(t,E.Constant(0)));break;}
   case "loop":{var v=E.Variable(typeof(int));var t=E.Label(typeof(int));body=E.Block(new[]{v},E.Assign(v,E.Constant(0)),E.Loop(E.IfThenElse(E.LessThan(v,E.Constant(8)),E.Block(E.PostIncrementAssign(v),E.Empty()),E.Break(t,v)),t));break;}
   case "blocks32":case "blocks128":{int n=name=="blocks32"?32:128;var arr=new List<X>();for(int i=0;i<n;i++){var v=E.Variable(typeof(int),"v"+i);arr.Add(E.Block(new[]{v},E.Assign(v,x),E.Add(v,E.Constant(i))));}body=E.Block(arr);break;}
   case "invoke_literal":{var p=E.Parameter(typeof(int));body=E.Invoke(E.Lambda<Func<int,int>>(E.Add(p,E.Constant(2)),p),x);break;}
   case "invoke_delegate":body=E.Invoke(E.Constant((Func<int,int>)(v=>v+2)),x);break;
   case "invoke_try_argument":{var p=E.Parameter(typeof(int));body=E.Invoke(E.Lambda<Func<int,int>>(E.Add(p,E.Constant(2)),p),E.TryFinally(x,E.Empty()));break;}
   case "capture_byref_call": return E.Lambda<Func<int,Func<int>>>(E.Lambda<Func<int>>(E.Call(typeof(Program).GetMethod("AddRef"),x)),x);
   case "capture_struct":case "capture_large_struct":{
    var type=name=="capture_struct"?typeof(Counter):typeof(LargeCounter);var v=E.Variable(type);
    return E.Lambda<Func<int,Func<int>>>(E.Block(new[]{v},E.Assign(v,E.New(type.GetConstructor(new[]{typeof(int)}),x)),E.Lambda<Func<int>>(E.Call(v,type.GetMethod("Increment")))),x);
   }
   case "capture_mutable_reference":case "capture_mutable_reference_ctor":case "capture_mutable_reference_array":{
    var v=E.Variable(typeof(string),"text");
    var toggle=E.Assign(v,E.Condition(E.Equal(v,E.Constant("first")),E.Constant("second"),E.Constant("first")));
    X child=E.Lambda<Func<int>>(E.Block(toggle,E.Property(v,"Length")));
    if(name=="capture_mutable_reference_ctor")child=E.Field(E.New(typeof(DelegateHolder).GetConstructors()[0],child),"Reader");
    if(name=="capture_mutable_reference_array")child=E.ArrayIndex(E.NewArrayInit(typeof(Func<int>),child),E.Constant(0));
    return E.Lambda<Func<int,Func<int>>>(E.Block(new[]{v},E.Assign(v,E.Constant("first")),child),x);
   }
   case "capture_mutable": return E.Lambda<Func<int,Func<int>>>(E.Lambda<Func<int>>(E.PreIncrementAssign(x)),x);
   case "capture1": return E.Lambda<Func<int,Func<int>>>(E.Lambda<Func<int>>(E.Add(x,E.Constant(1))),x);
   case "capture_call":case "capture_ctor":case "capture_invoke":case "capture_try":case "capture_array":{
   var v=E.Variable(typeof(Box),"box");X read=E.Field(v,"Value");
   if(name=="capture_call")read=E.Call(typeof(Box).GetMethod("Read"),v);
   if(name=="capture_ctor")read=E.Field(E.Field(E.New(typeof(Holder).GetConstructor(new[]{typeof(Box)}),v),"Box"),"Value");
   if(name=="capture_invoke")read=E.Invoke(E.Constant((Func<Box,int>)Box.Read),v);
   if(name=="capture_try")read=E.TryFinally(read,E.Empty());
   if(name=="capture_array")read=E.Field(E.ArrayIndex(E.NewArrayInit(typeof(Box),v),E.Constant(0)),"Value");
   return E.Lambda<Func<int,Func<int>>>(E.Block(new[]{v},E.Assign(v,E.Constant(new Box(7))),E.Lambda<Func<int>>(read)),x);
   }
   case "capture_reference":{var v=E.Variable(typeof(Box),"box");return E.Lambda<Func<int,Func<int>>>(E.Block(new[]{v},E.Assign(v,E.Constant(new Box(7))),E.Lambda<Func<int>>(E.Field(v,"Value"))),x);}
   case "nested_mixed32":case "nested_mixed128":{int n=int.Parse(name.Substring("nested_mixed".Length));for(int i=0;i<n;i++)body=E.Condition(E.GreaterThan(x,E.Constant(-9)),E.Block(body),E.Constant(0));break;}
   case "nested_eh8":case "nested_eh32":{int n=int.Parse(name.Substring("nested_eh".Length));for(int i=0;i<n;i++)body=E.TryFinally(body,E.Empty());break;}
   case "nested_blocks8":case "nested_blocks32":case "nested_blocks128":{int count=int.Parse(name.Substring("nested_blocks".Length));for(int i=0;i<count;i++)body=E.Block(body);break;}
   case "capture8":{var vs=Enumerable.Range(0,8).Select(i=>E.Variable(typeof(int),"v"+i)).ToArray();X sum=x;foreach(var v in vs)sum=E.Add(sum,v);return E.Lambda<Func<int,Func<int>>>(E.Block(vs,vs.Select(v=>(X)E.Assign(v,x)).Concat(new X[]{E.Lambda<Func<int>>(sum)})),x);}
   case "quote_closed":return E.Lambda<Func<int,System.Linq.Expressions.Expression<Func<int>>>>(E.Quote(E.Lambda<Func<int>>(E.Constant(9))),x);
   case "quote_capture":return E.Lambda<Func<int,System.Linq.Expressions.Expression<Func<int>>>>(E.Quote(E.Lambda<Func<int>>(x)),x);
   case "runtime_variables":
#if LIGHT
    var sp=System.Linq.Expressions.Expression.Parameter(typeof(int));
    return System.Linq.Expressions.Expression.Lambda<Func<int,IRuntimeVariables>>(System.Linq.Expressions.Expression.RuntimeVariables(sp),sp).ToLightExpression();
#else
    return E.Lambda<Func<int,IRuntimeVariables>>(E.RuntimeVariables(x),x);
#endif
   default:throw new Exception(name);
  }
  return E.Lambda<Func<int,int>>(body,x);
 }
 static string Verify(Delegate d) {
  var parts=new List<string>();
  foreach(int v in new[]{-2,0,3}) {
   var result=d.DynamicInvoke(v);
   if(result is Func<int> nested) result=nested()+":"+nested();
   if(result is System.Linq.Expressions.Expression<Func<int>> quote) result=quote.Compile()();
   if(result is IRuntimeVariables vars) {var initial=vars[0];vars[0]=17;result=initial+":"+vars[0];}
   parts.Add(result?.ToString()??"null");
  }
  return string.Join("|",parts);
 }
 static Action<int> Driver(Delegate d) {
  if(d is Func<int,int> f)return n=>{long s=0;for(int i=0;i<n;i++)s+=f(3);checksum=s;};
  if(d is Func<int,Func<int>> f2)return n=>{long s=0;for(int i=0;i<n;i++){var v=f2(3);sink=v;s+=v();}checksum=s;};
  if(d is Func<int,System.Linq.Expressions.Expression<Func<int>>> fq)return n=>{for(int i=0;i<n;i++)sink=fq(3);};
  if(d is Func<int,IRuntimeVariables> fr)return n=>{for(int i=0;i<n;i++)sink=fr(3);};
  throw new Exception("driver "+d.GetType());
 }


 [MethodImpl(MethodImplOptions.NoInlining)] static Delegate BeforeCompile(LambdaExpression e)=>Before::FastExpressionCompiler.ExpressionCompiler.CompileFast(e,true)??throw new Exception("before unsupported");
 [MethodImpl(MethodImplOptions.NoInlining)] static Delegate AfterCompile(LambdaExpression e)=>After::FastExpressionCompiler.ExpressionCompiler.CompileFast(e,true)??throw new Exception("after unsupported");
 sealed class Reentrant:Expression {
  readonly Func<Delegate> compile;
  public Reentrant(Func<Delegate> c)=>compile=c;
  public override Type Type=>typeof(int);public override ExpressionType NodeType=>ExpressionType.Extension;public override bool CanReduce=>true;
  public override Expression Reduce(){var f=(Func<int,int>)compile();return Expression.Constant(f(3));}
 }
 static LambdaExpression ReentrantTree(bool after){
  var inner=Build("nested_mixed32");var x=Expression.Parameter(typeof(int),"x");Expression body=new Reentrant(()=>after?AfterCompile(inner):BeforeCompile(inner));
  for(int i=0;i<128;++i)body=Expression.Condition(Expression.GreaterThan(x,Expression.Constant(-9)),Expression.Block(body),Expression.Constant(0));
  return Expression.Lambda<Func<int,int>>(body,x);
 }
 static long Measure(Func<Delegate> compile,int count){long start=GC.GetAllocatedBytesForCurrentThread();for(int i=0;i<count;++i)sink=compile();return GC.GetAllocatedBytesForCurrentThread()-start;}
 static string Misses(){
  var asm=typeof(After::FastExpressionCompiler.ExpressionCompiler).Assembly;
  var compiler=typeof(After::FastExpressionCompiler.ExpressionCompiler);
  var pool=compiler.GetNestedType("ScopeArrayPool`1",System.Reflection.BindingFlags.NonPublic);
  return string.Join(";",new[]{"LabelScopeFrame","ExceptionRegionFrame","ScopeInfo"}.Select(n=>{
   var closed=pool.MakeGenericType(compiler.GetNestedType(n,System.Reflection.BindingFlags.NonPublic));
   return n+":"+closed.GetField("MissCount").GetValue(null)+":"+closed.GetField("LastMissLength").GetValue(null);
  }));
 }
 public static void Main(string[] args){
  if(args[0]=="cold"){
   var tree=Build(args[2]);_=GC.GetAllocatedBytesForCurrentThread();long start=GC.GetAllocatedBytesForCurrentThread();sink=args[1]=="before"?BeforeCompile(tree):AfterCompile(tree);long bytes=GC.GetAllocatedBytesForCurrentThread()-start;
   Console.WriteLine(JsonSerializer.Serialize(new{Phase="cold",Runtime=Environment.Version.ToString(),Version=args[1],Scenario=args[2],Bytes=bytes}));return;
  }
  foreach(var name in new[]{"add","balanced256","blocks32","nested_mixed32","nested_mixed128","nested_eh32","goto","loop","switch","capture8","capture_mutable","reentrant"}.Where(n=>args.Length<2||args.Skip(1).Contains(n))){
   var b=name=="reentrant"?ReentrantTree(false):Build(name);var a=name=="reentrant"?ReentrantTree(true):b;
   Func<Delegate> before=()=>BeforeCompile(b),after=()=>AfterCompile(a);
   if(Verify(before())!=Verify(after()))throw new Exception("behavior "+name);
   for(int i=0;i<100;++i){sink=before();sink=after();}
   for(int j=0;j<5;++j){var prior=Misses();var bb=Measure(before,1000)/1000.0;var fb=Measure(after,1000)/1000.0;var next=Misses();Console.WriteLine(JsonSerializer.Serialize(new{Phase="warm",Runtime=Environment.Version.ToString(),Scenario=name,BeforeBytes=bb,FixedBytes=fb,PriorMisses=prior,AfterMisses=next}));}
  }
 }
}
