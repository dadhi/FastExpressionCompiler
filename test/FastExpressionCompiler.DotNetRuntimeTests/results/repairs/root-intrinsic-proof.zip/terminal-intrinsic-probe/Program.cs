extern alias Current;
extern alias Published;
extern alias Before;
using System;using System.Reflection.Emit;
namespace NBefore {
using F=Before::FastExpressionCompiler.LightExpression;
using R=Before::FastExpressionCompiler.LightExpression.ImTools.SmallList<Before::FastExpressionCompiler.LightExpression.ExpressionCompiler.NestedLambdaInfo>;
public sealed class Node:F.ConstantExpression {
 public override object Value=>null;public override Type Type=>typeof(int);public override bool IsIntrinsic=>true;
 readonly F.Expression jump,label;
 public Node(bool invalid){var target=F.Expression.Label("opaque-root");jump=F.Expression.Goto(target);var result=F.Expression.Block(F.Expression.Label(target),F.Expression.Constant(42));label=invalid?F.Expression.Add(result,F.Expression.Constant(0)):result;}
 public override F.ExpressionCompiler.Result TryCollectInfo(ref F.ExpressionCompiler.CompilerContext c,F.ExpressionCompiler.NestedLambdaInfo n,ref R roots){var r=F.ExpressionCompiler.TryCollectInfo(ref c,jump,n,ref roots);return r==F.ExpressionCompiler.Result.OK?F.ExpressionCompiler.TryCollectInfo(ref c,label,n,ref roots):r;}
 public override bool TryEmit(ref F.ExpressionCompiler.CompilerContext c,ILGenerator il,F.ExpressionCompiler.ParentFlags p,int b=-1)=>F.ExpressionCompiler.EmittingVisitor.TryEmit(jump,il,ref c,F.ExpressionCompiler.ParentFlags.IgnoreResult)&&F.ExpressionCompiler.EmittingVisitor.TryEmit(label,il,ref c,p,b);
}
public static class Run {public static void Check(bool invalid){try {var f=F.ExpressionCompiler.CompileFast(F.Expression.Lambda<Func<int>>(new Node(invalid)),true);Console.WriteLine("Before="+f());}catch(Exception e){Console.WriteLine("Before="+e.GetType().Name+":"+e.Message);}}}
}
namespace NPublished {
using F=Published::FastExpressionCompiler.LightExpression;
using R=Published::FastExpressionCompiler.LightExpression.ImTools.SmallList<Published::FastExpressionCompiler.LightExpression.ExpressionCompiler.NestedLambdaInfo>;
public sealed class Node:F.ConstantExpression {
 public override object Value=>null;public override Type Type=>typeof(int);public override bool IsIntrinsic=>true;
 readonly F.Expression jump,label;
 public Node(bool invalid){var target=F.Expression.Label("opaque-root");jump=F.Expression.Goto(target);var result=F.Expression.Block(F.Expression.Label(target),F.Expression.Constant(42));label=invalid?F.Expression.Add(result,F.Expression.Constant(0)):result;}
 public override F.ExpressionCompiler.Result TryCollectInfo(ref F.ExpressionCompiler.CompilerContext c,F.ExpressionCompiler.NestedLambdaInfo n,ref R roots){var r=F.ExpressionCompiler.TryCollectInfo(ref c,jump,n,ref roots);return r==F.ExpressionCompiler.Result.OK?F.ExpressionCompiler.TryCollectInfo(ref c,label,n,ref roots):r;}
 public override bool TryEmit(ref F.ExpressionCompiler.CompilerContext c,ILGenerator il,F.ExpressionCompiler.ParentFlags p,int b=-1)=>F.ExpressionCompiler.EmittingVisitor.TryEmit(jump,il,ref c,F.ExpressionCompiler.ParentFlags.IgnoreResult)&&F.ExpressionCompiler.EmittingVisitor.TryEmit(label,il,ref c,p,b);
}
public static class Run {public static void Check(bool invalid){try {var f=F.ExpressionCompiler.CompileFast(F.Expression.Lambda<Func<int>>(new Node(invalid)),true);Console.WriteLine("Published="+f());}catch(Exception e){Console.WriteLine("Published="+e.GetType().Name+":"+e.Message);}}}
}
namespace NCurrent {
using F=Current::FastExpressionCompiler.LightExpression;
using R=Current::FastExpressionCompiler.LightExpression.ImTools.SmallList<Current::FastExpressionCompiler.LightExpression.ExpressionCompiler.NestedLambdaInfo>;
public sealed class Node:F.ConstantExpression {
 public override object Value=>null;public override Type Type=>typeof(int);public override bool IsIntrinsic=>true;
 readonly F.Expression jump,label;
 public Node(bool invalid){var target=F.Expression.Label("opaque-root");jump=F.Expression.Goto(target);var result=F.Expression.Block(F.Expression.Label(target),F.Expression.Constant(42));label=invalid?F.Expression.Add(result,F.Expression.Constant(0)):result;}
 public override F.ExpressionCompiler.Result TryCollectInfo(ref F.ExpressionCompiler.CompilerContext c,F.ExpressionCompiler.NestedLambdaInfo n,ref R roots){var r=F.ExpressionCompiler.TryCollectInfo(ref c,jump,n,ref roots);return r==F.ExpressionCompiler.Result.OK?F.ExpressionCompiler.TryCollectInfo(ref c,label,n,ref roots):r;}
 public override bool TryEmit(ref F.ExpressionCompiler.CompilerContext c,ILGenerator il,F.ExpressionCompiler.ParentFlags p,int b=-1)=>F.ExpressionCompiler.EmittingVisitor.TryEmit(jump,il,ref c,F.ExpressionCompiler.ParentFlags.IgnoreResult)&&F.ExpressionCompiler.EmittingVisitor.TryEmit(label,il,ref c,p,b);
}
public static class Run {public static void Check(bool invalid){try {var f=F.ExpressionCompiler.CompileFast(F.Expression.Lambda<Func<int>>(new Node(invalid)),true);Console.WriteLine("Current="+f());}catch(Exception e){Console.WriteLine("Current="+e.GetType().Name+":"+e.Message);}}}
}
public static class Program {public static void Main(){Console.WriteLine("VALID");NBefore.Run.Check(false);NPublished.Run.Check(false);NCurrent.Run.Check(false);Console.WriteLine("INVALID");NBefore.Run.Check(true);NPublished.Run.Check(true);NCurrent.Run.Check(true);}}