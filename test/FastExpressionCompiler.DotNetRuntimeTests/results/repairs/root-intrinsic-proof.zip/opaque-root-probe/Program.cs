using System;using System.Reflection.Emit;using FastExpressionCompiler.LightExpression;using FastExpressionCompiler.LightExpression.ImTools;using E=FastExpressionCompiler.LightExpression.Expression;using C=FastExpressionCompiler.LightExpression.ExpressionCompiler;
class Program{
 sealed class OpaquePair:ConstantExpression{
  readonly NewExpression pair;public OpaquePair(E a,E b)=>pair=E.New(typeof(Tuple<Func<int>,System.Linq.Expressions.Expression<Func<int>>>).GetConstructors()[0],a,b);
  public override Type Type=>pair.Type;public override object Value=>null;public override bool IsIntrinsic=>true;
  public override C.Result TryCollectInfo(ref C.CompilerContext context,C.NestedLambdaInfo nested,ref SmallList<C.NestedLambdaInfo> roots){var r=C.TryCollectInfo(ref context,pair.GetArgument(0),nested,ref roots);return r!=C.Result.OK?r:C.TryCollectInfo(ref context,pair.GetArgument(1),nested,ref roots);}
  public override bool TryEmit(ref C.CompilerContext context,ILGenerator il,C.ParentFlags parent,int byRefIndex=-1)=>C.EmittingVisitor.TryEmit(pair,il,ref context,parent,byRefIndex);
 }
 static void Main(){try{var x=E.Parameter(typeof(int));var tree=E.Lambda<Func<int,Tuple<Func<int>,System.Linq.Expressions.Expression<Func<int>>>>>(new OpaquePair(E.Lambda<Func<int>>(E.PreIncrementAssign(x)),E.Quote(E.Lambda<Func<int>>(x))),x);var pair=tree.CompileFast(true)(3);int first=pair.Item1(),quoted=pair.Item2.Compile()();if(first!=4||quoted!=4||pair.Item1()!=5||pair.Item2.Compile()()!=5)throw new Exception("Storage mismatch");Console.WriteLine("Opaque root mutable child + later quote PASS");}catch(Exception e){Console.WriteLine(e.GetType().FullName+": "+e.Message);Environment.ExitCode=1;}}
}
