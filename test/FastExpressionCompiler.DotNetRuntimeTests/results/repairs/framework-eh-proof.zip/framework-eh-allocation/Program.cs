using System;
using System.Linq.Expressions;
using System.Reflection;
using System.Reflection.Emit;
using FastExpressionCompiler;
using FastExpressionCompiler.ILDecoder;
class Program{
 static object sink;
 static readonly Func<long> Allocated=(Func<long>)Delegate.CreateDelegate(typeof(Func<long>),typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread",Type.EmptyTypes));
 static readonly Type[] Empty=Type.EmptyTypes;
 static Expression<Func<int,int>> Tree(string name){var x=Expression.Parameter(typeof(int));Expression b=Expression.Add(x,Expression.Constant(1));if(name=="try_finally")b=Expression.TryFinally(b,Expression.Empty());else if(name=="try_catch")b=Expression.TryCatch(Expression.Divide(Expression.Constant(42),x),Expression.Catch(typeof(DivideByZeroException),Expression.Constant(-1)));return Expression.Lambda<Func<int,int>>(b,x);}
 static void Measure(string name,Func<object> create){for(int i=0;i<100;i++)sink=create();for(int sample=0;sample<5;sample++){long b=Allocated();for(int i=0;i<1000;i++)sink=create();Console.WriteLine(name+" sample="+sample+" bytes="+((Allocated()-b)/1000.0));}}
 static DynamicMethod New(bool restricted)=>ConstructorControl.New(restricted);
 static object Emit(bool restricted,bool eh){var d=New(restricted);var il=d.GetILGenerator();if(eh){var v=il.DeclareLocal(typeof(int));il.BeginExceptionBlock();il.Emit(OpCodes.Ldc_I4_4);il.Emit(OpCodes.Stloc,v);il.BeginFinallyBlock();il.EndExceptionBlock();il.Emit(OpCodes.Ldloc,v);}else il.Emit(OpCodes.Ldc_I4_4);il.Emit(OpCodes.Ret);return d.CreateDelegate(typeof(Func<int>));}
 static void Dump(MethodInfo method){
  var owner=method.GetType().GetField("m_owner",BindingFlags.Instance|BindingFlags.NonPublic);
  var dynamic=(DynamicMethod)(method is DynamicMethod?method:owner.GetValue(method));
  var resolver=typeof(DynamicMethod).GetField("m_resolver",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(dynamic);
  foreach(var field in resolver.GetType().GetFields(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic)){
   var value=field.GetValue(resolver);
   if(value is byte[] bytes)Console.WriteLine(field.Name+"="+BitConverter.ToString(bytes));
   else if(value is Array array)Console.WriteLine(field.Name+"="+array.GetType().Name+" length="+array.Length);
   else if(field.FieldType.IsPrimitive)Console.WriteLine(field.Name+"="+value);
  }
 }
 static void Main(string[] args){
  Console.WriteLine("assembly "+typeof(ExpressionCompiler).Assembly.GetName().Name);
  foreach(var name in new[]{"add","try_catch","try_finally"}){var e=Tree(name);var f=e.CompileFast(true);Console.WriteLine(name+" value="+f(3)+" module="+f.Method.Module.Assembly.GetName().Name);Dump(f.Method);Measure(name,()=>e.CompileFast(true));}
  Measure("ctor_owned",()=>New(false));Measure("ctor_restricted",()=>New(true));Measure("emit_owned",()=>Emit(false,false));Measure("emit_restricted",()=>Emit(true,false));Measure("eh_owned",()=>Emit(false,true));Measure("eh_restricted",()=>Emit(true,true));
  foreach(bool restricted in new[]{false,true}){var d=New(restricted);Console.WriteLine("Ctor fields restricted="+restricted);foreach(var field in typeof(DynamicMethod).GetFields(BindingFlags.Instance|BindingFlags.NonPublic)){var v=field.GetValue(d);if(v!=null&&(!field.FieldType.IsValueType||field.FieldType==typeof(bool)))Console.WriteLine(field.Name+" : "+v.GetType().FullName+" = "+v);}}
  GC.KeepAlive(sink);
 }
}
