from pathlib import Path
import subprocess,os,json,hashlib
root=Path(__file__).resolve().parent
env=os.environ.copy();env['DOTNET_TieredCompilation']='0';env['DOTNET_ReadyToRun']='0'
manifest={'head':'0fa003b9c51a9392f61142abe1485462c9cd8af5','before':subprocess.check_output(['git','rev-parse','e4c232da'],text=True).strip(),'candidate':'uncommitted-shared-lazy-holder','Sources':{},'Environment':{k:env[k] for k in ['DOTNET_TieredCompilation','DOTNET_ReadyToRun']}}
for v in ['before','head','candidate']:
 manifest['Sources'][v]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ((root/v/'library' if v=='candidate' else root.parent/'cold-allocation'/v/'library')).glob('*.cs')}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2))
with (root/'allocations.jsonl').open('w',encoding='utf-8') as out:
 for tfm in ['net8.0','net10.0']:
  for scenario in ['add','balanced256','quote','rv','quote_rv']:
   for rep in range(9):
    versions=['before','head','candidate'] if scenario in ['add','balanced256'] else ['head','candidate']
    versions=versions[rep%len(versions):]+versions[:rep%len(versions)]
    for v in versions:
     result=subprocess.run(['dotnet',str((root/v if v=='candidate' else root.parent/'cold-allocation'/v)/'bin'/'Release'/tfm/'Runner.dll'),v,scenario,str(rep)],capture_output=True,text=True,env=env)
     if result.returncode:raise RuntimeError(v+' '+tfm+' '+scenario+'\n'+result.stdout+'\n'+result.stderr)
     row=json.loads(result.stdout);out.write(json.dumps(row)+'\n');out.flush()
   print(tfm,scenario,'complete',flush=True)
