from pathlib import Path
import json,collections,statistics,hashlib
root=Path('work/shared-cold-allocation');rows=[json.loads(s) for s in (root/'allocations.jsonl').read_text().splitlines()];g=collections.defaultdict(list)
for r in rows:g[(r['Runtime'],r['Scenario'],r['Version'])].append(r)
summary=[]
for key,rs in sorted(g.items()):
 assert len(rs)==9,key
 item=dict(zip(['Runtime','Scenario','Version'],key));item['Count']=9
 metrics={name:[r[name] for r in rs] for name in ['ColdCompileBytes','FirstInvokeBytes']}
 metrics['ColdCombinedBytes']=[r['ColdCompileBytes']+r['FirstInvokeBytes'] for r in rs]
 metrics['WarmCompileBytesPerOp']=[r['WarmCompileBytes']/64 for r in rs]
 metrics['WarmInvokeBytesPerOp']=[r['WarmInvokeBytes']/256 for r in rs]
 for name,xs in metrics.items():item[name]={'Min':min(xs),'Median':statistics.median(xs),'Max':max(xs),'Samples':xs}
 summary.append(item)
for runtime in sorted(set(r['Runtime'] for r in rows)):
 for scenario in ['add','balanced256','quote','rv','quote_rv']:
  a=next(s for s in summary if s['Runtime']==runtime and s['Scenario']==scenario and s['Version']=='head');b=next(s for s in summary if s['Runtime']==runtime and s['Scenario']==scenario and s['Version']=='candidate')
  for field in ['FirstInvokeBytes','WarmCompileBytesPerOp','WarmInvokeBytesPerOp']:
   for stat in ['Min','Median','Max']:assert b[field][stat]<=a[field][stat],(runtime,scenario,field,stat,a[field],b[field])
  print(runtime,scenario,'coldhead',tuple(a['ColdCompileBytes'][x] for x in ['Min','Median','Max']),'candidate',tuple(b['ColdCompileBytes'][x] for x in ['Min','Median','Max']),'firsthead',tuple(a['FirstInvokeBytes'][x] for x in ['Min','Median','Max']),'candidate',tuple(b['FirstInvokeBytes'][x] for x in ['Min','Median','Max']),'warmcomphead/cand',a['WarmCompileBytesPerOp']['Samples'],b['WarmCompileBytesPerOp']['Samples'],'warminvokehead/cand',a['WarmInvokeBytesPerOp']['Samples'],b['WarmInvokeBytesPerOp']['Samples'])
(root/'summary.json').write_text(json.dumps(summary,indent=2))
manifest=json.loads((root/'manifest.json').read_text());manifest['HarnessSHA256']=hashlib.sha256((root/'Program.cs').read_bytes()).hexdigest();manifest['Binaries']={}
for version in ['before','head','candidate']:
 for tfm in ['net8.0','net10.0']:
  folder=(root/version if version=='candidate' else root.parent/'cold-allocation'/version)/'bin'/'Release'/tfm
  manifest['Binaries'][version+'/'+tfm]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.glob('*.dll')}
manifest['MeasuredRows']=len(rows);manifest['TimingMeasured']=False;manifest['ColdWarmup']='Only GC measurement infrastructure before first FEC call; compilation/invocation warmups occur after cold and first-invoke recording.'
manifest['AcceptedCriterion']='Candidate first-invoke, warm-compile, warm-invoke min/median/max never exceed head in any measured scenario/runtime. All raw samples retained, including noise and cold bimodality.'
(root/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('Total rows',len(rows))
