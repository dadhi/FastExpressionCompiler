from pathlib import Path
import json,collections,statistics,hashlib
root=Path('work/shared-cold-allocation');rows=[json.loads(s) for s in (root/'allocations.jsonl').read_text().splitlines()]
g=collections.defaultdict(list)
for r in rows:g[(r['Runtime'],r['Scenario'],r['Version'])].append(r)
summary=[]
for key,rs in sorted(g.items()):
 assert len(rs)==9,key
 item=dict(zip(['Runtime','Scenario','Version'],key));item['Count']=len(rs)
 for name in ['ColdCompileBytes','FirstInvokeBytes']:
  xs=[r[name] for r in rs];item[name]={'Min':min(xs),'Median':statistics.median(xs),'Max':max(xs),'Samples':xs}
 xs=[r['ColdCompileBytes']+r['FirstInvokeBytes'] for r in rs];item['ColdCombinedBytes']={'Min':min(xs),'Median':statistics.median(xs),'Max':max(xs),'Samples':xs}
 for name,count in [('WarmCompileBytes',64),('WarmInvokeBytes',256)]:item[name+'PerOp']=sorted(set(r[name]/count for r in rs))
 summary.append(item)
for runtime in sorted(set(r['Runtime'] for r in rows)):
 for scenario in ['add','balanced256','quote','rv','quote_rv']:
  a=next(s for s in summary if s['Runtime']==runtime and s['Scenario']==scenario and s['Version']=='head');b=next(s for s in summary if s['Runtime']==runtime and s['Scenario']==scenario and s['Version']=='candidate')
  assert a['FirstInvokeBytes']['Min']==b['FirstInvokeBytes']['Min'] and a['FirstInvokeBytes']['Max']==b['FirstInvokeBytes']['Max'],(runtime,scenario,'firstinvoke')
  assert a['WarmCompileBytesPerOp']==b['WarmCompileBytesPerOp'],(runtime,scenario,'warmcompile')
  assert a['WarmInvokeBytesPerOp']==b['WarmInvokeBytesPerOp'],(runtime,scenario,'warminvoke')
  print(runtime,scenario,'head/candidate coldmedian',a['ColdCompileBytes']['Median'],b['ColdCompileBytes']['Median'],'delta',b['ColdCompileBytes']['Median']-a['ColdCompileBytes']['Median'],'first',a['FirstInvokeBytes']['Median'],b['FirstInvokeBytes']['Median'],'combinedDelta',b['ColdCombinedBytes']['Median']-a['ColdCombinedBytes']['Median'],'warmcompile',b['WarmCompileBytesPerOp'],'warminvoke',b['WarmInvokeBytesPerOp'])
(root/'summary.json').write_text(json.dumps(summary,indent=2))
manifest=json.loads((root/'manifest.json').read_text());manifest['HarnessSHA256']=hashlib.sha256((root/'Program.cs').read_bytes()).hexdigest();manifest['Binaries']={}
for version in ['before','head','candidate']:
 for tfm in ['net8.0','net10.0']:
  folder=(root/version if version=='candidate' else root.parent/'cold-allocation'/version)/'bin'/'Release'/tfm
  manifest['Binaries'][version+'/'+tfm]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.glob('*.dll')}
manifest['MeasuredRows']=len(rows);manifest['TimingMeasured']=False;manifest['ColdWarmup']='Only GC measurement infrastructure before first FEC call; compilation/invocation warmups occur after cold and first-invoke recording.'
(root/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('Total rows',len(rows))
