from pathlib import Path
import shutil,difflib,json,hashlib
w=Path(__file__).resolve().parent
for suffix in ['','-light']:
 d=w/('fixed'+suffix);prior=w/('quote-only'+suffix)
 if not prior.exists():shutil.copytree(d,prior,ignore=shutil.ignore_patterns('bin','obj'))
 p=d/'FastExpressionCompiler.cs';before=p.read_bytes();s=before
 marker=b'            internal bool RequiresSpill;'
 helper='''
            internal static bool CheckArguments(ArgExprs arguments)
            {
                ArgumentSpillScope scope = null;
                for (var i = 0; i < arguments.GetArgCount(); ++i)
                {
                    var argument = arguments.GetArgument(i);
                    if (argument == null) continue;
                    if (
#if LIGHT_EXPRESSION
                        !argument.IsIntrinsic &&
#endif
                        (argument is ConstantExpression || argument is ParameterExpression || argument is DefaultExpression))
                        continue;
                    scope ??= new ArgumentSpillScope();
                    scope.Visit(argument);
                    if (scope.RequiresSpill) return true;
                }
                return false;
            }
'''.encode()
 if b'\r\n' in s:helper=helper.replace(b'\n',b'\r\n')
 assert s.count(marker)==1;s=s.replace(marker,marker+helper)
 old='''                                var argumentScope = new ArgumentSpillScope();
                                for (var i = 0; i < invokeArgCount; ++i)
                                    argumentScope.Visit(invokeArgs.GetArgument(i));'''.encode()
 old2='''                            var argumentScope = new ArgumentSpillScope();
                            var reducedArguments = ((InvocationExpression)reducedDynamic).GetArgExprs();
                            for (var i = 0; i < reducedArguments.GetArgCount(); ++i)
                                argumentScope.Visit(reducedArguments.GetArgument(i));'''.encode()
 nl=b'\r\n' if b'\r\n' in s else b'\n';old=old.replace(b'\n',nl);old2=old2.replace(b'\n',nl)
 if s.count(old)==0:old=old.replace(b'\r\n',b'\n')
 if s.count(old2)==0:old2=old2.replace(b'\r\n',b'\n')
 assert s.count(old)==1;s=s.replace(old,b'                                var argumentsRequireSpill = ArgumentSpillScope.CheckArguments(invokeArgs);')
 assert s.count(old2)==1;s=s.replace(old2,b'                            var reducedArguments = ((InvocationExpression)reducedDynamic).GetArgExprs();'+nl+b'                            var argumentsRequireSpill = ArgumentSpillScope.CheckArguments(reducedArguments);')
 assert s.count(b'argumentScope.RequiresSpill')==2;s=s.replace(b'argumentScope.RequiresSpill',b'argumentsRequireSpill')
 p.write_bytes(s)
 (w/'argument-scan.diff').write_text(''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),s.decode().splitlines(keepends=True),fromfile='quote-only/FastExpressionCompiler.cs',tofile='fixed/FastExpressionCompiler.cs')))
m=json.loads((w/'manifest.json').read_text());m['stages']={'before':'baseline8f','quote-only':'lazy quote free-variable list only','fixed':'quote-only plus lazy shared argument spill scan'}
for stem in ['quote-only','quote-only-light','fixed','fixed-light']:
 m['sources'][stem]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (w/stem).glob('*.cs')}
(w/'manifest.json').write_text(json.dumps(m,indent=2))
