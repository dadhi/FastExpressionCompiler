from pathlib import Path
import subprocess,difflib
w=Path(__file__).resolve().parent;repo=Path(r'C:\Data\Git\Github\FastExpressionCompiler');commit='8f12292f0baa596ed160c0e070ebb8329a623429'
patches=[]
def save(name,before,after):
 (w/('proposed-'+name+'.txt')).write_text(after,newline='\n')
 path='test/FastExpressionCompiler.UnitTests/'+name
 patches.append(''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path)))
name='InvocationJumpArgumentRegressionTests.cs';s=subprocess.check_output(['git','-C',str(repo),'show',commit+':test/FastExpressionCompiler.UnitTests/'+name]).decode().replace('\r\n','\n');before=s
s=s.replace('        Runtime_expression_compilation_follows_argument_jumps(t);','        Runtime_expression_compilation_follows_argument_jumps(t);\n        Pruned_argument_spill_syntax_preserves_runtime_compilation_order(t);')
method='''
    public void Pruned_argument_spill_syntax_preserves_runtime_compilation_order(TestContext t)
    {
        foreach (var jump in new[] { false, true })
        {
            var target = S.Label(typeof(int));
            System.Linq.Expressions.Expression dead = jump
                ? S.Goto(target, S.Constant(7), typeof(int))
                : S.TryFinally(S.Constant(0), S.Empty());
            var argument = S.Condition(S.Constant(true),
                S.Call(typeof(InvocationJumpArgumentRegressionTests).GetMethod(nameof(First))), dead);
            var receiver = S.Call(typeof(InvocationJumpArgumentRegressionTests).GetMethod(nameof(InvalidRuntimeExpression)));
            var tree = S.Lambda<Func<int>>(S.Block(S.Invoke(receiver, argument), S.Label(target, S.Constant(8))));
            var system = tree.Compile();
            Trace = ""; t.Throws<InvalidOperationException>(() => system()); t.AreEqual("receiver;first;", Trace);
            foreach (var flags in new[] { CompilerFlags.Default, CompilerFlags.NoInvocationLambdaInlining,
                CompilerFlags.EnableDelegateDebugInfo | CompilerFlags.ThrowOnNotSupportedExpression })
            {
                var fast = tree.FromSysExpression().CompileFast(true, flags);
                if (!t.IsNotNull(fast)) continue;
                Trace = ""; t.Throws<InvalidOperationException>(() => fast()); t.AreEqual("receiver;first;", Trace);
            }
        }
    }
'''
pos=s.rfind('}');s=s[:pos]+method+s[pos:];save(name,before,s)
name='QuoteIdentityRegressionTests.cs';s=subprocess.check_output(['git','-C',str(repo),'show',commit+':test/FastExpressionCompiler.UnitTests/'+name]).decode().replace('\r\n','\n');before=s
s=s.replace(' public void Run(TestRun t) {',' public void Run(TestRun t) { Opaque_quote_extensions_are_not_reduced(t);')
method='''
 private sealed class OpaqueQuoteBody : System.Linq.Expressions.Expression {
  internal int Reductions;
  public override System.Linq.Expressions.ExpressionType NodeType => System.Linq.Expressions.ExpressionType.Extension;
  public override Type Type => typeof(int);
  public override bool CanReduce => true;
  public override System.Linq.Expressions.Expression Reduce() { ++Reductions; return System.Linq.Expressions.Expression.Constant(42); }
 }
 public void Opaque_quote_extensions_are_not_reduced(TestContext t) {
  var body = new OpaqueQuoteBody();
  var expression = System.Linq.Expressions.Expression.Lambda<Func<System.Linq.Expressions.Expression<Func<int>>>>(
   System.Linq.Expressions.Expression.Quote(System.Linq.Expressions.Expression.Lambda<Func<int>>(body)));
#if LIGHT_EXPRESSION
  // Conversion of opaque System nodes is unsupported and must not reduce the data.
  t.Throws<NotSupportedException>(() => expression.FromSysExpression());
#else
  foreach (var flags in new[] { CompilerFlags.Default, CompilerFlags.NoInvocationLambdaInlining, CompilerFlags.EnableDelegateDebugInfo })
   t.IsTrue(expression.CompileFast(true, flags) == null);
#endif
  t.AreEqual(0, body.Reductions);
 }
'''
pos=s.rfind('}');s=s[:pos]+method+s[pos:];save(name,before,s)
(w/'proposed-native-boundaries.diff').write_text(''.join(patches),newline='\n')
for name in ['InvocationJumpArgumentRegressionTests.cs','QuoteIdentityRegressionTests.cs']:
 stale=w/('proposed-'+name)
 if stale.exists():stale.rename(w/('initial-proposed-'+name+'.txt'))
m=['CapturedQuoteRegressionTests','QuoteIdentityRegressionTests','CaptureFreeQuoteRegressionTests','RuntimeExpressionInvocationRegressionTests','DynamicCallSiteRegressionTests','InvocationJumpArgumentRegressionTests']
includes=''.join('<Compile Include="'+('proposed-'+name+'.cs.txt' if name in ['QuoteIdentityRegressionTests','InvocationJumpArgumentRegressionTests'] else name+'.cs')+'"/>' for name in m)
(w/'NativeProposal.csproj').write_text((w/'Fixture.csproj').read_text().replace('<Compile Include="*RegressionTests.cs"/>',includes))
