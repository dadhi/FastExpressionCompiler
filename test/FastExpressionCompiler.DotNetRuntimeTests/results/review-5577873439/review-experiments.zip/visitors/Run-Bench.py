from pathlib import Path
import argparse,json,subprocess
w=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--exclusive-window',action='store_true');p.add_argument('--stage',choices=['quote','arguments'],required=True);a=p.parse_args()
if not a.exclusive_window:raise SystemExit('An explicit exclusive timing grant is required.')
cases=json.loads((w/'bench-cases.json').read_text())[a.stage]
for light in ['false','true']:
 for tfm in ['net8.0','net10.0','net472']:
  tag=a.stage+'-'+light+'-'+tfm;out=w/'bench-runners'/tag
  exe=out/('VisitorBench.'+a.stage+'.'+light+('.exe' if tfm=='net472' else '.dll'));cmd=[str(exe)] if tfm=='net472' else ['dotnet',str(exe)]
  csv=w/('paired-'+tag+'.csv');log=w/('paired-'+tag+'.log')
  if csv.exists() or log.exists():raise SystemExit('Refusing to overwrite '+tag)
  with csv.open('w') as stdout,log.open('w') as stderr:subprocess.run(cmd+['--measure']+cases,cwd=w,stdout=stdout,stderr=stderr,check=True,timeout=240)
  print('FINISHED '+tag,flush=True)
