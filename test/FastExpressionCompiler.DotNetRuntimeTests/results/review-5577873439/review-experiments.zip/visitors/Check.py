from pathlib import Path
import subprocess,sys
w=Path(__file__).resolve().parent
stage=sys.argv[1] if len(sys.argv)>1 else 'quote-lazy'
if stage=='quote-lazy':subprocess.run(['python','Prepare.py'],cwd=w,check=True)
for light in ['false','true']:
 for tfm in ['net8.0','net10.0','net472']:
  tag=light+'-'+tfm
  with (w/(stage+'-build-'+tag+'.log')).open('w') as f:subprocess.run(['dotnet','build','Fixture.csproj','-c','Release','-f',tfm,'-p:Light='+light,'--nologo','-v:q'],cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True)
  exe=w/'bin'/'Release'/tfm/('Fixture.exe' if tfm=='net472' else 'Fixture.dll');cmd=[str(exe)] if tfm=='net472' else ['dotnet',str(exe)]
  with (w/(stage+'-check-'+tag+'.log')).open('w') as f:subprocess.run(cmd,cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=90)
  print('PASS '+tag,flush=True)
