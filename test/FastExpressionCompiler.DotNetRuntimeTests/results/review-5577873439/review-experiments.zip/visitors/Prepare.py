from pathlib import Path
import subprocess,json,hashlib,difflib
w=Path(__file__).resolve().parent;repo=Path(r'C:\Data\Git\Github\FastExpressionCompiler')
baseline='8f12292f0baa596ed160c0e070ebb8329a623429'
core=['src/FastExpressionCompiler/'+n for n in ['FastExpressionCompiler.cs','ImTools.cs','ILReader.cs','TestTools.cs']]
lightcore=['src/FastExpressionCompiler.LightExpression/'+n for n in ['Expression.cs','ExpressionVisitor.cs','FlatExpression.cs']]
tests=['CapturedQuoteRegressionTests','QuoteIdentityRegressionTests','CaptureFreeQuoteRegressionTests','RuntimeExpressionInvocationRegressionTests','DynamicCallSiteRegressionTests','InvocationJumpArgumentRegressionTests']
m={'baseline':baseline,'sources':{},'tests':tests}
for version in ['before','fixed']:
 for light in [False,True]:
  d=w/(version+('-light' if light else ''));d.mkdir(exist_ok=True)
  for name in core+(lightcore if light else []):
   data=subprocess.check_output(['git','-C',str(repo),'show',baseline+':'+name]);original=data
   if version=='fixed' and name.endswith('/FastExpressionCompiler.cs'):
    old=b'internal readonly List<System.Linq.Expressions.ParameterExpression> FreeVariables = new();'
    assert data.count(old)==1;data=data.replace(old,b'internal List<System.Linq.Expressions.ParameterExpression> FreeVariables;')
    old=b'if (!Bound.Contains(node) && !FreeVariables.Contains(node)) FreeVariables.Add(node);'
    new=b'if (!Bound.Contains(node))\r\n                {\r\n                    FreeVariables ??= new();\r\n                    if (!FreeVariables.Contains(node)) FreeVariables.Add(node);\r\n                }'
    # Preserve the source's existing line-ending convention for inserted lines.
    if b'\r\n' not in data:new=new.replace(b'\r\n',b'\n')
    assert data.count(old)==1;data=data.replace(old,new)
    old=b'quoted.Parameters = quoteVariables.FreeVariables.ToArray();'
    assert data.count(old)==1;data=data.replace(old,b'quoted.Parameters = quoteVariables.FreeVariables?.ToArray() ?? Array.Empty<System.Linq.Expressions.ParameterExpression>();')
    (w/'candidate.diff').write_text(''.join(difflib.unified_diff(original.decode().splitlines(keepends=True),data.decode().splitlines(keepends=True),fromfile='before/FastExpressionCompiler.cs',tofile='fixed/FastExpressionCompiler.cs')))
   (d/Path(name).name).write_bytes(data)
  defines='<DefineConstants>LIGHT_EXPRESSION</DefineConstants>' if light else ''
  (d/'Library.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><AssemblyName>Visitors.'+version+('.Light' if light else '')+'</AssemblyName>'+defines+'</PropertyGroup></Project>')
  m['sources'][d.name]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.glob('*.cs')}
for test in tests:
 data=subprocess.check_output(['git','-C',str(repo),'show',baseline+':test/FastExpressionCompiler.UnitTests/'+test+'.cs']);(w/(test+'.cs')).write_bytes(data)
(w/'manifest.json').write_text(json.dumps(m,indent=2))
