from pathlib import Path
import difflib
w=Path(__file__).resolve().parent
for first,last,name in [('before','quote-only','quote-lazy.diff'),('quote-only','fixed','argument-scan.diff')]:
 a=(w/first/'FastExpressionCompiler.cs').read_bytes().decode().replace('\r\n','\n')
 b=(w/last/'FastExpressionCompiler.cs').read_bytes().decode().replace('\r\n','\n')
 (w/name).write_text(''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/src/FastExpressionCompiler/FastExpressionCompiler.cs',tofile='b/src/FastExpressionCompiler/FastExpressionCompiler.cs')),newline='\n')
