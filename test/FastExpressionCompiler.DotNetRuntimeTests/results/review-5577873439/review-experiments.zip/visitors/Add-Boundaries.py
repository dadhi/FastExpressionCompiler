from pathlib import Path
p=Path(__file__).parent/'Fixture.csproj';s=p.read_text();s=s.replace('<Compile Include="Program.cs"/>','<Compile Include="Program.cs"/><Compile Include="BoundaryChecks.cs"/>');p.write_text(s)
