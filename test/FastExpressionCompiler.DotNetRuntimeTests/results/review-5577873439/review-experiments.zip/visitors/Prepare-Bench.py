from pathlib import Path
import json,hashlib
w=Path(__file__).resolve().parent
for suffix in ['','-light']:
 p=w/('quote-only'+suffix)/'Library.csproj';p.write_text(p.read_text().replace('Visitors.fixed','Visitors.quote'))
for alias,side in [('Before','BeforeSide'),('After','AfterSide')]:
 (w/(side+'.cs')).write_text((w/'Side.template').read_text().replace('ALIAS',alias).replace('SIDE',side))
project='''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><OutputType>Exe</OutputType><LangVersion>latest</LangVersion><Optimize>true</Optimize><EnableDefaultCompileItems>false</EnableDefaultCompileItems><Light Condition="'$(Light)'==''">false</Light><AssemblyName>VisitorBench.$(Stage).$(Light)</AssemblyName><DefineConstants Condition="'$(Light)'=='true'">$(DefineConstants);LIGHT</DefineConstants><BeforeDir Condition="'$(Stage)'=='quote'">before</BeforeDir><AfterDir Condition="'$(Stage)'=='quote'">quote-only</AfterDir><BeforeDir Condition="'$(Stage)'=='arguments'">quote-only</BeforeDir><AfterDir Condition="'$(Stage)'=='arguments'">fixed</AfterDir><Suffix Condition="'$(Light)'=='true'">-light</Suffix></PropertyGroup><ItemGroup><Compile Include="BenchShapes.cs"/><Compile Include="BenchRunner.cs"/><Compile Include="BeforeSide.cs"/><Compile Include="AfterSide.cs"/><ProjectReference Include="$(BeforeDir)$(Suffix)/Library.csproj" Aliases="Before"/><ProjectReference Include="$(AfterDir)$(Suffix)/Library.csproj" Aliases="After"/></ItemGroup></Project>'''
(w/'Bench.csproj').write_text(project)
(w/'bench-cases.json').write_text(json.dumps({'quote':['add','quote_closed','quote_capture'],'arguments':['add','runtime_terminal','runtime_try','runtime_goto','dynamic_terminal','dynamic_try','dynamic_goto']},indent=2))
