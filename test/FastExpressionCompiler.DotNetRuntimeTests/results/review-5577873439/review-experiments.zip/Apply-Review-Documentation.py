from pathlib import Path
import subprocess

w = Path(__file__).resolve().parent
repo = Path(r'C:\Data\Git\Github\FastExpressionCompiler')
source = repo / 'src/FastExpressionCompiler/FastExpressionCompiler.cs'
data = source.read_bytes()
old = (b'        // These scalar scope lists grow their heap part as 4, 9, 19, 39, ... .\r\n'
       b'        // Each growth size has its own logarithmic bucket; keep every reusable size\r\n'
       b'        // without allocating a 1024-entry table for the first overflow.\r\n')
if old not in data:
    old = old.replace(b'\r\n', b'\n')
assert data.count(old) == 1
nl = b'\r\n' if b'\r\n' in old else b'\n'
new = nl.join([
    b'        // Heap lengths grow as 4, 9, 19, 39, ... (2*n+1), each in a distinct',
    b'        // floor(log2(length)) bucket. The 1024 retention bound needs only 11 slots.',
    b'        // Other lengths may share a slot: rent checks the actual length, so a',
    b'        // collision can lose reuse but cannot return an incorrectly sized array.', b''])
data = data.replace(old, new)
marker = b'            [MethodImpl(MethodImplOptions.NoInlining)]\n            private void PushNewLabelScopeFrame'
if marker not in data:
    marker = marker.replace(b'\n', b'\r\n')
assert data.count(marker) == 1
nl = b'\r\n' if b'\r\n' in marker else b'\n'
comment = nl.join([
    b'            // Keep the repeated-kind fast path small when PushLabelScope is',
    b'            // inlined; appending a new frame (including list growth) stays outlined.', b''])
source.write_bytes(data.replace(marker, comment + marker))
for name in ['QuoteIdentityRegressionTests', 'InvocationJumpArgumentRegressionTests']:
    target = repo / 'test/FastExpressionCompiler.UnitTests' / (name + '.cs')
    assert target.read_bytes() == (w/'visitors'/(name+'.cs')).read_bytes()
    target.write_bytes((w/'visitors'/('proposed-'+name+'.cs.txt')).read_bytes())
subprocess.run(['git','diff','--check'], cwd=repo, check=True)
