from pathlib import Path
import subprocess,os,json,time
w=Path(__file__).resolve().parent
assert not (w/'isolated-execution.json').exists(),'Preserve earlier timing runs'
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0',COMPlus_TieredCompilation='0',COMPlus_ReadyToRun='0')
stages=[('flags',['python',str(w/'flags/bench/measure.py')]),('metadata',['python',str(w/'metadata/RunBench.py'),'--mode','warm']),('automatic-inlining',['python',str(w/'frame-inline/measure.py')]),('quote-lazy',['python',str(w/'visitors/Run-Bench.py'),'--stage','quote','--exclusive-window']),('argument-scan',['python',str(w/'visitors/Run-Bench.py'),'--stage','arguments','--exclusive-window'])]
status=[];start=time.monotonic()
for name,command in stages:
 print('START '+name,flush=True)
 result=subprocess.run(command,env=env,timeout=600)
 status.append(dict(stage=name,exit=result.returncode,elapsedTotalSeconds=time.monotonic()-start))
 (w/'isolated-execution.json').write_text(json.dumps(dict(environment={k:env[k] for k in ['DOTNET_TieredCompilation','DOTNET_ReadyToRun','COMPlus_TieredCompilation','COMPlus_ReadyToRun']},stages=status),indent=2))
 if result.returncode:raise SystemExit(result.returncode)
 print('END '+name,flush=True)
print('ALL WARM TIMINGS STOPPED',flush=True)
