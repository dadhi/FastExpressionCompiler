from pathlib import Path
import subprocess,shutil,json,hashlib
w=Path(__file__).resolve().parent;
cases=json.loads((w/'bench-cases.json').read_text());hashes={}
for stage in ['quote']:
 for light in ['false','true']:
  for tfm in ['net8.0','net10.0','net472']:
   tag=stage+'-'+light+'-'+tfm
   with (w/('bench-build-'+tag+'.log')).open('w') as f:subprocess.run(['dotnet','build','Bench.csproj','-c','Release','-f',tfm,'-p:Stage='+stage,'-p:Light='+light,'--nologo','-v:q'],cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True)
   out=w/'bench-runners'/tag;out.mkdir(parents=True,exist_ok=True)
   for p in (w/'bin'/'Release'/tfm).glob('*'):
    if p.is_file():shutil.copy2(p,out/p.name)
   exe=out/('VisitorV2Bench.'+stage+'.'+light+('.exe' if tfm=='net472' else '.dll'));cmd=[str(exe)] if tfm=='net472' else ['dotnet',str(exe)]
   with (w/('bench-check-'+tag+'.log')).open('w') as f:subprocess.run(cmd+['--check']+cases[stage],cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=90)
   hashes[tag]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*') if p.is_file()}
   print('BUILT/CHECKED '+tag,flush=True)
(w/'bench-hashes.json').write_text(json.dumps(hashes,indent=2))
