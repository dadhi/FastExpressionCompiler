from pathlib import Path
import collections,csv,hashlib,json,math,statistics
w=Path(__file__).resolve().parent;hashes=json.loads((w/'bench-hashes.json').read_text());errors=[]
for tag,files in hashes.items():
 for name,h in files.items():
  p=w/'bench-runners'/tag/name
  if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=h:errors.append(['frozenhash',tag,name])
for stage in ['quote']:
 rows=[];groups=collections.defaultdict(list);summary=[]
 for file in sorted(w.glob('paired-'+stage+'-*.csv')):
  light,runtime=file.stem[len('paired-'+stage+'-'):].split('-',1);flavor='Light' if light=='true' else 'Standard'
  for line,values in enumerate(csv.reader(file.open()),1):
   if len(values)!=8:errors.append([file.name,line,'columns',values]);continue
   name,phase,version,sample,n,ns,b,ms=values
   x=dict(scenario=name,phase=phase,version=version,sample=int(sample),operations=int(n),ns=float(ns),bytes=float(b),elapsed_ms=float(ms),runtime=runtime,flavor=flavor,raw=file.name,line=line)
   assert all(math.isfinite(x[k]) for k in ['ns','bytes','elapsed_ms']);assert x['ns']>0 and x['bytes']>=0
   rows.append(x);groups[runtime,flavor,name,phase].append(x)
 for key,xs in sorted(groups.items()):
  vs={v:sorted([x for x in xs if x['version']==v],key=lambda x:x['sample']) for v in ['before','after']}
  for v,z in vs.items():
   if [x['sample'] for x in z]!=list(range(11)):errors.append([stage,key,v,'samples'])
  if any(len(z)!=11 for z in vs.values()):continue
  pairs=list(zip(vs['before'],vs['after']));assert all(a['operations']==b['operations'] for a,b in pairs)
  entry=dict(zip(['runtime','flavor','scenario','phase'],key))
  for v,z in vs.items():entry[v]=dict(ns=statistics.median(x['ns'] for x in z),bytes=statistics.median(x['bytes'] for x in z),ns_samples=[x['ns'] for x in z],bytes_samples=[x['bytes'] for x in z],elapsed_ms=[x['elapsed_ms'] for x in z],operations=sorted({x['operations'] for x in z}))
  entry.update(paired_ratio=statistics.median(b['ns']/a['ns'] for a,b in pairs),paired_ratios=[b['ns']/a['ns'] for a,b in pairs],ratio_of_ns_medians=entry['after']['ns']/entry['before']['ns'],byte_delta=entry['after']['bytes']-entry['before']['bytes'],paired_byte_deltas=[b['bytes']-a['bytes'] for a,b in pairs])
  summary.append(entry)
 expected=66 if stage=='quote' else 126
 if len(summary)!=expected:errors.append([stage,'groups',len(summary),expected])
 counts=collections.Counter('higher' if x['byte_delta']>0 else 'lower' if x['byte_delta']<0 else 'equal' for x in summary)
 short=[x for x in rows if x['elapsed_ms']<20]
 result=dict(stage=stage,baseline='8f12292f0baa596ed160c0e070ebb8329a623429',comparison='baseline8f to compile-only-collector split V2',complete=not errors,rows=rows,summary=summary,allocation_counts=dict(counts),under20ms=len(short),minimum_ms=min(x['elapsed_ms'] for x in rows),errors=errors,frozen_hashes_match=not any(e[0]=='frozenhash' for e in errors))
 (w/('analysis-'+stage+'.json')).write_text(json.dumps(result,indent=2))
 lines=[stage+' COMPLETE='+str(not errors)+' ROWS='+str(len(rows))+' GROUPS='+str(len(summary)),'Allocation='+str(dict(counts))+' under20ms='+str(len(short))+' min_ms='+str(result['minimum_ms'])]
 for x in summary:lines.append(' '.join(x[k] for k in ['runtime','flavor','scenario','phase'])+' paired='+format(x['paired_ratio'],'.5f')+' medianRatio='+format(x['ratio_of_ns_medians'],'.5f')+' bytes='+str([x['before']['bytes'],x['after']['bytes'],x['byte_delta']]))
 (w/('REPORT-'+stage+'.txt')).write_text('\n'.join(lines))
 print('\n'.join(lines[:2]))
