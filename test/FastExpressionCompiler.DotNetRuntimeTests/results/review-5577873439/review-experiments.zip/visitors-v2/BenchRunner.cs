using System;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
class BenchRunner {
 static readonly Func<long> Allocated=(Func<long>)Delegate.CreateDelegate(typeof(Func<long>),typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread"));
 static int Count(Action<int>[] actions){int n=4;for(int attempt=0;attempt<6;attempt++){double fastest=double.MaxValue;foreach(var action in actions){long start=Stopwatch.GetTimestamp();action(n);fastest=Math.Min(fastest,(Stopwatch.GetTimestamp()-start)/(double)Stopwatch.Frequency);}if(fastest>=.020)return n;n=(int)Math.Min(64000000,Math.Max(n+1,Math.Ceiling(n*.025/Math.Max(fastest,.000001))));}return n;}
 static void Main(string[] args){bool check=args[0]=="--check";foreach(var name in args.Skip(1)){
  var tree=BenchShapes.Build(name);var operations=new[]{BeforeSide.Operations(name,tree),AfterSide.Operations(name,tree)};
  foreach(var phase in operations[0].Keys){var actions=operations.Select(x=>x[phase]).ToArray();if(check){foreach(var action in actions)action(1);continue;}
   foreach(var action in actions)action(40);int n=Count(actions);
   for(int sample=0;sample<11;sample++){if(sample%5==0){GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();}for(int order=0;order<2;order++){int v=(sample+order)%2;long bytes=Allocated(),start=Stopwatch.GetTimestamp();actions[v](n);long elapsed=Stopwatch.GetTimestamp()-start,allocated=Allocated()-bytes;double ms=elapsed*1000.0/Stopwatch.Frequency;Console.WriteLine(name+","+phase+","+(v==0?"before":"after")+","+sample+","+n+","+(ms*1e6/n).ToString("R",CultureInfo.InvariantCulture)+","+(allocated/(double)n).ToString("R",CultureInfo.InvariantCulture)+","+ms.ToString("R",CultureInfo.InvariantCulture));}}
  }Console.Error.WriteLine("PASS "+name);
 }}
}
