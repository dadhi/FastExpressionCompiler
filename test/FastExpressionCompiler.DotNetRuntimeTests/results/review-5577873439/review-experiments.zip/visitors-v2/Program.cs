using System;
#if LIGHT_EXPRESSION
using FastExpressionCompiler.LightExpression;
using FastExpressionCompiler.LightExpression.UnitTests;
#else
using FastExpressionCompiler;
using FastExpressionCompiler.UnitTests;
#endif
class Program {
 static void Main(){var t=new TestRun(TestFlags.RethrowException);
 t.Run(new CapturedQuoteRegressionTests());t.Run(new QuoteIdentityRegressionTests());t.Run(new CaptureFreeQuoteRegressionTests());t.Run(new RuntimeExpressionInvocationRegressionTests());t.Run(new DynamicCallSiteRegressionTests());t.Run(new InvocationJumpArgumentRegressionTests());
 if(t.FailedTestCount!=0)throw new Exception("Visitor fixtures failed");BoundaryChecks.Run();Console.WriteLine("VISITOR FIXTURES PASS tests="+t.TotalTestCount);}
}
