from pathlib import Path
import subprocess
w=Path(__file__).resolve().parent
for light in ['false','true']:
 for tfm in ['net8.0','net10.0','net472']:
  tag=light+'-'+tfm
  with (w/('native-proposal-build-'+tag+'.log')).open('w') as f:subprocess.run(['dotnet','build','NativeProposal.csproj','-c','Release','-f',tfm,'-p:Light='+light,'--nologo','-v:q'],cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True)
  exe=w/'bin'/'Release'/tfm/('NativeProposal.exe' if tfm=='net472' else 'NativeProposal.dll');cmd=[str(exe)] if tfm=='net472' else ['dotnet',str(exe)]
  with (w/('native-proposal-check-'+tag+'.log')).open('w') as f:subprocess.run(cmd,cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=90)
  print('PROPOSED NATIVE PASS '+tag,flush=True)
