using System;
using System.Collections.ObjectModel;
using System.Runtime.CompilerServices;
using S=System.Linq.Expressions.Expression;
static class BenchShapes {
 public static System.Linq.Expressions.Expression<Func<int,object>> Build(string name){
  var x=S.Parameter(typeof(int),"x");System.Linq.Expressions.Expression body;
  if(name=="add")body=S.Add(x,S.Constant(1));
  else if(name=="quote_closed"||name=="quote_capture")body=S.Quote(S.Lambda<Func<int>>(name=="quote_closed"?S.Constant(7):(System.Linq.Expressions.Expression)x));
  else {
   var target=S.Label(typeof(int));System.Linq.Expressions.Expression argument=x;
   if(name.EndsWith("try"))argument=S.Condition(S.Constant(true),x,S.TryFinally(S.Constant(0),S.Empty()));
   if(name.EndsWith("goto"))argument=S.Condition(S.LessThan(x,S.Constant(0)),S.Goto(target,S.Constant(7),typeof(int)),x);
   if(name.StartsWith("runtime")){
    var p=S.Parameter(typeof(int));var data=S.Lambda<Func<int,int>>(S.Add(p,S.Constant(1)),p);body=S.Invoke(S.Constant(data),argument);
   } else body=S.MakeDynamic(typeof(Func<CallSite,int,int>),new AddBinder(),argument);
   if(name.EndsWith("goto"))body=S.Block(body,S.Label(target,S.Constant(8)));
  }
  return S.Lambda<Func<int,object>>(S.Convert(body,typeof(object)),x);
 }
 sealed class AddBinder:CallSiteBinder {
  public override T BindDelegate<T>(CallSite<T> site,object[] args)=>(T)(object)new Func<CallSite,int,int>((s,x)=>x+1);
  public override System.Linq.Expressions.Expression Bind(object[] args,ReadOnlyCollection<System.Linq.Expressions.ParameterExpression> parameters,System.Linq.Expressions.LabelTarget returnLabel)=>throw new NotSupportedException();
 }
}
