extern alias Before;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
#if LIGHT
using Before::FastExpressionCompiler.LightExpression;
using Tree=Before::FastExpressionCompiler.LightExpression.LambdaExpression;
#else
using Before::FastExpressionCompiler;
using Tree=System.Linq.Expressions.LambdaExpression;
#endif
static class BeforeSide {
 static object sink;
 static Tree Convert(System.Linq.Expressions.Expression<Func<int,object>> source){
#if LIGHT
 return source.ToLightExpression();
#else
 return source;
#endif
 }
 [MethodImpl(MethodImplOptions.NoInlining)]static Func<int,object> Compile(Tree tree)=>(Func<int,object>)(tree.CompileFast(true)??throw new Exception("Strict compile failed"));
 static int Value(object result)=>result is System.Linq.Expressions.Expression<Func<int>> q?q.Compile()():(int)result;
 public static Dictionary<string,Action<int>> Operations(string name,System.Linq.Expressions.Expression<Func<int,object>> source){
  var tree=Convert(source);var compiled=Compile(tree);var system=source.Compile();
  foreach(int input in new[]{-1,3,7})if(Value(compiled(input))!=Value(system(input)))throw new Exception("Incorrect "+name);
  if(name.StartsWith("quote")){
   var first=(System.Linq.Expressions.Expression<Func<int>>)compiled(3);var second=(System.Linq.Expressions.Expression<Func<int>>)compiled(7);
   if(name=="quote_closed"&&!ReferenceEquals(first,second))throw new Exception("Closed identity changed");
   if(name=="quote_capture"&&(ReferenceEquals(first,second)||first.Compile()()!=3||second.Compile()()!=7))throw new Exception("Quote activation binding changed");
  }
  var ops=new Dictionary<string,Action<int>>();
  ops["compile"]=n=>{for(int i=0;i<n;i++)sink=Compile(tree);};
  ops["compile_first"]=n=>{for(int i=0;i<n;i++)sink=Compile(tree)(3);};
  ops[name.StartsWith("quote")?"quoted_activation":"invoke"]=n=>{for(int i=0;i<n;i++)sink=compiled(3);};
  if(name.StartsWith("quote")){
   var child=((System.Linq.Expressions.Expression<Func<int>>)compiled(3)).Compile();
   ops["quoted_nested_invoke"]=n=>{int sum=0;for(int i=0;i<n;i++)sum+=child();sink=sum;};
  }return ops;
 }
}
