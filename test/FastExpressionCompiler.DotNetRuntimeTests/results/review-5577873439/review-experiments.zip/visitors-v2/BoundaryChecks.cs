using System;
using System.Reflection;
using S=System.Linq.Expressions.Expression;
#if LIGHT_EXPRESSION
using FastExpressionCompiler.LightExpression;
#else
using FastExpressionCompiler;
#endif
static class BoundaryChecks {
 static string trace;
 public static System.Linq.Expressions.Expression<Func<int,int>> InvalidRuntimeData(){trace+="receiver;";return S.Lambda<Func<int,int>>(S.Parameter(typeof(int),"unbound"),S.Parameter(typeof(int),"p"));}
 public static int Argument(){trace+="argument;";return 42;}
 sealed class Opaque:System.Linq.Expressions.Expression {
  public int Reductions;
  public override System.Linq.Expressions.ExpressionType NodeType=>System.Linq.Expressions.ExpressionType.Extension;
  public override Type Type=>typeof(int);public override bool CanReduce=>true;
  public override System.Linq.Expressions.Expression Reduce(){++Reductions;return S.Constant(42);}
 }
 public static void Run(){
  var opaque=new Opaque();var template=S.Lambda<Func<int>>(opaque);
  // Light cannot convert a System opaque extension. Exercise the same System quote
  // analysis boundary directly there, without inventing a Light conversion policy.
  var compiler=typeof(CompilerFlags).Assembly.GetType(typeof(CompilerFlags).Namespace+".ExpressionCompiler");
  var scopeType=compiler.GetNestedType("QuoteVariableScope",BindingFlags.NonPublic);
  var scope=(System.Linq.Expressions.ExpressionVisitor)Activator.CreateInstance(scopeType,true);scope.Visit(template);
  if(opaque.Reductions!=0||!(bool)scopeType.GetField("HasOpaqueExtension",BindingFlags.Instance|BindingFlags.NonPublic).GetValue(scope))throw new Exception("Opaque quote analysis reduced or missed extension");
#if !LIGHT_EXPRESSION
  if(S.Lambda<Func<System.Linq.Expressions.Expression<Func<int>>>>(S.Quote(template)).CompileFast(true)!=null||opaque.Reductions!=0)throw new Exception("Opaque quote must remain unsupported without Reduce");
#endif
  foreach(bool jump in new[]{false,true}){
   var done=S.Label(typeof(int));
   System.Linq.Expressions.Expression removed=jump?S.Goto(done,S.Constant(7),typeof(int)):S.TryFinally(S.Constant(0),S.Empty());
   var argument=S.Condition(S.Constant(true),S.Call(typeof(BoundaryChecks).GetMethod(nameof(Argument))),removed);
   var tree=S.Lambda<Func<int>>(S.Block(S.Invoke(S.Call(typeof(BoundaryChecks).GetMethod(nameof(InvalidRuntimeData))),argument),S.Label(done,S.Constant(8))));
   var system=Observe(tree.Compile());
   foreach(var flags in new[]{CompilerFlags.Default,CompilerFlags.NoInvocationLambdaInlining,CompilerFlags.EnableDelegateDebugInfo|CompilerFlags.ThrowOnNotSupportedExpression}){
    var fast=tree.FromSysExpression().CompileFast(true,flags);if(fast==null||Observe(fast)!=system)throw new Exception("Pruned argument spill order mismatch");
   }
  }Console.WriteLine("OPAQUE/PRUNED BOUNDARIES PASS");
 }
 static string Observe(Func<int> f){trace="";try{return f()+":"+trace;}catch(Exception e){return e.GetType().FullName+":"+trace;}}
}
