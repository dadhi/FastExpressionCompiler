from pathlib import Path
import json
w=Path(__file__).resolve().parent;a=json.loads((w/'analysis-quote.json').read_text());old=json.loads((w.parent/'visitors'/'analysis-quote.json').read_text())
v1={(x['runtime'],x['flavor'],x['scenario'],x['phase']):x for x in old['summary']};rows=[]
for x in a['summary']:
 if x['scenario']!='quote_capture':continue
 key=(x['runtime'],x['flavor'],x['scenario'],x['phase']);p=v1[key]
 rows.append(dict(runtime=x['runtime'],flavor=x['flavor'],phase=x['phase'],v1_paired_ratio=p['paired_ratio'],v2_paired_ratio=x['paired_ratio'],v1_ns_median_ratio=p['ratio_of_ns_medians'],v2_ns_median_ratio=x['ratio_of_ns_medians'],v1_byte_delta=p['byte_delta'],v2_byte_delta=x['byte_delta'],v2_before_ns=x['before']['ns'],v2_after_ns=x['after']['ns']))
(w/'v1-v2-comparison.json').write_text(json.dumps({'note':'Separate experiments, each paired against baseline8f. No direct paired V2/V1 speed claim.', 'rows':rows},indent=2))
lines=['FINAL DECISION: HOLD/REJECT quote V1 and V2 under the no-introduced-performance-regression criterion.',
'V2 sources remain scratch only; no production edit or GitHub reply. No further variants or measurements.',
'V2 complete:1452 observations,66 phase/config groups;52 allocation medians equal,14 lower,0 higher. Of14 lower,12 are captured activation/compilefirst and2 fractional differences. Frozen file hash guard matched all six configurations.',
'Captured quote activation saves40B on .NET8/10 (384→344),48B on Framework (624→576); V1 saved32/40B. The extra8B is consistent with removal of the unused field from the binder object. V2 retains eager compile-time collection, so the material closed-quote compile savings of V1 are absent.',
'Captured compile-first remains slower: paired ratios Standard8 1.0209,Light8 1.1571,Standard10 1.2502,Light10 1.1870,StandardFramework 1.1692,LightFramework 1.1994. Standard8 ratio of ns medians is0.9911; retain this distinction. Other five ns-median ratios are1.1513–1.2363. FrameworkLight activation is also1.0687 paired. These observations prevent a CPU-parity claim.',
'57 samples were below20ms; minimum13.8778ms. All durations and samples retained. Disturbed scalar controls (e.g. Standard10 add compile paired1.2692,medianratio1.0823) limit causal attribution; they do not justify discarding observed target costs.',
'Source/harness diagnosis: compile_first constructs and invokes a fresh DynamicMethod on every operation. For these no-EH roots, target JIT is deferred to invocation. BindQuote, QuoteBinder construction and its lexical-base construction are small unannotated methods that may inline transitively into each fresh target. Removing the list changes constructor IL and object layout. This is a plausible first-JIT effect, not proven native/JIT attribution. V2 removes the V1 compile-time lazy-list branch while retaining a shorter runtime base constructor; persistence of the target cost means that branch alone cannot explain the regression.',
'Keep the meaningful opaque-quote/noReduce and constant-pruned Try/Goto ordering tests and concrete documentation about compiler-stage/runtime-stage/preserved-syntax distinctions. Do not claim a full visitor merge: QuoteBinder still requires actual activation cells, and argument syntax scanning must retain pruned branches.',
'V1/V2 comparisons describe two separate experiments relative to8f; no direct V2/V1 speed ratio is asserted.']
(w/'DECISION.txt').write_text('\n\n'.join(lines),encoding='utf-8')
print(lines[0])
