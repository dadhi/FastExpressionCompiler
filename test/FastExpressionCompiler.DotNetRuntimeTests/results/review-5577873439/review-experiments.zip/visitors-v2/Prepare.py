from pathlib import Path
import shutil,json,difflib,hashlib
w=Path(__file__).resolve().parent;old=w.parent/'visitors';m={'baseline':'8f12292f0baa596ed160c0e070ebb8329a623429','sources':{}}
for version in ['before','fixed']:
 for light in [False,True]:
  suffix='-light' if light else '';d=w/(version+suffix);d.mkdir(exist_ok=True)
  for p in (old/('before'+suffix)).glob('*.cs'):
   data=p.read_bytes()
   if version=='fixed' and p.name=='FastExpressionCompiler.cs':
    before=data.decode().replace('\r\n','\n');s=before
    field='            internal readonly List<System.Linq.Expressions.ParameterExpression> FreeVariables = new();\n'
    method='''            protected override System.Linq.Expressions.Expression VisitParameter(System.Linq.Expressions.ParameterExpression node)
            {
                if (!Bound.Contains(node) && !FreeVariables.Contains(node)) FreeVariables.Add(node);
                return node;
            }
'''
    assert s.count(field)==1 and s.count(method)==1
    s=s.replace(field,'').replace(method,'')
    marker='        internal sealed class QuotedExpressionCache'
    derived='''        private sealed class QuoteVariableCollector : QuoteVariableScope
        {
            internal readonly List<System.Linq.Expressions.ParameterExpression> FreeVariables = new();
'''+method+'''        }

'''
    assert s.count(marker)==1;s=s.replace(marker,derived+marker)
    assert s.count('var quoteVariables = new QuoteVariableScope();')==1;s=s.replace('var quoteVariables = new QuoteVariableScope();','var quoteVariables = new QuoteVariableCollector();')
    data=s.encode();(w/'candidate.diff').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='a/src/FastExpressionCompiler/FastExpressionCompiler.cs',tofile='b/src/FastExpressionCompiler/FastExpressionCompiler.cs')),newline='\n')
   (d/p.name).write_bytes(data)
  defines='<DefineConstants>LIGHT_EXPRESSION</DefineConstants>' if light else ''
  (d/'Library.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><AssemblyName>VisitorsV2.'+version+('.Light' if light else '')+'</AssemblyName>'+defines+'</PropertyGroup></Project>')
  m['sources'][d.name]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.glob('*.cs')}
for p in old.glob('*RegressionTests.cs'):shutil.copy2(p,w/p.name)
for name in ['Program.cs','BoundaryChecks.cs','Fixture.csproj','NativeProposal.csproj','Verify-Native-Proposals.py','BenchShapes.cs','BenchRunner.cs','BeforeSide.cs','AfterSide.cs']:
 shutil.copy2(old/name,w/name)
for p in old.glob('proposed-*.cs.txt'):shutil.copy2(p,w/p.name)
shutil.copy2(old/'proposed-native-boundaries.diff',w/'proposed-native-boundaries.diff')
project=(old/'Bench.csproj').read_text().replace('VisitorBench.','VisitorV2Bench.').replace('<AfterDir Condition="\'$(Stage)\'==\'quote\'">quote-only</AfterDir>','<AfterDir Condition="\'$(Stage)\'==\'quote\'">fixed</AfterDir>')
(w/'Bench.csproj').write_text(project)
(w/'bench-cases.json').write_text(json.dumps({'quote':['add','quote_closed','quote_capture']}))
build=(old/'Build-Bench.py').read_text().replace("subprocess.run(['python','Prepare-Bench.py'],cwd=w,check=True)", '').replace("['quote','arguments']","['quote']").replace('VisitorBench.','VisitorV2Bench.')
(w/'Build-Bench.py').write_text(build)
(w/'Run-Bench.py').write_text((old/'Run-Bench.py').read_text().replace('VisitorBench.','VisitorV2Bench.'))
(w/'Analyze.py').write_text((old/'Analyze.py').read_text().replace("['quote','arguments']","['quote']").replace("'baseline→quote-only' if stage=='quote' else 'quote-only→arguments'","'baseline→compile-time collector split'"))
(w/'manifest.json').write_text(json.dumps(m,indent=2))
