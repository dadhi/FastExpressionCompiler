from pathlib import Path
import subprocess,json,hashlib,difflib
r=Path(r'C:/Data/Git/Github/FastExpressionCompiler');out=Path(__file__).resolve().parent
base='8f12292f0baa596ed160c0e070ebb8329a623429';files=['FastExpressionCompiler.cs','ImTools.cs','ILReader.cs','TestTools.cs']
for name in ['before','fixed']:
 p=out/name;p.mkdir(exist_ok=True)
 for file in files:(p/file).write_bytes(subprocess.check_output(['git','show',base+':src/FastExpressionCompiler/'+file],cwd=r))
 (p/'Library.csproj').write_text(f'<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><AssemblyName>FecMetadata.{name}</AssemblyName></PropertyGroup></Project>')
 for_light=out/(name+'-light');for_light.mkdir(exist_ok=True)
 for file in ['Expression.cs','ExpressionVisitor.cs','FlatExpression.cs']:(for_light/file).write_bytes(subprocess.check_output(['git','show',base+':src/FastExpressionCompiler.LightExpression/'+file],cwd=r))
 (for_light/'Library.csproj').write_text(f'<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><DefineConstants>LIGHT_EXPRESSION</DefineConstants><AssemblyName>FecMetadata.Light.{name}</AssemblyName></PropertyGroup><ItemGroup>'+''.join(f'<Compile Include="../{name}/{file}"/>' for file in files)+'</ItemGroup></Project>')
p=out/'fixed/FastExpressionCompiler.cs';original=p.read_bytes();text=original.decode();old='''        internal struct ExceptionRegionFrame
        {
            internal bool CannotLeave;
            internal int Region;
        }''';new='''        internal struct ExceptionRegionFrame
        {
            // Region is a nonnegative ScopeInfos index; reserve only its unused sign bit.
            private int _regionAndCannotLeave;
            internal bool CannotLeave
            {
                get => _regionAndCannotLeave < 0;
                set => _regionAndCannotLeave = (_regionAndCannotLeave & int.MaxValue) | (value ? int.MinValue : 0);
            }
            internal int Region
            {
                get => _regionAndCannotLeave & int.MaxValue;
                set => _regionAndCannotLeave = (_regionAndCannotLeave & int.MinValue) | value;
            }
        }'''
normalized=text.replace('\r\n','\n');assert normalized.count(old)==1;patched=normalized.replace(old,new);p.write_bytes(patched.replace('\n','\r\n').encode() if '\r\n' in text else patched.encode());(out/'candidate.diff').write_text(''.join(difflib.unified_diff(normalized.splitlines(True),patched.splitlines(True),fromfile='a/src/FastExpressionCompiler/FastExpressionCompiler.cs',tofile='b/src/FastExpressionCompiler/FastExpressionCompiler.cs')),encoding='utf8')
fixtures=['ScopedVariableBindingRegressionTests','ScopedLabelBindingRegressionTests','LexicalJumpScopeRegressionTests','LabelDefinitionValidationRegressionTests','ExceptionRegionValidationRegressionTests','ExceptionJumpValidationRegressionTests']
for f in fixtures:(out/(f+'.cs')).write_bytes(subprocess.check_output(['git','show',base+':test/FastExpressionCompiler.UnitTests/'+f+'.cs'],cwd=r))
for flavor in ['standard','light']:
 p=out/('native-'+flavor);p.mkdir(exist_ok=True);light=flavor=='light';ns='FastExpressionCompiler.LightExpression' if light else 'FastExpressionCompiler';lib='fixed-light' if light else 'fixed';asm='FecMetadata.Light.fixed' if light else 'FecMetadata.fixed'
 (p/'Native.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><EnableDefaultCompileItems>false</EnableDefaultCompileItems>'+('<DefineConstants>LIGHT_EXPRESSION</DefineConstants>' if light else '')+'</PropertyGroup><ItemGroup>'+''.join(f'<Compile Include="../{f}.cs"/>' for f in fixtures)+f'<Compile Include="Program.cs"/><ProjectReference Include="../{lib}/Library.csproj"/></ItemGroup></Project>')
 (p/'Program.cs').write_text(f'using System;class Program{{static void Main(){{var run=new {ns}.TestRun();'+''.join(f'run.Run(new {ns}.UnitTests.{f}());' for f in fixtures)+'Console.WriteLine("Tests="+run.TotalTestCount+" failed="+run.FailedTestCount+" assertions="+run.Failures.Count);if(run.FailedTestCount!=0)Environment.Exit(1);}}')
(out/'manifest.json').write_text(json.dumps(dict(base=base,sourceHashes={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['before','fixed','before-light','fixed-light'] for p in (out/folder).glob('*.cs')},scope='Only ExceptionRegionFrame sign-bit packing; no int narrowing, explicit layout, new traversal, cache or valid-tree limit.'),indent=2))
