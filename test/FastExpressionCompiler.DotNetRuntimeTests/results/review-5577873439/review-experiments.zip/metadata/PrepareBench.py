from pathlib import Path
p=Path(__file__).resolve().parent;b=p/'benchmark';b.mkdir(exist_ok=True);template=p.parents[1]/'pr558-round4/combined-final-bounded'
for source,target in [('Current.cs','Current.cs'),('Fixed.cs','Fixed.cs'),('Canonical.cs','Canonical.cs')]:
 s=(template/source).read_text(encoding='utf8')
 if target!='Canonical.cs':
  start=s.index(' public static void Cold(');s=s[:start]+''' public static void Cold(string name){
  var original=SharedShapes.Build(name);var tree=Convert(original);_=Allocated();
  long b=Allocated();var compiled=Compile(tree);int result=Invoke(compiled);long bytes=Allocated()-b;
  if(result!=Invoke(original.Compile()))throw new Exception("Cold oracle mismatch");
  Console.WriteLine(name+",VERSION,"+bytes+","+result);GC.KeepAlive(compiled);
 }
}}
'''.replace('VERSION','current' if target=='Current.cs' else 'fixed')
 else:s=s.replace('s.Replace("Combined.current.Light","CompilerSnapshot.Light")','s.Replace("FecMetadata.Light.before","CompilerSnapshot.Light").Replace("FecMetadata.Light.fixed","CompilerSnapshot.Light").Replace("FecMetadata.before","CompilerSnapshot").Replace("FecMetadata.fixed","CompilerSnapshot").Replace("Combined.current.Light","CompilerSnapshot.Light")')
 (b/target).write_text(s,encoding='utf8')
(b/'SharedShapes.cs').write_text('''using System;using S=System.Linq.Expressions.Expression;
public static class SharedShapes {
 public static int FinallyCount; public static void Finish(){++FinallyCount;}
 public static System.Linq.Expressions.LambdaExpression Build(string name){
 var x=S.Parameter(typeof(int),"x");System.Linq.Expressions.Expression body=S.Add(x,S.Constant(1));
 if(name!="add"){
  var done=S.Label(typeof(int),"done");body=S.Goto(done,body,typeof(int));
  int depth=name=="try_goto"?1:name=="nested_eh12"?12:throw new ArgumentException(name);
  for(int i=0;i<depth;i++)body=S.TryFinally(body,S.Call(typeof(SharedShapes).GetMethod("Finish")));
  body=S.Block(body,S.Label(done,S.Constant(-1)));
 }return S.Lambda<Func<int,int>>(body,x);
 }}''',encoding='utf8')
(b/'Runner.cs').write_text('''using System;using System.Diagnostics;using System.Globalization;using System.Linq;
class Runner {
 static readonly Func<long> Allocated=(Func<long>)Delegate.CreateDelegate(typeof(Func<long>),typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread"));
 static void Measure(string name,string phase,string version,int sample,Action<int> op,int n){long b=Allocated(),t=Stopwatch.GetTimestamp();op(n);long elapsed=Stopwatch.GetTimestamp()-t,bytes=Allocated()-b;double ms=elapsed*1000.0/Stopwatch.Frequency;Console.WriteLine(string.Join(",",name,phase,version,sample,n,(elapsed*1e9/Stopwatch.Frequency/n).ToString("R",CultureInfo.InvariantCulture),(bytes/(double)n).ToString("R",CultureInfo.InvariantCulture),ms.ToString("R",CultureInfo.InvariantCulture),ms<20,n==64000000));}
 static int Calibrate(Action<int>[] actions,string phase){int n=phase=="compile"?8:phase=="compile_first"?4:1024;for(int attempt=0;attempt<6;attempt++){double fastest=double.MaxValue;foreach(var op in actions){long t=Stopwatch.GetTimestamp();op(n);fastest=Math.Min(fastest,(Stopwatch.GetTimestamp()-t)/(double)Stopwatch.Frequency);}if(fastest>=.025)return n;n=(int)Math.Min(64000000,Math.Max(n+1,Math.Ceiling(n*.025/Math.Max(fastest,.00001))));}return n;}
 static void Main(string[] args){if(args[0]=="--cold"){if(args[1]=="current")Current.Bench.Cold(args[2]);else Fixed.Bench.Cold(args[2]);return;}bool check=args[0]=="--check";if(check)args=args.Skip(1).ToArray();foreach(var name in args){var tree=SharedShapes.Build(name);var operations=new[]{Current.Bench.Operations(name,tree),Fixed.Bench.Operations(name,tree)};if(check){foreach(var ops in operations)foreach(var op in ops.Values)op(1);Console.WriteLine(Json.Write(new{Name=name,Current=Canonical.Delegates(Current.Bench.Compiled(tree)),Fixed=Canonical.Delegates(Fixed.Bench.Compiled(tree))}));continue;}foreach(var phase in operations[0].Keys){var actions=operations.Select(x=>x[phase]).ToArray();foreach(var op in actions)op(40);int n=Calibrate(actions,phase);Console.Error.WriteLine(name+" "+phase+" commonCount="+n);for(int k=0;k<11;k++){if(k%5==0){GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();}for(int j=0;j<2;j++){int v=(k+j)%2;Measure(name,phase,v==0?"current":"fixed",k,actions[v],n);}}}}}
}''',encoding='utf8')
for light in [False,True]:
 suffix='light' if light else 'standard';folder=b/suffix;folder.mkdir(exist_ok=True);before='before-light' if light else 'before';fixed='fixed-light' if light else 'fixed'
 (folder/'Bench.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><OutputType>Exe</OutputType><LangVersion>latest</LangVersion><Optimize>true</Optimize><EnableDefaultCompileItems>false</EnableDefaultCompileItems>'+('<DefineConstants>LIGHT</DefineConstants>' if light else '')+'</PropertyGroup><ItemGroup>'+''.join(f'<Compile Include="../{s}.cs"/>' for s in ['Runner','Canonical','SharedShapes','Current','Fixed'])+f'<ProjectReference Include="../../{before}/Library.csproj" Aliases="Before"/><ProjectReference Include="../../{fixed}/Library.csproj" Aliases="After"/></ItemGroup></Project>')
print('Prepared metadata-only pair scaffold, no measurements.')
