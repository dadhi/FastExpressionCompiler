from pathlib import Path
import json,csv,statistics,collections
p=Path(__file__).resolve().parent;b=p/'benchmark';rows=[]
for f in sorted(b.glob('warm-*.csv')):
 flavor,tfm=f.stem[5:].split('-',1)
 for r in csv.reader(f.open(encoding='utf8')):
  assert len(r)==10,(f,r)
  name,phase,version,sample,ops,ns,bs,ms,short,cap=r;rows.append(dict(flavor=flavor,tfm=tfm,shape=name,phase=phase,version=version,sample=int(sample),operations=int(ops),ns=float(ns),bytes=float(bs),duration_ms=float(ms),under20=short=='True',atCap=cap=='True'))
groups=collections.defaultdict(list)
for r in rows:groups[tuple(r[k] for k in ['tfm','flavor','shape','phase'])].append(r)
comparisons=[]
for key,rs in sorted(groups.items()):
 versions={v:sorted([r for r in rs if r['version']==v],key=lambda r:r['sample']) for v in ['current','fixed']};a=versions['current'];z=versions['fixed'];assert len(a)==len(z)==11
 assert all(x['sample']==y['sample'] and x['operations']==y['operations'] for x,y in zip(a,z))
 comparisons.append(dict(zip(['tfm','flavor','shape','phase'],key),before_ns=statistics.median(x['ns'] for x in a),fixed_ns=statistics.median(x['ns'] for x in z),paired_ratio=statistics.median(y['ns']/x['ns'] for x,y in zip(a,z)),before_bytes=statistics.median(x['bytes'] for x in a),fixed_bytes=statistics.median(x['bytes'] for x in z),paired_bytes_delta=statistics.median(y['bytes']-x['bytes'] for x,y in zip(a,z)),min_ms=min(x['duration_ms'] for x in rs),max_ms=max(x['duration_ms'] for x in rs),operations=a[0]['operations']))
result=dict(rows=rows,comparisons=comparisons,complete=len(rows)==1188 and len(comparisons)==54,under20=sum(x['under20'] for x in rows),atCap=sum(x['atCap'] for x in rows));(b/'warm-analysis.json').write_text(json.dumps(result,indent=2),encoding='utf8')
for c in comparisons:print(c['tfm'],c['flavor'],c['shape'],c['phase'],round(c['paired_ratio'],4),'bytes',c['before_bytes'],c['fixed_bytes'],'delta',c['paired_bytes_delta'])
