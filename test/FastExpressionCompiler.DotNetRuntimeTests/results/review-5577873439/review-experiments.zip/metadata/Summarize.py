from pathlib import Path
import json,re,hashlib
p=Path('work/pr558-review-comments/metadata');rows=[]
for tfm in ['net8.0','net10.0','net472']:
 text=(p/f'sizes-{tfm}.log').read_text(encoding='utf8')
 for chunk in text.split('VERSION ')[1:]:
  lines=chunk.splitlines();rows.append(dict(tfm=tfm,version=lines[0],sizes={x.split('=')[0]:int(x.split('=')[1]) for x in lines if '=' in x},boundaryProof='PASS' if 'Full-width region and bidirectional flag preservation PASS' in chunk else 'FAIL'))
result=dict(baseline='8f12292f0baa596ed160c0e070ebb8329a623429',candidate='Only ExceptionRegionFrame sign-bit storage',measurement='Actual CLR sizeof opcode emitted in DynamicMethod; no elapsed performance measurements',sizeRows=rows,boundaryValues=[0,32768,65536,2147483647],native=json.loads((p/'native-status.json').read_text()),testsPassed=258,testsFailed=0,patchSHA256=hashlib.sha256((p/'candidate.diff').read_bytes()).hexdigest(),layout='No explicit layout, Pack=1, unsafe pointer code, int narrowing or valid-tree limit.')
(p/'proof.json').write_text(json.dumps(result,indent=2),encoding='utf8')
(p/'REPORT.txt').write_text('''Metadata review proposal, baseline8f12292f.
Only production change: ExceptionRegionFrame stores CannotLeave in the unused
sign bit of its nonnegative Region index, with named properties retaining the
existing call sites and initializer semantics. All Region values0..int.MaxValue
remain representable; neither index range nor tree depth is narrowed.

Actual CLR sizeof opcode, all Standard+Light net8/net10 ARM64 and FrameworkX64:
ScopeInfo12 ->12B; LabelScopeFrame16 ->16B; ExceptionRegionFrame8 ->4B.
TargetScope tuple16 ->16B; TargetRegion tuple16 ->16B (unchanged).
CompilerContext shrinks16B in every measured flavor/runtime:
modernStandard1584 ->1568; modernLight1592 ->1576;
FrameworkStandard1736 ->1720; FrameworkLight1744 ->1728.
These are isolated before/fixed metadata snapshots, excluding root's separate
CompilerContext flag packing. Runtime throughput and allocations NOT timed.

No shorts/ushorts for scopes: AddScopeInfo numbers lexical AND exception
ancestors into one positive-int SmallList. Number of scopes is not bounded by
method-local counts. Sibling scopes can exceed ushort without deep traversal;
run-length compression counts can also exceed ushort. Narrowing would impose
a new valid-tree restriction/truncation. ScopeInfo/LabelScopeFrame remain
full width. Pack=1 would introduce unaligned scalar-array strides and is not
proposed merely to remove padding.

Target+int tuples retain16B on measured64-bit runtimes. Naming/sequential
layout alone does not remove pointer alignment/tail padding, and overlapping
managed references would not be a portable solution. Retain the existing
ordinary managed layout rather than cosmetic tuple churn without size benefit.

Boundary proof tests Region0/32768/65536/int.MaxValue, flag false/true and back,
then decreasing Region values. Each setter preserves the other field exactly.
Existing six lexical/EH fixtures pass42Standard/44Light tests on each of
net8/net10/Framework,258total0fail: scoped variables, scoped labels, lexical
jumps, label definitions, exception regions, exception jumps. Deep-tree stress
was not rerun. Raw size logs and six native logs plus exact source hashes are
preserved; no production source, git branch or commit was changed.
''',encoding='utf8')
(p/'reply-drafts.txt').write_text('''4318977043 (Target+Scope/Region pairs):
Scope and Region index the shared lexical/exception ancestry list; they do not
have a proven ushort bound. I kept their full-width indices to avoid adding a
new valid-tree limit. I checked the actual CLR sizeof on .NET8/.NET10 ARM64 and
Framework x64: the current target+int tuples are16B. Named sequential structs
retain the same pointer-alignment footprint; forcing overlap/unaligned managed
references would not be portable, so I have left those ordinary tuples intact.

4319030709 (ScopeInfo/LabelScopeFrame):
I kept the int fields: scope count and compressed-frame counts can exceed
ushort, independently of method-local limits. They measure12B and16B on all
three runtimes tested. Packing those bytes would require narrower counters or
unaligned strides, so I have not added that tradeoff or a new tree-size limit.
The exception frame below does have a lossless one-word representation.

4319042922 (ExceptionRegionFrame):
Yes: the unused sign bit of the existing nonnegative int Region holds
CannotLeave, without narrowing it to short. This reduces each frame8→4B and
the enclosing CompilerContext16B in every measured flavor/runtime. Both field
setters preserve the other value;0,32768,65536,int.MaxValue and flag toggles
pass. The258 targeted Standard/Light lexical/EH cases pass across .NET8,
.NET10 and Framework. This is a size result, not a measured speedup claim.
''',encoding='utf8')
print(json.dumps({k:v for k,v in result.items() if k!='sizeRows'},indent=2))
