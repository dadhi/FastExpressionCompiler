from pathlib import Path
import json,subprocess,os,hashlib,argparse
p=Path(__file__).resolve().parent; parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=['check','warm','cold'],required=True);args=parser.parse_args();b=p/'benchmark';cases=['add','try_goto','nested_eh12'];status=[]
manifest=json.loads((p/'manifest.json').read_text());assert all(hashlib.sha256((p/n).read_bytes()).hexdigest()==sha for n,sha in manifest['sourceHashes'].items()),'Frozen compiler source mismatch'
env=os.environ.copy();env.update(DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0',COMPlus_TieredCompilation='0',COMPlus_ReadyToRun='0')
for tfm in ['net8.0','net10.0','net472']:
 for flavor in ['standard','light']:
  exe=b/flavor/'bin/Release'/tfm/('Bench.exe' if tfm=='net472' else 'Bench.dll');cmd=[str(exe)] if tfm=='net472' else ['dotnet',str(exe)]
  if args.mode=='cold':
   for sample in range(5):
    for version in (['current','fixed'] if sample%2==0 else ['fixed','current']):
     out=b/f'cold-{flavor}-{tfm}-{sample}-{version}.csv';assert not out.exists();run=subprocess.run(cmd+['--cold',version,'nested_eh12'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env=env,timeout=120);out.write_text(run.stdout,encoding='utf8');status.append(dict(tfm=tfm,flavor=flavor,sample=sample,version=version,exit=run.returncode));assert run.returncode==0,run.stdout
  else:
   out=b/f'check-{flavor}-{tfm}.jsonl' if args.mode=='check' else b/f'warm-{flavor}-{tfm}.csv'
   assert not out.exists();run=subprocess.run(cmd+(['--check'] if args.mode=='check' else [])+cases,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=env,timeout=240);out.write_text(run.stdout,encoding='utf8');out.with_suffix('.log').write_text(run.stderr,encoding='utf8');status.append(dict(tfm=tfm,flavor=flavor,exit=run.returncode));assert run.returncode==0,run.stdout+run.stderr
  print(args.mode,tfm,flavor,'PASS',flush=True)
(b/(args.mode+'-status.json')).write_text(json.dumps(status,indent=2),encoding='utf8')
