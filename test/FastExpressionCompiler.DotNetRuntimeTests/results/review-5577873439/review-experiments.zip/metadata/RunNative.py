from pathlib import Path
import subprocess,json
p=Path('work/pr558-review-comments/metadata');results=[]
for tfm in ['net8.0','net10.0','net472']:
 for flavor in ['standard','light']:
  executable=p/('native-'+flavor)/'bin/Release'/tfm/('Native.exe' if tfm=='net472' else 'Native.dll');cmd=[str(executable.resolve())] if tfm=='net472' else ['dotnet',str(executable)]
  run=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60);(p/f'native-{flavor}-{tfm}.log').write_text(run.stdout,encoding='utf8');results.append(dict(kind='native',flavor=flavor,tfm=tfm,exit=run.returncode));print(tfm,flavor,run.returncode,run.stdout[-800:],flush=True)
(p/'native-status.json').write_text(json.dumps(results,indent=2));assert all(x['exit']==0 for x in results)
