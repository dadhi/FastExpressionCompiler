using System;using S=System.Linq.Expressions.Expression;
public static class SharedShapes {
 public static int FinallyCount; public static void Finish(){++FinallyCount;}
 public static System.Linq.Expressions.LambdaExpression Build(string name){
 var x=S.Parameter(typeof(int),"x");System.Linq.Expressions.Expression body=S.Add(x,S.Constant(1));
 if(name!="add"){
  var done=S.Label(typeof(int),"done");body=S.Goto(done,body,typeof(int));
  int depth=name=="try_goto"?1:name=="nested_eh12"?12:throw new ArgumentException(name);
  for(int i=0;i<depth;i++)body=S.TryFinally(body,S.Call(typeof(SharedShapes).GetMethod("Finish")));
  body=S.Block(body,S.Label(done,S.Constant(-1)));
 }return S.Lambda<Func<int,int>>(body,x);
 }}