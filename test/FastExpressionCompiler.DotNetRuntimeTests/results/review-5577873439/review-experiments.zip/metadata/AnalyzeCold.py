from pathlib import Path
import csv,collections,statistics,json
p=Path('work/pr558-review-comments/metadata/benchmark');rows=[]
for f in p.glob('cold-*.csv'):
 flavor,tfm,sample,version=f.stem[5:].split('-');r=list(csv.reader(f.open(encoding='utf8')));assert len(r)==1 and len(r[0])==4;r=r[0];assert int(r[3])==4;rows.append(dict(flavor=flavor,tfm=tfm,sample=int(sample),version=version,bytes=int(r[2]),result=int(r[3])))
groups=collections.defaultdict(list)
for x in rows:groups[(x['tfm'],x['flavor'])].append(x)
cs=[]
for (tfm,flavor),rs in sorted(groups.items()):
 by={v:sorted([x for x in rs if x['version']==v],key=lambda x:x['sample']) for v in ['current','fixed']};a=by['current'];z=by['fixed'];assert len(a)==len(z)==5
 cs.append(dict(tfm=tfm,flavor=flavor,before_bytes=statistics.median(x['bytes'] for x in a),fixed_bytes=statistics.median(x['bytes'] for x in z),paired_deltas=[y['bytes']-x['bytes'] for x,y in zip(a,z)],before_samples=[x['bytes'] for x in a],fixed_samples=[x['bytes'] for x in z]))
d=dict(rows=rows,comparisons=cs,complete=len(rows)==60,scope='Fresh-process compile+first invocation allocation-only; no elapsed claim');(p/'cold-analysis.json').write_text(json.dumps(d,indent=2),encoding='utf8');print(json.dumps(cs,indent=2))
