from pathlib import Path
import json, os, subprocess
w=Path(__file__).resolve().parent
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0',COMPlus_TieredCompilation='0',COMPlus_ReadyToRun='0')
rows=[]
for name,cmd in [('flags-v2',['python',str(w/'flags-v2/bench/measure.py')]),
                 ('visitors-v2',['python',str(w/'visitors-v2/Run-Bench.py'),'--stage','quote','--exclusive-window'])]:
    print('Exclusive elapsed stage: '+name,flush=True)
    result=subprocess.run(cmd,cwd=w.parent.parent,env=env)
    rows.append({'stage':name,'exit':result.returncode})
    (w/'final-revisions-execution.json').write_text(json.dumps(rows,indent=2))
    if result.returncode:raise SystemExit(result.returncode)
print('Final bounded revisions complete',flush=True)
