from pathlib import Path
import hashlib, json, subprocess, zipfile

w = Path(__file__).resolve().parent
repo = Path(r'C:\Data\Git\Github\FastExpressionCompiler')
publication = w / 'publication'
publication.mkdir(exist_ok=True)
archive = publication / 'review-experiments.zip'
assert not archive.exists(), 'Do not overwrite evidence'
excluded = {'bin', 'obj', 'runners', 'bench-runners', 'publication', '__pycache__', '.git'}
extensions = {'.cs', '.csproj', '.py', '.diff', '.json', '.csv', '.log', '.txt', '.md', '.template'}
entries = {}
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in sorted(w.rglob('*')):
        rel = path.relative_to(w)
        if not path.is_file() or any(part in excluded for part in rel.parts) or path.suffix not in extensions:
            continue
        data = path.read_bytes()
        z.writestr(rel.as_posix(), data)
        entries[rel.as_posix()] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
manifest = {'baseline': '8f12292f0baa596ed160c0e070ebb8329a623429',
    'codeHead': subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
    'archive': archive.name, 'bytes': archive.stat().st_size,
    'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'entries': entries,
    'scope': 'Scratch experiments include held candidates. Read README decisions; they are not all merged.',
    'excluded': 'Build outputs/binaries excluded; source, project files, raw rows, logs and runner hashes retained.'}
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == set(entries)
    for name, metadata in entries.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == metadata['sha256']
(publication/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({k:manifest[k] for k in ['codeHead','archive','bytes','sha256']}))
