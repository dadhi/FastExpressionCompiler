from pathlib import Path
import subprocess,hashlib,json
w=Path(__file__).resolve().parent; repo=Path(r'C:\Data\Git\Github\FastExpressionCompiler')
commit='8f12292f0baa596ed160c0e070ebb8329a623429';manifest={'baseline':commit,'candidate':'Only remove NoInlining from PushNewLabelScopeFrame; automatic JIT policy','files':{}}
for label in ['Current','Auto']:
 for light in [False,True]:
  folder=w/(label+('-light' if light else ''));folder.mkdir(exist_ok=True)
  paths=subprocess.check_output(['git','-C',str(repo),'ls-tree','-r','--name-only',commit,'src/FastExpressionCompiler.LightExpression' if light else 'src/FastExpressionCompiler']).decode().splitlines()
  # Shared core/support files are explicitly linked in Light's production project.
  paths=[p for p in paths if p.endswith('.cs')]
  if light:paths += ['src/FastExpressionCompiler/'+n for n in ['FastExpressionCompiler.cs','ImTools.cs','ILReader.cs','TestTools.cs']]
  for path in paths:
   data=subprocess.check_output(['git','-C',str(repo),'show',commit+':'+path]);name=Path(path).name
   if name=='FastExpressionCompiler.cs' and label=='Auto':
    marker=b'            [MethodImpl(MethodImplOptions.NoInlining)]\n            private void PushNewLabelScopeFrame'
    if marker not in data:
     marker=marker.replace(b'\n',b'\r\n')
    assert data.count(marker)==1
    data=data.replace(marker,marker.split(b']',1)[1].lstrip(b'\r\n'),1)
   (folder/name).write_bytes(data);manifest['files'][str(folder.name+'/'+name)]=hashlib.sha256(data).hexdigest()
  constants='<DefineConstants>LIGHT_EXPRESSION</DefineConstants>' if light else ''
  (folder/'Library.csproj').write_text(f'<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><AssemblyName>FrameInline.{folder.name}</AssemblyName>{constants}</PropertyGroup></Project>')
old=w.parents[1]/'pr558-round4/try-result-value/Current.cs'
source=old.read_text(encoding='utf-8')
extra='''
   case "blocks32":body=S.Add(x,S.Constant(1));for(int i=0;i<32;i++)body=S.Block(body);break;
   case "mixed32":body=S.Add(x,S.Constant(1));for(int i=0;i<32;i++)body=S.Block(S.Condition(S.GreaterThan(x,S.Constant(0)),body,S.Constant(-1)));break;
   case "scope_jump":var doneScope=S.Label(typeof(int));body=S.Goto(doneScope,S.Add(x,S.Constant(1)));for(int i=0;i<32;i++)body=S.Block(body);body=S.Block(body,S.Label(doneScope,S.Constant(-1)));break;
   case "capture8":var vs=new System.Linq.Expressions.ParameterExpression[8];var init=new System.Linq.Expressions.Expression[9];System.Linq.Expressions.Expression sum=S.Constant(0);for(int i=0;i<8;i++){vs[i]=S.Variable(typeof(int));init[i]=S.Assign(vs[i],S.Add(x,S.Constant(i)));sum=S.Add(sum,vs[i]);}init[8]=S.Lambda<Func<int>>(sum);return S.Lambda<Func<int,Func<int>>>(S.Block(vs,init),x);
'''
source=source.replace('   case "add":',extra+'   case "add":')
source=source.replace('  if(compiled is Func<int,Func<int>> factory){','  if(compiled is Func<int,Func<int>> factory){actions["activate_and_invoke"]=actions["invoke"];actions.Remove("invoke");')
source=source.replace(' public static Dictionary<string,Action<int>> Operations', ''' public static void Proof(string name){var original=Build(name);var tree=Convert(original);var expected=Verify(original.Compile());foreach(var flags in new[]{CompilerFlags.Default,CompilerFlags.NoInvocationLambdaInlining,CompilerFlags.EnableDelegateDebugInfo}){var actual=tree.CompileFast(true,flags);if(actual==null||Verify(actual)!=expected)throw new Exception("Mismatch "+name+" "+flags);}}
 public static Dictionary<string,Action<int>> Operations''')
for label,alias in [('Current','Before'),('Auto','After')]:
 s=source.replace('extern alias Before;',f'extern alias {alias};').replace('Before::',alias+'::').replace('using Before','using '+alias).replace('namespace Current',f'namespace {label}').replace('"current"','"'+label.lower()+'"')
 (w/f'{label}.cs').write_text(s,encoding='utf-8')
for light in [False,True]:
 suffix='-light' if light else '';defs='<DefineConstants>LIGHT</DefineConstants>' if light else ''
 refs=''.join(f'<Reference Include="FrameInline.{label}{suffix}"><HintPath>{label}{suffix}/bin/Release/$(TargetFramework)/FrameInline.{label}{suffix}.dll</HintPath><Aliases>{alias}</Aliases></Reference>' for label,alias in [('Current','Before'),('Auto','After')])
 (w/f'Runner{suffix}.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><EnableDefaultCompileItems>false</EnableDefaultCompileItems><AssemblySearchPaths>{HintPathFromItem};{TargetFrameworkDirectory};{RawFileName}</AssemblySearchPaths><OutputPath>bin'+suffix+'/</OutputPath>'+defs+'</PropertyGroup><ItemGroup><Compile Include="Runner.cs"/><Compile Include="Current.cs"/><Compile Include="Auto.cs"/>'+refs+'</ItemGroup></Project>')
(w/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('Export only complete; no builds or timings.')
