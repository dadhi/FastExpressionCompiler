using System;
using System.Diagnostics;
using System.Globalization;
class Runner {
 static readonly Func<long> Allocated=(Func<long>)Delegate.CreateDelegate(typeof(Func<long>),typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread",Type.EmptyTypes));
 static readonly string[] Shapes={"add","balanced256","blocks32","mixed32","scope_jump","capture8","try_finally"};
 public static void Row(string name,string phase,string version,int round,int sample,int operations,double ns,double bytes)=>Console.WriteLine(name+","+phase+","+version+","+sample+","+operations+","+ns.ToString("R",CultureInfo.InvariantCulture)+","+bytes.ToString("R",CultureInfo.InvariantCulture)+","+(ns*operations/1e6).ToString("R",CultureInfo.InvariantCulture));
 static void Main(string[] args){
  CultureInfo.CurrentCulture=CultureInfo.InvariantCulture;CultureInfo.CurrentUICulture=CultureInfo.InvariantCulture;
  if(args.Length==0)throw new Exception("Explicit proof/measure/cold required");
  if(args[0]=="cold"){if(args[1]=="current")Current.Bench.Cold(args[2]);else Auto.Bench.Cold(args[2]);return;}
  if(args[0]=="proof"){foreach(var s in Shapes){Current.Bench.Proof(s);Auto.Bench.Proof(s);}Console.WriteLine("PASS42 flag/version/shape differentials");return;}
  if(args[0]!="measure")throw new Exception("Unknown mode");
  foreach(var name in Shapes){var a=Current.Bench.Operations(name);var b=Auto.Bench.Operations(name);
   foreach(var phase in a.Keys){var ops=new[]{a[phase],b[phase]};int n=1;
    while(true){long shortest=long.MaxValue;foreach(var op in ops){long t=Stopwatch.GetTimestamp();op(n);shortest=Math.Min(shortest,Stopwatch.GetTimestamp()-t);}if(shortest>=Stopwatch.Frequency/50)break;if(n>=1<<26)throw new Exception("Calibration cap");n*=2;}
    for(int sample=0;sample<11;sample++)for(int offset=0;offset<2;offset++){int v=(sample+offset)%2;long bytes=Allocated(),t=Stopwatch.GetTimestamp();ops[v](n);long elapsed=Stopwatch.GetTimestamp()-t;bytes=Allocated()-bytes;Row(name,phase,v==0?"current":"auto",0,sample,n,elapsed*1e9/Stopwatch.Frequency/n,bytes/(double)n);}
   }
  }
 }
}
