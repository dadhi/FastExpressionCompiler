from pathlib import Path
import json,statistics,hashlib,re
w=Path(__file__).resolve().parent
for folder,label,status in [(w,'NoInlining removal','HOLD: retain intentional outline; no consistent target win'),(w.parent/'flags/bench','Packed CompilerContext flags','HOLD:8B smaller context does not meet no-introduced-regression requirement; parent confirmed both flags candidates held')]:
 d=json.loads((folder/'analysis.json').read_text())
 sizes=[]
 if label.startswith('Packed'):
  for light in ['false','true']:
   for runtime in ['net8.0','net10.0','net472']:
    before=(folder.parent/f'check-before-{light}-{runtime}.log').read_text();after=(folder.parent/f'check-fixed-{light}-{runtime}.log').read_text()
    sizes.append(dict(light=light,runtime=runtime,before=int(re.search(r'CompilerContextBytes=(\d+)',before)[1]),fixed=int(re.search(r'CompilerContextBytes=(\d+)',after)[1])))
 decision=dict(candidate=label,status=status,baseline=d['manifest']['baseline'],errors=d['errors'],rows=len(d['rows']),pairs=len(d['comparisons']),contextSizes=sizes,cold='Not measured; no cold parity claim',notes=['Fractional sample allocation deltas retained, not silently rounded away.','Runtime code is unchanged by these collector/context changes; observed runtime variation is not a causal speedup claim.','Calibrated count targets20ms but actual samples can drift below; durations all retained.','One bounded proposal only; no additional variants.'])
 (folder/'decision.json').write_text(json.dumps(decision,indent=2))
 lines=[label,status,'',f"Baseline {d['manifest']['baseline']}",f"{len(d['rows'])} rows; {len(d['comparisons'])} paired comparisons; strict errors{len(d['errors'])}",'','Paired ratio = median of per-sample candidate/current ratios. Marginal ratio also retained.','No overall application-speedup or universal pre-PR parity claim.','']
 if sizes:lines+=['Context sizes (bytes):']+[str(r) for r in sizes]+['']
 for phase in ['compile','compile_first','invoke','activate','nested_invoke','activate_and_invoke']:
  g=[r for r in d['comparisons'] if r['phase']==phase]
  lines.append(f"{phase}: n={len(g)}; median paired ratio{statistics.median(r['paired_ratio'] for r in g):.4f}; range{min(r['paired_ratio'] for r in g):.4f}..{max(r['paired_ratio'] for r in g):.4f}")
 lines+=['',f"Actual sample duration minimum{min(r['duration_ms'] for r in d['rows']):.3f}ms; below20ms{sum(r['duration_ms']<20 for r in d['rows'])}/{len(d['rows'])}.",'Cold not measured; no cold parity claim.','All runtime/activation byte medians unchanged. Fractional compile-phase allocation differences remain visible below.','','runtime flavor scenario phase pairedRatio marginalRatio beforeBytes candidateBytes deltaBytes']
 for r in d['comparisons']:lines.append(f"{r['runtime']} {r['flavor']} {r['scenario']} {r['phase']} {r['paired_ratio']:.6f} {r['median_ratio']:.6f} {r['bytes_before']:.8f} {r['bytes_auto']:.8f} {r['bytes_delta']:+.8f}")
 (folder/'REPORT.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 (folder/'artifact-hashes.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.glob('*') if p.is_file() and p.name!='artifact-hashes.json'},indent=2))
print('Reports/decisions only generated; no measurements or source changes')
