using System;using System.Reflection;
class Program{static void Main(string[] args){var a=Assembly.LoadFrom(args[0]);var actual=a.GetType("FastExpressionCompiler.ExpressionCompiler+CompilerContext",true);foreach(var p in typeof(V1).GetProperties(BindingFlags.Instance|BindingFlags.NonPublic)){var x=p.GetSetMethod(true).GetMethodBody().GetILAsByteArray();var y=typeof(V2).GetProperty(p.Name,BindingFlags.Instance|BindingFlags.NonPublic).GetSetMethod(true).GetMethodBody().GetILAsByteArray();var z=actual.GetProperty(p.Name,BindingFlags.Instance|BindingFlags.NonPublic).GetSetMethod(true).GetMethodBody().GetILAsByteArray();Console.WriteLine(p.Name+","+x.Length+","+y.Length+","+z.Length+","+BitConverter.ToString(x)+","+BitConverter.ToString(y));}}}
internal enum CompilerContextFlags : ushort
        {
            HasComplexExpression = 1 << 0,
            HasExceptionBlock = 1 << 1,
            IsEmittingExceptionFilter = 1 << 2,
            CanRethrow = 1 << 3,
            IsCollectingExceptionFilter = 1 << 4,
            CaptureStorageAnalyzed = 1 << 5,
            CaptureStorageRequiresCells = 1 << 6,
            CaptureStorageQuoteReferences = 1 << 7,
            CaptureStorageRequiresTypedCells = 1 << 8,
        }
struct V1 {
            private CompilerContextFlags _state;

            internal bool HasComplexExpression
            {
                get => (_state & CompilerContextFlags.HasComplexExpression) != 0;
                set => _state = value ? _state | CompilerContextFlags.HasComplexExpression : _state & ~CompilerContextFlags.HasComplexExpression;
            }
            internal bool HasExceptionBlock
            {
                get => (_state & CompilerContextFlags.HasExceptionBlock) != 0;
                set => _state = value ? _state | CompilerContextFlags.HasExceptionBlock : _state & ~CompilerContextFlags.HasExceptionBlock;
            }
            internal bool IsEmittingExceptionFilter
            {
                get => (_state & CompilerContextFlags.IsEmittingExceptionFilter) != 0;
                set => _state = value ? _state | CompilerContextFlags.IsEmittingExceptionFilter : _state & ~CompilerContextFlags.IsEmittingExceptionFilter;
            }
            internal bool CanRethrow
            {
                get => (_state & CompilerContextFlags.CanRethrow) != 0;
                set => _state = value ? _state | CompilerContextFlags.CanRethrow : _state & ~CompilerContextFlags.CanRethrow;
            }
            internal bool IsCollectingExceptionFilter
            {
                get => (_state & CompilerContextFlags.IsCollectingExceptionFilter) != 0;
                set => _state = value ? _state | CompilerContextFlags.IsCollectingExceptionFilter : _state & ~CompilerContextFlags.IsCollectingExceptionFilter;
            }
            internal bool CaptureStorageAnalyzed
            {
                get => (_state & CompilerContextFlags.CaptureStorageAnalyzed) != 0;
                set => _state = value ? _state | CompilerContextFlags.CaptureStorageAnalyzed : _state & ~CompilerContextFlags.CaptureStorageAnalyzed;
            }
            internal bool CaptureStorageRequiresCells
            {
                get => (_state & CompilerContextFlags.CaptureStorageRequiresCells) != 0;
                set => _state = value ? _state | CompilerContextFlags.CaptureStorageRequiresCells : _state & ~CompilerContextFlags.CaptureStorageRequiresCells;
            }
            internal bool CaptureStorageQuoteReferences
            {
                get => (_state & CompilerContextFlags.CaptureStorageQuoteReferences) != 0;
                set => _state = value ? _state | CompilerContextFlags.CaptureStorageQuoteReferences : _state & ~CompilerContextFlags.CaptureStorageQuoteReferences;
            }
            internal bool CaptureStorageRequiresTypedCells
            {
                get => (_state & CompilerContextFlags.CaptureStorageRequiresTypedCells) != 0;
                set => _state = value ? _state | CompilerContextFlags.CaptureStorageRequiresTypedCells : _state & ~CompilerContextFlags.CaptureStorageRequiresTypedCells;
            }

}
struct V2 {
            private CompilerContextFlags _state;

            internal bool HasComplexExpression
            {
                get => (_state & CompilerContextFlags.HasComplexExpression) != 0;
                set => _state = (_state & ~CompilerContextFlags.HasComplexExpression) | (value ? CompilerContextFlags.HasComplexExpression : 0);
            }
            internal bool HasExceptionBlock
            {
                get => (_state & CompilerContextFlags.HasExceptionBlock) != 0;
                set => _state = (_state & ~CompilerContextFlags.HasExceptionBlock) | (value ? CompilerContextFlags.HasExceptionBlock : 0);
            }
            internal bool IsEmittingExceptionFilter
            {
                get => (_state & CompilerContextFlags.IsEmittingExceptionFilter) != 0;
                set => _state = (_state & ~CompilerContextFlags.IsEmittingExceptionFilter) | (value ? CompilerContextFlags.IsEmittingExceptionFilter : 0);
            }
            internal bool CanRethrow
            {
                get => (_state & CompilerContextFlags.CanRethrow) != 0;
                set => _state = (_state & ~CompilerContextFlags.CanRethrow) | (value ? CompilerContextFlags.CanRethrow : 0);
            }
            internal bool IsCollectingExceptionFilter
            {
                get => (_state & CompilerContextFlags.IsCollectingExceptionFilter) != 0;
                set => _state = (_state & ~CompilerContextFlags.IsCollectingExceptionFilter) | (value ? CompilerContextFlags.IsCollectingExceptionFilter : 0);
            }
            internal bool CaptureStorageAnalyzed
            {
                get => (_state & CompilerContextFlags.CaptureStorageAnalyzed) != 0;
                set => _state = (_state & ~CompilerContextFlags.CaptureStorageAnalyzed) | (value ? CompilerContextFlags.CaptureStorageAnalyzed : 0);
            }
            internal bool CaptureStorageRequiresCells
            {
                get => (_state & CompilerContextFlags.CaptureStorageRequiresCells) != 0;
                set => _state = (_state & ~CompilerContextFlags.CaptureStorageRequiresCells) | (value ? CompilerContextFlags.CaptureStorageRequiresCells : 0);
            }
            internal bool CaptureStorageQuoteReferences
            {
                get => (_state & CompilerContextFlags.CaptureStorageQuoteReferences) != 0;
                set => _state = (_state & ~CompilerContextFlags.CaptureStorageQuoteReferences) | (value ? CompilerContextFlags.CaptureStorageQuoteReferences : 0);
            }
            internal bool CaptureStorageRequiresTypedCells
            {
                get => (_state & CompilerContextFlags.CaptureStorageRequiresTypedCells) != 0;
                set => _state = (_state & ~CompilerContextFlags.CaptureStorageRequiresTypedCells) | (value ? CompilerContextFlags.CaptureStorageRequiresTypedCells : 0);
            }

}
