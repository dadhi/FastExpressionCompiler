from pathlib import Path
import subprocess,os,json
w=Path(__file__).resolve().parent
results=[]
for name,folder in [('v1',w.parent/'flags/bench'),('v2',w/'bench')]:
 output=w/f'jit-setters-{name}.txt'
 env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0',COMPlus_TieredCompilation='0',COMPlus_ReadyToRun='0',DOTNET_JitDisasm='*set_*',DOTNET_JitDisasmAssemblies='FrameInline.Auto',DOTNET_JitStdOutFile=str(output),COMPlus_JitDisasm='*set_*',COMPlus_JitDisasmAssemblies='FrameInline.Auto',COMPlus_JitStdOutFile=str(output))
 r=subprocess.run(['dotnet',str(folder/'runners/Std/net10.0/Runner.dll'),'proof'],env=env,capture_output=True,text=True,timeout=60)
 (w/f'jit-proof-{name}.log').write_text(r.stdout+r.stderr)
 results.append(dict(version=name,exit=r.returncode,disassemblyCreated=output.exists(),lines=output.read_text().count('\n') if output.exists() else 0,proofOutput=r.stdout))
(w/'jit-diagnosis.json').write_text(json.dumps(results,indent=2));print(results)
