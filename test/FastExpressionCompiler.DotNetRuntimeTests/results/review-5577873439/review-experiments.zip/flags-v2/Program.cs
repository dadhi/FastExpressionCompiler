using System;using System.Reflection.Emit;
#if LIGHT_EXPRESSION
using FastExpressionCompiler.LightExpression;using FastExpressionCompiler.LightExpression.UnitTests;
#else
using FastExpressionCompiler;using FastExpressionCompiler.UnitTests;
#endif
class Program {
 static int Size(Type type) {var d=new DynamicMethod("Size",typeof(int),Type.EmptyTypes,true);var il=d.GetILGenerator();il.Emit(OpCodes.Sizeof,type);il.Emit(OpCodes.Ret);return ((Func<int>)d.CreateDelegate(typeof(Func<int>)))();}
 static void Main(){Console.WriteLine("CompilerContextBytes="+Size(typeof(ExpressionCompiler.CompilerContext)));var t=new TestRun(TestFlags.RethrowException);
t.Run(new NonExceptionThrowPolicyRegressionTests());
t.Run(new CapturedQuoteRegressionTests());
t.Run(new ScopedVariableBindingRegressionTests());
t.Run(new ExceptionRegionValidationRegressionTests());
t.Run(new DynamicCallSiteRegressionTests());
t.Run(new NestedJumpArgumentRegressionTests());
t.Run(new CapturedStructArithmeticRegressionTests());
if(t.FailedTestCount!=0)throw new Exception("Failure");Console.WriteLine("FLAGS SEMANTIC PASS");}}
