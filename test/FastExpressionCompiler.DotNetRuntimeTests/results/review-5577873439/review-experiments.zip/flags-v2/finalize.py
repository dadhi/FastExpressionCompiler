from pathlib import Path
import json,statistics,hashlib,re
w=Path(__file__).resolve().parent;bench=w/'bench'
v1=json.loads((w.parent/'flags/bench/analysis.json').read_text());v2=json.loads((bench/'analysis.json').read_text());manifest=json.loads((w/'manifest.json').read_text())
sizes=[]
for light in ['false','true']:
 for runtime in ['net8.0','net10.0','net472']:
  old=(w.parent/f'flags/check-before-{light}-{runtime}.log').read_text();new=(w/f'check-fixed-{light}-{runtime}.log').read_text()
  sizes.append(dict(light=light,runtime=runtime,before=int(re.search(r'CompilerContextBytes=(\d+)',old)[1]),candidate=int(re.search(r'CompilerContextBytes=(\d+)',new)[1])))
decision=dict(status='HOLD both flags-v1 and flags-v2; parent confirmed; no production flags change',baseline=manifest['baseline'],sourceSHA256=manifest['fixedSHA256'],v1SourceSHA256=manifest['parentCandidateSHA256'],correctness='All six native fixture configurations and six benchmark proof configurations pass',rows=len(v2['rows']),comparisons=len(v2['comparisons']),errors=v2['errors'],contextSizes=sizes,reasons=['Framework Light capture8 compilation+192B and compile+first+192B observed; exact cause unresolved.','V2 smaller IL does not establish no-regression performance.','No new variants or investigations; no universal allocation/runtime/cold parity claim.'],cold='Not measured; warm hold decision requires no additional cold experiments',comparisonCaveat='V1 andV2 each paired against baseline8f in separate process runs; not a directly pairedV1/V2 experiment')
(w/'decision.json').write_text(json.dumps(decision,indent=2));(bench/'decision.json').write_text(json.dumps(decision,indent=2))
lines=['Packed CompilerContext flags: FINAL HOLD both bounded candidates','',f"Baseline {manifest['baseline']}",f"V1 source SHA256 {manifest['parentCandidateSHA256']}",f"V2 source SHA256 {manifest['fixedSHA256']}",'','V2 changes only nine setters to single-load form. Actual IL32/33/36B becomes27/28/31B. No CompilerContext setter is listed out of line in either scoped proof JIT listing; failed inlining was not established as the V1 cost.','',f"All six native fixture configurations pass; six benchmark proof configurations pass. V2 rows={len(v2['rows'])}, comparisons={len(v2['comparisons'])}, strict errors={len(v2['errors'])}.",'','All contexts are8B smaller (exact runtime/flavor sizes below), but this stack/layout improvement does not establish improved managed allocation or compilation performance.']
lines += [str(r) for r in sizes]
lines += ['','Decisive observed regression: Framework Light capture8 compilation6896.625→7088.625B (+192), compile+first7304→7496B (+192). The fractional0.625B is retained from the measured samples. Paired compilation ratio1.188205; compile+first1.154654. Exact allocating mechanism UNRESOLVED. No capacity/metadata workaround or new probe is introduced.','V2 also has Std.NET8 EH compilation ratio1.138428 and Std.NET10 capture8 compilation1.080771. Runtime/activation byte medians remain unchanged, but timing varies even for unchanged generated delegates.','No universal parsing/runtime/allocation or cold parity claim. Main flags remain unchanged; parent confirmed HOLD. No additional variants.','', 'V1 andV2 below each compare to8f in their OWN paired process run; do not interpret their ratio difference as a directly pairedV2/V1 speedup. Both paired medians and marginal medians are retained.']
for name,data in [('V1',v1),('V2',v2)]:
 lines+=['',name+':']
 for phase in ['compile','compile_first','invoke','activate','nested_invoke','activate_and_invoke']:
  g=[r for r in data['comparisons'] if r['phase']==phase]
  lines.append(f"{phase}: median paired ratio{statistics.median(r['paired_ratio'] for r in g):.6f}; range{min(r['paired_ratio'] for r in g):.6f}..{max(r['paired_ratio'] for r in g):.6f}")
 lines.append(f"Actual duration minimum{min(r['duration_ms'] for r in data['rows']):.6f}ms; below20ms{sum(r['duration_ms']<20 for r in data['rows'])}/{len(data['rows'])}; all durations/operations preserved.")
lines+=['','runtime flavor scenario phase V1paired V2paired V2marginal V2beforeB V2candidateB V2deltaB']
lookup={(r['runtime'],r['flavor'],r['scenario'],r['phase']):r for r in v1['comparisons']}
for r in v2['comparisons']:
 p=lookup[(r['runtime'],r['flavor'],r['scenario'],r['phase'])]
 lines.append(f"{r['runtime']} {r['flavor']} {r['scenario']} {r['phase']} {p['paired_ratio']:.6f} {r['paired_ratio']:.6f} {r['median_ratio']:.6f} {r['bytes_before']:.8f} {r['bytes_auto']:.8f} {r['bytes_delta']:+.8f}")
(w/'REPORT.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8');(bench/'REPORT.txt').write_bytes((w/'REPORT.txt').read_bytes())
hashes={str(p.relative_to(w)):hashlib.sha256(p.read_bytes()).hexdigest() for p in w.glob('*') if p.is_file() and p.name!='artifact-hashes.json'}
for p in (bench/'runners').rglob('*'):
 if p.is_file():hashes[p.relative_to(w).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(w/'artifact-hashes.json').write_text(json.dumps(hashes,indent=2))
print('Final HOLD report and hashes saved; no builds/probes/timings')
