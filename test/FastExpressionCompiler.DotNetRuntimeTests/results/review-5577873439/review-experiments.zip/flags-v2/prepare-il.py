from pathlib import Path
import re
w=Path(__file__).resolve().parent; original=w.parent/'flags/fixed/FastExpressionCompiler.cs'
s=original.read_text(encoding='utf-8')
enum=re.search(r'internal enum CompilerContextFlags : ushort\s*\{.*?\n        \}',s,re.S)[0]
start=s.index('            private CompilerContextFlags _state;');end=s.index('            internal SmallList<ExceptionRegionFrame',start)
v1=s[start:end];v2,n=re.subn(r'set => _state = value \? _state \| (CompilerContextFlags\.\w+) : _state & ~\1;',r'set => _state = (_state & ~\1) | (value ? \1 : 0);',v1)
assert n==9
tool='''using System;using System.Reflection;
class Program{static void Main(string[] args){var a=Assembly.LoadFrom(args[0]);var actual=a.GetType("FastExpressionCompiler.ExpressionCompiler+CompilerContext",true);foreach(var p in typeof(V1).GetProperties(BindingFlags.Instance|BindingFlags.NonPublic)){var x=p.GetSetMethod(true).GetMethodBody().GetILAsByteArray();var y=typeof(V2).GetProperty(p.Name,BindingFlags.Instance|BindingFlags.NonPublic).GetSetMethod(true).GetMethodBody().GetILAsByteArray();var z=actual.GetProperty(p.Name,BindingFlags.Instance|BindingFlags.NonPublic).GetSetMethod(true).GetMethodBody().GetILAsByteArray();Console.WriteLine(p.Name+","+x.Length+","+y.Length+","+z.Length+","+BitConverter.ToString(x)+","+BitConverter.ToString(y));}}}
'''
(w/'ILProbe.cs').write_text(tool+enum+'\nstruct V1 {\n'+v1+'\n}\nstruct V2 {\n'+v2+'\n}\n',encoding='utf-8')
(w/'ILProbe.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net10.0</TargetFramework><Optimize>true</Optimize><EnableDefaultCompileItems>false</EnableDefaultCompileItems></PropertyGroup><ItemGroup><Compile Include="ILProbe.cs"/></ItemGroup></Project>')
