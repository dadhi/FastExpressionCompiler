Exact baseline8f versus packed CompilerContext flags candidate; source hashes
are in manifest.json. Four shapes: add, capture8, try_finally, mixed32.
The generic scaffold's "auto" CSV label means the FLAGS candidate here;
PushNewLabelScopeFrame NoInlining remains unchanged in both versions.

prepare-flags.py reconstructs source/wrappers from sibling frame-inline scaffold
and ../fixed source. build.py builds/runs proof only, all six configurations.
measure.py runs warm11paired samples/configuration; --cold is optional and must
be separately authorized after warm review. Runner uses invariant culture,
reflective Framework allocation counter and common calibrated≥20ms workload.
Raw per-sample operation counts/durations and all phase allocation data retained.
analyze.py validates308rows/config; this is an isolated flags-only comparison,
not a claim about combined final production source or application speedup.
