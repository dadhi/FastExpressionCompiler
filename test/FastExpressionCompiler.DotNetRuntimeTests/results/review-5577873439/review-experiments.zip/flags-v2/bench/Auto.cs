extern alias After;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using S=System.Linq.Expressions.Expression;
#if LIGHT
using After::FastExpressionCompiler.LightExpression;
using L=After::FastExpressionCompiler.LightExpression.LambdaExpression;
#else
using After::FastExpressionCompiler;
using L=System.Linq.Expressions.LambdaExpression;
#endif
namespace Auto {
public static class Bench {
 public struct BenchCounter { public int Value; public int Increment()=>++Value; }
 static object sink; static long checksum;
 static readonly Func<long> Allocated=(Func<long>)Delegate.CreateDelegate(typeof(Func<long>),typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread"));
 static System.Linq.Expressions.Expression Balanced(System.Linq.Expressions.Expression x,int n)=>n==0?x:S.Add(Balanced(x,n-1),Balanced(x,n-1));
 public static int Counter; public static void Tick() { ++Counter; }
 public static System.Linq.Expressions.LambdaExpression Build(string name){
  var x=S.Parameter(typeof(int)); System.Linq.Expressions.Expression body=x;
  switch(name){

   case "blocks32":body=S.Add(x,S.Constant(1));for(int i=0;i<32;i++)body=S.Block(body);break;
   case "mixed32":body=S.Add(x,S.Constant(1));for(int i=0;i<32;i++)body=S.Block(S.Condition(S.GreaterThan(x,S.Constant(0)),body,S.Constant(-1)));break;
   case "scope_jump":var doneScope=S.Label(typeof(int));body=S.Goto(doneScope,S.Add(x,S.Constant(1)));for(int i=0;i<32;i++)body=S.Block(body);body=S.Block(body,S.Label(doneScope,S.Constant(-1)));break;
   case "capture8":var vs=new System.Linq.Expressions.ParameterExpression[8];var init=new System.Linq.Expressions.Expression[9];System.Linq.Expressions.Expression sum=S.Constant(0);for(int i=0;i<8;i++){vs[i]=S.Variable(typeof(int));init[i]=S.Assign(vs[i],S.Add(x,S.Constant(i)));sum=S.Add(sum,vs[i]);}init[8]=S.Lambda<Func<int>>(sum);return S.Lambda<Func<int,Func<int>>>(S.Block(vs,init),x);
   case "add":body=S.Add(x,S.Constant(1));break;
   case "balanced256":body=Balanced(x,8);break;
   case "try_finally":body=S.TryFinally(S.Add(x,S.Constant(1)),S.Empty());break;
   case "try_finally_real":body=S.TryFinally(S.Add(x,S.Constant(1)),S.Call(typeof(Bench).GetMethod(nameof(Tick))));break;
   case "default_receiver":body=S.Call(S.TryFinally(S.Default(typeof(BenchCounter)),S.Empty()),typeof(BenchCounter).GetMethod(nameof(BenchCounter.Increment)));break;
   case "try_catch":body=S.TryCatch(S.Add(x,S.Constant(1)),S.Catch(typeof(Exception),S.Constant(-1)));break;
   case "nested_eh32":body=S.Add(x,S.Constant(1));for(int i=0;i<32;i++)body=S.TryFinally(body,S.Empty());break;
   case "nested_eh32_real":body=S.Add(x,S.Constant(1));for(int i=0;i<32;i++)body=S.TryFinally(body,S.Call(typeof(Bench).GetMethod(nameof(Tick))));break;
   case "goto_empty": var done=S.Label(typeof(int));body=S.Block(S.TryFinally(S.Goto(done,S.Add(x,S.Constant(1))),S.Empty()),S.Label(done,S.Constant(-1)));break;
   case "capture1":return S.Lambda<Func<int,Func<int>>>(S.Lambda<Func<int>>(S.Add(x,S.Constant(1))),x);
   case "capture_repeat":return S.Lambda<Func<int,Func<int>>>(S.Lambda<Func<int>>(S.Add(x,x)),x);
   case "capture_mutable":return S.Lambda<Func<int,Func<int>>>(S.Lambda<Func<int>>(S.PreIncrementAssign(x)),x);
   case "capture_try":return S.Lambda<Func<int,Func<int>>>(S.Lambda<Func<int>>(S.TryFinally(S.Add(x,S.Constant(1)),S.Empty())),x);
   default:throw new ArgumentException(name);
  } return S.Lambda<Func<int,int>>(body,x);
 }
 static L Convert(System.Linq.Expressions.LambdaExpression source){
#if LIGHT
  return source.ToLightExpression();
#else
  return source;
#endif
 }
 [MethodImpl(MethodImplOptions.NoInlining)]static Delegate Compile(L tree)=>tree.CompileFast(true)??throw new Exception("Strict compile failed");
 static int Invoke(Delegate d){var scalar=d as Func<int,int>;return scalar!=null?scalar(3):((Func<int,Func<int>>)d)(3)();}
 static string Verify(Delegate d){var scalar=d as Func<int,int>;if(scalar!=null)return scalar(3).ToString();var nested=((Func<int,Func<int>>)d)(3);return nested()+":"+nested();}
 public static void Proof(string name){var original=Build(name);var tree=Convert(original);var expected=Verify(original.Compile());foreach(var flags in new[]{CompilerFlags.Default,CompilerFlags.NoInvocationLambdaInlining,CompilerFlags.EnableDelegateDebugInfo}){var actual=tree.CompileFast(true,flags);if(actual==null||Verify(actual)!=expected)throw new Exception("Mismatch "+name+" "+flags);}}
 public static Dictionary<string,Action<int>> Operations(string name){
  var original=Build(name);var tree=Convert(original);var compiled=Compile(tree);
  if(Verify(compiled)!=Verify(original.Compile()))throw new Exception("Incorrect result "+name);
  var actions=new Dictionary<string,Action<int>>();
  actions["compile"]=n=>{for(int i=0;i<n;i++)sink=Compile(tree);};
  actions["compile_first"]=n=>{long sum=0;for(int i=0;i<n;i++)sum+=Invoke(Compile(tree));checksum=sum;};
  actions["invoke"]=n=>{long sum=0;for(int i=0;i<n;i++)sum+=Invoke(compiled);checksum=sum;};
  if(compiled is Func<int,Func<int>> factory){actions["activate_and_invoke"]=actions["invoke"];actions.Remove("invoke");
   actions["activate"]=n=>{for(int i=0;i<n;i++)sink=factory(3);};
   var nested=factory(3);actions["nested_invoke"]=n=>{long sum=0;for(int i=0;i<n;i++)sum+=nested();checksum=sum;};
  } return actions;
 }
 public static void Cold(string name){
  var original=Build(name);var tree=Convert(original);
  _=Allocated();_=Stopwatch.GetTimestamp();_=Stopwatch.Frequency;
  long b=Allocated(),t=Stopwatch.GetTimestamp();var compiled=Compile(tree);long compile=Stopwatch.GetTimestamp()-t,bytes=Allocated()-b;
  b=Allocated();t=Stopwatch.GetTimestamp();int first=Invoke(compiled);long firstTime=Stopwatch.GetTimestamp()-t,firstBytes=Allocated()-b;
  var oracle=original.Compile();if(first!=Invoke(oracle)||Verify(compiled)!=Verify(oracle))throw new Exception("Incorrect cold result "+name);
  Runner.Row(name,"cold_compile","auto",0,0,1,compile*1e9/Stopwatch.Frequency,bytes);
  Runner.Row(name,"cold_first_invoke","auto",0,0,1,firstTime*1e9/Stopwatch.Frequency,firstBytes);
  Runner.Row(name,"cold_compile_first","auto",0,0,1,(compile+firstTime)*1e9/Stopwatch.Frequency,bytes+firstBytes);
  GC.KeepAlive(compiled);
 }
}}
