from pathlib import Path
import subprocess,json,hashlib
w=Path(__file__).resolve().parent
for folder in ['Current','Auto','Current-light','Auto-light']:
 with (w/f'build-{folder}.log').open('w') as f:subprocess.run(['dotnet','build',str(w/folder/'Library.csproj'),'-c','Release','--nologo','-v:q'],stdout=f,stderr=subprocess.STDOUT,check=True,timeout=180)
proof=[]
for light in [False,True]:
 suffix='-light' if light else ''
 with (w/f'build-runner{suffix}.log').open('w') as f:subprocess.run(['dotnet','build',str(w/f'Runner{suffix}.csproj'),'-c','Release','--nologo','-v:q'],stdout=f,stderr=subprocess.STDOUT,check=True,timeout=180)
 for tfm in ['net8.0','net10.0','net472']:
  source=w/f'bin{suffix}'/tfm
  target=w/'runners'/('Light' if light else 'Std')/tfm;target.mkdir(parents=True,exist_ok=True)
  import shutil
  for p in source.iterdir():
   if p.is_file():shutil.copy2(p,target/p.name)
  p=target/f'Runner{suffix}.{("exe" if tfm=="net472" else "dll")}'
  args=([str(p)] if tfm=='net472' else ['dotnet',str(p)])+['proof']
  r=subprocess.run(args,capture_output=True,text=True,timeout=60)
  (w/f'proof{suffix}-{tfm}.log').write_text(r.stdout+r.stderr)
  proof.append(dict(light=light,target=tfm,exit=r.returncode,output=r.stdout,runnerSHA256=hashlib.sha256(p.read_bytes()).hexdigest()))
  if r.returncode:raise SystemExit(r.stdout+r.stderr)
(w/'proof.json').write_text(json.dumps(proof,indent=2))
print('Six proof configurations pass; no elapsed performance measurements run.')
