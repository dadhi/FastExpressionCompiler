from pathlib import Path
import json,csv,statistics,hashlib
w=Path(__file__).resolve().parent;rows=[];errors=[];summaries=[];pairs=[]
for flavor in ['Std','Light']:
 for tfm in ['net8.0','net10.0','net472']:
  p=w/f'warm-{flavor}-{tfm}.csv'
  if not p.exists():errors.append('Missing '+p.name);continue
  groups={};local=[]
  for r in csv.reader(p.open()):
   if len(r)!=8:errors.append('Malformed '+str(r));continue
   scenario,phase,version,sample,n,ns,b,duration=r
   row=dict(flavor=flavor,runtime=tfm,scenario=scenario,phase=phase,version=version,sample=int(sample),operations=int(n),ns=float(ns),bytes=float(b),duration_ms=float(duration));local.append(row);rows.append(row)
   groups.setdefault((scenario,phase,version),[]).append(row)
  if len(local)!=308:errors.append(f'{flavor}/{tfm} expected308rows got{len(local)}')
  for (scenario,phase,version),g in groups.items():
   if sorted(r['sample'] for r in g)!=list(range(11)):errors.append(f'Missing/duplicates {flavor}/{tfm}/{scenario}/{phase}/{version}')
   summaries.append(dict(flavor=flavor,runtime=tfm,scenario=scenario,phase=phase,version=version,ns=statistics.median(r['ns'] for r in g),bytes=statistics.median(r['bytes'] for r in g),samples=len(g),duration_ms_min=min(r['duration_ms'] for r in g)))
   if version!='current':continue
   other=groups.get((scenario,phase,'auto'))
   if not other:errors.append('Missing AUTO');continue
   a=sorted(other,key=lambda r:r['sample']);b=sorted(g,key=lambda r:r['sample'])
   if [r['operations'] for r in a]!=[r['operations'] for r in b]:errors.append('Unmatched workload')
   pairs.append(dict(flavor=flavor,runtime=tfm,scenario=scenario,phase=phase,paired_ratio=statistics.median(x['ns']/y['ns'] for x,y in zip(a,b)),median_ratio=statistics.median(x['ns'] for x in a)/statistics.median(y['ns'] for y in b),bytes_before=statistics.median(x['bytes'] for x in b),bytes_auto=statistics.median(x['bytes'] for x in a),bytes_delta=statistics.median(x['bytes'] for x in a)-statistics.median(x['bytes'] for x in b)))
result=dict(errors=errors,rows=rows,summaries=summaries,comparisons=pairs,manifest=json.loads((w/'manifest.json').read_text()),limits=['One bounded candidate; no automatic integration.','Pair medians and ratios of marginal medians both retained; no application speedup claim.','Factory activation, nested call and combined activation+call are separately labeled.','No cold parity claim unless separately measured.'])
(w/'analysis.json').write_text(json.dumps(result,indent=2))
(w/'artifact-hashes.json').write_text(json.dumps({str(p.relative_to(w)):hashlib.sha256(p.read_bytes()).hexdigest() for p in w.glob('*') if p.is_file() and p.name!='artifact-hashes.json'},indent=2))
print(f'rows={len(rows)} pairs={len(pairs)} errors={len(errors)}')
for row in pairs:
 if row['bytes_delta']!=0 or row['paired_ratio']>1.05:print(row)
if errors:raise SystemExit('\n'.join(errors))
