from pathlib import Path
import subprocess,os,json,sys
w=Path(__file__).resolve().parent
if list(w.glob('warm-*.csv')) or list(w.glob('cold-*.json')):raise SystemExit('Refusing to overwrite evidence')
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
for flavor in ['Std','Light']:
 for tfm in ['net8.0','net10.0','net472']:
  s='-light' if flavor=='Light' else '';p=w/'runners'/flavor/tfm/f'Runner{s}.{("exe" if tfm=="net472" else "dll")}'
  command=[str(p)] if tfm=='net472' else ['dotnet',str(p)]
  with (w/f'warm-{flavor}-{tfm}.csv').open('w') as f,(w/f'warm-{flavor}-{tfm}.stderr.log').open('w') as e:subprocess.run(command+['measure'],stdout=f,stderr=e,env=env,check=True,timeout=300)
  if '--cold' not in sys.argv:continue
  rows=[]
  for rep in range(3):
   for name in ['add','mixed32']:
    for v in (['current','auto'] if rep%2==0 else ['auto','current']):
     r=subprocess.run(command+['cold',v,name],capture_output=True,text=True,env=env,check=True,timeout=30)
     rows.append(dict(version=v,scenario=name,repetition=rep,stdout=r.stdout,stderr=r.stderr))
  (w/f'cold-{flavor}-{tfm}.json').write_text(json.dumps(rows,indent=2))
print('Bounded measurements complete; no automatic source decision.')
