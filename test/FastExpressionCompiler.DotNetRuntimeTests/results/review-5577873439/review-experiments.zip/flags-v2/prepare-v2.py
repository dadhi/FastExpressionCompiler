from pathlib import Path
import re,shutil,json,hashlib
w=Path(__file__).resolve().parent;original=w.parent/'flags'
fixed=w/'fixed';fixed.mkdir(exist_ok=True)
for p in (original/'fixed').glob('*.cs'):shutil.copy2(p,fixed/p.name)
p=fixed/'FastExpressionCompiler.cs';data=p.read_bytes()
pattern=rb'set => _state = value \? _state \| (CompilerContextFlags\.\w+) : _state & ~\1;'
data,count=re.subn(pattern,rb'set => _state = (_state & ~\1) | (value ? \1 : 0);',data)
assert count==9;p.write_bytes(data)
for n in ['Fixture.csproj','Program.cs','Run.py']:shutil.copy2(original/n,w/n)
p=w/'Run.py';p.write_text(p.read_text().replace("['before','fixed']","['fixed']"))
bench=w/'bench';bench.mkdir(exist_ok=True)
template=original/'bench'
for folder in ['Current','Auto','Current-light','Auto-light']:
 dest=bench/folder;dest.mkdir(exist_ok=True)
 for p in (template/folder).iterdir():
  if p.is_file() and p.suffix in ['.cs','.csproj']:shutil.copy2(p,dest/p.name)
 if folder.startswith('Auto'):
  for p in fixed.glob('*.cs'):shutil.copy2(p,dest/p.name)
for name in ['Current.cs','Auto.cs','Runner.cs','Runner.csproj','Runner-light.csproj','build.py','measure.py','analyze.py','README.txt']:shutil.copy2(template/name,bench/name)
manifest=dict(baseline='8f12292f0baa596ed160c0e070ebb8329a623429',candidate='flags-v2:9 single-load setters; other flags-v1 source unchanged',parentCandidateSHA256=hashlib.sha256((original/'fixed/FastExpressionCompiler.cs').read_bytes()).hexdigest(),fixedSHA256=hashlib.sha256((fixed/'FastExpressionCompiler.cs').read_bytes()).hexdigest(),files={})
for folder in ['Current','Auto','Current-light','Auto-light']:
 for p in (bench/folder).glob('*.cs'):manifest['files'][p.relative_to(bench).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(w/'manifest.json').write_text(json.dumps(manifest,indent=2));(bench/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('Prepared9setter-only v2; original measured flags-v1 evidence untouched')
