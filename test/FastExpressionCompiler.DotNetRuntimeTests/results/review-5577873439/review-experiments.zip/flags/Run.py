from pathlib import Path
import subprocess
w=Path(__file__).resolve().parent
for variant in ['before','fixed']:
 for light in ['false','true']:
  for tfm in ['net8.0','net10.0','net472']:
   tag=variant+'-'+light+'-'+tfm
   with (w/('build-'+tag+'.log')).open('w') as f:subprocess.run(['dotnet','build','Fixture.csproj','-c','Release','-f',tfm,'-p:Variant='+variant,'-p:Light='+light,'--nologo','-v:q'],cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True)
   exe=w/'bin/Release'/tfm/('Fixture.exe' if tfm=='net472' else 'Fixture.dll')
   with (w/('check-'+tag+'.log')).open('w') as f:subprocess.run(([str(exe)] if tfm=='net472' else ['dotnet',str(exe)]),cwd=w,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=120)
   print('PASS '+tag,flush=True)
