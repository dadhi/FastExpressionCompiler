from pathlib import Path
import shutil,json,hashlib
w=Path(__file__).resolve().parent; flags=w.parent;template=flags.parent/'frame-inline'
for folder in ['Current','Auto','Current-light','Auto-light']:
 dest=w/folder;dest.mkdir(parents=True,exist_ok=True)
 for p in (template/folder).iterdir():
  if p.is_file() and p.suffix in ['.cs','.csproj']:shutil.copy2(p,dest/p.name)
 if folder.startswith('Auto'):
  for p in (flags/'fixed').glob('*.cs'):shutil.copy2(p,dest/p.name)
for name in ['Current.cs','Auto.cs','Runner.cs','Runner.csproj','Runner-light.csproj','build.py','measure.py','analyze.py']:
 shutil.copy2(template/name,w/name)
p=w/'Runner.cs';s=p.read_text();s=s.replace('"add","balanced256","blocks32","mixed32","scope_jump","capture8","try_finally"','"add","capture8","try_finally","mixed32"').replace('PASS42 flag/version/shape','PASS24 flag/version/shape');p.write_text(s)
p=w/'analyze.py';s=p.read_text().replace('!=506','!=308').replace('expected506','expected308').replace("'auto'","'auto'");p.write_text(s)
p=w/'measure.py';s=p.read_text().replace("['add','mixed32']","['add','mixed32']");p.write_text(s)
source_manifest=json.loads((flags/'manifest.json').read_text())
manifest=dict(baseline=source_manifest['baseline'],candidate='Packed internal CompilerContext booleans into ushort flags; NoInlining attribute unchanged',versionLabels={'current':'baseline8f','auto':'flags candidate (scaffolding generic label)'},files={})
for folder in ['Current','Auto','Current-light','Auto-light']:
 for p in (w/folder).glob('*.cs'):manifest['files'][p.relative_to(w).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['Auto','Auto-light']:
 assert manifest['files'][name+'/FastExpressionCompiler.cs']==source_manifest['files']['fixed']['FastExpressionCompiler.cs']
(w/'manifest.json').write_text(json.dumps(manifest,indent=2));print('Flags-only benchmark source prepared')
