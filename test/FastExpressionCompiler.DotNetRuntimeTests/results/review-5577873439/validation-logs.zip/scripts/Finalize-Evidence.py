from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
w=Path(__file__).resolve().parent
repo=Path(r'C:\Data\Git\Github\FastExpressionCompiler')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head=='35622f327afd42603e83403b3b5724750108e7d2'
validation=w.parent/'pr558-repair'/('validation-'+head[:8])
codes=json.loads((validation/'codes.json').read_text())
assert len(codes)==8 and all(x==0 for x in codes.values())
run=json.loads((validation/'suite/fec/run.json').read_text())
batches=run['batches'];assert len(batches)==21 and not run['crashes']
assert all(b['status']=='Complete' and b['attempt']==1 for b in batches)
fields=['total','executed','passed','failed','error','timeout','aborted','notExecuted']
totals={k:sum(int(b['counters'].get(k,0)) for b in batches) for k in fields}
assert totals['passed']==35064 and all(totals[k]==0 for k in ['failed','error','timeout','aborted'])
frame=(validation/'framework-run.log').read_text()
assert '1041 tests are passing' in frame and '1595 tests are passing' in frame
result={'codeHead':head,'codes':codes,'imported':{'batches':21,'crashes':0,'counters':totals,
    'originalDenominator':35133,'exclusions':69,'newExclusions':0},
    'native':{'net10':'All runner suites pass; legacy1712','net8':'All runner suites pass; legacy1711',
    'framework':'TestX1041 and legacy1595 pass'},
    'snapshot':json.loads((validation/'snapshot.json').read_text()),
    'productionBehavior':'Only source comments changed since8f; held experiments are not merged.'}
p=w/'publication'
(p/'validation.json').write_text(json.dumps(result,indent=2))
archive=p/'validation-logs.zip';assert not archive.exists()
entries={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    files=[(x,x.relative_to(validation).as_posix()) for x in validation.rglob('*') if x.is_file()]
    files += [(w.parent/'pr558-repair/validate.py','scripts/validate.py'),
              (w.parent/'fec-round12/Run-Full.py','scripts/Run-Full.py'),
              (Path(__file__),'scripts/Finalize-Evidence.py')]
    for path,name in sorted(files,key=lambda x:x[1]):
        data=path.read_bytes();z.writestr(name,data)
        entries[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,meta in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==meta['sha256']
(p/'validation-manifest.json').write_text(json.dumps({'codeHead':head,'archive':archive.name,
    'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'entries':entries},indent=2))
readme=(w/'Review-Report.md').read_text()
readme += '\nFinal result at `'+head+'`: **35,064 imported cases pass, zero executed failures/crashes; 69 existing exclusions unchanged.** Both production builds and .NET 8/10 native suites pass. Framework passes 1,041 TestX and 1,595 legacy tests.\n'
(p/'README.md').write_text(readme,encoding='utf-8')
(p/'.gitattributes').write_text('* -text\n')
destination=repo/'test/FastExpressionCompiler.DotNetRuntimeTests/results/review-5577873439'
assert not destination.exists();shutil.copytree(p,destination)
print(json.dumps({'codeHead':head,'importedPassed':totals['passed'],'executedFailures':0,
    'crashes':0,'exclusions':69,'validationZipBytes':archive.stat().st_size,'destination':str(destination)},indent=2))
