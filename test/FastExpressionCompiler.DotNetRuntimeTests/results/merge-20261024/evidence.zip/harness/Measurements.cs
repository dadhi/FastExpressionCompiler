using System;
using System.Diagnostics;
using System.Linq.Expressions;
#if LIGHT_EXPRESSION
using FastExpressionCompiler.LightExpression;
using FastExpressionCompiler.LightExpression.ILDecoder;
#else
using FastExpressionCompiler;
using FastExpressionCompiler.ILDecoder;
#endif
static class Measurements
{
    public static int Compare(int a, int b) => a * 10 + b;
    static int sink;
    public static int Run()
    {
        System.Globalization.CultureInfo.CurrentCulture = System.Globalization.CultureInfo.InvariantCulture;
#if NET8_0_OR_GREATER
        var x = System.Linq.Expressions.Expression.Parameter(typeof(int));
        foreach (var shape in new[] { "scalar", "converted-add-eh", "converted-method-eh" })
        {
            var right = shape == "scalar" ? (System.Linq.Expressions.Expression)System.Linq.Expressions.Expression.Constant(2) :
                System.Linq.Expressions.Expression.Convert(System.Linq.Expressions.Expression.Convert(x, typeof(long)), typeof(int));
            var binary = shape == "converted-method-eh" ?
                System.Linq.Expressions.Expression.Equal(System.Linq.Expressions.Expression.Constant(3), right, false, typeof(Measurements).GetMethod(nameof(Compare))) :
                System.Linq.Expressions.Expression.Add(System.Linq.Expressions.Expression.Constant(3), right);
            var body = shape == "scalar" ? (System.Linq.Expressions.Expression)binary :
                System.Linq.Expressions.Expression.TryFinally(binary, System.Linq.Expressions.Expression.Empty());
            var sys = System.Linq.Expressions.Expression.Lambda<Func<int,int>>(body, x);
#if LIGHT_EXPRESSION
            var light = sys.ToLightExpression();
            Func<Func<int,int>> fec = () => light.CompileFast(true);
#else
            Func<Func<int,int>> fec = () => sys.CompileFast(true);
#endif
            foreach (var compiler in new[] { "fec", "system" })
            {
                Func<Func<int,int>> compile = compiler == "fec" ? fec : () => sys.Compile();
                var d = compile();
                if (d(4) != (shape == "scalar" ? 5 : shape == "converted-method-eh" ? 34 : 7)) return 1;
                Console.WriteLine("IL " + shape + " " + compiler);
                if (compiler == "fec") Console.WriteLine(d.Method.ToILString());
                for (int i=0;i<1000;i++) GC.KeepAlive(compile());
                for (int sample=0;sample<7;sample++)
                {
                    GC.Collect(); GC.WaitForPendingFinalizers(); GC.Collect();
                    var allocated = GC.GetAllocatedBytesForCurrentThread();
                    var start = Stopwatch.GetTimestamp();
                    for (int i=0;i<2000;i++) GC.KeepAlive(compile());
                    var compileNs = (Stopwatch.GetTimestamp()-start)*1e9/Stopwatch.Frequency/2000;
                    var compileBytes = (GC.GetAllocatedBytesForCurrentThread()-allocated)/2000.0;
                    for (int i=0;i<100000;i++) sink = d(i);
                    allocated = GC.GetAllocatedBytesForCurrentThread(); start=Stopwatch.GetTimestamp();
                    int sum=0; for (int i=0;i<5000000;i++) sum+=d(i);
                    var runtimeNs=(Stopwatch.GetTimestamp()-start)*1e9/Stopwatch.Frequency/5000000;
                    var runtimeBytes=(GC.GetAllocatedBytesForCurrentThread()-allocated)/5000000.0;
                    sink=sum;
                    Console.WriteLine($"DATA,{shape},{compiler},{sample},{compileNs:R},{compileBytes:R},{runtimeNs:R},{runtimeBytes:R}");
                }
            }
        }
#endif
        return 0;
    }
}
