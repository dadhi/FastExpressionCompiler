using System;
using System.Linq.Expressions;
using System.Runtime.InteropServices;

#if LIGHT_EXPRESSION
using FastExpressionCompiler.LightExpression;
using FastExpressionCompiler.LightExpression.ILDecoder;
#if NET8_0_OR_GREATER
using FastExpressionCompiler.LightExpression.IssueTests;
#endif
#else
using FastExpressionCompiler;
using FastExpressionCompiler.ILDecoder;
#if NET8_0_OR_GREATER
using FastExpressionCompiler.IssueTests;
#endif
#endif

class Program
{
    [DllImport("kernel32.dll")] static extern uint SetErrorMode(uint mode);
    static int Main(string[] args)
    {
        Console.WriteLine("Runtime=" + Environment.Version + ";64Bit=" + Environment.Is64BitProcess);
        if (args[0] == "measure") return Measurements.Run();
        if (args[0] == "fixture")
        {
#if NET8_0_OR_GREATER
            var run = new TestRun();
            run.Run(new Issue561_NonBooleanEqualityOperator());
            for (var i = 0; i < run.Failures.Count; ++i) Console.WriteLine(run.Failures[i]);
            Console.WriteLine("Native regression fixture: total=" + run.TotalTestCount + ";failed=" + run.FailedTestCount);
            return run.FailedTestCount == 0 ? 0 : 1;
#else
            Console.WriteLine("Native guard requires the modern dynamic-method decoder; use the isolated raw repro on Framework.");
            return 2;
#endif
        }
        // Each unsafe original repro is launched in its own disposable process.
        if (Environment.OSVersion.Platform == PlatformID.Win32NT) SetErrorMode(2);
        bool neq = Array.IndexOf(args, "neq") >= 0;
        bool reversed = Array.IndexOf(args, "reversed") >= 0;
        bool debug = Array.IndexOf(args, "debug") >= 0;
        System.Linq.Expressions.Expression<Func<ICustomObject>> tree = reversed
            ? (neq ? () => new CustomObject() != 1 : () => new CustomObject() == 1)
            : (neq ? () => 1 != new CustomObject() : () => 1 == new CustomObject());
        var binary = (System.Linq.Expressions.BinaryExpression)tree.Body;
        Console.WriteLine("Node=" + binary.NodeType + ";type=" + binary.Type + ";method=" + binary.Method + ";lifted=" + binary.IsLifted);
        Func<ICustomObject> compiled;
        if (args[0] == "system") compiled = tree.Compile();
        else
        {
            var flags = debug ? CompilerFlags.EnableDelegateDebugInfo : CompilerFlags.Default;
#if LIGHT_EXPRESSION
            var converted = tree.ToLightExpression();
            Console.WriteLine("Converted body type=" + converted.Body.Type);
            compiled = converted.CompileFast(true, flags);
#else
            compiled = tree.CompileFast(true, flags);
#endif
            Console.WriteLine("StrictFecDelegate=" + (compiled != null));
            if (compiled == null) return 3;
        }
        Console.WriteLine(compiled.Method.ToILString());
        if (args[0] == "inspect") return 0;
        Console.WriteLine("Invoking delegate");
        var result = compiled();
        Console.WriteLine("OperatorCalls=" + CustomObject.OperatorCalls);
        if (result is null) { Console.WriteLine("WRONG: null result"); return 4; }
        Console.WriteLine("Calling Ping on returned interface");
        result.Ping();
        Console.WriteLine("PASS");
        return CustomObject.OperatorCalls == 1 ? 0 : 5;
    }

    public interface ICustomObject { void Ping(); }
    public sealed class CustomObject : ICustomObject
    {
        public static int OperatorCalls;
        public static ICustomObject operator ==(double left, CustomObject right) => Result();
        public static ICustomObject operator !=(double left, CustomObject right) => Result();
        public static ICustomObject operator ==(CustomObject left, double right) => Result();
        public static ICustomObject operator !=(CustomObject left, double right) => Result();
        static ICustomObject Result() { ++OperatorCalls; return new CustomObject(); }
        public void Ping() { Console.WriteLine("pong"); }
        public override bool Equals(object obj) => ReferenceEquals(this, obj);
        public override int GetHashCode() => base.GetHashCode();
    }
}
