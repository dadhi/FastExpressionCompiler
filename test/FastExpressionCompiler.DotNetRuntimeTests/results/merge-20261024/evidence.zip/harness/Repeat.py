from pathlib import Path
import subprocess,json,statistics
w=Path(__file__).resolve().parent
allrows=json.loads((w/'measurements.json').read_text())['samples']
for repeat in [2,3]:
 for i,tfm in enumerate(['net10.0','net8.0']):
  for flavor in ['Light','Std']:
   for version in (['before','after'] if (repeat+i+(flavor=='Light'))%2==0 else ['after','before']):
    binary=w/'bin'/version/flavor/tfm/f'Issue561.{version}.{flavor}.dll'
    p=subprocess.run(['dotnet',str(binary),'measure'],capture_output=True,text=True,timeout=180)
    (w/f'measure-repeat{repeat}-{version}-{flavor}-{tfm}.log').write_text(p.stdout+'\nSTDERR:\n'+p.stderr,encoding='utf-8');assert p.returncode==0
    for line in p.stdout.splitlines():
     if line.startswith('DATA,'):
      _,shape,compiler,sample,comp,alloc,runtime,ralloc=line.split(',')
      allrows.append(dict(version=version,flavor=flavor,tfm=tfm,shape=shape,compiler=compiler,sample=int(sample),repeat=repeat,compileNs=float(comp),compileBytes=float(alloc),runtimeNs=float(runtime),runtimeBytes=float(ralloc)))
    print(repeat,version,flavor,tfm,flush=True)
summary=[]
for flavor in ['Std','Light']:
 for tfm in ['net8.0','net10.0']:
  for shape in ['scalar','converted-add-eh','converted-method-eh']:
   item=dict(flavor=flavor,tfm=tfm,shape=shape)
   for version in ['before','after']:
    for compiler in ['fec','system']:
     xs=[x for x in allrows if all(x[k]==v for k,v in dict(version=version,flavor=flavor,tfm=tfm,shape=shape,compiler=compiler).items())];assert len(xs)==21
     item[version+'-'+compiler]={k:statistics.median(x[k] for x in xs) for k in ['compileNs','compileBytes','runtimeNs','runtimeBytes']}
   summary.append(item)
(w/'all-measurements.json').write_text(json.dumps(allrows,indent=2),encoding='utf-8')
(w/'repeated-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
