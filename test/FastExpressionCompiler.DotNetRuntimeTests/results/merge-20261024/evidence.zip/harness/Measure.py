from pathlib import Path
import subprocess,json,hashlib,statistics,os
w=Path(__file__).resolve().parent
rows=[];binaries=[]
for i,tfm in enumerate(['net8.0','net10.0']):
 for flavor in ['Std','Light']:
  for version in (['before','after'] if (i+(flavor=='Light'))%2==0 else ['after','before']):
   binary=w/'bin'/version/flavor/tfm/f'Issue561.{version}.{flavor}.dll'
   binaries.append(dict(version=version,flavor=flavor,tfm=tfm,sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))
   p=subprocess.run(['dotnet',str(binary),'measure'],capture_output=True,text=True,timeout=180,env=dict(os.environ,DOTNET_CLI_UI_LANGUAGE='en'))
   (w/f'measure-{version}-{flavor}-{tfm}.log').write_text(p.stdout+'\nSTDERR:\n'+p.stderr,encoding='utf-8')
   assert p.returncode==0,(version,flavor,tfm,p.stderr)
   for line in p.stdout.splitlines():
    if line.startswith('DATA,'):
     _,shape,compiler,sample,comp,alloc,runtime,ralloc=line.split(',')
     rows.append(dict(version=version,flavor=flavor,tfm=tfm,shape=shape,compiler=compiler,sample=int(sample),compileNs=float(comp),compileBytes=float(alloc),runtimeNs=float(runtime),runtimeBytes=float(ralloc)))
   print(version+' '+flavor+' '+tfm+' complete',flush=True)
(w/'measurements.json').write_text(json.dumps(dict(samples=rows,binaries=binaries),indent=2),encoding='utf-8')
summary=[]
for flavor in ['Std','Light']:
 for tfm in ['net8.0','net10.0']:
  for shape in ['scalar','converted-add-eh','converted-method-eh']:
   item=dict(flavor=flavor,tfm=tfm,shape=shape)
   for version in ['before','after']:
    for compiler in ['fec','system']:
     samples=[x for x in rows if all(x[k]==v for k,v in dict(version=version,flavor=flavor,tfm=tfm,shape=shape,compiler=compiler).items())]
     assert len(samples)==7
     item[version+'-'+compiler]={k:statistics.median(x[k] for x in samples) for k in ['compileNs','compileBytes','runtimeNs','runtimeBytes']}
   summary.append(item)
(w/'measurement-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
