from pathlib import Path
import hashlib,json,re,shutil,subprocess,zipfile
w=Path(__file__).resolve().parent
repo=Path(r'C:\Data\Git\Github\FastExpressionCompiler')
old='187b9b8f5505b9b69708170a4da13f440ca7a12f'
base='3aefb5e58cd3bdd92d5f2fb00e72692ab3c08c67'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('5ce56174')
subprocess.run(['git','merge-base','--is-ancestor',base,head],cwd=repo,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
v=w.parent/'pr558-repair'/('validation-'+head[:8])
codes=json.loads((v/'codes.json').read_text())
assert len(codes)==8 and all(x==0 for x in codes.values())
run=json.loads((v/'suite/fec/run.json').read_text());bs=run['batches']
assert len(bs)==21 and not run['crashes']
assert all(x['status']=='Complete' and x['attempt']==1 for x in bs)
fields=['total','executed','passed','failed','error','timeout','aborted','notExecuted']
totals={k:sum(int(b['counters'].get(k,0)) for b in bs) for k in fields}
assert totals['passed']==35064 and all(totals[k]==0 for k in ['failed','error','timeout','aborted'])
native={}
for name in ['native-net10.0','native-net8.0','framework-run']:
    text=(v/(name+'.log')).read_text(encoding='utf-8')
    legacy=int(re.search(r'//ALL\s+(\d+)\s+tests are passing',text)[1])
    native[name]={'legacyPassed':legacy}
    if name=='framework-run':native[name]['testXPassed']=int(re.search(r'//TestX:\s+(\d+)\s+tests are passing',text)[1])
metadata={'previousPublishedHead':old,'upstreamMaster':base,'validatedCodeHead':head,'codes':codes,
    'imported':{'batches':21,'crashes':0,'counters':totals,'originalDenominator':35133,'exclusions':69,'newExclusions':0},
    'native':native,'snapshot':json.loads((v/'snapshot.json').read_text()),
    'preservation':'Upstream SmallSet4 and helper rename retained; compatibility fixes preserved; duplicate upstream Light conversion patch dropped.',
    'performance':'Existing performance data remains tied to original source hashes; no new timing or performance-parity claim.'}
p=w/'publication';p.mkdir(exist_ok=True)
(p/'validation.json').write_bytes(json.dumps(metadata,indent=2).encode('utf-8'))
archive=p/'validation-logs.zip';assert not archive.exists();entries={}
files=[(x,x.relative_to(v).as_posix()) for x in v.rglob('*') if x.is_file()]
files += [(w.parent/'pr558-repair/validate.py','scripts/validate.py'),
    (w.parent/'fec-round12/Run-Full.py','scripts/Run-Full.py'),(Path(__file__),'scripts/Finalize.py')]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path,name in sorted(files,key=lambda x:x[1]):
        data=path.read_bytes();z.writestr(name,data)
        entries[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,m in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==m['sha256']
(p/'manifest.json').write_bytes(json.dumps({'codeHead':head,'archive':archive.name,'bytes':archive.stat().st_size,
    'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'entries':entries},indent=2).encode('utf-8'))
for name in ['range-diff.txt','source-delta.diff','rebase-summary.txt','integration-check.json']:
    (p/name).write_bytes((w/name).read_bytes().replace(b'\r\n',b'\n'))
readme=f'''# Rebase onto current dadhi/master (20 October 2026)

PR #558 was rebased from `{old}` onto `{base}`. A local backup branch preserves the former history. The upstream base now includes the merged #557 and dadhi's map-to-set cleanup. #559 was not rewritten.

Conflict resolutions preserve the existing exception/invocation compatibility behavior while adopting `SmallSet4` for both complex-argument and invocation-jump membership tracking. They do not restore the removed `NoValue` type. The Issue476 regression test uses upstream's renamed `AddSureAbsentDefaultAndGetValueRef` helper. The already-upstream Light null-conversion preservation commit was dropped as redundant; upstream round-trip fixes/tests and README changes are retained.

The full range comparison is in [range-diff.txt](range-diff.txt). The final source integration delta versus the previous published head is in [source-delta.diff](source-delta.diff), with the overall file summary in [rebase-summary.txt](rebase-summary.txt). A normalized-line-ending comparison confirms that the core compiler is exactly the former source plus the specified set type/member substitutions; [integration-check.json](integration-check.json) records the hashes and replacement counts. Earlier reports retain their original measured/validated commit IDs; the mapping makes the rewritten history traceable. No experimental packed-flag, region-packing, quote-visitor or inlining proposal from the prior review study was added.

Fresh validation at `{head}`:

- Both production projects build across their configured targets.
- .NET 10 native suites pass, including {native['native-net10.0']['legacyPassed']:,} legacy cases.
- .NET 8 native suites pass, including {native['native-net8.0']['legacyPassed']:,} legacy cases.
- Framework passes {native['framework-run']['testXPassed']:,} TestX and {native['framework-run']['legacyPassed']:,} legacy cases.
- All 21 imported batches complete on the first attempt: **35,064 cases pass, zero executed failures/crashes**. The **69 existing exclusions** are unchanged; the deferred deep-tree crash remains excluded.

[validation.json](validation.json) records exact source/assembly hashes and counters. [validation-logs.zip](validation-logs.zip) contains all build/test logs, batch results and validation scripts; [manifest.json](manifest.json) records the archive and every entry's SHA-256. The final evidence-only commit does not alter validated production or test source.

Previous performance/allocation measurements remain source-specific historical results. This rebase was correctness-validated; no new timing result or claim of performance parity on the new base is made.
'''
(p/'README.md').write_bytes(readme.encode('utf-8'))
(p/'.gitattributes').write_bytes(b'* -text\n')
dest=repo/'test/FastExpressionCompiler.DotNetRuntimeTests/results/rebase-20261020'
assert not dest.exists();shutil.copytree(p,dest)
print(json.dumps(metadata,indent=2))
