Baseline: exact0197699d; candidate only adds Volatile.Read empty-bucket precheck.
Reproduce setup: python setup.py
Build only: powershell -File Build.ps1
Correctness: dotnet bin/Concurrency{before|fixed}/{net8.0|net10.0}/Concurrency{before|fixed}.dll
24,000 exclusive leases per run; exact/min growth lengths; content integrity; oversized retention rejection.

Only run measurements in root-authorized quiet window:
python Run-Warm.py
  Collection: balanced, blocks, mixed32/128, EH8/32; 101 alternating paired samples.
  Runner: 11 scenarios, compile, compile+first, invoke and activation phases; allocations included.
python ../run-cold-candidate.py scope-read-gate 9 final-cold add balanced256 nested_mixed128 try_catch try_finally capture8
  Fresh process per version/runtime/case; cold managed allocations + elapsed compile/first.

Builds and correctness probes completed; no elapsed measurements yet.
