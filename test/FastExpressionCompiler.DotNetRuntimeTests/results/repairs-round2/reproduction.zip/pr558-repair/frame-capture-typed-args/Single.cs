using System;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Linq.Expressions;
using E=System.Linq.Expressions.Expression;
public class ProbeBox{public static int Last;}
class Program{
 static readonly Func<long> Allocated=(Func<long>)Delegate.CreateDelegate(typeof(Func<long>),typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread"));
 static object sink;static long checksum;
 static LambdaExpression Build(string name){
  var x=E.Parameter(typeof(int),"x");var y=E.Parameter(typeof(int),"y");
  if(name=="action")return E.Lambda<Func<int,Action<int>>>(E.Lambda<Action<int>>(
   E.Block(E.Assign(E.Field(null,typeof(ProbeBox).GetField("Last")),E.AddAssign(x,y)),E.Empty()),y),x);
  Expression body=E.Add(x,y);if(name=="tryfunc")body=E.TryFinally(body,E.Empty());
  if(name=="dead")body=E.Condition(E.Constant(true),E.Constant(5),body);
  return E.Lambda<Func<int,Func<int,int>>>(E.Lambda<Func<int,int>>(body,y),x);
 }
 [MethodImpl(MethodImplOptions.NoInlining)]static Delegate CompileFirst(LambdaExpression source)=>FastExpressionCompiler.ExpressionCompiler.CompileFast(source,true);
 [MethodImpl(MethodImplOptions.NoInlining)]static int InvokeFirst(Delegate f){if(f is Func<int,Action<int>> a){a(3)(1);return ProbeBox.Last;}return ((Func<int,Func<int,int>>)f)(3)(1);}
 static void Row(string phase,double ns,double bytes){Console.WriteLine(phase+" "+ns.ToString("R",CultureInfo.InvariantCulture)+" "+bytes.ToString("R",CultureInfo.InvariantCulture));}
 static void Measure(string phase,int n,Action<int> action){action(Math.Min(n,1000));for(int r=0;r<7;r++){long b=Allocated(),t=Stopwatch.GetTimestamp();action(n);long elapsed=Stopwatch.GetTimestamp()-t,bytes=Allocated()-b;Row(phase,elapsed*1e9/Stopwatch.Frequency/n,bytes/(double)n);}}
 static void Main(string[] args){
  var source=Build(args[1]);
  if(args[0]=="cold"){
   long b=Allocated(),t=Stopwatch.GetTimestamp();var f=CompileFirst(source);long elapsed=Stopwatch.GetTimestamp()-t,bytes=Allocated()-b;
   b=Allocated();t=Stopwatch.GetTimestamp();int first=InvokeFirst(f);long invoke=Stopwatch.GetTimestamp()-t,invokeBytes=Allocated()-b;
   if(first!=InvokeFirst(source.Compile()))throw new Exception("wrong output");
   Row("cold_compile",elapsed*1e9/Stopwatch.Frequency,bytes);Row("cold_first_invoke",invoke*1e9/Stopwatch.Frequency,invokeBytes);Row("cold_compile_first",(elapsed+invoke)*1e9/Stopwatch.Frequency,bytes+invokeBytes);return;
  }
  var factory=CompileFirst(source);if(InvokeFirst(factory)!=InvokeFirst(source.Compile()))throw new Exception("wrong output");
  Measure("compile",1000,n=>{for(int i=0;i<n;i++)sink=CompileFirst(source);});
  if(factory is Func<int,Action<int>> action){
   Measure("activate",100000,n=>{for(int i=0;i<n;i++)sink=action(3);});var inner=action(3);
   Measure("nested_invoke",1000000,n=>{for(int i=0;i<n;i++)inner(1);checksum=ProbeBox.Last;});
   Measure("invoke",100000,n=>{for(int i=0;i<n;i++)action(3)(1);checksum=ProbeBox.Last;});
  }else{var f=(Func<int,Func<int,int>>)factory;
   Measure("activate",100000,n=>{for(int i=0;i<n;i++)sink=f(3);});var inner=f(3);
   Measure("nested_invoke",1000000,n=>{long sum=0;for(int i=0;i<n;i++)sum+=inner(i&1);checksum=sum;});
   Measure("invoke",100000,n=>{long sum=0;for(int i=0;i<n;i++)sum+=f(3)(i&1);checksum=sum;});
  }GC.KeepAlive(sink);
 }
}
