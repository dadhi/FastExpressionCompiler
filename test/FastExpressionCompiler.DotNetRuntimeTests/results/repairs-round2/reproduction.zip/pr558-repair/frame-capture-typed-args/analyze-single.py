from pathlib import Path
from collections import defaultdict
import re,statistics,json,hashlib
w=Path(__file__).resolve().parent;groups=defaultdict(list);inputs={}
for p in w.glob('single-*.txt'):
 if not p.name.startswith(('single-cold-','single-warm-')):continue
 data=p.read_text(encoding='utf-8-sig');inputs[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
 m=re.match(r'single-(cold|warm)-(net472|net8\.0|net10\.0)-(?:[0-9]+-)?(current|candidate)-(\w+)\.txt',p.name)
 if not m:raise Exception('Unknown input '+p.name)
 kind,runtime,version,scenario=m.groups()
 for line in data.splitlines():
  parts=line.split()
  if not parts:continue
  if len(parts)!=3:raise Exception('Unexpected diagnostic '+p.name+': '+line)
  phase,ns,allocation=parts
  groups[(kind,runtime,version,scenario,phase)].append((float(ns),float(allocation)))
rows=[]
for (kind,runtime,version,scenario,phase),data in sorted(groups.items()):
 rows.append(dict(kind=kind,runtime=runtime,version=version,scenario=scenario,phase=phase,samples=len(data),ns=statistics.median(v[0] for v in data),bytes=statistics.median(v[1] for v in data),bytes_min=min(v[1] for v in data),bytes_max=max(v[1] for v in data)))
comparisons=[]
for r in rows:
 if r['version']!='candidate':continue
 b=next(v for v in rows if all(v[k]==r[k] for k in ['kind','runtime','scenario','phase']) and v['version']=='current')
 comparisons.append(dict(kind=r['kind'],runtime=r['runtime'],scenario=r['scenario'],phase=r['phase'],current_ns=b['ns'],candidate_ns=r['ns'],ratio=r['ns']/b['ns'],current_bytes=b['bytes'],candidate_bytes=r['bytes'],delta_bytes=r['bytes']-b['bytes']))
(w/'typed-measurements.json').write_text(json.dumps(dict(current='89f3f1b8',candidateSourceSHA256=hashlib.sha256((w/'candidate/FastExpressionCompiler.cs').read_bytes()).hexdigest(),rows=rows,comparisons=comparisons,inputs=inputs,caveats=['Warm Framework: two fresh processes per version/scenario, opposite version order, seven samples per phase/process.','Cold Framework: three fresh processes per version/scenario; compiler first call and activation/first nested invocation measured separately.','Modern controls: one fresh process per version/scenario, seven warmed samples per phase.','These time ratios are descriptive independent-process medians, not alternating matched sample ratios.']),indent=2))
for r in comparisons:
 print(r['kind'],r['runtime'],r['scenario'],r['phase'],'B',r['current_bytes'],'->',r['candidate_bytes'],'ratio',round(r['ratio'],3))
