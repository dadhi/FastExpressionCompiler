using System;
using System.Linq;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Linq.Expressions;
using E=System.Linq.Expressions.Expression;
public class ProbeBox{public int Value=7;}
class Program{
 static readonly Func<long> Allocated=(Func<long>)Delegate.CreateDelegate(typeof(Func<long>),typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread"));
 static object sink;static long checksum;static bool measureTime=true;
 static Expression<Func<int,Func<int>>> Build(string name){
  var x=E.Parameter(typeof(int),"x");
  if(name=="capture_mutable")return E.Lambda<Func<int,Func<int>>>(E.Lambda<Func<int>>(E.PreIncrementAssign(x)),x);
  if(name=="capture8"){
   var vs=Enumerable.Range(0,8).Select(i=>E.Variable(typeof(int),"v"+i)).ToArray();Expression sum=x;foreach(var v in vs)sum=E.Add(sum,v);
   return E.Lambda<Func<int,Func<int>>>(E.Block(vs,vs.Select(v=>(Expression)E.Assign(v,x)).Concat(new Expression[]{E.Lambda<Func<int>>(sum)})),x);
  }
  var b=E.Variable(typeof(ProbeBox),"b");Expression read=E.Field(b,"Value");if(name=="capture_try")read=E.TryFinally(read,E.Empty());
  return E.Lambda<Func<int,Func<int>>>(E.Block(new[]{b},E.Assign(b,E.Constant(new ProbeBox())),E.Lambda<Func<int>>(read)),x);
 }
 [MethodImpl(MethodImplOptions.NoInlining)]static Func<int,Func<int>> CompileFirst(Expression<Func<int,Func<int>>> source)=>FastExpressionCompiler.ExpressionCompiler.CompileFast(source,true);
 [MethodImpl(MethodImplOptions.NoInlining)]static int InvokeFirst(Func<int,Func<int>> f)=>f(3)();
 static string Result(Func<int,Func<int>> f){var inner=f(3);return inner()+":"+inner();}
 static void Row(string phase,double ns,double bytes){Console.WriteLine(phase+" "+ns.ToString("R",CultureInfo.InvariantCulture)+" "+bytes.ToString("R",CultureInfo.InvariantCulture));}
 static void Measure(string phase,int n,Action<int> action){action(Math.Min(n,1000));for(int r=0;r<7;r++){long b=Allocated(),t=measureTime?Stopwatch.GetTimestamp():0;action(n);long elapsed=measureTime?Stopwatch.GetTimestamp()-t:0,bytes=Allocated()-b;Row(phase,elapsed*1e9/Stopwatch.Frequency/n,bytes/(double)n);}}
 static void Main(string[] args){
  measureTime=args[0]!="allocation";var source=Build(args[1]);
  if(args[0]=="cold"){
   long b=Allocated(),t=Stopwatch.GetTimestamp();var f=CompileFirst(source);long elapsed=Stopwatch.GetTimestamp()-t,bytes=Allocated()-b;
   b=Allocated();t=Stopwatch.GetTimestamp();int first=InvokeFirst(f);long invoke=Stopwatch.GetTimestamp()-t,invokeBytes=Allocated()-b;
   // System compilation/behavior checks happen after both measured cold phases.
   if(first!=InvokeFirst(source.Compile())||Result(f)!=Result(source.Compile()))throw new Exception("wrong output");
   Row("cold_compile",elapsed*1e9/Stopwatch.Frequency,bytes);Row("cold_first_invoke",invoke*1e9/Stopwatch.Frequency,invokeBytes);Row("cold_compile_first",(elapsed+invoke)*1e9/Stopwatch.Frequency,bytes+invokeBytes);return;
  }
  var factory=CompileFirst(source);if(Result(factory)!=Result(source.Compile()))throw new Exception("wrong output");
  Measure("compile",1000,n=>{for(int i=0;i<n;i++)sink=CompileFirst(source);});
  Measure("activate",100000,n=>{for(int i=0;i<n;i++)sink=factory(3);});
  var inner=factory(3);
  Measure("nested_invoke",1000000,n=>{long sum=0;for(int i=0;i<n;i++)sum+=inner();checksum=sum;});
  Measure("invoke",100000,n=>{long sum=0;for(int i=0;i<n;i++)sum+=factory(3)();checksum=sum;});
  GC.KeepAlive(sink);
 }
}
