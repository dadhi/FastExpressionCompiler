from pathlib import Path
import subprocess, statistics, json, os, sys
w=Path(__file__).resolve().parent
env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
rows=[]
runtime=sys.argv[1] if len(sys.argv)>1 else 'net472'
for mode,reps in [('warm',2),('cold',3)]:
 for rep in range(reps):
  for shape in ['capture_mutable','capture8','capture_reference','capture_try']:
   for version in (['current','candidate'] if rep%2==0 else ['candidate','current']):
    exe=w/('runner-'+version)/runtime/('Single.'+version+('.exe' if runtime=='net472' else '.dll'))
    command=[str(exe)] if runtime=='net472' else ['dotnet',str(exe)]
    p=subprocess.run(command+[mode,shape],capture_output=True,text=True,env=env,check=True)
    (w/f'{runtime}-{mode}-{rep}-{version}-{shape}.txt').write_text(p.stdout)
    for line in p.stdout.splitlines():
     phase,ns,alloc=line.split()
     rows.append(dict(runtime=runtime,mode=mode,repetition=rep,scenario=shape,version=version,phase=phase,ns=float(ns),bytes=float(alloc)))
out=[]
for mode in ['warm','cold']:
 for shape in ['capture_mutable','capture8','capture_reference','capture_try']:
  phases=sorted({r['phase'] for r in rows if r['mode']==mode and r['scenario']==shape})
  for phase in phases:
   entry=dict(runtime=runtime,mode=mode,scenario=shape,phase=phase)
   for version in ['current','candidate']:
    matches=[r for r in rows if r['mode']==mode and r['scenario']==shape and r['phase']==phase and r['version']==version]
    entry[version]=dict(ns=statistics.median(r['ns'] for r in matches),bytes=statistics.median(r['bytes'] for r in matches),samples=len(matches))
   entry['time_ratio']=entry['candidate']['ns']/entry['current']['ns']
   entry['allocation_delta']=entry['candidate']['bytes']-entry['current']['bytes']
   out.append(entry)
(w/f'measurements-{runtime}.json').write_text(json.dumps(dict(rows=rows,summary=out),indent=2))
for r in out: print(r)
