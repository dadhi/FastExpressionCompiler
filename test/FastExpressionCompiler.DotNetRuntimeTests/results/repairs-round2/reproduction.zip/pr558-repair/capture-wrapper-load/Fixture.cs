using System;
#if LIGHT_EXPRESSION
using FastExpressionCompiler.LightExpression;
using FastExpressionCompiler.LightExpression.UnitTests;
#else
using FastExpressionCompiler;
using FastExpressionCompiler.UnitTests;
#endif
class Program{static void Main(){var t=new TestRun();t.Run(new CapturedValueRefRegressionTests());Console.WriteLine("CapturedValueRef fixture: tests="+t.TotalTestCount+" failed="+t.FailedTestCount);Environment.ExitCode=t.FailedTestCount==0?0:1;}}
