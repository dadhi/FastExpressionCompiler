using System;
using System.Reflection;
using System.Runtime.CompilerServices;
class Program {
 static object sink;
 static readonly Func<long> Allocated=(Func<long>)Delegate.CreateDelegate(typeof(Func<long>),typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread"));
 static void Measure(string name,Action<int> action){action(1000);long before=Allocated();action(10000);long bytes=Allocated()-before;Console.WriteLine(name+"="+(bytes/10000.0));}
 static void Main(){
  var open=typeof(StrongBox<>);var type=typeof(StrongBox<int>);var scratch=new[]{typeof(int)};
  var empty=open.GetConstructor(Type.EmptyTypes).MethodHandle;var value=open.GetConstructor(open.GetGenericArguments()).MethodHandle;
  Measure("MakeGenericType",n=>{for(int i=0;i<n;i++)sink=open.MakeGenericType(scratch);});
  Measure("GetField",n=>{for(int i=0;i<n;i++)sink=type.GetField("Value");});
  Measure("EmptyConstructor",n=>{for(int i=0;i<n;i++)sink=type.GetConstructor(Type.EmptyTypes);});
  Measure("ValueConstructor",n=>{for(int i=0;i<n;i++)sink=type.GetConstructor(scratch);});
  Measure("EmptyHandle",n=>{for(int i=0;i<n;i++)sink=MethodBase.GetMethodFromHandle(empty,type.TypeHandle);});
  Measure("ValueHandle",n=>{for(int i=0;i<n;i++)sink=MethodBase.GetMethodFromHandle(value,type.TypeHandle);});
  Measure("Constructors",n=>{for(int i=0;i<n;i++)sink=type.GetConstructors();});
  Measure("ConstructorSearch",n=>{for(int i=0;i<n;i++){var cs=type.GetConstructors();for(int j=0;j<cs.Length;j++){var ps=cs[j].GetParameters();sink=ps.Length==0?cs[j]:(ps[0].ParameterType==typeof(int)?cs[j]:null);}}});
  Measure("GenericArguments",n=>{for(int i=0;i<n;i++)sink=type.GetGenericArguments();});
  GC.KeepAlive(sink);
 }
}
