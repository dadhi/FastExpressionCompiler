extern alias baseline;
extern alias current;
extern alias candidate;
using System;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Diagnostics;
using E=System.Linq.Expressions.Expression;
class Box{public int Value=7;}
class Program{
 static object sink;
 static long checksum;
 static bool timings;
 static readonly Func<long> Allocated=(Func<long>)Delegate.CreateDelegate(typeof(Func<long>),typeof(GC).GetMethod("GetAllocatedBytesForCurrentThread"));
 static Expression<Func<int,Func<int>>> Build(string name){
  var x=E.Parameter(typeof(int),"x");
  if(name=="capture_mutable")return E.Lambda<Func<int,Func<int>>>(E.Lambda<Func<int>>(E.PreIncrementAssign(x)),x);
  if(name=="capture8"){
   var vs=Enumerable.Range(0,8).Select(i=>E.Variable(typeof(int),"v"+i)).ToArray();Expression sum=x;foreach(var v in vs)sum=E.Add(sum,v);
   return E.Lambda<Func<int,Func<int>>>(E.Block(vs,vs.Select(v=>(Expression)E.Assign(v,x)).Concat(new Expression[]{E.Lambda<Func<int>>(sum)})),x);
  }
  var b=E.Variable(typeof(Box),"b");Expression read=E.Field(b,"Value");if(name=="capture_try")read=E.TryFinally(read,E.Empty());
  return E.Lambda<Func<int,Func<int>>>(E.Block(new[]{b},E.Assign(b,E.Constant(new Box())),E.Lambda<Func<int>>(read)),x);
 }
 static string Result(Func<int,Func<int>> f){var inner=f(3);return inner()+":"+inner();}
 static void Measure(string version,string scenario,Func<Func<int,Func<int>>> compile){
  MeasurePhase(version,scenario,"compile",1000,n=>{for(int i=0;i<n;i++)sink=compile();});
  if(!timings)return;
  var factory=compile();var inner=factory(3);
  MeasurePhase(version,scenario,"activate",100000,n=>{for(int i=0;i<n;i++)sink=factory(3);});
  MeasurePhase(version,scenario,"nested_invoke",1000000,n=>{long sum=0;for(int i=0;i<n;i++)sum+=inner();checksum=sum;});
  MeasurePhase(version,scenario,"invoke",100000,n=>{long sum=0;for(int i=0;i<n;i++)sum+=factory(3)();checksum=sum;});
 }
 static void MeasurePhase(string version,string scenario,string phase,int count,Action<int> action){
  action(Math.Min(count,1000));
  for(int round=0;round<5;round++){
   long start=Allocated();long tick=timings?Stopwatch.GetTimestamp():0;action(count);long elapsed=timings?Stopwatch.GetTimestamp()-tick:0;long bytes=Allocated()-start;
   Console.WriteLine(version+" "+scenario+" "+phase+" "+(bytes/(double)count)+(timings?" ns="+(elapsed*1000000000.0/Stopwatch.Frequency/count):""));
  }
 }
 static void Main(string[] args){timings=args.Length>1 && args[1]=="timing";foreach(var name in new[]{"capture_mutable","capture8","capture_reference","capture_try"}){
  var e=Build(name);var expected=Result(e.Compile());
  Func<Func<int,Func<int>>> before=()=>baseline::FastExpressionCompiler.ExpressionCompiler.CompileFast(e,true);
  Func<Func<int,Func<int>>> now=()=>current::FastExpressionCompiler.ExpressionCompiler.CompileFast(e,true);
  Func<Func<int,Func<int>>> after=()=>candidate::FastExpressionCompiler.ExpressionCompiler.CompileFast(e,true);
  foreach(var entry in new[]{Tuple.Create("baseline",before),Tuple.Create("current",now),Tuple.Create("candidate",after)}){
   if(args.Length!=0 && entry.Item1!=args[0])continue;
   var actual=Result(entry.Item2());if(actual!=expected)throw new Exception(entry.Item1+"/"+name+" wrong "+actual+" expected "+expected);
   Console.WriteLine("PASS "+entry.Item1+" "+name+" "+actual);Measure(entry.Item1,name,entry.Item2);
   if(args.Length>1 && args[1]=="instrument"){
   var compiler=entry.Item1=="current"?typeof(current::FastExpressionCompiler.ExpressionCompiler):entry.Item1=="candidate"?typeof(candidate::FastExpressionCompiler.ExpressionCompiler):null;
   var info=compiler==null?null:compiler.GetNestedType("HoistedTypeInfo",BindingFlags.NonPublic);
   var count=info==null?null:info.GetField("ProbeCount",BindingFlags.Static|BindingFlags.Public);
   if(count!=null)Console.WriteLine("METADATA "+entry.Item1+" count="+count.GetValue(null)+" type="+info.GetField("ProbeType",BindingFlags.Static|BindingFlags.Public).GetValue(null));
   }
  }
 }GC.KeepAlive(sink);}
}
