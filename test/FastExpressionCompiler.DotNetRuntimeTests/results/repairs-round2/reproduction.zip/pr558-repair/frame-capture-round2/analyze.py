from pathlib import Path
from collections import defaultdict
import re,json,statistics
w=Path(__file__).resolve().parent
groups=defaultdict(list)
for p in w.glob('timing-*.txt'):
 runtime=p.name[len('timing-'):].split('-')[0]
 for line in p.read_text(encoding='utf-8-sig').splitlines():
  m=re.match(r'(baseline|current|candidate) (\w+) (\w+) ([0-9,.]+) ns=([0-9,.]+)$',line)
  if not m:continue
  version,scenario,phase,allocation,ns=m.groups()
  groups[(runtime,version,scenario,phase)].append((float(allocation.replace(',','.')),float(ns.replace(',','.'))))
rows=[]
for (runtime,version,scenario,phase),data in sorted(groups.items()):
 rows.append(dict(runtime=runtime,version=version,scenario=scenario,phase=phase,bytes=statistics.median(v[0] for v in data),ns=statistics.median(v[1] for v in data),samples=len(data)))
comparisons=[]
for r in rows:
 if r['version']!='candidate':continue
 b=next(v for v in rows if v['runtime']==r['runtime'] and v['version']=='current' and v['scenario']==r['scenario'] and v['phase']==r['phase'])
 comparisons.append(dict(runtime=r['runtime'],scenario=r['scenario'],phase=r['phase'],current_bytes=b['bytes'],candidate_bytes=r['bytes'],delta_bytes=r['bytes']-b['bytes'],current_ns=b['ns'],candidate_ns=r['ns'],ratio=r['ns']/b['ns']))
(w/'metadata-measurements.json').write_text(json.dumps(dict(rows=rows,comparisons=comparisons),indent=2))
for r in comparisons:
 if r['runtime']=='net472':print(r['scenario'],r['phase'],'B',r['current_bytes'],'->',r['candidate_bytes'],'ratio',round(r['ratio'],3))
