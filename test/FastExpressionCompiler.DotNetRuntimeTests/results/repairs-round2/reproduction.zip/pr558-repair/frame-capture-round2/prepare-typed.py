"""Prepare an isolated accurately typed Framework nested-closure prototype only."""
from pathlib import Path
import shutil,subprocess,difflib
w=Path(__file__).resolve().parent
base=w.parent/'captures/src/FastExpressionCompiler'
d=w/'typed';d.mkdir(exist_ok=True)
for name in ['ImTools.cs','ILReader.cs','TestTools.cs']:(d/name).write_bytes((base/name).read_bytes())
raw=subprocess.check_output(['git','show','89f3f1b8:src/FastExpressionCompiler/FastExpressionCompiler.cs'],cwd=w.parent/'captures')
s=raw.decode('utf-8-sig').replace('\r\n','\n')
s=s.replace('ShouldBeStaticMethod = 1 << 3','ShouldBeStaticMethod = 1 << 3,\n            TypedNonPassedClosure = 1 << 4')
anchor='            var method = nestedLambdaContext.HasExceptionBlock'
assert s.count(anchor)==1
s=s.replace(anchor,'''#if NETFRAMEWORK
            // Curry<C,...> accepts the actual derived closure type. Accurate hidden
            // parameter typing avoids a cast for every access without unverifiable IL.
            if (hasNonPassedParameters)
            {
                if (closurePlusParamTypes.Length == 1)
                    closurePlusParamTypes = FrameworkNonPassedClosureSignature.Types;
                else
                    closurePlusParamTypes[0] = typeof(ArrayClosureWithNonPassedParams);
                nestedLambdaContext.Status |= ClosureStatus.TypedNonPassedClosure;
            }
#endif
'''+anchor)
anchor='        private static bool TryCompileNestedLambda(ref CompilerContext nestedLambdaContext, NestedLambdaInfo nestedLambdaInfo)'
s=s.replace(anchor,'''#if NETFRAMEWORK
        private static class FrameworkNonPassedClosureSignature
        {
            internal static readonly Type[] Types = { typeof(ArrayClosureWithNonPassedParams) };
            static FrameworkNonPassedClosureSignature() { }
        }
#endif

'''+anchor)
s=s.replace('private static void EmitLoadNonPassedParams(ILGenerator il)','private static void EmitLoadNonPassedParams(ILGenerator il, ref CompilerContext context)')
s=s.replace('EmitLoadNonPassedParams(il);','EmitLoadNonPassedParams(il, ref context);')
start=s.index('public static bool TryEmitNonByRefNonValueTypeParameter(')
end=s.index('private static bool TryEmitSimpleUnaryExpression',start)
portion=s[start:end]
assert portion.count('EmitLoadNonPassedParams(il, ref context);')==1
s=s[:start]+portion.replace('EmitLoadNonPassedParams(il, ref context);','EmitLoadNonPassedParams(il, ref closure);')+s[end:]
anchor='                il.Demit(OpCodes.Castclass, typeof(ArrayClosureWithNonPassedParams));'
assert s.count(anchor)==1
s=s.replace(anchor,'''                if ((context.Status & ClosureStatus.TypedNonPassedClosure) == 0)
                    il.Demit(OpCodes.Castclass, typeof(ArrayClosureWithNonPassedParams));''')
original=raw.splitlines(keepends=True)
old=[line.decode('utf-8').rstrip('\r\n') for line in original]
new=s.splitlines()
result=[]
for tag,a,b,c,e in difflib.SequenceMatcher(None,old,new,autojunk=False).get_opcodes():
 result.extend(original[a:b] if tag=='equal' else [line.encode('utf-8')+b'\n' for line in new[c:e]])
(d/'FastExpressionCompiler.cs').write_bytes(b''.join(result))
(d/'Library.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><AssemblyName>FrameRound2.typed</AssemblyName></PropertyGroup></Project>')
print('Prepared typed-signature prototype only; no build or execution')
