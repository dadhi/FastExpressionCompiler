from pathlib import Path
import subprocess,sys
w=Path(__file__).resolve().parent
repo=Path(r'C:\Data\Git\Github\FastExpressionCompiler')
candidate=w.parent/'captures'
for version,ref in [('baseline','e4c232da'),('current','25955bb5'),('candidate',None)]:
 d=w/version;d.mkdir(exist_ok=True)
 for name in ['FastExpressionCompiler.cs','ImTools.cs','ILReader.cs','TestTools.cs']:
  rel='src/FastExpressionCompiler/'+name
  data=subprocess.check_output(['git','show',ref+':'+rel],cwd=repo) if ref else (candidate/rel).read_bytes()
  if '--instrument' in sys.argv and name=='FastExpressionCompiler.cs' and version!='baseline':
   text=data.decode('utf-8-sig').replace('internal readonly struct HoistedTypeInfo\r\n        {','internal readonly struct HoistedTypeInfo\r\n        {\r\n            public static int ProbeCount;\r\n            public static Type ProbeType;')
   if 'public static int ProbeCount' not in text:
    text=text.replace('internal readonly struct HoistedTypeInfo\n        {','internal readonly struct HoistedTypeInfo\n        {\n            public static int ProbeCount;\n            public static Type ProbeType;')
   text=text.replace('BoxType = typeof(System.Runtime.CompilerServices.StrongBox<>).MakeGenericType(scratch);','++ProbeCount; ProbeType = type;\n                    BoxType = typeof(System.Runtime.CompilerServices.StrongBox<>).MakeGenericType(scratch);')
   data=text.encode('utf-8')
  (d/name).write_bytes(data)
 (d/'Library.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><AssemblyName>FrameRound2.'+version+'</AssemblyName></PropertyGroup></Project>')
(w/'Allocation.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><OutputType>Exe</OutputType><LangVersion>latest</LangVersion><Optimize>true</Optimize><EnableDefaultCompileItems>false</EnableDefaultCompileItems></PropertyGroup><ItemGroup><Compile Include="Allocation.cs"/>'+''.join('<ProjectReference Include="'+v+'/Library.csproj" Aliases="'+v+'"/>' for v in ['baseline','current','candidate'])+'</ItemGroup></Project>')
light=w/'candidate-light';light.mkdir(exist_ok=True)
for name in ['FastExpressionCompiler.cs','ImTools.cs','ILReader.cs','TestTools.cs']:
 (light/name).write_bytes((candidate/'src/FastExpressionCompiler'/name).read_bytes())
for name in ['Expression.cs','ExpressionVisitor.cs','FlatExpression.cs']:
 (light/name).write_bytes((candidate/'src/FastExpressionCompiler.LightExpression'/name).read_bytes())
(light/'Library.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net472;net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><Optimize>true</Optimize><DefineConstants>LIGHT_EXPRESSION</DefineConstants><AssemblyName>FrameRound2.light</AssemblyName></PropertyGroup></Project>')
print('Prepared isolated source snapshots only')

