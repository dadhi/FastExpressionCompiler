extern alias Before;
extern alias After;
using System;
using System.Diagnostics;
using System.Linq.Expressions;
using System.Collections.Generic;
using System.Text.Json;
using BC = Before::FastExpressionCompiler.ExpressionCompiler;
using AC = After::FastExpressionCompiler.ExpressionCompiler;
using BR = Before::FastExpressionCompiler.ImTools.SmallList<Before::FastExpressionCompiler.ExpressionCompiler.NestedLambdaInfo>;
using AR = After::FastExpressionCompiler.ImTools.SmallList<After::FastExpressionCompiler.ExpressionCompiler.NestedLambdaInfo>;
public static class Program {
 static int sink;
 static Expression Balanced(Expression x,int d)=>d==0?x:Expression.Add(Balanced(x,d-1),Balanced(x,d-1));
 static LambdaExpression Build(string name){
  var x=Expression.Parameter(typeof(int),"x");Expression body=x;
  if(name=="balanced256")body=Balanced(x,8);
  else if(name=="nested_blocks128")for(int i=0;i<128;++i)body=Expression.Block(body);
  else {var nodes=new List<Expression>();for(int i=0;i<32;++i){var v=Expression.Variable(typeof(int),"v"+i);nodes.Add(Expression.Block(new[]{v},Expression.Assign(v,x),Expression.Add(v,Expression.Constant(i))));}body=Expression.Block(nodes);}
  return Expression.Lambda<Func<int,int>>(body,x);
 }
 static void BeforeBatch(LambdaExpression tree,int count){for(int i=0;i<count;++i){
  var context=new BC.CompilerContext(BC.ClosureStatus.ToBeCollected,tree.Parameters,default);
  BR roots=default;
  var result=BC.TryCollectInfo(ref context,tree.Body,null,ref roots);
  if(result!=BC.Result.OK)throw new Exception("Before collection: "+result);
  sink=(int)result;
 }}
 static void AfterBatch(LambdaExpression tree,int count){for(int i=0;i<count;++i){
  var context=new AC.CompilerContext(AC.ClosureStatus.ToBeCollected,tree.Parameters,default);
  AR roots=default;
  var result=AC.TryCollectInfo(ref context,tree.Body,null,ref roots);
  if(result!=AC.Result.OK)throw new Exception("After collection: "+result);
  sink=(int)result;
 }}
 public static void Main(string[] args){
  Console.Error.WriteLine("ContextBytes before="+System.Runtime.CompilerServices.Unsafe.SizeOf<BC.CompilerContext>()+" fixed="+System.Runtime.CompilerServices.Unsafe.SizeOf<AC.CompilerContext>());
  int round=args.Length==0?0:int.Parse(args[0]);const int n=1024;
  foreach(var name in new[]{"balanced256","nested_blocks128","blocks32"}){
   var tree=Build(name);BeforeBatch(tree,2048);AfterBatch(tree,2048);
   for(int sample=0;sample<101;++sample){
    if(sample%8==0){GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();}
    for(int order=0;order<2;++order){
     bool before=(sample+round+order)%2==0;
     long bytes=GC.GetAllocatedBytesForCurrentThread(),t=Stopwatch.GetTimestamp();
     if(before)BeforeBatch(tree,n);else AfterBatch(tree,n);
     long elapsed=Stopwatch.GetTimestamp()-t;bytes=GC.GetAllocatedBytesForCurrentThread()-bytes;
     Console.WriteLine(JsonSerializer.Serialize(new {Runtime=Environment.Version.ToString(),Scenario=name,Phase="collect",Version=before?"before":"fixed",Round=round,SampleIndex=sample,Operations=n,NsPerOp=elapsed*1e9/Stopwatch.Frequency/n,BytesPerOp=bytes/(double)n}));
    }
   }
  }
  GC.KeepAlive(sink);
 }
}
