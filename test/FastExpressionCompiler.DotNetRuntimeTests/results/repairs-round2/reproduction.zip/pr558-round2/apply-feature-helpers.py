from pathlib import Path
p=Path(r'C:\Data\Git\Github\FastExpressionCompiler\src\FastExpressionCompiler\FastExpressionCompiler.cs')
s=p.read_bytes().decode('utf-8')
start=s.index('                    case ExpressionType.Quote:',s.index('        private static Result TryCollectInfo(ref'))
end=s.index('                    case ExpressionType.DebugInfo:',start)
old=s[start:end]
chunks=[]
names=['Quote','Dynamic','RuntimeVariables']
for i,name in enumerate(names):
 marker='                    case ExpressionType.'+name+':'
 a=old.index(marker)+len(marker)
 b=old.index('                    case ExpressionType.'+names[i+1]+':') if i+1<len(names) else len(old)
 body=old[a:b].strip('\r\n')
 lines=body.splitlines()
 if name=='Dynamic':
  assert lines[0].strip()=='{' and lines[-1].strip()=='}'
  lines=lines[1:-1];remove=16
 else:remove=12
 body='\n'.join(line[remove:] if line.startswith(' '*remove) else line for line in lines)+'\n'
 for result in ['r','Result.OK','Result.NotSupported_Quote','Result.NotSupported_HoistedVariable']:
  body=body.replace('RestoreScopeAndReturn(ref context, scopeDepth, '+result+')',result)
 assert 'scopeDepth' not in body
 chunks.append('        [MethodImpl(MethodImplOptions.NoInlining)]\n        private static Result TryCollect'+name+'Info(ref CompilerContext context, Expression expr,\n            NestedLambdaInfo nestedLambda, ref SmallList<NestedLambdaInfo> rootNestedLambdas)\n        {\n            var r = Result.OK;\n'+body+'        }\n\n')
dispatch=''.join('                    case ExpressionType.'+name+':\n                        return RestoreScopeAndReturn(ref context, scopeDepth,\n                            TryCollect'+name+'Info(ref context, expr, nestedLambda, ref rootNestedLambdas));\n' for name in names)
s=s[:start]+dispatch+s[end:]
marker='        private static Result TryCollectTerminalInfo('
s=s.replace(marker,'        // Keep feature-specific collection out of ordinary expressions\' first-use JIT.\n'+''.join(chunks)+marker,1)
p.write_bytes(s.encode('utf-8'))
