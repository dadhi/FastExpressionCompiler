from pathlib import Path
import subprocess,json,os,sys,statistics,re
from collections import defaultdict
w=Path(__file__).resolve().parent;d=w/'allocation-confirmation';d.mkdir(exist_ok=True)
if sys.argv[1]=='build':
 source=(w/'integrated/Program.cs').read_text(encoding='utf-8')
 old='''  int n=phase=="invoke"?10000:20;
  var sw=Stopwatch.StartNew();op(n);sw.Stop();
  n=(int)Math.Clamp(n*8.0/Math.Max(sw.Elapsed.TotalMilliseconds,0.01),phase=="invoke"?1000:10,phase=="invoke"?1000000:2000);'''
 assert old in source
 source=source.replace(old,'  int n=phase=="invoke"?100000:200;')
 source=source.replace('  foreach(string name in names) {','  Measure(version,flavor,"observer_empty","compile",round,n=>{});\n  foreach(string name in names) {')
 (d/'Program.cs').write_text(source,encoding='utf-8')
 for v in ['before','published','fixed']:
  for flavor in ['standard','light']:
   p=d/v/flavor;p.mkdir(parents=True,exist_ok=True)
   project='<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFrameworks>net8.0;net10.0</TargetFrameworks><LangVersion>latest</LangVersion><EnableDefaultCompileItems>false</EnableDefaultCompileItems><Optimize>true</Optimize>'+('<DefineConstants>LIGHT</DefineConstants>' if flavor=='light' else '')+'</PropertyGroup><ItemGroup><Compile Include="../../Program.cs"/><ProjectReference Include="../../../integrated/'+v+'/'+flavor+'/Library.csproj"/></ItemGroup></Project>'
   (p/'Harness.csproj').write_text(project,encoding='utf-8')
   with (p/'build.log').open('w',encoding='utf-8') as log:subprocess.run(['dotnet','build',str(p/'Harness.csproj'),'-c','Release','--nologo','-v:q','-m:1','-nodeReuse:false'],stdout=log,stderr=subprocess.STDOUT,check=True)
 print('Fixed-count confirmation builds complete',flush=True)
elif sys.argv[1]=='run':
 env=dict(os.environ,DOTNET_TieredCompilation='0',DOTNET_ReadyToRun='0')
 for runtime,flavor,names in [('net8.0','light',['add','balanced256','capture1','quote_capture','blocks32','blocks128']),('net8.0','standard',['balanced256','capture1','capture_array','capture_mutable_reference_array']),('net10.0','light',['blocks32'])]:
  for round,versions in enumerate([['before','published','fixed'],['fixed','published','before']]):
   for v in versions:
    tag=f'{runtime}-{flavor}-{round}-{v}'
    with (d/(tag+'.jsonl')).open('w',encoding='utf-8') as out,(d/(tag+'.log')).open('w',encoding='utf-8') as log:subprocess.run(['dotnet',str(d/v/flavor/'bin/Release'/runtime/'Harness.dll'),v,flavor,str(round),*names],env=env,stdout=out,stderr=log,check=True)
    text=(d/(tag+'.log')).read_text(encoding='utf-8')
    assert all(line.startswith('PASS ') or v=='before' and line.startswith('FAIL before') and 'quote_capture' in line for line in text.splitlines() if line.startswith(('PASS ','FAIL '))),text
    assert sum(line.startswith('PASS ') for line in text.splitlines())==len(names)-(v=='before' and 'quote_capture' in names),text
    print(tag,flush=True)
else:
 groups=defaultdict(list)
 for p in d.glob('net*.jsonl'):
  for line in p.read_text(encoding='utf-8').splitlines():
   x=json.loads(line);groups[tuple(x[k] for k in ['Runtime','Flavor','Scenario','Phase','Version'])].append(x)
 rows=[]
 for key,values in sorted(groups.items()):
  assert len(values)==14
  row=dict(zip(['runtime','flavor','scenario','phase','version'],key));row.update(ns=statistics.median(x['NsPerOp'] for x in values),bytes=statistics.median(x['BytesPerOp'] for x in values),samples=14,operations=sorted(set(x['Operations'] for x in values)));rows.append(row)
 index={tuple(x[k] for k in ['runtime','flavor','scenario','phase','version']):x for x in rows};comparisons=[]
 for key,row in index.items():
  if key[-1]!='fixed':continue
  for baseline in ['before','published']:
   other=index.get(key[:-1]+(baseline,))
   if other:comparisons.append(dict(runtime=key[0],flavor=key[1],scenario=key[2],phase=key[3],baseline=baseline,beforeBytes=other['bytes'],fixedBytes=row['bytes'],byteDelta=row['bytes']-other['bytes'],nsRatio=row['ns']/other['ns']))
 (d/'analysis.json').write_text(json.dumps(dict(reason='Investigate small fractional B/op residuals in adaptive-operation broad matrix. Same fixed operation counts for every source version; original observations preserved, no subtraction or replacement.',rows=rows,comparisons=comparisons),indent=2),encoding='utf-8')
 print('Compared',len(comparisons),'fixed-count groups')
 for r in comparisons:
  if r['phase'] in ['compile','compile_first']:print(r)
