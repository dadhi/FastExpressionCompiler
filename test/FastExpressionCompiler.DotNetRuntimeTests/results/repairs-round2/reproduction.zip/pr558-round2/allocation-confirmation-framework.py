from pathlib import Path
import subprocess,json,sys,statistics,hashlib
from collections import defaultdict
w=Path(__file__).resolve().parent;d=w/'allocation-confirmation-framework';d.mkdir(exist_ok=True)
if sys.argv[1]=='build':
 source=(w/'integrated-framework/Program.cs').read_text(encoding='utf-8')
 old='''  bool hotInvoke=phase=="invoke"||phase=="nested_invoke";int maxOperations=hotInvoke?1000000:phase=="activate"?100000:2000;
  int n=hotInvoke?10000:phase=="activate"?1000:20;
  var sw=Stopwatch.StartNew();op(n);sw.Stop();
  n=(int)Clamp(n*8.0/Math.Max(sw.Elapsed.TotalMilliseconds,0.01),hotInvoke?1000:10,maxOperations);'''
 assert old in source
 source=source.replace(old,'  int n=(phase=="invoke"||phase=="nested_invoke")?100000:200;').replace('  foreach(string name in names) {','  Measure(version,flavor,"observer_empty","compile",round,n=>{});\n  foreach(string name in names) {')
 (d/'Program.cs').write_text(source,encoding='utf-8')
 for v in ['before','published','fixed']:
  for flavor in ['standard','light']:
   p=d/v/flavor;p.mkdir(parents=True,exist_ok=True)
   (p/'Harness.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net472</TargetFramework><LangVersion>latest</LangVersion><EnableDefaultCompileItems>false</EnableDefaultCompileItems><Optimize>true</Optimize>'+('<DefineConstants>LIGHT</DefineConstants>' if flavor=='light' else '')+'</PropertyGroup><ItemGroup><Compile Include="../../Program.cs"/><ProjectReference Include="../../../integrated-framework/'+v+'/'+flavor+'/library/Library.csproj"/></ItemGroup></Project>',encoding='utf-8')
   with (p/'build.log').open('w',encoding='utf-8') as log:subprocess.run(['dotnet','build',str(p/'Harness.csproj'),'-c','Release','--nologo','-v:q','-m:1','-nodeReuse:false'],stdout=log,stderr=subprocess.STDOUT,check=True)
 (d/'manifest.json').write_text(json.dumps(dict(sourceManifest='../integrated-framework/manifest.json',harnessSha256=hashlib.sha256((d/'Program.cs').read_bytes()).hexdigest(),fixedCompileOperations=200),indent=2),encoding='utf-8')
 print('Framework confirmation builds complete',flush=True)
elif sys.argv[1]=='run':
 for flavor,names in [('standard',['blocks32','blocks128','nested_mixed32','nested_mixed128','capture_mutable','capture_reference','capture8','capture_try']),('light',['invoke_try_argument','try_finally'])]:
  for round,versions in enumerate([['before','published','fixed'],['fixed','published','before']]):
   for v in versions:
    tag=f'{flavor}-{round}-{v}'
    with (d/(tag+'.jsonl')).open('w',encoding='utf-8') as out,(d/(tag+'.log')).open('w',encoding='utf-8') as log:subprocess.run([str(d/v/flavor/'bin/Release/net472/Harness.exe'),v,flavor,str(round),*names],stdout=out,stderr=log,check=True)
    statuses=[json.loads(line) for line in (d/(tag+'.log')).read_text(encoding='utf-8').splitlines()]
    assert sorted(s['Scenario'] for s in statuses)==sorted(names) and all(s['Status']=='PASS' for s in statuses),statuses
    print(tag,flush=True)
else:
 groups=defaultdict(list)
 for p in d.glob('*.jsonl'):
  for line in p.read_text(encoding='utf-8').splitlines():
   x=json.loads(line);groups[tuple(x[k] for k in ['Runtime','Flavor','Scenario','Phase','Version'])].append(x)
 rows=[]
 for key,values in sorted(groups.items()):
  assert len(values)==14
  row=dict(zip(['runtime','flavor','scenario','phase','version'],key));row.update(ns=statistics.median(x['NsPerOp'] for x in values),bytes=statistics.median(x['BytesPerOp'] for x in values),samples=14,operations=sorted(set(x['Operations'] for x in values)));rows.append(row)
 index={tuple(x[k] for k in ['runtime','flavor','scenario','phase','version']):x for x in rows};comparisons=[]
 for key,row in index.items():
  if key[-1]!='fixed':continue
  for baseline in ['before','published']:
   other=index.get(key[:-1]+(baseline,))
   if other:comparisons.append(dict(runtime=key[0],flavor=key[1],scenario=key[2],phase=key[3],baseline=baseline,beforeBytes=other['bytes'],fixedBytes=row['bytes'],byteDelta=row['bytes']-other['bytes'],nsRatio=row['ns']/other['ns']))
 (d/'analysis.json').write_text(json.dumps(dict(reason='Equal-operation confirmation of fractional adaptive-operation B/op residuals. Original matrix unchanged. No allocation subtraction. Empty-observer samples included.',rows=rows,comparisons=comparisons),indent=2),encoding='utf-8')
 for r in comparisons:
  if r['phase']=='compile':print(r)
