from pathlib import Path
import subprocess,json,time,sys
w=Path(__file__).resolve().parent
codes=w.parent/'pr558-repair/validation-db640cba/codes.json'
print('Waiting for frozen-source validation before matrix builds/timing',flush=True)
start=time.monotonic()
while True:
 values=json.loads(codes.read_text(encoding='utf-8'))
 if any(v!=0 for v in values.values()):raise SystemExit('Validation failed: '+str(values))
 if values.get('imported-full')==0:break
 if time.monotonic()-start>1800:raise SystemExit('Validation wait exceeded30 minutes')
 time.sleep(2)
for script,mode in [('integrated-matrix.py','build'),('integrated-framework.py','build'),('integrated-matrix.py','run'),('integrated-matrix.py','analyze'),('integrated-framework.py','run'),('integrated-framework.py','analyze')]:
 print('START '+script+' '+mode,flush=True)
 subprocess.run([sys.executable,str(w/script),mode],check=True)
print('ALL MATRICES COMPLETE',flush=True)
