from pathlib import Path
from collections import defaultdict
import json,statistics,sys
d=Path(__file__).resolve().parent/(sys.argv[1] if len(sys.argv)>1 else 'trivial-binary-light');rows=[]
for runtime in ['net8.0','net10.0']:
 p=d/f'paired-{runtime}.jsonl'
 pairs=defaultdict(dict)
 for line in p.read_text(encoding='utf-8').splitlines():
  x=json.loads(line);pairs[(x['Scenario'],x['Phase'],x['SampleIndex'])][x['Version']]=x
 groups=defaultdict(list)
 for (case,phase,i),v in pairs.items():
  assert set(v)=={'before','fixed'}
  groups[(case,phase)].append(v)
 for (case,phase),values in groups.items():
  assert len(values)==101
  ratios=[v['fixed']['NsPerOp']/v['before']['NsPerOp'] for v in values]
  row=dict(runtime=runtime,scenario=case,phase=phase,ratio=statistics.median(ratios),beforeBytes=statistics.median(v['before']['BytesPerOp'] for v in values),fixedBytes=statistics.median(v['fixed']['BytesPerOp'] for v in values))
  rows.append(row)
  if phase in ['compile','compile_first']:print(row)
(d/'paired-analysis.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
