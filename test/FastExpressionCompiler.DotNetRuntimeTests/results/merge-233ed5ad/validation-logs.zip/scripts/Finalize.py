from pathlib import Path
import json,subprocess,hashlib,re,zipfile
w=Path(__file__).resolve().parent;r=Path(r'C:/Data/Git/Github/FastExpressionCompiler')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();assert head.startswith('7949ee5d')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r)
v=w/('validation-'+head[:8]);codes=json.loads((v/'codes.json').read_text());assert len(codes)==8 and all(x==0 for x in codes.values())
run=json.loads((v/'suite/fec/run.json').read_text());bs=run['batches'];assert len(bs)==21 and not run['crashes'];assert all(b['status']=='Complete' and b['attempt']==1 for b in bs)
totals={k:sum(int(b['counters'].get(k,0)) for b in bs) for k in ['total','executed','passed','failed','error','timeout','aborted']};assert totals['passed']==35064 and totals['failed']==0
native={}
for name in ['native-net10.0','native-net8.0','framework-run']:
 s=(v/(name+'.log')).read_text(encoding='utf-8');native[name]={'legacyPassed':int(re.search(r'//ALL\s+(\d+)\s+tests are passing',s)[1])}
 if name=='framework-run':native[name]['testXPassed']=int(re.search(r'//TestX:\s+(\d+)\s+tests are passing',s)[1])
meta=dict(upstreamMaster='233ed5adaa9d9ceea67d71e153d0d2457f2cce00',commentCommit='f089ff5b82d4f374d7953b9641b18d876eb7f08e',validatedCodeHead=head,codes=codes,imported=totals,batches=21,executedCrashes=0,exclusions=69,newExclusions=0,native=native,snapshot=json.loads((v/'snapshot.json').read_text()),performance='No fresh timings; earlier reports retain their original source IDs.')
d=r/'test/FastExpressionCompiler.DotNetRuntimeTests/results/merge-233ed5ad';assert not d.exists();d.mkdir()
(d/'validation.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
(d/'README.md').write_text(f"""# Follow-up merge of dadhi/master 233ed5ad

Source comment in `f089ff5b` distinguishes runtime System expression values from LightExpression AST nodes. The review reply points to `Parameter_and_concrete_expression_types_preserve_runtime_delegate_signatures`. No behavior changes were made for that comment.

Merge `7949ee5d` integrates upstream `233ed5ad`. Conflict resolution keeps #558's reference-comparison helper and method-aware shared arithmetic path, avoiding the standalone comparison emitter that this PR supersedes. Upstream's iterative conversion stripping, node-type predicate helper and editor setting are retained. #558's intrinsic-chain handling and regression tests remain in place.

Fresh validation at `{head}`: both production projects build across configured targets; full .NET 10 ARM64 / .NET 8 ARM64 suites pass ({native['native-net10.0']['legacyPassed']:,} / {native['native-net8.0']['legacyPassed']:,} legacy tests, plus registered regressions). Framework passes {native['framework-run']['testXPassed']:,} TestX and {native['framework-run']['legacyPassed']:,} legacy cases. All 21 imported batches pass on their first attempt: **35,064 executed passes, zero executed failures/crashes, the same 69 exclusions**. The deferred deep-tree modes remain deferred. The native tests include runtime-expression invocation and the intrinsic conversion regressions in both flavors. No fresh performance measurements are claimed for this merge; previous measurements remain source-specific.

`validation.json` records exact source/assembly hashes and counters. `validation-logs.zip` contains full build/test logs, batch results, and the validation scripts; `manifest.json` records all archive entry hashes. This evidence-only commit leaves validated code and tests unchanged.
""",encoding='utf-8')
(d/'.gitattributes').write_bytes(b'* -text\n')
files=[(x,x.relative_to(v).as_posix()) for x in v.rglob('*') if x.is_file()]
files += [(w/'validate.py','scripts/validate.py'),(w/'Finalize.py','scripts/Finalize.py'),(w.parent/'fec-round12/Run-Full.py','scripts/Run-Full.py')]
entries={}
with zipfile.ZipFile(d/'validation-logs.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p,name in files:
  data=p.read_bytes();z.writestr(name,data);entries[name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
with zipfile.ZipFile(d/'validation-logs.zip') as z:assert z.testzip() is None
(d/'manifest.json').write_text(json.dumps(dict(codeHead=head,sha256=hashlib.sha256((d/'validation-logs.zip').read_bytes()).hexdigest(),entries=entries),indent=2),encoding='utf-8')
print(json.dumps(meta,indent=2))
