using System;
using System.IO;
using System.Reflection;
public static class Program
{
    public static int Main(string[] args)
    {
        try
        {
            foreach (var component in new[] { "FastExpressionCompiler", "FastExpressionCompiler.LightExpression" })
                Assembly.LoadFrom(Path.Combine(args[0], component + ".dll"));
            foreach (var component in new[] { "FastExpressionCompiler", "FastExpressionCompiler.LightExpression" })
            {
                var assembly = Assembly.LoadFrom(Path.Combine(args[1], component + ".UnitTests.dll"));
                var type = assembly.GetType(component + ".UnitTests." + args[2], true);
                Console.WriteLine(component + ": " + type.GetMethod("Run").Invoke(Activator.CreateInstance(type), null) + " focused regression methods passed");
            }
            return 0;
        }
        catch (Exception e) { Console.WriteLine(e); return 1; }
    }
}
