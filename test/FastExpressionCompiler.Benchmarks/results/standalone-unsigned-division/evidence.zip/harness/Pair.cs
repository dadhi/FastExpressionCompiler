using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;

public static class Pair
{
    static object sink;
    static long checksum;
    public static void Main(string[] args)
    {
        var process = Process.GetCurrentProcess(); var mask = process.ProcessorAffinity.ToInt64();
        process.ProcessorAffinity = new IntPtr(mask & -mask);
        object[][] Load(string folder)
        {
            var context = new AssemblyLoadContext(folder, true);
            context.Resolving += (c, name) => File.Exists(Path.Combine(folder, name.Name + ".dll")) ? c.LoadFromAssemblyPath(Path.Combine(folder, name.Name + ".dll")) : null;
            return (object[][])context.LoadFromAssemblyPath(Path.Combine(folder, "Benchmark.dll")).GetType("Program").GetMethod("CreateBridgeCases").Invoke(null, null);
        }
        var before = Load(Path.GetFullPath(args[0])); var after = Load(Path.GetFullPath(args[1]));
        var rows = new List<object>();
        foreach (var old in before)
        {
            var newer = after.Single(r => (string)r[0] == (string)old[0] && (string)r[1] == (string)old[1]);
            var factories = new[] { (Func<Delegate>)old[2], (Func<Delegate>)newer[2] };
            var calls = new[] { ((Func<Delegate, Func<long>>)old[3])(factories[0]()), ((Func<Delegate, Func<long>>)newer[3])(factories[1]()) };
            for (var i = 0; i < 300; ++i) { sink = factories[0](); sink = factories[1](); }
            for (var i = 0; i < 100000; ++i) { checksum = calls[0](); checksum = calls[1](); }
            for (var mode = 0; mode < 2; ++mode)
            {
                var actions = mode == 0 ? factories.Select(f => new Action<int>(n => { for (var i = 0; i < n; ++i) sink = f(); })).ToArray()
                    : calls.Select(f => new Action<int>(n => { long total = 0; for (var i = 0; i < n; ++i) total += f(); checksum = total; })).ToArray();
                var max = mode == 1 && ((string)old[0]).Contains("list") ? 1 << 20 : 1 << 26;
                var n = 1;
                while (true)
                {
                    var t = Stopwatch.GetTimestamp(); actions[0](n); actions[1](n);
                    var elapsed = Stopwatch.GetElapsedTime(t).TotalMilliseconds;
                    if (elapsed >= 70 || n == max) break;
                    n = (int)Math.Min(max, Math.Max(n + 1, n * Math.Min(8, 80 / Math.Max(elapsed, .001))));
                }
                var ns = new[] { new double[9], new double[9] }; var bytes = new[] { new double[9], new double[9] };
                for (var sample = 0; sample < 9; ++sample)
                    foreach (var side in sample % 2 == 0 ? new[] { 0, 1 } : new[] { 1, 0 })
                    {
                        GC.Collect(); GC.WaitForPendingFinalizers(); GC.Collect();
                        var noGC = GC.TryStartNoGCRegion(256 * 1024 * 1024, true);
                        var allocated = GC.GetAllocatedBytesForCurrentThread(); var started = Stopwatch.GetTimestamp(); actions[side](n);
                        ns[side][sample] = Stopwatch.GetElapsedTime(started).TotalNanoseconds / n;
                        bytes[side][sample] = (GC.GetAllocatedBytesForCurrentThread() - allocated) / (double)n;
                        if (noGC) GC.EndNoGCRegion();
                    }
                rows.Add(new { Workload = old[0], Flavor = old[1], Phase = mode == 0 ? "compile" : "runtime", Count = n,
                    BeforeNs = ns[0].Order().ElementAt(4), AfterNs = ns[1].Order().ElementAt(4),
                    BeforeBytes = bytes[0].Order().ElementAt(4), AfterBytes = bytes[1].Order().ElementAt(4), BeforeSamples = ns[0], AfterSamples = ns[1] });
            }
        }
        Console.WriteLine(JsonSerializer.Serialize(rows));
    }
}
