from pathlib import Path
import subprocess, os, json, time
root = Path(__file__).resolve().parent
for framework in ['net8.0', 'net10.0']:
    for name in ['unsigned-division', 'byref-char', 'list-initializer']:
        start = time.monotonic()
        cmd = ['dotnet', str(root / 'pair/bin/Release' / framework / 'Pair.dll'),
               str(root / 'bench-master/bin/Release' / framework), str(root / ('bench-' + name) / 'bin/Release' / framework)]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=dict(os.environ, DOTNET_TieredCompilation='0'))
        (root / f'paired-{framework}-{name}.log').write_bytes(result.stdout)
        assert result.returncode == 0, result.stdout.decode(errors='replace')
        data = json.loads(result.stdout.decode().splitlines()[-1])
        (root / f'paired-{framework}-{name}.json').write_text(json.dumps(data, indent=2) + '\n')
        print(framework, name, f'{time.monotonic()-start:.1f}s', flush=True)
