from pathlib import Path
import json
import subprocess

root = Path(__file__).resolve().parent
cases = [('unsigned-division', 'UnsignedDivisionRegressionTests'), ('byref-char', 'ByRefCharacterWidthRegressionTests'), ('list-initializer', 'NonVoidListInitializerRegressionTests')]
results = []
for name, fixture in cases:
    for framework in ['net8.0', 'net10.0', 'net472']:
        testdir = root / name / 'test'
        runner = ('FastExpressionCompiler.TestsRunner.Net472' if framework == 'net472' else 'FastExpressionCompiler.TestsRunner')
        folder = testdir / runner / 'bin/Release' / framework
        probe = root / 'probe/bin/Release' / framework / ('Probe.exe' if framework == 'net472' else 'Probe.dll')
        cmd = ([str(probe)] if framework == 'net472' else ['dotnet', str(probe)]) + [str(folder), str(folder), fixture]
        r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (root / f'{name}-focused-{framework}.log').write_bytes(r.stdout)
        results.append({'revision': name, 'framework': framework, 'exit': r.returncode})
        assert r.returncode == 0, (name, framework, r.stdout.decode(errors='replace'))
    # Same regression assembly, explicitly load the unmodified master compiler first.
    framework = 'net8.0'
    folder = root / name / 'test/FastExpressionCompiler.TestsRunner/bin/Release' / framework
    libfolder = root / 'bench-master/bin/Release' / framework
    probe = root / 'probe/bin/Release' / framework / 'Probe.dll'
    r = subprocess.run(['dotnet', str(probe), str(libfolder), str(folder), fixture], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (root / f'{name}-master-reproduction.log').write_bytes(r.stdout)
    results.append({'revision': 'master', 'regression': name, 'framework': framework, 'exit': r.returncode})
    assert r.returncode != 0, name + ' did not reproduce on master'
(root / 'focused-results.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results))
