from pathlib import Path
import subprocess
import json
import time
import os

root = Path(__file__).resolve().parent
names = ['master', 'unsigned-division', 'byref-char', 'list-initializer']
for framework in ['net8.0', 'net10.0']:
    for round in range(2):
        for name in (names if round == 0 else list(reversed(names))):
            exe = root / ('bench-' + name) / 'bin/Release' / framework / 'Benchmark.dll'
            command = ['dotnet', str(exe)] + (['--nonvoid'] if name == 'list-initializer' else [])
            started = time.monotonic()
            env = dict(os.environ, DOTNET_TieredCompilation='0')
            run = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env)
            (root / f'perf-{framework}-{round}-{name}.log').write_bytes(run.stdout)
            assert run.returncode == 0, run.stdout.decode(errors='replace')
            result = json.loads(run.stdout.decode().splitlines()[-1])
            (root / f'perf-{framework}-{round}-{name}.json').write_text(json.dumps(result, indent=2) + '\n')
            print(framework, round, name, f'{time.monotonic()-started:.1f}s', flush=True)
