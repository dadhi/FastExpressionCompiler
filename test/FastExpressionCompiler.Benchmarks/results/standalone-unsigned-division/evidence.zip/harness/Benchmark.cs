using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.InteropServices;
using System.Text.Json;
using FastExpressionCompiler;
using FastExpressionCompiler.LightExpression;
using S = System.Linq.Expressions.Expression;

public delegate char ReadChar(ref char value);
public delegate char WriteChar(ref char value, char replacement);

public static class Program
{
    public static object[][] CreateBridgeCases()
    {
        var all = new List<object[]>();
        foreach (var light in new[] { false, true })
        {
            void Add<T>(string name, System.Linq.Expressions.Expression<T> tree, Func<T, Func<long>> runtime) where T : Delegate
            {
                FastExpressionCompiler.LightExpression.Expression<T> le = null;
                if (light && tree.Body is System.Linq.Expressions.ListInitExpression init)
                    le = FastExpressionCompiler.LightExpression.Expression.Lambda<T>(FastExpressionCompiler.LightExpression.Expression.ListInit(
                        FastExpressionCompiler.LightExpression.Expression.New(init.Type), init.Initializers.Select(i =>
                            FastExpressionCompiler.LightExpression.Expression.ElementInit(i.AddMethod, i.Arguments.Select(a => a.ToLightExpression()).ToArray())).ToArray()));
                else if (light) le = tree.ToLightExpression();
                Func<Delegate> factory = light ? () => le.CompileFast(true) : () => tree.CompileFast(true);
                all.Add(new object[] { name, light ? "Light" : "Standard", factory, new Func<Delegate, Func<long>>(f => runtime((T)f)) });
            }
            var u = S.Parameter(typeof(uint)); var v = S.Parameter(typeof(uint));
            Add("uint_divide", S.Lambda<Func<uint, uint, uint>>(S.Divide(u, v), u, v), f => () => f(100003, 7));
            var x = S.Parameter(typeof(ulong)); var y = S.Parameter(typeof(ulong));
            Add("ulong_divide", S.Lambda<Func<ulong, ulong, ulong>>(S.Divide(x, y), x, y), f => () => (long)f(100000000003, 7));
            var a = S.Parameter(typeof(int)); var b = S.Parameter(typeof(int));
            Add("signed_divide_control", S.Lambda<Func<int, int, int>>(S.Divide(a, b), a, b), f => () => f(100003, 7));
            var c = S.Parameter(typeof(char).MakeByRefType()); var next = S.Parameter(typeof(char));
            Add("ref_char_read", S.Lambda<ReadChar>(c, c), f => { char value = 'A'; return () => f(ref value); });
            Add("ref_char_write", S.Lambda<WriteChar>(S.Assign(c, next), c, next), f => { char value = 'A'; return () => f(ref value, 'B'); });
            Add("void_add_list_control", S.Lambda<Func<List<int>>>(S.ListInit(S.New(typeof(List<int>)), S.Constant(1), S.Constant(2), S.Constant(3))), f => () => f().Count);
        }
        return all.ToArray();
    }
    static object sink;
    static long sum;
    sealed record Row(string Workload, string Flavor, double CompileNs, double CompileBytes, double RuntimeNs, double RuntimeBytes,
        double[] CompileSamples, double[] RuntimeSamples);
    public static void Main(string[] args)
    {
        var process = Process.GetCurrentProcess();
        var available = process.ProcessorAffinity.ToInt64();
        process.ProcessorAffinity = new IntPtr(available & -available);
        var rows = new List<Row>();
        foreach (var light in new[] { false, true })
        {
            var flavor = light ? "Light" : "Standard";
            void Run<T>(string name, System.Linq.Expressions.Expression<T> tree, Func<T, Func<long>> invoke) where T : Delegate
            {
                FastExpressionCompiler.LightExpression.Expression<T> le = null;
                if (light && tree.Body is System.Linq.Expressions.ListInitExpression init)
                {
                    var elements = init.Initializers.Select(i => FastExpressionCompiler.LightExpression.Expression.ElementInit(i.AddMethod,
                        i.Arguments.Select(a => a.ToLightExpression()).ToArray())).ToArray();
                    le = FastExpressionCompiler.LightExpression.Expression.Lambda<T>(
                        FastExpressionCompiler.LightExpression.Expression.ListInit(
                            FastExpressionCompiler.LightExpression.Expression.New(init.Type), elements));
                }
                else if (light) le = tree.ToLightExpression();
                Func<T> factory = light ? () => le.CompileFast(true) : () => tree.CompileFast(true);
                var compiled = factory() ?? throw new Exception("Strict compilation failed: " + name);
                var action = invoke(compiled);
                for (var i = 0; i < 100; ++i) sink = factory();
                for (var i = 0; i < 100000; ++i) sum = action();
                var compile = Measure(n => { for (var i = 0; i < n; ++i) sink = factory(); });
                var runtime = Measure(n => { long x = 0; for (var i = 0; i < n; ++i) x += action(); sum = x; }, name.Contains("list") || name.Contains("nonvoid") ? 1 << 20 : 1 << 26);
                rows.Add(new Row(name, flavor, compile.Ns, compile.Bytes, runtime.Ns, runtime.Bytes, compile.Samples, runtime.Samples));
            }
            var u = S.Parameter(typeof(uint)); var v = S.Parameter(typeof(uint));
            Run("uint_divide", S.Lambda<Func<uint, uint, uint>>(S.Divide(u, v), u, v), f => () => f(100003, 7));
            var x = S.Parameter(typeof(ulong)); var y = S.Parameter(typeof(ulong));
            Run("ulong_divide", S.Lambda<Func<ulong, ulong, ulong>>(S.Divide(x, y), x, y), f => () => (long)f(100000000003, 7));
            var a = S.Parameter(typeof(int)); var b = S.Parameter(typeof(int));
            Run("signed_divide_control", S.Lambda<Func<int, int, int>>(S.Divide(a, b), a, b), f => () => f(100003, 7));
            var c = S.Parameter(typeof(char).MakeByRefType()); var next = S.Parameter(typeof(char));
            Run("ref_char_read", S.Lambda<ReadChar>(c, c), f => { char value = 'A'; return () => f(ref value); });
            Run("ref_char_write", S.Lambda<WriteChar>(S.Assign(c, next), c, next), f => { char value = 'A'; return () => f(ref value, 'B'); });
            var list = S.ListInit(S.New(typeof(List<int>)), S.Constant(1), S.Constant(2), S.Constant(3));
            Run("void_add_list_control", S.Lambda<Func<List<int>>>(list), f => () => f().Count);
            if (args.Contains("--nonvoid"))
            {
                var set = S.ListInit(S.New(typeof(HashSet<int>)), S.Constant(1), S.Constant(2), S.Constant(2));
                Run("nonvoid_add_fixed_only", S.Lambda<Func<HashSet<int>>>(set), f => () => f().Count);
            }
        }
        Console.WriteLine(JsonSerializer.Serialize(new { Runtime = RuntimeInformation.FrameworkDescription,
            Arch = RuntimeInformation.ProcessArchitecture.ToString(), Results = rows }));
    }
    sealed record Measurement(double Ns, double Bytes, double[] Samples);
    static Measurement Measure(Action<int> run, int maximum = 1 << 26)
    {
        GC.Collect(); GC.WaitForPendingFinalizers(); GC.Collect();
        var count = 1;
        while (true)
        {
            var started = Stopwatch.GetTimestamp(); run(count);
            var elapsed = Stopwatch.GetElapsedTime(started).TotalMilliseconds;
            if (elapsed >= 30 || count == maximum) break;
            count = (int)Math.Min(maximum, Math.Max(count + 1, count * Math.Min(8, 40 / Math.Max(elapsed, .001))));
        }
        var times = new double[7]; var bytes = new double[7];
        for (var sample = 0; sample < times.Length; ++sample)
        {
            GC.Collect(); GC.WaitForPendingFinalizers(); GC.Collect();
            var noGC = GC.TryStartNoGCRegion(256 * 1024 * 1024, true);
            var before = GC.GetAllocatedBytesForCurrentThread();
            var started = Stopwatch.GetTimestamp(); run(count);
            times[sample] = Stopwatch.GetElapsedTime(started).TotalNanoseconds / count;
            bytes[sample] = (GC.GetAllocatedBytesForCurrentThread() - before) / (double)count;
            if (noGC) GC.EndNoGCRegion();
        }
        return new Measurement(times.Order().ElementAt(3), bytes.Order().ElementAt(3), times);
    }
}
